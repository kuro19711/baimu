using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

class InstallerHost : Form {
    readonly string root=AppDomain.CurrentDomain.BaseDirectory;
    readonly TextBox destination=new TextBox(), data=new TextBox();
    readonly Label status=new Label();
    readonly ProgressBar progress=new ProgressBar();
    readonly Button install=new Button(), close=new Button();
    bool busy;
    [STAThread] static void Main() {
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        try { Application.Run(new InstallerHost()); }
        catch(Exception e) { MessageBox.Show(e.Message,"百慕安装",MessageBoxButtons.OK,MessageBoxIcon.Error); }
    }
    ProcessStartInfo Command(string arguments) {
        string python=Path.Combine(root,"payload","runtime","python.exe");
        if(!File.Exists(python)||!File.Exists(Path.Combine(root,"installer.py")))throw new IOException("请完整解压安装包后再运行安装百慕.exe。");
        return new ProcessStartInfo(python,"-B -X utf8 \""+Path.Combine(root,"installer.py")+"\" "+arguments) {
            UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=root,
            RedirectStandardOutput=true,RedirectStandardError=true,
            StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8
        };
    }
    static string Quote(string value) {
        if(String.IsNullOrWhiteSpace(value)||value.Contains("\"")||value.Contains("\n"))throw new ArgumentException("请输入有效的本地文件夹路径。");
        return "\""+Path.GetFullPath(value).TrimEnd('\\')+"\"";
    }
    InstallerHost() {
        Text="安装百慕";ClientSize=new Size(640,330);StartPosition=FormStartPosition.CenterScreen;
        FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;
        Font=new Font("Microsoft YaHei UI",10);BackColor=Color.FromArgb(245,247,250);
        var title=new Label{Text="百慕 · 本地剪辑工作台",Location=new Point(24,20),Size=new Size(590,35),Font=new Font(Font.FontFamily,16,FontStyle.Bold)};
        Controls.Add(title);
        Controls.Add(new Label{Text="程序目录",Location=new Point(24,77),AutoSize=true});
        destination.SetBounds(120,72,490,30);Controls.Add(destination);
        Controls.Add(new Label{Text="工程目录",Location=new Point(24,123),AutoSize=true});
        data.SetBounds(120,118,490,30);Controls.Add(data);
        status.SetBounds(24,165,590,50);status.Text="升级前保存工作并退出百慕，等待后台任务结束。已有工程会保留。";Controls.Add(status);
        progress.SetBounds(24,220,590,18);Controls.Add(progress);
        install.Text="安装 / 更新";install.SetBounds(390,265,115,36);install.Click+=async(s,e)=>await Install();Controls.Add(install);
        close.Text="关闭";close.SetBounds(519,265,95,36);close.Click+=(s,e)=>Close();Controls.Add(close);
        FormClosing+=(s,e)=>{if(busy)e.Cancel=true;};
        using(var p=Process.Start(Command("--paths-json"))) {
            string output=p.StandardOutput.ReadToEnd(),error=p.StandardError.ReadToEnd();p.WaitForExit();
            if(p.ExitCode!=0)throw new IOException(error);
            var paths=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(output);
            destination.Text=Convert.ToString(paths["destination"]);data.Text=Convert.ToString(paths["data"]);
        }
    }
    async Task Install() {
        string args;
        try { args="--cli --progress-json --destination "+Quote(destination.Text)+" --data "+Quote(data.Text); }
        catch(Exception e){MessageBox.Show(e.Message,Text);return;}
        busy=true;install.Enabled=close.Enabled=destination.Enabled=data.Enabled=false;
        try {
            await Task.Run(()=>{
                using(var p=new Process{StartInfo=Command(args)}) {
                    p.Start();var errors=p.StandardError.ReadToEndAsync();string line;
                    while((line=p.StandardOutput.ReadLine())!=null) {
                        var item=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(line);
                        if(item.ContainsKey("progress")) {
                            string message=Convert.ToString(item["message"]);int value=Math.Max(0,Math.Min(100,Convert.ToInt32(item["progress"])));
                            BeginInvoke(new Action(()=>{status.Text=message;progress.Value=value;}));
                        }
                    }
                    p.WaitForExit();if(p.ExitCode!=0)throw new IOException(errors.Result);
                }
            });
            status.Text="安装完成，可从桌面启动九州百慕。";progress.Value=100;
        } catch(Exception e) { status.Text="安装未完成";MessageBox.Show(e.Message,Text,MessageBoxButtons.OK,MessageBoxIcon.Error); }
        finally { busy=false;install.Enabled=close.Enabled=destination.Enabled=data.Enabled=true; }
    }
}
