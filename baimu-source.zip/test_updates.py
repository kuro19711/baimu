"""Daily GitHub check: cross-process persistence, failures, force and notices."""
from datetime import datetime, timedelta
import json
import multiprocessing
from pathlib import Path
import sys
import tempfile
import time
import unittest
import threading
import urllib.request
import urllib.error
from http.server import ThreadingHTTPServer
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parent/'app'))
from studio.updates import UpdateChecker, REPOSITORY, github_latest, version_key


def release(tag='v0.6.1'):
    return dict(tag=tag, release_url=REPOSITORY+'/releases/tag/'+tag)


def concurrent_check(root, event, queue):
    def fetch():
        with (Path(root)/'network-calls.txt').open('a') as log:
            log.write('request\n')
        time.sleep(.2)
        return release()
    event.wait()
    queue.put(UpdateChecker(root, fetch).check('0.6.0', claim_notice=True))


class UpdateTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='baimu-updates-test-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.calls = []
        self.day = datetime(2026, 11, 3, 23, 59)

    def checker(self):
        def fetch():
            self.calls.append(1)
            return release()
        return UpdateChecker(self.root, fetch, lambda: self.day)

    def test_daily_cache_restart_midnight_and_installed_version(self):
        first = self.checker().check('0.6.0', claim_notice=True)
        self.assertTrue(first['notify'])
        second = self.checker().check('0.6.0', claim_notice=True)
        self.assertTrue(second['cached'])
        self.assertFalse(second['notify'])
        self.assertFalse(self.checker().check('0.6.1')['update_available'])
        self.assertEqual(len(self.calls), 1)
        self.day += timedelta(minutes=2)
        self.assertFalse(self.checker().check('0.6.0')['cached'])
        self.assertEqual(len(self.calls), 2)

    def test_failure_deduplicated_and_force_retries(self):
        def failed():
            self.calls.append(1)
            raise OSError('offline')
        c = UpdateChecker(self.root, failed, lambda: self.day)
        self.assertEqual(c.check('0.6.0')['status'], 'error')
        self.assertTrue(c.check('0.6.0')['cached'])
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(self.checker().check('0.6.0', force=True)['status'], 'ok')
        self.assertEqual(len(self.calls), 2)

    def test_previous_success_not_presented_as_fresh_after_failure(self):
        self.checker().check('0.6.0')
        self.day += timedelta(days=1)
        c = UpdateChecker(self.root, lambda: (_ for _ in ()).throw(OSError()), lambda: self.day)
        result = c.check('0.6.0', claim_notice=True)
        self.assertEqual(result['latest']['tag'], 'v0.6.1')
        self.assertEqual(result['status'], 'error')
        self.assertFalse(result['notify'])
        self.assertFalse(result['update_available'])

    def test_interrupted_attempt_not_repeated_until_force(self):
        self.checker().check('0.6.0')
        path = self.root/'state.json'
        state = json.loads(path.read_text())
        state['status'] = 'interrupted'
        path.write_text(json.dumps(state))
        self.assertEqual(self.checker().check('0.6.0')['status'], 'interrupted')
        self.assertEqual(len(self.calls), 1)
        self.checker().check('0.6.0', force=True)
        self.assertEqual(len(self.calls), 2)

    def test_corrupt_cache_and_unwritable_location_do_not_block(self):
        (self.root/'state.json').write_text('{')
        self.assertEqual(self.checker().check('0.6.0')['status'], 'ok')
        blocked = self.root/'not-a-directory'
        blocked.write_text('file')
        self.assertEqual(UpdateChecker(blocked).check('0.6.0')['status'], 'unavailable')

    def test_cross_process_one_network_request_and_one_notice(self):
        context = multiprocessing.get_context('spawn')
        event, queue = context.Event(), context.Queue()
        children = [context.Process(target=concurrent_check, args=(str(self.root), event, queue)) for _ in range(4)]
        for child in children: child.start()
        event.set()
        try:
            results = [queue.get(timeout=20) for _ in children]
            for child in children:
                child.join(10)
                self.assertEqual(child.exitcode, 0)
            self.assertEqual((self.root/'network-calls.txt').read_text().splitlines(), ['request'])
            self.assertEqual(sum(r['notify'] for r in results), 1)
            self.assertEqual(sum(not r['cached'] for r in results), 1)
        finally:
            for child in children:
                if child.is_alive(): child.terminate(); child.join()
            queue.close()

    def test_release_version_order_and_public_redirect(self):
        self.assertLess(version_key('v0.6.0-shared.3'), version_key('0.6.0'))
        self.assertLess(version_key('0.6.1'), version_key('v0.6.10'))
        self.assertEqual(version_key('0.6.1+build'), version_key('v0.6.1'))
        with patch('studio.updates.urllib.request.urlopen') as open_url:
            open_url.return_value.__enter__.return_value.geturl.return_value = release()['release_url']
            self.assertEqual(github_latest(), release())
            request = open_url.call_args.args[0]
            self.assertEqual(request.full_url, REPOSITORY+'/releases/latest')
            self.assertEqual(request.method, 'HEAD')
            self.assertNotIn('X-studio-token', request.headers)
            open_url.return_value.__enter__.return_value.geturl.return_value = 'https://example.com/releases/tag/v99.0.0'
            with self.assertRaises(ValueError): github_latest()

    def test_authenticated_api_and_no_project_mutation(self):
        import app
        self.enterContext(patch.object(app, 'VERSION', '0.6.0'))
        from studio.store import Store
        store = Store(self.root/'data')
        project = store.create('Updates isolated fixture')
        before = store.path(project['id']).read_bytes()
        with patch.object(app, 'UpdateChecker', return_value=self.checker()):
            server = ThreadingHTTPServer(('127.0.0.1', 0), app.create_handler(store, None, 'test-update-token'))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        def request(path, body=None, authenticated=True):
            headers = {'Content-Type': 'application/json'}
            if authenticated: headers['X-Studio-Token'] = 'test-update-token'
            req = urllib.request.Request(f'http://127.0.0.1:{server.server_port}'+path,
                data=None if body is None else json.dumps(body).encode(), headers=headers)
            with urllib.request.urlopen(req, timeout=10) as response:
                return json.load(response)
        try:
            with self.assertRaises(urllib.error.HTTPError) as denied:
                request('/api/updates/check', {}, False)
            self.assertEqual(denied.exception.code, 403)
            result = request('/api/updates/check', {'claim_notice': True})
            self.assertTrue(result['notify'])
            self.assertTrue(request('/api/updates')['cached'])
            with self.assertRaises(urllib.error.HTTPError) as invalid:
                request('/api/updates/check', {'force': 'false'})
            self.assertEqual(invalid.exception.code, 400)
            request('/api/updates/check', {'force': True})
            self.assertEqual(len(self.calls), 2)
            self.assertEqual(store.path(project['id']).read_bytes(), before)
        finally:
            server.shutdown(); server.server_close(); thread.join()


if __name__ == '__main__':
    unittest.main()
