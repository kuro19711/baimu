"""Offline per-user installer. Copies only a verified, state-free payload."""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request
import uuid
import time

APP_ID = 'muxu-studio-local'
ROOT = Path(__file__).resolve().parent


def read_manifest(package):
    value = json.loads((package/'manifest.json').read_text(encoding='utf-8'))
    if value.get('app_id') != APP_ID or not isinstance(value.get('files'), list):
        raise ValueError('安装包清单无效，请重新获取完整安装包。')
    files = value['files']
    seen = set()
    for entry in files:
        name = entry.get('path', '')
        path = PurePosixPath(name)
        if (not name or '\\' in name or ':' in name or path.is_absolute()
                or '..' in path.parts or name != path.as_posix() or name in seen
                or path.parts[0] not in ('app', 'runtime', 'engine', 'models', 'licenses', 'bundle.json')):
            raise ValueError('安装包包含无效路径。')
        if any(part.rstrip(' .') != part or re.search(r'[<>"|?*\x00-\x1f]', part)
               or re.fullmatch(r'(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?', part, re.I)
               for part in path.parts) or name.casefold() in seen:
            raise ValueError('安装包包含 Windows 无效路径或重复文件。')
        if not isinstance(entry.get('size'), int) or entry['size'] < 0:
            raise ValueError('安装包文件长度无效。')
        if not re.fullmatch('[a-f0-9]{64}', entry.get('sha256', '')):
            raise ValueError('安装包校验值无效。')
        seen.add(name.casefold())
    required = {'bundle.json', 'app/app.py', 'app/desktop_launcher.py', 'runtime/python.exe',
                'runtime/pythonw.exe', 'app/bin/ffmpeg.exe', 'app/bin/ffprobe.exe'}
    if not required <= seen:
        raise ValueError('安装包缺少运行组件。')
    if not re.fullmatch('[a-zA-Z0-9]{1,30}', value.get('build_id', '')):
        raise ValueError('安装包版本编号无效。')
    return value


def file_hash(path):
    with open(long_path(path), 'rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def long_path(path):
    value = str(path.resolve())
    if os.name != 'nt' or value.startswith('\\\\?\\'): return value
    return '\\\\?\\UNC\\'+value[2:] if value.startswith('\\\\') else '\\\\?\\'+value


def ensure_regular(root, relative):
    target = root.joinpath(*PurePosixPath(relative).parts)
    if root.resolve() not in target.resolve().parents:
        raise ValueError('安装文件路径越界。')
    for part in (target, *target.parents):
        if part == root.parent:
            break
        inspected = Path(long_path(part))
        if inspected.is_symlink() or (hasattr(inspected, 'is_junction') and inspected.is_junction()):
            raise ValueError('安装文件夹包含链接，请解压到普通本地文件夹。')
    if not Path(long_path(target)).is_file():
        raise ValueError('安装包缺少文件：'+relative)
    return target


def verify(root, manifest, progress=lambda *args: None):
    for index, entry in enumerate(manifest['files']):
        source = ensure_regular(root, entry['path'])
        if Path(long_path(source)).stat().st_size != entry['size'] or file_hash(source) != entry['sha256']:
            raise ValueError('文件校验失败，请重新下载并解压：'+entry['path'])
        progress('正在校验安装文件', 30*(index+1)/len(manifest['files']))


def active_instance(data):
    try:
        session = json.loads((data/'session.json').read_text(encoding='utf-8'))
        url = urllib.parse.urlsplit(session['url'])
        if (url.scheme != 'http' or url.hostname != '127.0.0.1' or not url.port
                or url.username or url.password or url.path not in ('', '/') or url.query):
            return False
        token = urllib.parse.parse_qs(url.fragment).get('token', [''])[0]
        if not token:
            return False
        request = urllib.request.Request('http://'+url.netloc+'/api/bootstrap', headers={'X-Studio-Token': token})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request, timeout=2) as response:
            return Path(json.load(response).get('data_dir', '')).resolve() == data.resolve()
    except (OSError, ValueError, KeyError, TypeError):
        return False


@contextlib.contextmanager
def install_lock(destination, name='install.lock'):
    import msvcrt
    destination.mkdir(parents=True, exist_ok=True)
    with (destination/name).open('a+b') as handle:
        handle.seek(0, 2)
        if not handle.tell():
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        try:
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            raise ValueError('另一个安装或启动程序正在运行，请等待它完成。')
        try:
            yield
        finally:
            handle.seek(0); msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)


def install(package=ROOT, destination=None, data=None, shortcut=True, progress=lambda *args: None):
    if os.name != 'nt' or sys.maxsize <= 2**32:
        raise ValueError('此安装包仅适用于 Windows 10/11 的 Intel/AMD 64 位电脑。')
    local = os.environ.get('LOCALAPPDATA')
    if not local and (destination is None or data is None):
        raise ValueError('无法读取当前 Windows 用户目录。')
    destination = Path(destination or Path(local)/'MuXuStudio').resolve()
    data = Path(data or Path(local)/'MuXuStudio'/'data').resolve()
    manifest = read_manifest(package)
    if data == destination/'versions' or destination/'versions' in data.parents:
        raise ValueError('工程数据不能放在程序版本目录里。')
    if package.resolve() == destination or package.resolve() in destination.parents:
        raise ValueError('请勿把软件安装到安装包内部。')
    with install_lock(destination), install_lock(data, 'launcher.lock'):
        if active_instance(data):
            raise ValueError('九州百慕独立版仍在运行。请先保存修改，等队列完成，再用「关闭九州百慕」退出后台，然后重新安装。')
        verify(package/'payload', manifest, progress)
        versions = destination/'versions'
        versions.mkdir(exist_ok=True)
        if versions.is_symlink() or (hasattr(versions, 'is_junction') and versions.is_junction()):
            raise ValueError('程序版本目录不能是目录链接。')
        target = versions/manifest['build_id']
        if target.exists():
            verify(target, manifest, progress)
        else:
            required = sum(item['size'] for item in manifest['files']) + 512*1024*1024
            if shutil.disk_usage(destination).free < required:
                raise ValueError('磁盘剩余空间不足，请至少预留 2 GB 后再安装。')
            stage = Path(tempfile.mkdtemp(prefix='.install-', dir=versions)).resolve()
            try:
                for index, entry in enumerate(manifest['files']):
                    source = ensure_regular(package/'payload', entry['path'])
                    output = stage.joinpath(*PurePosixPath(entry['path']).parts)
                    Path(long_path(output.parent)).mkdir(parents=True, exist_ok=True)
                    # CopyFile2 needs an explicit extended path on some Windows systems.
                    try:
                        shutil.copy2(long_path(source), long_path(output))
                    except OSError as exc:
                        raise ValueError('无法复制文件：'+entry['path']+'。'+str(exc)) from exc
                    if file_hash(output) != entry['sha256']:
                        raise ValueError('复制后的文件校验失败：'+entry['path'])
                    progress('正在安装运行组件', 30+65*(index+1)/len(manifest['files']))
                # A new version is published atomically; never overwrite an old version.
                # Windows may briefly hold a freshly copied DLL open.
                # Keep the old version intact and retry publishing this stage.
                for attempt in range(12):
                    try:
                        stage.rename(target)
                        break
                    except PermissionError:
                        if target.exists() or attempt == 11:
                            raise
                        time.sleep(min(.25 * (attempt + 1), 1.0))
            except Exception:
                if stage.exists() and stage.parent == versions.resolve() and stage.name.startswith('.install-'):
                    shutil.rmtree(long_path(stage))
                raise
        if shortcut:
            progress('正在创建桌面和开始菜单图标', 97)
            powershell = Path(os.environ.get('SystemRoot', 'C:/Windows'))/'System32/WindowsPowerShell/v1.0/powershell.exe'
            result = subprocess.run([str(powershell), '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
                '-File', str(target/'app/create_bundle_shortcuts.ps1'), '-InstallRoot', str(destination),
                '-VersionRoot', str(target)], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
            if result.returncode:
                raise ValueError('软件文件已安装，但桌面图标创建失败。请联系维护者，或从安装目录启动。')
        record = {'app_id': APP_ID, 'version': manifest['version'], 'build_id': manifest['build_id'],
                  'program': str(target), 'data': str(data)}
        temporary = destination/('installation.'+uuid.uuid4().hex+'.tmp')
        temporary.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temporary, destination/'installation.json')
        progress('安装完成', 100)
        return record


def launch(record):
    root = Path(record['program'])
    subprocess.Popen([str(root/'runtime/pythonw.exe'), '-B', '-X', 'utf8', str(root/'app/desktop_launcher.py')],
                     cwd=root/'app', creationflags=subprocess.CREATE_NO_WINDOW)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cli', action='store_true')
    parser.add_argument('--destination', type=Path)
    parser.add_argument('--data', type=Path)
    parser.add_argument('--no-shortcut', action='store_true')
    parser.add_argument('--progress-json', action='store_true')
    args = parser.parse_args()
    if args.cli:
        def progress(message, number):
            if args.progress_json:
                print(json.dumps({'message': message, 'progress': round(number, 1)}, ensure_ascii=False), flush=True)
        try:
            print(json.dumps(install(destination=args.destination, data=args.data, shortcut=not args.no_shortcut, progress=progress), ensure_ascii=False), flush=True)
        except Exception as exc:
            print(str(exc), file=sys.stderr)
            raise SystemExit(1)
    else:
        raise SystemExit('请双击安装九州百慕.exe，或使用 --cli 执行受控安装。')
