import importlib.util,json,os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent/'app'))
from studio import runtime
from studio.updates import UpdateChecker
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
client=load('brand_client',Path.home()/'.codex/skills/baimu/scripts/baimu_client.py')
installer=load('brand_installer',Path(__file__).resolve().parent/'installer.py')
class Paths(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        self.enterContext(patch.dict(os.environ,{'LOCALAPPDATA':str(self.root),'BAIMU_DATA_DIR':'','MUXU_DATA_DIR':''}))
    def record(self,name,data=None):
        root=self.root/name;root.mkdir(exist_ok=True)
        value=dict(app_id='muxu-studio-local' if name=='MuXuStudio' else 'baimu-studio-local',program=str(root/'versions/build'),data=str(data or root/'data'))
        (root/'installation.json').write_text(json.dumps(value),encoding='utf-8');return root
    def test_new_defaults(self):
        with patch.object(runtime,'is_bundle',return_value=True):self.assertEqual(runtime.data_directory(),self.root/'Baimu/data')
        self.assertEqual(installer.default_paths(),(self.root/'Baimu',self.root/'Baimu/data'))
        self.assertEqual(client.installation_root(str(self.root)),self.root/'Baimu')
        self.assertEqual(UpdateChecker().root,self.root/'Baimu/updates')
    def test_existing_legacy_custom_data_is_preserved(self):
        data=self.root/'custom-data';self.record('MuXuStudio',data)
        with patch.object(runtime,'is_bundle',return_value=True):self.assertEqual(runtime.data_directory(),data)
        self.assertEqual(installer.default_paths(),(self.root/'Baimu',data))
        self.assertEqual(client.installation_root(str(self.root)),self.root/'MuXuStudio')
    def test_new_record_wins_without_deleting_legacy(self):
        old=self.record('MuXuStudio');new=self.record('Baimu')
        with patch.object(runtime,'is_bundle',return_value=True):self.assertEqual(runtime.data_directory(),new/'data')
        self.assertEqual(client.installation_info()['program'],str(new/'versions/build'))
        self.assertTrue((old/'installation.json').exists())
    def test_data_only_installation(self):
        data=self.root/'MuXuStudio/data';data.mkdir(parents=True)
        with patch.object(runtime,'is_bundle',return_value=True):self.assertEqual(runtime.data_directory(),data)
        self.assertEqual(installer.default_paths()[1],data)
    def test_environment_precedence(self):
        with patch.dict(os.environ,{'BAIMU_DATA_DIR':str(self.root/'new'),'MUXU_DATA_DIR':str(self.root/'old')}):self.assertEqual(runtime.data_directory(),self.root/'new')
        with patch.dict(os.environ,{'MUXU_DATA_DIR':str(self.root/'old')}):self.assertEqual(runtime.data_directory(),self.root/'old')
    def test_cache_reuses_legacy_lock(self):
        legacy=self.root/'MuXuStudio/updates';legacy.mkdir(parents=True)
        (self.root/'Baimu').mkdir()
        self.assertEqual(UpdateChecker().root,legacy)
    def test_session_discovery_on_both_names(self):
        for name in ('MuXuStudio','Baimu'):
            root=self.record(name);data=root/'data';data.mkdir()
            (data/'session.json').write_text(json.dumps({'url':'http://127.0.0.1:12345/#token=test-only'}))
            origin,token,found=client.discover()
            self.assertEqual((origin,token,found),('http://127.0.0.1:12345','test-only',data))
    def test_unrelated_record_is_rejected(self):
        p=self.record('Baimu')/'installation.json';p.write_text(json.dumps({'app_id':'other'}))
        with self.assertRaises(ValueError):installer.default_paths()
if __name__=='__main__':unittest.main()
