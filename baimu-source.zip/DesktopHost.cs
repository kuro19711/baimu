using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.Script.Serialization;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

// Small Windows host. The editor backend stays loopback-only and owns all media work.
class DesktopHost : Form {
    readonly WebView2 view = new WebView2();
    readonly Label status = new Label();
    readonly string appRoot;
    bool ready, closing, approved;
    string origin, entryUrl;
    readonly string smokePath;
    readonly StudioWindows windows;
    readonly string folderId;

    static string DataDirectory() {
        string value=Environment.GetEnvironmentVariable("BAIMU_DATA_DIR") ?? Environment.GetEnvironmentVariable("MUXU_DATA_DIR");
        if(!String.IsNullOrEmpty(value))return Path.GetFullPath(value);
        string local=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        foreach(string name in new[]{"Baimu","MuXuStudio"}) {
            string record=Path.Combine(local,name,"installation.json");
            if(File.Exists(record)) {
                var settings=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(record));
                if(settings.ContainsKey("data"))return Path.GetFullPath(Convert.ToString(settings["data"]));
            }
        }
        foreach(string name in new[]{"Baimu","MuXuStudio"}) {
            string candidate=Path.Combine(local,name,"data");
            if(Directory.Exists(candidate))return candidate;
        }
        return Path.Combine(local,"Baimu","data");
    }

    [STAThread] static int Main(string[] args) {
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        string bundleRoot=Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"..",".."));
        string bundleFile=Path.Combine(bundleRoot,"bundle.json");
        if(String.IsNullOrEmpty(Environment.GetEnvironmentVariable("BAIMU_DATA_DIR"))&&String.IsNullOrEmpty(Environment.GetEnvironmentVariable("MUXU_DATA_DIR"))&&File.Exists(bundleFile)){
            var bundle=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(bundleFile));
            string location=bundle.ContainsKey("data_location")?Convert.ToString(bundle["data_location"]):"";
            if(location.Length>0&&!location.StartsWith("%"))Environment.SetEnvironmentVariable("BAIMU_DATA_DIR",Path.GetFullPath(Path.Combine(bundleRoot,location)));
        }
        string profile=DataDirectory();
        Environment.SetEnvironmentVariable("BAIMU_DATA_DIR",profile);
        string identity;
        using(var hash=SHA256.Create())identity=BitConverter.ToString(hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(profile.ToLowerInvariant()))).Replace("-","").Substring(0,24);
        string initial=Array.IndexOf(args,"--native")>=0?"native":"";for(int i=0;i+1<args.Length;i++)if(args[i]=="--workspace"&&Regex.IsMatch(args[i+1],"^[a-f0-9]{32}$"))initial=args[i+1];
        bool owns;
        using(var mutex=new Mutex(true,"Local\\BaimuLibrary-"+identity,out owns)) {
            if(!owns){
                try{using(var pipe=new NamedPipeClientStream(".","BaimuLibrary-"+identity,PipeDirection.Out)){pipe.Connect(2000);using(var writer=new StreamWriter(pipe)){writer.WriteLine(initial.Length==0?"home":initial);writer.Flush();}}}catch(IOException){}
                return 0;
            }
            using(var context=new StudioWindows(args,"BaimuLibrary-"+identity)){context.Open(initial);Application.Run(context);}
        }
        return 0;
    }
    [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern IntPtr FindWindow(string cls,string name);
    [DllImport("user32.dll")]static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")]static extern bool ShowWindow(IntPtr hwnd,int cmd);

    internal DesktopHost(string[] args,StudioWindows windows,string folderId) {
        this.windows=windows;this.folderId=folderId;
        appRoot=Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,".."));
        for(int i=0;i+1<args.Length;i++)if(args[i]=="--smoke-output")smokePath=Path.GetFullPath(args[i+1]);
        Text=folderId.StartsWith("native")?"九州百慕 · 剪映工程":folderId.Length==0?"九州百慕 · 剧本总览":"九州百慕 · 工作页";MinimumSize=new Size(1060,700);Size=new Size(1500,950);
        StartPosition=FormStartPosition.CenterScreen;BackColor=Color.FromArgb(17,19,24);
        AutoScaleMode=AutoScaleMode.Dpi;
        string icon=Path.Combine(appRoot,"assets","studio.ico");if(File.Exists(icon))Icon=new Icon(icon);
        status.Text="正在启动本地工作台…\n工程与视频保存在这台电脑";status.ForeColor=Color.FromArgb(212,242,154);
        status.Font=new Font("Microsoft YaHei UI",13);status.TextAlign=ContentAlignment.MiddleCenter;status.Dock=DockStyle.Fill;
        view.Dock=DockStyle.Fill;view.DefaultBackgroundColor=BackColor;Controls.Add(view);Controls.Add(status);status.BringToFront();
        if(windows.IsTest){Opacity=0;ShowInTaskbar=false;}
        Shown+=async(s,e)=>await StartEditor();FormClosing+=OnClosing;
    }
    async Task StartEditor() {
        try {
            // Check runtime before starting a backend, so a failed host leaves no new service.
            CoreWebView2Environment.GetAvailableBrowserVersionString();
            string data=DataDirectory();
            var env=await CoreWebView2Environment.CreateAsync(null,Path.Combine(data,"desktop-webview"));
            await view.EnsureCoreWebView2Async(env);
            var settings=view.CoreWebView2.Settings;settings.AreDevToolsEnabled=false;
            settings.AreDefaultContextMenusEnabled=false;settings.IsStatusBarEnabled=false;
            settings.IsZoomControlEnabled=false;
            string runtime=Path.Combine(appRoot,"..","runtime","python.exe");
            if(!File.Exists(runtime))throw new IOException("内置 Python 环境缺失，请重新安装完整安装包。");
            var info=new ProcessStartInfo(runtime,"-B -X utf8 \""+Path.Combine(appRoot,"desktop_launcher.py")+"\" --print-session --no-browser");
            info.UseShellExecute=false;info.CreateNoWindow=true;info.WorkingDirectory=appRoot;
            info.RedirectStandardOutput=true;info.RedirectStandardError=true;
            info.StandardOutputEncoding=System.Text.Encoding.UTF8;info.StandardErrorEncoding=System.Text.Encoding.UTF8;
            string url=await Task.Run(()=>{
                using(var process=Process.Start(info)) {
                    var read=process.StandardOutput.ReadToEndAsync();var err=process.StandardError.ReadToEndAsync();
                    if(!process.WaitForExit(60000)){process.Kill();throw new IOException("启动超时，请查看本机启动日志。");}
                    Task.WaitAll(read,err);
                    if(process.ExitCode!=0)throw new IOException(read.Result.Trim()+"\n"+err.Result.Trim());
                    return read.Result.Trim();
                }
            });
            Uri address;
            if(!Uri.TryCreate(url,UriKind.Absolute,out address)||address.Scheme!="http"||address.Host!="127.0.0.1"||!String.IsNullOrEmpty(address.UserInfo)||address.AbsolutePath!="/"||!String.IsNullOrEmpty(address.Query)||!address.Fragment.StartsWith("#token="))throw new IOException("本机启动地址校验失败。");
            origin=address.GetLeftPart(UriPartial.Authority);
            entryUrl=folderId=="native"?origin+"/?native=1"+address.Fragment:
                folderId.StartsWith("native-")?origin+"/?native=1&project="+folderId.Substring(7)+address.Fragment:
                folderId.Length==0?url:origin+"/?workspace="+folderId+address.Fragment;
            view.CoreWebView2.NavigationStarting+=(s,e)=>{Uri target;if(!Uri.TryCreate(e.Uri,UriKind.Absolute,out target)||target.GetLeftPart(UriPartial.Authority)!=origin)e.Cancel=true;};
            view.CoreWebView2.NewWindowRequested+=(s,e)=>{e.Handled=true;};
            view.CoreWebView2.DownloadStarting+=(s,e)=>{
                using(var picker=new SaveFileDialog()) {
                    picker.FileName=Path.GetFileName(e.ResultFilePath);picker.Title="保存到这台电脑";
                    if(picker.ShowDialog(this)==DialogResult.OK){e.ResultFilePath=picker.FileName;e.Handled=true;}else e.Cancel=true;
                }
            };
            view.CoreWebView2.NavigationCompleted+=async(s,e)=>{
                if(!e.IsSuccess){status.Text="工作台加载失败，请重新打开应用。";return;}
                ready=true;status.Visible=false;
                if(smokePath!=null){if(folderId.StartsWith("native"))await NativeSmoke();else await Smoke();}
            };
            view.CoreWebView2.Navigate(entryUrl);
        }catch(Exception error){
            if(smokePath!=null){File.WriteAllText(smokePath,"ERROR: "+error.ToString());approved=true;Close();return;}
            status.Text="启动未完成";
            if(error is WebView2RuntimeNotFoundException)MessageBox.Show(this,"这台电脑缺少 Microsoft Edge WebView2 Runtime。\n请运行程序目录 desktop 中的“安装桌面运行环境.exe”后再打开。首次安装该组件需要联网。\n官方地址：https://developer.microsoft.com/microsoft-edge/webview2/","缺少桌面运行环境",MessageBoxButtons.OK,MessageBoxIcon.Information);
            else MessageBox.Show(this,error.Message,"启动提示",MessageBoxButtons.OK,MessageBoxIcon.Error);
        }
    }
    async void OnClosing(object sender,FormClosingEventArgs e) {
        if(approved||!ready)return;e.Cancel=true;if(closing)return;closing=true;
        try {
            await view.CoreWebView2.ExecuteScriptAsync("typeof window.studioPrepareClose==='function' ? window.studioPrepareClose().then(ok=>window.chrome.webview.postMessage({type:'close-ready',ok})) : window.chrome.webview.postMessage({type:'close-ready',ok:false})");
            // Completion arrives through a web message after asynchronous saving.
            await Task.Delay(20000);
            if(closing&&!approved){closing=false;MessageBox.Show(this,"保存仍未完成，请检查本机服务状态后再关闭。","等待保存");}
        }catch(Exception){closing=false;MessageBox.Show(this,"无法确认修改已保存，请先在工作台保存或备份草稿。","暂未关闭");}
    }
    protected override void OnLoad(EventArgs e) {
        base.OnLoad(e);
        view.CoreWebView2InitializationCompleted+=(s,args)=>{
            if(args.IsSuccess)view.CoreWebView2.WebMessageReceived+=(sender,message)=>{
                if(message.Source==null||origin==null||!message.Source.StartsWith(origin+"/",StringComparison.Ordinal))return;
                var data=new JavaScriptSerializer().Deserialize<System.Collections.Generic.Dictionary<string,object>>(message.WebMessageAsJson);
                if(data.ContainsKey("type")&&Equals(data["type"],"open-home")){windows.Open("");return;}
                if(data.ContainsKey("type")&&Equals(data["type"],"pick-media-file")){
                    string requestId=data.ContainsKey("request_id")?Convert.ToString(data["request_id"]):"";
                    if(!Regex.IsMatch(requestId,"^relink-[0-9]{1,10}$"))return;
                    using(var picker=new OpenFileDialog()){
                        picker.Title="重连原素材（保留原裁剪）";picker.CheckFileExists=true;picker.Multiselect=false;
                        picker.Filter="媒体文件|*.mp4;*.mov;*.mkv;*.avi;*.webm;*.m4v;*.wav;*.mp3;*.m4a;*.aac;*.flac;*.ogg|所有文件|*.*";
                        string selected=picker.ShowDialog(this)==DialogResult.OK?picker.FileName:null;
                        view.CoreWebView2.PostWebMessageAsJson(new JavaScriptSerializer().Serialize(new {type="media-file-picked",request_id=requestId,path=selected}));
                    }
                    return;
                }
                if(data.ContainsKey("type")&&Equals(data["type"],"open-native")){
                    string id=data.ContainsKey("project_id")?Convert.ToString(data["project_id"]):"";
                    windows.Open(Regex.IsMatch(id,"^[a-f0-9]{32}$")?"native-"+id:"native");return;
                }
                if(data.ContainsKey("type")&&Equals(data["type"],"open-workspace")){
                    string id=data.ContainsKey("folder_id")?Convert.ToString(data["folder_id"]):"";
                    if(Regex.IsMatch(id,"^[a-f0-9]{32}$"))windows.Open(id);return;
                }
                if(data.ContainsKey("type")&&Equals(data["type"],"workspace-title")&&folderId.Length>0){
                    string name=data.ContainsKey("title")?Convert.ToString(data["title"]):"";
                    Text="九州百慕 · "+(folderId.StartsWith("native")?"剪映工程 · ":"")+(name.Length>150?name.Substring(0,150):name);return;
                }
                if(data.ContainsKey("type")&&Equals(data["type"],"open-data")){
                    string folder=DataDirectory();
                    Process.Start(new ProcessStartInfo("explorer.exe","\""+Path.GetFullPath(folder)+"\""){UseShellExecute=true});return;
                }
                if(data.ContainsKey("type")&&Equals(data["type"],"open-browser")){
                    Process.Start(new ProcessStartInfo(entryUrl){UseShellExecute=true});return;
                }
                if(!closing)return;
                if(!data.ContainsKey("type")||!Equals(data["type"],"close-ready"))return;
                if(data.ContainsKey("ok")&&Equals(data["ok"],true)){approved=true;Close();}
                else {closing=false;MessageBox.Show(this,"仍有未保存修改或导入任务，请处理完成后再关闭。\n已排队的渲染任务会在后台继续。","暂未关闭",MessageBoxButtons.OK,MessageBoxIcon.Information);}
            };
        };
    }
    async Task NativeSmoke(){
        try{
            string ready="false";
            for(int i=0;i<120&&ready!="true";i++){
                await Task.Delay(250);ready=await view.CoreWebView2.ExecuteScriptAsync("document.querySelectorAll('#native-list .native-row').length>0");
            }
            if(ready!="true")throw new IOException("Native draft list did not load");
            await view.CoreWebView2.ExecuteScriptAsync("[...document.querySelectorAll('#native-list .native-row')].find(x=>x.textContent.includes('BAIMU_TEST_NATIVE_20261015'))?.click()");
            ready="false";
            for(int i=0;i<240&&ready!="true";i++){
                await Task.Delay(250);ready=await view.CoreWebView2.ExecuteScriptAsync("document.querySelectorAll('[data-text-id]').length===2");
            }
            if(ready!="true")throw new IOException("Native test draft did not load");
            string proof=await view.CoreWebView2.ExecuteScriptAsync("JSON.stringify({native:true,drafts:document.querySelectorAll('#native-list .native-row').length,texts:[...document.querySelectorAll('[data-text-id]')].map(x=>x.value),title:document.title,bodyMode:document.body.classList.contains('native-mode')})");
            File.WriteAllText(smokePath,new JavaScriptSerializer().Deserialize<string>(proof));
            using(var file=File.Create(Path.ChangeExtension(smokePath,".png")))await view.CoreWebView2.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png,file);
        }catch(Exception error){File.WriteAllText(smokePath,"ERROR: "+error.ToString());}
        approved=true;Close();
    }
    async Task Smoke() {
        try {
            await Task.Delay(2000);
            await view.CoreWebView2.ExecuteScriptAsync("(async()=>{try{const f=await api('/api/library');if(f.length<2)throw Error('Need two fixture folders');window.__nativeFolders=f.slice(0,2).map(x=>x.id)}catch(e){window.__nativeError=e.message}})()");
            string json="null";
            for(int i=0;i<40&&json=="null";i++){await Task.Delay(150);json=await view.CoreWebView2.ExecuteScriptAsync("window.__nativeFolders??null");}
            string[] ids=new JavaScriptSerializer().Deserialize<string[]>(json);
            if(ids==null||ids.Length!=2)throw new IOException("Native library test could not find two folders.");
            windows.Open(ids[0]);windows.Open(ids[1]);await Task.Delay(3000);
            DesktopHost a=windows.Get(ids[0]),b=windows.Get(ids[1]);
            string first=await a.view.CoreWebView2.ExecuteScriptAsync("JSON.stringify({folder:studioLibrary.current()?.id,project:p?.id,rows:[...document.querySelectorAll('#projects [data-project]')].map(x=>x.dataset.project)})");
            string second=await b.view.CoreWebView2.ExecuteScriptAsync("JSON.stringify({folder:studioLibrary.current()?.id,project:p?.id,rows:[...document.querySelectorAll('#projects [data-project]')].map(x=>x.dataset.project)})");
            int count=windows.Count;windows.Open(ids[0]);if(windows.Count!=count)throw new IOException("Duplicate folder opened a second window.");
            File.WriteAllText(smokePath,new JavaScriptSerializer().Serialize(new {home=true,windows=count,first=first,second=second,reused=true}));
            using(var file=File.Create(Path.ChangeExtension(smokePath,".png")))await view.CoreWebView2.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png,file);
            a.approved=true;b.approved=true;a.Close();b.Close();
        }catch(Exception error){File.WriteAllText(smokePath,"ERROR: "+error.ToString());approved=true;}
        approved=true;
        Close();
    }
}

// One UI process and one backend, with one independent editor state per drama.
class StudioWindows : ApplicationContext {
    readonly Dictionary<string,DesktopHost> forms=new Dictionary<string,DesktopHost>();
    readonly string[] args;
    readonly Control dispatcher=new Control();
    volatile bool stopped;
    NamedPipeServerStream server;
    internal bool IsTest {get;private set;}
    internal int Count {get{return forms.Count;}}
    internal DesktopHost Get(string id){return forms[id];}
    internal StudioWindows(string[] args,string pipeName){
        this.args=args;IsTest=Array.IndexOf(args,"--smoke-output")>=0;
        IntPtr unused=dispatcher.Handle;
        Task.Run(async()=>{
            while(!stopped){
                try{
                    var security=new PipeSecurity();security.SetAccessRuleProtection(true,false);
                    security.AddAccessRule(new PipeAccessRule(WindowsIdentity.GetCurrent().User,PipeAccessRights.FullControl,AccessControlType.Allow));
                    using(var pipe=new NamedPipeServerStream(pipeName,PipeDirection.In,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous,4096,4096,security)){
                        server=pipe;await pipe.WaitForConnectionAsync();
                        string command=await new StreamReader(pipe).ReadLineAsync();
                        if(command=="home"||command=="native"||command!=null&&Regex.IsMatch(command,"^(?:[a-f0-9]{32}|native-[a-f0-9]{32})$"))dispatcher.BeginInvoke(new Action(()=>Open(command=="home"?"":command)));
                    }
                }catch(Exception){if(stopped)break;}
                await Task.Delay(300);
            }
        });
    }
    internal void Open(string id){
        DesktopHost form;
        if(forms.TryGetValue(id,out form)){
            if(!IsTest){if(form.WindowState==FormWindowState.Minimized)form.WindowState=FormWindowState.Normal;form.Show();form.Activate();}return;
        }
        string[] childArgs=(id.Length==0||id=="native")?args:new string[0];
        form=new DesktopHost(childArgs,this,id);forms[id]=form;
        form.FormClosed+=(s,e)=>{forms.Remove(id);if(forms.Count==0)ExitThread();};
        form.Show();
    }
    protected override void ExitThreadCore(){stopped=true;if(server!=null)server.Dispose();dispatcher.Dispose();base.ExitThreadCore();}
}
