"""Review configuration contracts using isolated records and real HTTP routes."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'app'))
import app
from studio.store import Store, write_json
from studio.review_rules import ReviewRules, parse_review

spec = importlib.util.spec_from_file_location('review_client', Path.home()/'.codex/skills/baimu/scripts/baimu_client.py')
client = importlib.util.module_from_spec(spec)
spec.loader.exec_module(client)


class ReviewTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix='baimu-review-test-')
        self.addCleanup(temporary.cleanup)
        self.box = Path(temporary.name)
        self.store = Store(self.box/'data')
        self.project = self.store.create('Review fixture')
        self.pid = self.project['id']
        self.service = ReviewRules(self.store)

    def update_docs(self, review=None, repair=None):
        docs = self.service.documents()
        return self.service.save_documents(dict(revision=docs['revision'], review=review or docs['review'], repair=repair or docs['repair']))

    def scope(self, selected):
        context = self.service.context(self.pid)
        return self.service.update_scope(self.pid, dict(rules_revision=context['rules_revision'], scope_revision=context['scope_revision'], selected_ids=selected))

    def test_parser_ignores_code_and_nested_headings(self):
        intro, rows = parse_review('# intro\n## 字幕 ##\n细则\n### 子项\n```md\n## not-a-rule\n```\n~~~~\n## ignored\n~~~~\n## 音频\n声音')
        self.assertEqual([r['title'] for r in rows], ['字幕', '音频'])
        self.assertIn('### 子项', rows[0]['body'])
        self.assertIn('## not-a-rule', rows[0]['body'])
        self.assertEqual(intro, '# intro')
        for bad in ('# no categories', '## 同名\nA\n## 同名\nB', '## 内容\n```\n## 假标题'):
            with self.assertRaises(ValueError): parse_review(bad)

    def test_defaults_read_only_and_no_timeline_mutation(self):
        before = self.store.path(self.pid).read_bytes()
        context = self.service.context(self.pid)
        self.assertGreaterEqual(len(context['selected_ids']), 8)
        self.assertEqual(context['needs_clarification'], [])
        self.assertFalse(self.service.root.exists())
        self.scope([])
        self.update_docs(review=context['review_skill']+'\n## 新规则\n新要求')
        self.assertEqual(before, self.store.path(self.pid).read_bytes())
        self.assertEqual(context['project_revision'], self.service.context(self.pid)['project_revision'])

    def test_scope_isolated_persistent_empty_scope_and_new_rules(self):
        original = self.service.context(self.pid)
        self.scope([])
        self.assertEqual(ReviewRules(self.store).context(self.pid)['selected_ids'], [])
        other = self.store.create('Other')
        self.assertEqual(len(self.service.context(other['id'])['selected_ids']), len(original['selected_ids']))
        self.update_docs(review=original['review_skill']+'\n## 手写的新要求\n需要询问含义')
        context = self.service.context(self.pid)
        self.assertEqual([s['title'] for s in context['sections'] if s['selected']], ['手写的新要求'])
        self.assertEqual([s['title'] for s in context['needs_clarification']], ['手写的新要求'])
        self.assertNotIn('## 字幕', context['selected_review_markdown'])

    def test_confirmed_interpretation_expires_on_body_change(self):
        self.update_docs(review='# 总则\n## 新规则\n初稿')
        c = self.service.context(self.pid)
        rule = c['sections'][0]
        args = dict(rules_revision=c['rules_revision'], scope_revision=c['scope_revision'], id=rule['id'], interpretation='与用户确认的意思', confirmed_by_user=True)
        self.service.update_scope(self.pid, args, confirm=True)
        c = self.service.context(self.pid)
        self.assertFalse(c['sections'][0]['needs_clarification'])
        other = self.store.create('Second episode')
        self.assertFalse(self.service.context(other['id'])['sections'][0]['needs_clarification'])
        self.scope([])
        self.update_docs(review='# 总则\n## 新规则\n修改细则')
        c = self.service.context(self.pid)
        self.assertEqual(c['selected_ids'], [])
        self.assertTrue(c['sections'][0]['needs_clarification'])
        self.assertFalse(c['sections'][0]['interpretation_current'])
        self.assertEqual(c['sections'][0]['interpretation'], '与用户确认的意思')
        self.assertEqual(c['sections'][0]['id'], rule['id'])

    def test_common_and_repair_changes_also_require_clarification(self):
        c = self.service.context(self.pid)
        self.update_docs(review=c['review_skill'].replace('# 短剧审核要求', '# 短剧审核要求\n更改通用规则'), repair=c['repair_skill']+'\n追加返工要求')
        ids = {s['id'] for s in self.service.context(self.pid)['needs_clarification']}
        self.assertEqual(ids, {'review-intro', 'repair'})

    def test_conflicts_invalid_scope_and_confirmation_do_not_overwrite(self):
        old = self.service.context(self.pid)
        self.scope([])
        with self.assertRaises(ValueError):
            self.service.update_scope(self.pid, dict(rules_revision=old['rules_revision'], scope_revision=old['scope_revision'], selected_ids=old['selected_ids']))
        c = self.service.context(self.pid)
        for selected in (['unknown'], [1], [old['selected_ids'][0]]*2):
            with self.assertRaises(ValueError):
                self.service.update_scope(self.pid, dict(rules_revision=c['rules_revision'], scope_revision=c['scope_revision'], selected_ids=selected))
        with self.assertRaises(ValueError):
            self.service.update_scope(self.pid, dict(rules_revision=c['rules_revision'], scope_revision=c['scope_revision'], id='repair', interpretation='自己猜测'), confirm=True)
        docs = self.service.documents()
        self.update_docs(repair=docs['repair']+'\n新的方式')
        with self.assertRaises(ValueError): self.service.save_documents(docs)
        self.assertEqual(self.service.context(self.pid)['selected_ids'], [])
        self.assertTrue((self.service.root/'history'/(docs['revision']+'.json')).exists())

    def test_corrupt_records_preserved_and_bad_project_ids_rejected(self):
        self.service.root.mkdir()
        path = self.service.root/'skills.json'
        path.write_text('{not valid', encoding='utf-8')
        with self.assertRaises(ValueError): self.service.context(self.pid)
        self.assertEqual(path.read_text(encoding='utf-8'), '{not valid')
        with self.assertRaises(ValueError): self.service.context('../outside')

    def test_real_http_and_skill_client(self):
        jobs = type('IdleJobs', (), {'items': {}})()
        server = ThreadingHTTPServer(('127.0.0.1', 0), app.create_handler(self.store, jobs, 'test-private-token'))
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self.addCleanup(lambda: (server.shutdown(), server.server_close()))
        with patch.object(client, 'discover', return_value=(f'http://127.0.0.1:{server.server_port}', 'test-private-token', self.store.root)):
            command = lambda *args: client.execute(client.build_parser().parse_args(list(args)))
            docs = command('review-skills')
            self.assertIn('## 字幕', docs['review'])
            c = command('review-context', self.pid)
            self.assertEqual(c['project_id'], self.pid)
            conn = client.Client()
            saved = conn.request('POST', '/api/review-skills', dict(revision=docs['revision'], review=docs['review']+'\n## API 新规则\n细则', repair=docs['repair']))
            c = command('review-context', self.pid)
            new = next(s for s in c['sections'] if s['title']=='API 新规则')
            note = self.box/'interpretation.txt';note.write_text('这是人工已经确认的解释', encoding='utf-8')
            args = ('confirm-review-rule', self.pid, '--rules-revision', saved['revision'], '--scope-revision', c['scope_revision'], '--rule-id', new['id'], '--interpretation-file', str(note))
            with self.assertRaises(client.BaimuError): command(*args)
            confirmed = command(*args, '--confirmed-by-user')
            self.assertFalse(next(s for s in confirmed['sections'] if s['id']==new['id'])['needs_clarification'])
            conn._token = 'invalid'
            with self.assertRaises(client.BaimuError): conn.request('GET', '/api/review-skills')


if __name__ == '__main__': unittest.main()
