"""Close this data directory's authenticated idle backend after GUI exit."""
import json,re,subprocess,urllib.error,urllib.parse,urllib.request
from studio.runtime import data_directory

def main():
    hosts=subprocess.run(['tasklist','/FO','CSV','/NH','/FI','IMAGENAME eq 九州百慕.exe'],
        capture_output=True,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    if re.search(rb'(?m)^"[^"]+","[0-9]+"',hosts.stdout):
        print('请先正常保存并关闭百慕所有窗口，再关闭后台。');return 1
    path=data_directory()/'session.json'
    if not path.is_file():print('百慕后台未运行。');return 0
    session=json.loads(path.read_text(encoding='utf-8'));url=urllib.parse.urlsplit(session['url'])
    if (url.scheme!='http' or url.hostname!='127.0.0.1' or not url.port or url.username or url.password
            or url.path not in ('','/') or url.query):raise ValueError('本机会话地址无效')
    token=urllib.parse.parse_qs(url.fragment)['token'][0]
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    headers={'X-Studio-Token':token,'Content-Type':'application/json'}
    request=urllib.request.Request('http://'+url.netloc+'/api/bootstrap',headers=headers)
    try:
        with opener.open(request,timeout=5) as response:boot=json.load(response)
    except urllib.error.URLError:
        print('百慕后台未运行。');return 0
    from pathlib import Path
    if Path(boot.get('data_dir','')).resolve()!=data_directory().resolve():raise ValueError('后台工程目录不匹配')
    request=urllib.request.Request('http://'+url.netloc+'/api/shutdown',data=b'{}',headers=headers)
    with opener.open(request,timeout=5) as response:result=json.load(response)
    print(result.get('message','百慕后台已关闭。'));return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as error:print('未关闭后台：'+str(error));raise SystemExit(1)
