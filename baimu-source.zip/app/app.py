"""Loopback-only, token-authenticated desktop web app. No remote media uploads."""
from __future__ import annotations
import argparse
import base64
import copy
import importlib.util
import hashlib
import json
import mimetypes
import math
import os
import queue
import re
import secrets
import threading
import time
import urllib.parse
import webbrowser
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from studio.core import VERSION, ass_text, digest, parse_srt, quality, sound_digest, srt_text, uid, wrap_text,view_reference
from studio.media import ROOT, binary, process, render, transcribe
from studio.store import Store, natural, read_json, write_json
from studio.folder_ingest import FolderIngest, FolderDropError, MAX_CHUNK
from studio.script_import import ScriptImports, ScriptImportError
from studio.timeline_media import TimelineMedia
from studio.detached_audio import detach_audio
from studio.library import Library
from studio.portable import PortableProjects
from studio.playback import select_playback
from studio.edit_preview import EditingPreviews
from studio.editor_commands import EditorCommands
from studio.live_media import LiveMedia
from studio.native_drafts import NativeDrafts
from studio.native_caption import public_calibration
from studio.export_quality import HD_PROFILE_VERSION, validate_export_options
from studio.runtime import data_directory, default_model, is_bundle


class Jobs:
    @staticmethod
    def valid_record(value):
        return (isinstance(value,dict)
                and bool(re.fullmatch('[a-f0-9]{32}',str(value.get('id',''))))
                and bool(re.fullmatch('[a-f0-9]{32}',str(value.get('project_id',''))))
                and value.get('state') in ('queued','running','complete','failed','cancelled','interrupted')
                and value.get('kind') in ('preview','draft','final','transcribe')
                and isinstance(value.get('created'),(int,float)) and math.isfinite(value['created'])
                and isinstance(value.get('snapshot'),dict)
                and isinstance(value.get('options',{}),dict)
                and isinstance(value.get('result',{}),dict))

    def __init__(self, store):
        self.store=store
        self.items={}
        self.queue=queue.Queue()
        self.lock=threading.RLock()
        self.health=dict(storage_error=None,last_error=None,worker_started=time.time())
        for path in (store.root/'jobs').glob('*.json'):
            job=store.read_record(path,None,lambda value:self.valid_record(value) and value['id']==path.stem)
            if job is None:continue
            if job['state'] in ('queued','running'):
                job.update(state='interrupted',message='上次程序关闭；可重新提交，原工程未改动')
                self.persist(job)
            self.items[job['id']]=job
        self.thread=threading.Thread(target=self.worker,daemon=True)
        self.thread.start()

    def add(self,pid,kind,options):
        project=self.store.get(pid)
        if options.get('revision') is not None and options['revision']!=project['revision']:
            raise ValueError('工程版本已变化，请重新读取再导出')
        return self.enqueue(project,kind,options)

    def batch(self,body):
        rows=body.get('projects');kind=body.get('kind','draft');request_id=body.get('request_id')
        if not isinstance(rows,list) or not 1<=len(rows)<=100 or any(not isinstance(row,dict) for row in rows):raise ValueError('请选择1至100集')
        if any(not isinstance(row.get('id'),str) or isinstance(row.get('revision'),bool) or not isinstance(row.get('revision'),int) for row in rows):raise ValueError('每集需要 id 和当前整数 revision')
        if len({row.get('id') for row in rows})!=len(rows):raise ValueError('批量导出不能重复选择同一集')
        if kind not in ('preview','draft','final','transcribe'):raise ValueError('未知任务类型')
        if not isinstance(request_id,str) or not re.fullmatch('[a-f0-9]{32}',request_id):raise ValueError('批量请求需要32位十六进制 request_id，重试时保持不变')
        options=validate_export_options(kind,body.get('options',{}))
        signature=hashlib.sha256(json.dumps(dict(projects=rows,kind=kind,options=options),sort_keys=True).encode()).hexdigest()
        with self.lock,self.store.lock:
            path=self.store.root/'batches'/('export-'+request_id+'.json')
            previous=read_json(path)
            if previous and previous.get('signature')!=signature:raise ValueError('本批次已提交其他导出内容，请重新打开批量窗口建立新批次')
            result=previous or dict(id=request_id,signature=signature,results=[])
            for row in rows:
                if any(item['project_id']==row.get('id') for item in result['results']):continue
                existing=next((j for j in self.items.values() if j.get('options',{}).get('batch_request')==request_id and j['project_id']==row.get('id')),None)
                try:
                    if existing and existing.get('options',{}).get('batch_signature')!=signature:raise ValueError('本批次已有其他内容的任务，请使用新批次提交')
                    job=self.public(existing) if existing else self.add(row['id'],kind,dict(options,revision=row.get('revision'),batch_request=request_id,batch_signature=signature))
                    item=dict(project_id=row['id'],job_id=job['id'],state=job['state'])
                except Exception as exc:item=dict(project_id=row.get('id'),error=str(exc))
                result['results'].append(item);write_json(path,result)
            return result

    def enqueue(self,project,kind,options,retry_of=None):
        project=copy.deepcopy(project)
        options=validate_export_options(kind,options)
        if 'subtitle_text' in options:
            if kind!='transcribe':raise ValueError('TXT 对齐仅用于字幕识别任务')
            from studio.txt_alignment import split_text
            split_text(options['subtitle_text'],options.get('subtitle_split','lines'))
        if not project['clips']:
            raise ValueError('请先导入视频')
        if project.get('native',{}).get('issues'):
            raise ValueError('当前原生工程需在剪映渲染：'+'；'.join(project['native']['issues']))
        if kind=='transcribe' and not options.get('model_path'):
            options['model_path']=self.store.settings.get('model_path')
        if kind=='transcribe' and not options.get('model_path'):
            raise ValueError('请先设置本地语音模型目录；也可先导入SRT并编辑')
        job=dict(id=uid(),project_id=project['id'],name=project['name'],kind=kind,state='queued',message='原快照重试，等待处理' if retry_of else '等待处理',progress=0,
                 created=time.time(),snapshot=project,options=options, cancel_requested=False)
        if retry_of:job['retry_of']=retry_of
        with self.lock, self.store.lock:
            self.store.get(project['id'])  # Archive and enqueue are mutually exclusive.
            if not self.persist(job):
                raise ValueError('无法保存任务；未加入队列。请检查磁盘空间或文件夹写入权限。')
            self.items[job['id']]=job
            self.queue.put(job)
        return self.public(job)

    def hd_review_render(self,project,render_id):
        """Bind the human HD review to a real current enhanced draft, not a flag."""
        if not isinstance(render_id,str):return False
        candidate=self.items.get(render_id,{})
        result=candidate.get('result',{})
        profile=result.get('export_quality',{})
        if (candidate.get('state')!='complete' or candidate.get('kind')!='draft'
                or candidate.get('project_id')!=project['id']
                or result.get('project_hash')!=digest(project)
                or result.get('captions_burned') is not True
                or result.get('file')!='film.mp4'
                or profile.get('enhance_hd') is not True
                or profile.get('profile')!=HD_PROFILE_VERSION):
            return False
        target=self.store.root/'renders'/render_id
        return (target/'film.mp4').is_file() and (target/'rendered_audio.wav').is_file()

    def retry(self,jid):
        with self.lock:
            old=self.items[jid]
            if old['state'] not in ('failed','cancelled','interrupted'):
                raise ValueError('只允许重试失败、已取消或中断的任务')
            project=copy.deepcopy(old['snapshot']);options=copy.deepcopy(old.get('options',{}));kind=old['kind']
        if kind=='final':
            current=self.store.get(project['id'])
            if digest(current)!=digest(project):
                raise ValueError('当前工程已改变，不能直接重试旧版本；请从当前工程重新导出')
        return self.enqueue(project,kind,options,retry_of=jid)

    def persist(self,job):
        try:
            write_json(self.store.root/'jobs'/(job['id']+'.json'),job)
            self.health['storage_error']=None
            return True
        except Exception as exc:
            self.health.update(storage_error=str(exc),last_error=dict(time=time.time(),job_id=job['id'],message=str(exc)))
            return False

    def public(self,job,detail=False):
        result={k:v for k,v in list(job.items()) if k not in ('snapshot','result')}
        if 'result' in job:
            result['result']={k:v for k,v in list(job['result'].items()) if detail or k not in ('waveform','captions','words')}
            if 'captions' in job['result']:result['result']['caption_count']=len(job['result']['captions'])
        if detail:result['view_reference']=view_reference(job['snapshot'])
        return copy.deepcopy(result)

    def status(self):
        return dict(self.health,worker_alive=self.thread.is_alive(),pending=sum(j['state'] in ('queued','running') for j in list(self.items.values())))

    def cancel(self,jid):
        with self.lock:
            job=self.items[jid]
            if job['state'] not in ('queued','running'):
                return self.public(job)
            job['cancel_requested']=True
            if job['state']=='queued':job.update(state='cancelled',message='已取消，未开始处理')
            else:job['message']='正在取消；等待当前媒体步骤退出'
            if not self.persist(job):
                raise ValueError('已在当前进程取消，但取消记录无法写入磁盘；请检查空间，暂勿强制关闭。')
            return self.public(job)

    def worker(self):
        while True:
            job=self.queue.get()
            try:
                with self.lock:
                    if job['cancel_requested']:
                        raise ValueError('任务已取消')
                    job.update(state='running',message='开始处理')
                    if not self.persist(job):
                        raise ValueError('磁盘或权限异常，任务未开始处理；解决后可重新提交。')
                project=job['snapshot']
                target=self.store.root/'renders'/job['id']
                if job['kind']=='transcribe':
                    previous=next((j for j in sorted(list(self.items.values()),key=lambda j:j['created'],reverse=True)
                                   if j.get('result',{}).get('sound_digest')==sound_digest(project) and j['state']=='complete'
                                   and (self.store.root/'renders'/j['id']/'rendered_audio.wav').exists()),None)
                    if previous:
                        wav=self.store.root/'renders'/previous['id']/'rendered_audio.wav'
                    else:
                        from studio.media import prepare_audio
                        wav=prepare_audio(project,target,job)
                    result=transcribe(wav,job['options'].get('model_path') or self.store.settings['model_path'],job['options'].get('language') or None,job)
                    if 'subtitle_text' in job['options']:
                        from studio.txt_alignment import align_text
                        job.update(message='正在将 TXT 原文对齐音频对白',progress=.97)
                        result.update(align_text(job['options']['subtitle_text'],result['words'],job['options'].get('subtitle_split','lines'),job))
                    result['sound_digest']=sound_digest(project)
                    for cue in result['captions']:
                        cue['speech']=dict(start=cue['start'],end=cue['end'],sound_digest=result['sound_digest'],method='TXT_ASR_unverified' if 'alignment' in result else 'ASR_unverified')
                    # Results are proposals. Never overwrite a manually edited caption list.
                else:
                    burn=job['kind'] in ('draft','final')
                    result=render(project,target,self.store.fonts,job,burn,not burn,
                                  enhance_hd=job['options'].get('enhance_hd',False))
                    (target/'subtitles.srt').write_text(srt_text(project['captions']),encoding='utf-8-sig')
                    report=quality(project)
                    report['delivery_state']='按任务提交时的工程快照导出；检查提示见本报告'
                    report['export_quality']=result['export_quality']
                    report['output_visual_review']='pending; 导出设置不是验收凭据，请检查实际输出'
                    report['chinese_intervals']=[dict(start=c['start'],end=c['end'],text=c['text']) for c in project['captions'] if c.get('spoken_language')=='zh']
                    report['chinese_detection_notice']='中文区间来自人工标记；未标记不等于确认没有中文。'
                    write_json(target/'quality.json',report)
                with self.lock:
                    if job.get('cancel_requested'):raise ValueError('任务已取消')
                    job.update(state='complete',message='已完成',progress=1,result=result)
            except Exception as exc:
                job.update(state='cancelled' if job['cancel_requested'] else 'failed',message=str(exc))
            finally:
                self.persist(job)
                self.queue.task_done()


def create_handler(store,jobs,token):
    folder_drop=FolderIngest(store)
    script_import=ScriptImports(store,jobs)
    timeline_media=TimelineMedia(store)
    editor_commands=EditorCommands(store)
    live_media=LiveMedia(store)
    portable=PortableProjects(store)
    editing=EditingPreviews(store,jobs)
    native=getattr(store,'native_service',None) or NativeDrafts(store)
    class Handler(BaseHTTPRequestHandler):
        server_version='ShortDramaStudio/'+VERSION

        def log_message(self,*args):
            pass

        def authorized(self):
            split=urllib.parse.urlsplit(self.path)
            supplied=self.headers.get('X-Studio-Token') or urllib.parse.parse_qs(split.query).get('token',[''])[0]
            return secrets.compare_digest(supplied,token)

        def same_origin(self):
            expected=f'127.0.0.1:{self.server.server_port}'
            if self.headers.get('Host')!=expected:
                return False
            return self.headers.get('Origin') in (None,'http://'+expected)

        def json(self,value,status=200):
            raw=json.dumps(value,ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Content-Length',str(len(raw)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            try:
                self.end_headers()
                self.wfile.write(raw)
            except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError):pass

        def file(self,path,download=False,download_name=None):
            if not path.is_file():
                raise ValueError('文件尚未生成')
            size=path.stat().st_size
            start,end=0,size-1
            header=self.headers.get('Range')
            if header:
                match=re.fullmatch(r'bytes=(\d+)-(\d*)',header)
                if not match:
                    self.send_error(416)
                    return
                start=int(match[1]); end=min(size-1,int(match[2]) if match[2] else size-1)
                if start>end:
                    self.send_error(416)
                    return
            self.send_response(206 if header else 200)
            self.send_header('Content-Type',mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
            self.send_header('Content-Length',str(end-start+1))
            self.send_header('Accept-Ranges','bytes')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            if header:
                self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
            if download:
                filename=str(download_name or path.name).strip() or path.name
                self.send_header('Content-Disposition',f"attachment; filename*=UTF-8''{urllib.parse.quote(filename,safe='')}")
            self.end_headers()
            try:
                with path.open('rb') as f:
                    f.seek(start)
                    left=end-start+1
                    while left>0:
                        block=f.read(min(left,1024*1024))
                        if not block: break
                        self.wfile.write(block); left-=len(block)
            except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError):
                pass

        def do_GET(self):
            try:
                if not self.same_origin():
                    return self.json({'error':'仅允许本机应用访问'},403)
                split=urllib.parse.urlsplit(self.path)
                path=split.path
                static={'/':'index.html','/app.js':'app.js','/hardening.js':'hardening.js','/project-management.js':'project-management.js','/folder-drop.js':'folder-drop.js','/script-import.js':'script-import.js','/font-preset.js':'font-preset.js','/style.css':'style.css','/layout.css':'layout.css','/layout.js':'layout.js','/library.js':'library.js','/library.css':'library.css',
                        '/timeline-model.js':'timeline-model.js','/timeline.js':'timeline.js','/mask-ui.js':'mask-ui.js','/timeline.css':'timeline.css'}
                static['/workflow.js']='workflow.js'
                static['/live-editor.js']='live-editor.js'
                static['/realtime-player.js']='realtime-player.js'
                static['/editor-actions.js']='editor-actions.js'
                static['/editor-refinement.css']='editor-refinement.css'
                static['/editor-bundle.js']='editor-bundle.js'
                static['/native-drafts.css']='native-drafts.css'
                static['/simple-ui.css']='simple-ui.css'
                if path in static:
                    return self.file(ROOT/'web'/static[path])
                if not self.authorized():
                    return self.json({'error':'请通过启动器打开，访问令牌缺失或已过期'},401)
                parts=path.strip('/').split('/')
                if path=='/api/native/overview':
                    return self.json(native.overview())
                if len(parts)==4 and parts[:3]==['api','native','packages'] and re.fullmatch('[a-f0-9]{32}',parts[3]):
                    return self.file(native.root/'packages'/(parts[3]+'.zip'),True)
                if len(parts)==4 and parts[:3]==['api','native','drafts']:
                    try:return self.json(native.refresh(parts[3]))
                    except Exception as exc:return self.json({'error':str(exc)},400)
                if len(parts)==4 and parts[:3]==['api','native','migration']:
                    return self.json(native.migration_report(parts[3]))
                if len(parts)==3 and parts[:2]==['api','folder-drop']:
                    return self.json(folder_drop.status(parts[2]))
                if path=='/api/library':
                    return self.json(Library(store).list())
                if path=='/api/identity':
                    return self.json(dict(version=VERSION,data_dir=str(store.root)))
                if path=='/api/bootstrap':
                    deps={k:bool(importlib.util.find_spec(k)) for k in ['PIL','fontTools','pypdf','faster_whisper']}
                    try: ff=binary('ffmpeg')
                    except ValueError: ff=None
                    fonts=[]
                    for font in store.fonts.values():
                        row=copy.deepcopy(font)
                        try:row['jianying_font_size']=public_calibration(store,font['path'])
                        except (OSError,ValueError,KeyError,TypeError):
                            row['jianying_font_size']=dict(verified=False,native_units_per_1080px=1/8,canvas_width=1080,canvas_height=1920)
                        fonts.append(row)
                    return self.json(dict(version=VERSION,projects=store.list_projects(refresh_native=False),fonts=fonts,
                                          settings=store.settings,dependencies=deps,ffmpeg=ff,data_dir=str(store.root),recovery_issues=store.issues[-50:]))
                if path=='/api/health':
                    return self.json(dict(jobs=jobs.status(),folder_import_active=folder_drop.busy(),script_import_active=script_import.busy(),package_active=portable.busy(),editing_preview_active=editing.busy(),recovery_issues=store.issues[-50:]))
                if len(parts)==3 and parts[:2]==['api','packages'] and re.fullmatch('[a-f0-9]{32}',parts[2]):
                    return self.file(portable.owned('packages',parts[2]+'.zip'),True)
                if path=='/api/trash':
                    return self.json(store.list_projects(archived=True))
                if path=='/api/jobs':
                    query=urllib.parse.parse_qs(split.query)
                    limit=max(1,min(100,int(query.get('limit',['30'])[0])))
                    offset=max(0,int(query.get('offset',['0'])[0]))
                    rows=list(jobs.items.values())
                    if query.get('folder_id'):
                        folder=Library(store).get(query['folder_id'][0]);allowed={p['id'] for p in folder['episodes']}
                        rows=[j for j in rows if j['project_id'] in allowed]
                    return self.json([jobs.public(j) for j in sorted(rows,key=lambda j:j['created'],reverse=True)[offset:offset+limit]])
                if len(parts)==3 and parts[:2]==['api','jobs']:
                    return self.json(jobs.public(jobs.items[parts[2]],detail=True))
                if len(parts)==4 and parts[:2]==['api','projects'] and parts[3]=='history':
                    return self.json(store.history(parts[2]))
                if len(parts)==4 and parts[:2]==['api','projects'] and parts[3]=='playback':
                    mode=urllib.parse.parse_qs(split.query).get('mode',[''])[0]
                    return self.json(select_playback(store,jobs,parts[2],mix_only=mode=='mix',export_only=mode=='export'))
                if len(parts)==5 and parts[:2]==['api','projects'] and parts[3]=='timeline-media':
                    query=urllib.parse.parse_qs(split.query,keep_blank_values=True)
                    streams=query.get('stream',[])
                    if len(streams)>1 or streams and (not re.fullmatch(r'[0-9]{1,5}',streams[0]) or int(streams[0])>65535):
                        raise ValueError('音轨参数必须为唯一的非负整数')
                    return self.json(timeline_media.get(parts[2],parts[4],int(streams[0]) if streams else None))
                if len(parts)==5 and parts[:2]==['api','projects'] and parts[3]=='live-audio':
                    values=urllib.parse.parse_qs(split.query).get('stream',[])
                    if len(values)>1 or values and not re.fullmatch(r'[0-9]{1,5}',values[0]):raise ValueError('音轨参数无效')
                    return self.file(live_media.audio(parts[2],parts[4],int(values[0]) if values else None))
                if len(parts)==3 and parts[:2]==['api','projects']:
                    return self.json(store.get(parts[2]))
                if len(parts)==4 and parts[:2]==['api','projects'] and parts[3]=='native-timeline':
                    project=store.get(parts[2])
                    if not project.get('native',{}).get('shared'):raise ValueError('此工程尚未转为原生共同工程')
                    _,folder,state,content=store.shared_timeline.state(parts[2])
                    return self.json(dict(revision=project['revision'],native_revision=state['revision'],timeline=content,path=str(folder)))
                if len(parts)==4 and parts[:2]==['api','projects'] and parts[3]=='editor-state':
                    project=store.get(parts[2]);return self.json(dict(revision=project['revision'],track_locks=project.get('track_locks',[]),editor_running=native.running() if project.get('native',{}).get('shared') else False))
                if len(parts)==4 and parts[:2]==['api','projects'] and parts[3]=='quality':
                    return self.json(quality(store.get(parts[2])))
                if len(parts)==3 and parts[0]=='asset':
                    return self.file(store.asset_path(parts[1],parts[2]))
                if len(parts)==2 and parts[0]=='font':
                    return self.file(Path(store.fonts[parts[1]]['path']))
                if len(parts)==3 and parts[0]=='render' and parts[1] in jobs.items and parts[2] in ('preview.mp4','edit.mp4','film.mp4','rendered_audio.wav','speech.wav','final_mix.wav','waveform.json','quality.json','subtitles.srt','project.json'):
                    download='download' in urllib.parse.parse_qs(split.query)
                    export_name=None
                    if download and parts[2] in ('preview.mp4','edit.mp4','film.mp4'):
                        export_name=str(jobs.items[parts[1]].get('name') or '成片').strip() or '成片'
                        if not export_name.lower().endswith('.mp4'):export_name+='.mp4'
                    return self.file(store.root/'renders'/parts[1]/parts[2],download,export_name)
                return self.json({'error':'不存在的接口'},404)
            except FolderDropError as exc:
                self.json(exc.payload,exc.status)
            except (ValueError,KeyError,OSError,RuntimeError) as exc:
                self.json({'error':str(exc)},400)

        def do_PUT(self):
            try:
                # Binary copies require the header token, never a URL token.
                if not self.same_origin() or not secrets.compare_digest(self.headers.get('X-Studio-Token',''),token):
                    return self.json({'error':'访问被拒绝'},403)
                split=urllib.parse.urlsplit(self.path)
                parts=split.path.strip('/').split('/')
                if len(parts)!=5 or parts[:2]!=['api','folder-drop'] or parts[3]!='files':
                    return self.json({'error':'不存在的接口'},404)
                lengths=self.headers.get_all('Content-Length',[])
                if self.headers.get('Transfer-Encoding') or len(lengths)!=1 or not re.fullmatch(r'[0-9]+',lengths[0]):
                    return self.json({'error':'复制分片必须使用明确的Content-Length'},411)
                length=int(lengths[0])
                if not 0<length<=MAX_CHUNK:
                    return self.json({'error':'复制分片必须为1至8MiB'},413)
                offsets=urllib.parse.parse_qs(split.query).get('offset',[])
                if len(offsets)!=1 or not re.fullmatch(r'[0-9]+',offsets[0]):
                    raise FolderDropError('请提供唯一的非负复制偏移量')
                self.connection.settimeout(30)
                return self.json(folder_drop.put(parts[2],parts[4],int(offsets[0]),length,self.rfile))
            except FolderDropError as exc:
                return self.json(exc.payload,exc.status)
            except (ValueError,KeyError,OSError) as exc:
                return self.json({'error':str(exc)},400)

        def do_POST(self):
            try:
                if not self.same_origin() or not self.authorized():
                    return self.json({'error':'访问被拒绝'},403)
                length=int(self.headers.get('Content-Length',0))
                if length<0 or length>45*1024*1024:
                    raise ValueError('请求过大')
                body=json.loads(self.rfile.read(length) or b'{}')
                path=urllib.parse.urlsplit(self.path).path
                parts=path.strip('/').split('/')
                if path.startswith('/api/native/'):
                    if not isinstance(body,dict):raise ValueError('请求应为对象')
                    try:
                        if path=='/api/native/bind':return self.json(native.bind(body))
                        if path=='/api/native/snapshot':return self.json(native.snapshot(body['key']))
                        if path=='/api/native/verify':return self.json(native.verify(body['key']))
                        if path=='/api/native/save-text':return self.json(native.save_text(body))
                        if path=='/api/native/patch':
                            from studio.native_patch import save as save_native_patch
                            return self.json(save_native_patch(native,body))
                        if path=='/api/native/package':
                            from studio.native_package import export as package_native
                            with portable.activity():return self.json(package_native(native,body))
                        if path=='/api/native/import-package':
                            from studio.native_package import import_package as import_native_package
                            with portable.activity():return self.json(import_native_package(native,Path(body['path'])))
                        if path=='/api/native/recover':return self.json(native.recover(body['key']))
                        if path=='/api/native/launch':return self.json(native.launch())
                        if path=='/api/native/reveal':return self.json(native.reveal(body['key']))
                        if path=='/api/native/export':return self.json(native.export_project(body))
                        return self.json({'error':'不存在的剪映操作'},404)
                    except Exception as exc:return self.json({'error':str(exc)},400)
                if path=='/api/script-import/preview':
                    try:return self.json(script_import.preview(body))
                    except ScriptImportError:raise
                    except Exception as exc:raise ScriptImportError('无法预览剧本：'+str(exc))
                if len(parts)==4 and parts[:2]==['api','script-import'] and parts[3]=='apply':
                    try:return self.json(script_import.apply(parts[2],body))
                    except ScriptImportError:raise
                    except Exception as exc:raise ScriptImportError('无法应用剧本：'+str(exc))
                if len(parts)==4 and parts[:2]==['api','script-import'] and parts[3]=='discard':
                    return self.json(script_import.discard(parts[2]))
                if path=='/api/folder-drop/preview':
                    return self.json(folder_drop.preview(body.get('files'),body.get('roots'),body.get('include_audio_only') is True))
                if path=='/api/folder-drop/start':
                    return self.json(folder_drop.start(body.get('files'),body.get('roots'),body.get('selected'),body.get('confirmed'),body.get('series'),body.get('target_project_id'),body.get('append',True)))
                if len(parts)==4 and parts[:2]==['api','folder-drop']:
                    if parts[3]=='commit':return self.json(folder_drop.commit(parts[2]))
                    if parts[3]=='cancel':return self.json(folder_drop.cancel(parts[2]))
                if path=='/api/shutdown':
                    if editing.busy():raise ValueError('正在准备编辑底图，请稍后再关闭后台')
                    if portable.busy():raise ValueError('工程正在打包或导入，请等待完成后再关闭后台')
                    if script_import.busy():
                        raise ValueError('剧本正在解析或应用，请等待完成再关闭，避免丢失本次应用结果')
                    if folder_drop.busy():
                        raise ValueError('文件夹仍在本机复制或导入，请先暂停或等待完成再关闭')
                    if any(j['state'] in ('queued','running') for j in list(jobs.items.values())):
                        raise ValueError('仍有任务在处理，请先取消或等待完成')
                    self.json({'ok':True,'message':'本机软件已关闭'})
                    threading.Thread(target=self.server.shutdown,daemon=True).start()
                    return
                if path=='/api/library':
                    return self.json(Library(store).create(body.get('name','')))
                if path=='/api/projects':
                    return self.json(store.create(str(body.get('name','新剧集')),body.get('series','')))
                if path=='/api/exports/batch':return self.json(jobs.batch(body))
                if path=='/api/packages/import':
                    import zipfile
                    candidate=Path(str(body.get('path','')).strip().strip('"')).expanduser()
                    if candidate.is_file() and candidate.suffix.lower()=='.zip':
                        with zipfile.ZipFile(candidate) as package:
                            info=package.getinfo('project.json')
                            if info.file_size>64*1024**2:raise ValueError('工程清单过大')
                            kind=json.loads(package.read(info)).get('format')
                        if kind=='baimu-native-project':
                            from studio.native_package import import_package as import_native_package
                            with portable.activity():return self.json(import_native_package(native,candidate))
                    return self.json(portable.import_package(body.get('path',''),body.get('series')))
                if len(parts)==4 and parts[:2]==['api','projects'] and parts[3]=='package':
                    project=store.get(parts[2])
                    if project.get('native',{}).get('shared'):
                        if body.get('revision')!=project['revision']:raise ValueError('工程版本已变化，请重新打包')
                        from studio.native_package import export as export_native_package
                        with portable.activity():return self.json(export_native_package(native,dict(key=project['native']['key'],revision=project['native']['revision'])))
                    return self.json(portable.export(parts[2],body.get('revision')))
                if len(parts)==4 and parts[:2]==['api','projects'] and parts[3]=='editing-preview':
                    return self.json(editing.prepare(parts[2]))
                if path=='/api/batch/preview':
                    return self.json(store.batch_preview(body['path']))
                if path=='/api/batch':
                    if body.get('confirmed') is not True:
                        raise ValueError('请先预览候选目录，勾选所需剧集并确认导入')
                    selected=body.get('selected')
                    if not isinstance(selected,list) or not selected or len(selected)>30 or not all(isinstance(name,str) for name in selected) or len(set(selected))!=len(selected):
                        raise ValueError('请选择1至30个不重复的剧集子目录')
                    series=store.series_name(body.get('series',''))
                    preview=store.batch_preview(body['path'])
                    allowed={folder['name']:Path(folder['path']) for folder in preview['folders']}
                    if any(name not in allowed for name in selected):
                        raise ValueError('所选目录不在当前安全候选名单中（可能为空、只有音频、已改变或是软件目录），请重新预览')
                    root=Path(preview['path'])
                    dirs=sorted([allowed[name] for name in selected],key=natural)
                    batch_id=hashlib.sha256(os.path.normcase(str(root)).encode('utf-8')).hexdigest()
                    journal_path=store.root/'batches'/(batch_id+'.json')
                    results=[]
                    # Serialize retries, with a durable folder->project mapping before probing.
                    with store.batch_lock:
                        journal=store.read_record(journal_path,dict(root=str(root),folders={}),lambda value:isinstance(value,dict) and isinstance(value.get('folders'),dict))
                        for folder in dirs:
                            key=os.path.normcase(str(folder.resolve()))
                            entry=journal['folders'].get(key)
                            if entry is None:
                                # Reserve a durable ID, but publish no empty project.
                                entry=dict(id=uid(),name=folder.name,state='pending',series=series)
                                journal['folders'][key]=entry
                                write_json(journal_path,journal)
                            try:
                                if not store.path(entry['id']).exists():
                                    if entry['state'] in ('complete','missing'):
                                        entry['state']='missing'
                                        raise ValueError('已导入的工程文件缺失，请先检查恢复记录；不会静默重建并丢失旧编辑')
                                    project=store.create_imported(folder.name,entry.get('series',series),folder,pid=entry['id'])
                                    entry.update(state='complete',error=None)
                                    write_json(journal_path,journal)
                                    results.append(dict(id=project['id'],name=folder.name,state='已导入'))
                                    continue
                                project=store.get(entry['id'],include_archived=True)
                                if project.get('archived'):
                                    results.append(dict(id=project['id'],name=folder.name,state='已在回收站；请明确恢复，不会重复建立或自动恢复',archived=True,reused=True))
                                    continue
                                if entry['state']=='complete' or project['clips']:
                                    entry.update(state='complete',error=None)
                                    write_json(journal_path,journal)
                                    results.append(dict(id=project['id'],name=folder.name,state='已存在，保留当前剪辑',reused=True))
                                    continue
                                project=store.import_paths(project['id'],[str(folder)])
                                entry.update(state='complete',error=None)
                                results.append(dict(id=project['id'],name=folder.name,state='已导入' if project['clips'] else '无视频'))
                            except Exception as exc:
                                entry.update(state='missing' if entry.get('state')=='missing' else 'failed',error=str(exc))
                                result=dict(name=folder.name,state=str(exc),retryable=True)
                                if store.path(entry['id']).exists():result['id']=entry['id']
                                results.append(result)
                            write_json(journal_path,journal)
                    return self.json(results)
                if path=='/api/fonts':
                    if body.get('data'):
                        name=Path(body['name']).name
                        ext=Path(name).suffix.lower()
                        if ext not in ('.ttf','.otf'): raise ValueError('仅支持TTF/OTF字体')
                        temp=store.root/'fonts'/('upload-'+uid()+ext)
                        try:
                            temp.write_bytes(base64.b64decode(body['data'],validate=True))
                            info=store.import_font(temp)
                        finally:
                            temp.unlink(missing_ok=True)
                    else:
                        info=store.import_font(body['path'])
                    return self.json(info)
                if path=='/api/settings':
                    model=Path(body.get('model_path','')).expanduser().resolve()
                    if not (model/'model.bin').is_file(): raise ValueError('模型目录中没有model.bin')
                    store.settings['model_path']=str(model)
                    write_json(store.root/'settings.json',store.settings)
                    return self.json(store.settings)
                if len(parts)==4 and parts[:2]==['api','jobs'] and parts[3]=='cancel':
                    return self.json(dict(ok=True,job=jobs.cancel(parts[2])))
                if len(parts)==4 and parts[:2]==['api','jobs'] and parts[3]=='retry':
                    return self.json(jobs.retry(parts[2]))
                if len(parts)>=3 and parts[:2]==['api','projects']:
                    pid=parts[2]
                    action=parts[3] if len(parts)==4 else 'save'
                    if action=='edits':return self.json(editor_commands.execute(pid,body))
                    if action=='handoff':
                        with store.lock:
                            project=store.get(pid)
                            if body.get('revision')!=project['revision']:raise ValueError('工程版本已变化，请重新读取')
                            if not project.get('native',{}).get('shared'):project=store.shared_timeline.activate(project)
                            return self.json(store.shared_timeline.register(pid,project['revision']))
                    if action in ('archive','unarchive'):
                        with jobs.lock, store.lock:
                            if action=='archive' and any(j.get('project_id')==pid and j.get('state') in ('queued','running') for j in list(jobs.items.values())):
                                raise ValueError('该集仍有排队或运行任务，请先取消或等待完成，再移入回收站')
                            return self.json(store.set_archived(pid,body.get('revision'),body.get('confirmed'),action=='archive'))
                    if action=='detach-audio':
                        with store.lock:
                            project=store.get(pid)
                            if body.get('revision')!=project['revision']:
                                raise ValueError('工程版本已变化，请重新选择画面片段后分离')
                            return self.json(store.save(pid,detach_audio(project,body.get('clip_id'))))
                    if action=='save': return self.json(store.save(pid,body))
                    if action=='restore': return self.json(store.restore(pid,body['history_revision'],body['revision']))
                    if action=='import': return self.json(store.import_paths(pid,body['paths'],body.get('append',True)))
                    if action=='refresh-assets': return self.json(store.refresh_assets(pid,body['asset_ids'],body['revision'],body.get('confirmed')))
                    if action=='media-status':return self.json(store.media_status(pid))
                    if action=='relink-preview':return self.json(store.relink_preview(pid,body['asset_id'],body['path'],body['revision']))
                    if action=='relink-asset':return self.json(store.relink_asset(pid,body['asset_id'],body['path'],body['revision'],body.get('confirmed'),body.get('expected_sha256')))
                    if action=='confirm-cue':
                        project=store.get(pid)
                        if body.get('confirmed') is not True or body.get('revision')!=project['revision']:
                            raise ValueError('请基于当前工程版本实际试听后确认')
                        render_job=jobs.items.get(body.get('render_id'),{})
                        result=render_job.get('result',{})
                        if render_job.get('state')!='complete' or render_job.get('project_id')!=pid or result.get('file') not in ('film.mp4','preview.mp4') or result.get('sound_digest')!=sound_digest(project):
                            raise ValueError('必须选择当前声音版本的已完成视频预览／导出，识别草稿不能证明已试听')
                        output_dir=store.root/'renders'/render_job['id']
                        if not (output_dir/result['file']).is_file() or not (output_dir/'rendered_audio.wav').is_file():
                            raise ValueError('当前视频或实际音轨文件缺失，请重新生成预览')
                        start,end=float(body['start']),float(body['end'])
                        duration=quality(project)['duration']
                        if not math.isfinite(start) or not math.isfinite(end) or not 0<=start<end<=duration:
                            raise ValueError('确认发声区间必须位于当前成片时长内')
                        cue=next((c for c in project['captions'] if c['id']==body['cue_id']),None)
                        if cue is None:raise ValueError('字幕已不存在')
                        cue['speech']=dict(start=start,end=end,sound_digest=sound_digest(project),method='manual_verified',render_id=render_job['id'])
                        return self.json(store.save(pid,project))
                    if action=='script':
                        raise ScriptImportError('旧的直接整本剧本导入已停用；请使用“导入剧本”的预览、分集与逐项确认入口，避免覆盖错误工程',409)
                    if action=='srt':
                        return self.json(parse_srt(body['text']))
                    if action=='wrap':
                        project=store.get(pid)
                        if body.get('revision')!=project['revision']:
                            raise ValueError('工程版本已变化，请保存并刷新后再断行')
                        for cue in project['captions']:
                            if body.get('cue_id') and cue['id']!=body['cue_id']: continue
                            st=dict(project['style'],**cue.get('style',{}))
                            font=store.fonts.get(st['font_id'])
                            if not font: raise ValueError('请先选择字体')
                            cue['text']=wrap_text(cue['text'].replace('\n',' '),font['path'],st['font_size'],1080*st['max_width']/100,st['spacing'])
                        return self.json(store.save(pid,project))
                    if action=='review':
                        with store.lock:
                            project=store.get(pid)
                            if body.get('revision')!=project['revision']: raise ValueError('版本已变化，请刷新后复核')
                            if body['key'] not in ('dialogue','timing','listening','visual','visual_hd'): raise ValueError('无效复核类型')
                            if body.get('confirmed') is not True: raise ValueError('必须由实际复核者确认')
                            if body['key']=='visual_hd' and not jobs.hd_review_render(project,body.get('render_id')):
                                raise ValueError('请先导出并播放当前工程的高清审阅版；旧版、普通版或未完成任务不能作为高清验收凭据')
                            if body['key'] in ('timing','listening','visual'):
                                valid_render=False
                                for candidate in list(jobs.items.values()):
                                    result=candidate.get('result',{})
                                    if candidate.get('state')!='complete' or candidate.get('project_id')!=pid or result.get('file') not in ('film.mp4','preview.mp4'):
                                        continue
                                    target=store.root/'renders'/candidate['id']
                                    if not (target/result['file']).is_file() or not (target/'rendered_audio.wav').is_file():
                                        continue
                                    if body['key']=='visual':
                                        valid_render=bool(result.get('captions_burned')) and result.get('project_hash')==digest(project)
                                    else:
                                        valid_render=result.get('sound_digest')==sound_digest(project)
                                    if valid_render:break
                                if not valid_render:
                                    raise ValueError('请先导出当前工程的烧录字幕审阅版，再实际查看后验收' if body['key']=='visual' else '请先生成当前声音版本的视频混音预览，再实际试听后验收；识别草稿不能代替试听')
                            project['reviews'][body['key']]=(dict(project_hash=digest(project),profile=HD_PROFILE_VERSION,render_id=body['render_id'])
                                                           if body['key']=='visual_hd' else digest(project))
                            return self.json(store.persist_metadata(project))
                    if action=='jobs':
                        if body['kind'] not in ('preview','draft','final','transcribe'): raise ValueError('未知任务类型')
                        return self.json(jobs.add(pid,body['kind'],body))
                return self.json({'error':'不存在的接口'},404)
            except (FolderDropError,ScriptImportError) as exc:
                return self.json(exc.payload,exc.status)
            except Exception as exc:
                return self.json({'error':str(exc)},400)
    return Handler


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=18742)
    parser.add_argument('--data',type=Path,default=data_directory())
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args()
    store=Store(args.data)
    if 'native_authority' not in store.settings:
        store.settings['native_authority']=True
        write_json(store.root/'settings.json',store.settings)
    if is_bundle() and not (Path(store.settings.get('model_path',''))/'model.bin').is_file():
        model=default_model()
        if (model/'model.bin').is_file():
            store.settings['model_path']=str(model)
            write_json(store.root/'settings.json',store.settings)
    from studio.subtitle_preset import install_reference_preset
    try:
        install_reference_preset(store,ROOT/'assets'/'fonts'/'NotoSans-SemiBold.ttf')
    except (ValueError,OSError) as exc:
        store.issues.append(dict(kind='default_font_missing',message=str(exc)))
    if not store.fonts:
        folder=Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts'
        # Copy a known available system font; never silently call it Noto.
        for filename in ('NotoSansBengali-Regular.ttf','segoeui.ttf','arial.ttf'):
            path=folder/filename
            if path.is_file():
                try: store.import_font(path); break
                except Exception: pass
    token=secrets.token_urlsafe(32)
    jobs=Jobs(store)
    server=ThreadingHTTPServer(('127.0.0.1',args.port),create_handler(store,jobs,token))
    url=f'http://127.0.0.1:{server.server_port}/#token={token}'
    write_json(store.root/'session.json',dict(url=url,pid=os.getpid(),port=server.server_port))
    print('短剧工坊已启动：'+url,flush=True)
    print('仅本机可访问。关闭此进程后任务停止，下次启动可重新提交。',flush=True)
    if not args.no_browser: webbrowser.open(url)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()


if __name__=='__main__':
    main()
