"""Quiet desktop entrypoint. Reuse our local server; never stop other programs."""
from __future__ import annotations
import argparse
import contextlib
import ctypes
import json
import os
from pathlib import Path
import socket
import subprocess
import time
import urllib.parse
import urllib.request
import webbrowser
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from studio.runtime import data_directory, is_bundle, python_executable
from studio.branding import APP_NAME
from studio.core import VERSION

ROOT=Path(__file__).resolve().parent


def launch_port(root=ROOT):
    """Reuse a bundle's previous origin so browser drafts survive a restart."""
    if not is_bundle(root):return 18742
    try:
        saved=json.loads((data_directory(root)/'session.json').read_text(encoding='utf-8'))
        port=saved.get('port')
        if not isinstance(port,int) or not 1024<=port<=65535:return 0
        with socket.socket() as probe:probe.bind(('127.0.0.1',port))
        return port
    except (OSError,ValueError,TypeError):return 0


def session_url(root=ROOT):
    """A session file is only a hint: authenticate and match the data directory."""
    try:
        session=json.loads((data_directory(root)/'session.json').read_text(encoding='utf-8'))
        url=urllib.parse.urlsplit(session['url'])
        if url.scheme!='http' or url.hostname!='127.0.0.1' or url.username or url.password:
            return None
        if not url.port or url.path not in ('','/') or url.query:
            return None
        token=urllib.parse.parse_qs(url.fragment).get('token',[''])[0]
        if not token:return None
        request=urllib.request.Request('http://'+url.netloc+'/api/identity',headers={'X-Studio-Token':token})
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request,timeout=1.5) as response:
            bootstrap=json.load(response)
        if bootstrap.get('version')!=VERSION or Path(bootstrap.get('data_dir','')).resolve()!=data_directory(root).resolve():
            return None
        return session['url']
    except (OSError,ValueError,KeyError,TypeError):
        return None


@contextlib.contextmanager
def startup_lock(root=ROOT):
    """Serialize double-clicks so they cannot spawn competing server instances."""
    import msvcrt
    data=data_directory(root)
    data.mkdir(parents=True,exist_ok=True)
    with (data/'launcher.lock').open('a+b') as handle:
        handle.seek(0,2)
        if not handle.tell():handle.write(b'0');handle.flush()
        deadline=time.monotonic()+30
        while True:
            try:
                handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
                break
            except OSError:
                if time.monotonic()>deadline:raise RuntimeError('软件仍在启动，请稍候再双击。')
                time.sleep(.2)
        try:yield
        finally:
            handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)


def ensure_running(root=ROOT):
    with startup_lock(root):
        existing=session_url(root)
        if existing:return existing
        python=python_executable(root)
        if not python.is_file():
            raise RuntimeError('运行环境缺失。请先在软件文件夹双击 install.cmd。')
        with socket.socket() as probe:
            probe.settimeout(.3)
            occupied=probe.connect_ex(('127.0.0.1',18742))==0
        if occupied and not is_bundle(root):
            raise RuntimeError('本机端口18742被占用，但不是可验证的本软件实例。未关闭任何其他程序，请联系维护者检查。')
        logs=data_directory(root).parent/'logs' if is_bundle(root) else root
        logs.mkdir(parents=True,exist_ok=True)
        with (logs/'startup.log').open('ab') as out,(logs/'startup-error.log').open('ab') as err:
            child=subprocess.Popen([str(python),'-X','utf8','-u',str(root/'app.py'),'--no-browser',
                '--data',str(data_directory(root)),'--port',str(launch_port(root))],
                cwd=root,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            ready=session_url(root)
            if ready:return ready
            if child.poll() is not None:
                raise RuntimeError('启动失败，请查看：'+str(logs/'startup-error.log'))
            time.sleep(.25)
        raise RuntimeError('启动超过20秒。请稍后再双击图标，或查看：'+str(logs/'startup-error.log'))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--browser',action='store_true',help='Open the same editor in a browser instead of the native window')
    parser.add_argument('--no-browser',action='store_true',help='Health test without opening a browser')
    parser.add_argument('--print-session',action='store_true',help='Return an authenticated URL to the native desktop host')
    parser.add_argument('--check',action='store_true',help='Only check an existing server; do not start it')
    args=parser.parse_args()
    try:
        url=session_url() if args.check else ensure_running()
        if not url:raise RuntimeError('本机软件尚未运行。')
        if args.print_session:
            print(url,flush=True)
            return 0
        native=ROOT/'desktop'/'九州百慕.exe'
        if not args.no_browser and not args.browser and native.is_file():
            subprocess.Popen([str(native)],cwd=native.parent,close_fds=True)
            return 0
        if not args.no_browser and not webbrowser.open(url):
            raise RuntimeError('软件已经启动，但无法打开默认浏览器。请检查默认浏览器设置。')
        if args.no_browser:print('Studio is ready. Existing work preserved.')
        return 0
    except Exception as exc:
        if args.no_browser or args.print_session:
            print(str(exc))
        else:
            ctypes.windll.user32.MessageBoxW(None,str(exc)+'\n\n软件目录：'+str(ROOT),APP_NAME+' · 启动提示',0x10)
        return 1


if __name__=='__main__':raise SystemExit(main())
