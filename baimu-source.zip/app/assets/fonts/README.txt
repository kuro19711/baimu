NotoSans-SemiBold.ttf is the unmodified font supplied by the user on 2026-10-14.
Source: NotoSans-SemiBold(2).ttf. Weight: 600. It does not contain Chinese glyphs.
Copyright and license metadata are embedded in the font's name table.
The font metadata states: SIL Open Font License, Version 1.1.
License URL from the font: https://openfontlicense.org
Copyright from the font and the full license are included in OFL.txt.
License text source: https://openfontlicense.org/open-font-license-official-text/
The app imports an app-owned copy with a unique internal family name for libass.
The user's original and this bundled font are not modified.
