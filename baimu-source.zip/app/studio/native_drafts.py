"""Jianying integration, deliberately separate from the legacy project Store.

Native timelines remain full JSON objects. No simplified Baimu model is ever
serialized over an existing Jianying draft. Only indexed drafts are addressable.
"""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import threading
import time
import uuid
from .jianying_bridge import bridge
from .store import read_json, write_json
from .jianying_paths import discover_launcher, install_roots


class NativeDrafts:
    # The DLL ABI is version-specific. Auto-selection is limited to versions
    # that have passed encrypted read/write roundtrips; explicit overrides are
    # still available for diagnostics of a newly adapted version.
    VERIFIED_DLLS={
        '11.6.0.14552':'8cfcbb612ccd946df974428977b1902736c1de0ae561e20c26cbd4ea86099cb1',
    }

    @staticmethod
    def valid_install(path):
        path=Path(path)
        return path.is_dir() and (path/'videoeditor.dll').is_file() and (path/'JianyingPro.exe').is_file()

    @classmethod
    def compatible_install(cls,path):
        path=Path(path)
        expected=cls.VERIFIED_DLLS.get(path.name)
        # Upgrades can remove the old executable while leaving a usable codec.
        if not expected or not (path/'videoeditor.dll').is_file():return False
        try:
            digest=hashlib.sha256()
            with (path/'videoeditor.dll').open('rb') as handle:
                for chunk in iter(lambda:handle.read(1024*1024),b''):digest.update(chunk)
            return digest.hexdigest()==expected
        except OSError:return False

    @classmethod
    def discover_install(cls,preferred,roots=(),validator=None):
        """Recover from Jianying upgrades that leave connection.json on an old version."""
        preferred=Path(preferred)
        validator=validator or cls.compatible_install
        if validator(preferred):return preferred
        search=[]
        for root in (preferred.parent,*roots,*install_roots(preferred)):
            root=Path(root)
            if root not in search:search.append(root)
        for variable in ('ProgramFiles','LOCALAPPDATA'):
            value=os.environ.get(variable)
            if value:
                root=Path(value)/'JianyingPro'
                if root not in search:search.append(root)
        candidates=[]
        for root in search:
            if validator(root):candidates.append(root)
            if not root.is_dir():continue
            try:candidates.extend(path for path in root.iterdir() if validator(path))
            except OSError:continue
        if not candidates:return preferred
        def version(path):
            numbers=tuple(int(value) for value in re.findall(r'\d+',path.name))
            try:modified=path.stat().st_mtime_ns
            except OSError:modified=0
            return numbers,modified
        return max(set(candidates),key=version)

    def __init__(self, store, index=None, install=None):
        self.store=store
        self.root=store.root/'jianying'
        connection=read_json(self.root/'connection.json',{})
        self.index=Path(index or connection.get('index') or Path(os.environ['LOCALAPPDATA'])/'JianyingPro/User Data/Projects/com.lveditor.draft/root_meta_info.json')
        configured=Path(install or connection.get('install') or os.environ.get('BAIMU_JIANYING_INSTALL',r'D:\JianyingPro\11.6.0.14552'))
        roots=[]
        environment=os.environ.get('BAIMU_JIANYING_INSTALL')
        if environment:roots.append(Path(environment).parent)
        self.install=configured if install is not None else self.discover_install(configured,roots)
        recovered=self.install.resolve()!=configured.resolve()
        if install is None and not recovered and not self.compatible_install(configured):
            unverified=self.discover_install(configured,roots,self.valid_install)
            if unverified.resolve()!=configured.resolve():
                store.issues.append(dict(kind='unsupported_jianying_version',path=str(unverified),
                    message=f'检测到剪映 {unverified.name}，但当前原生草稿编解码仅验收 11.6.0.14552；未自动切换到未经往返验证的 DLL'))
        if index is not None or install is not None or recovered:
            write_json(self.root/'connection.json',dict(connection,index=str(self.index.resolve()),install=str(self.install.resolve())))
        # One lock order for ordinary saves, native patches and package imports.
        # Sharing the store's reentrant mutex prevents store/native inversion.
        self.lock=store.lock
        self.cache={}
        self.store.native_service=self
        from .shared_timeline import SharedTimeline
        self.store.shared_timeline=SharedTimeline(store,self)

    @staticmethod
    def key(path):return hashlib.sha256(os.path.normcase(str(Path(path).resolve())).encode()).hexdigest()[:24]

    def entries(self):
        data=json.loads(bridge.stable_bytes(self.index).decode('utf-8-sig')) if self.index.is_file() else {'all_draft_store':[]}
        rows=data.get('all_draft_store')
        if not isinstance(rows,list):raise ValueError('剪映草稿索引结构无法识别')
        entries=[e for e in rows if isinstance(e,dict) and isinstance(e.get('draft_fold_path'),str)]
        known={os.path.normcase(str(Path(e['draft_fold_path']).resolve())) for e in entries}
        for path in (self.root/'local-drafts').glob('*/draft_meta_info.json'):
            if self.store.is_link(path) or self.store.is_link(path.parent):continue
            if os.path.normcase(str(path.parent.resolve())) in known:continue
            try:meta,_=bridge.decode(bridge.stable_bytes(path),str(self.install))
            except (ValueError,RuntimeError,OSError):continue
            entries.append(dict(draft_fold_path=str(path.parent.resolve()),draft_name=meta.get('draft_name',path.parent.name),draft_id=meta.get('draft_id'),internal=True))
        return entries

    def resolve(self,key):
        if not isinstance(key,str) or not re.fullmatch('[a-f0-9]{24}',key):raise ValueError('草稿标识无效')
        matches=[e for e in self.entries() if self.key(e['draft_fold_path'])==key]
        if len(matches)!=1:raise ValueError('草稿已移动或索引中存在重复路径，请重新扫描')
        entry=matches[0];path=Path(entry['draft_fold_path']).resolve()
        if not path.is_dir():raise ValueError('草稿目录不存在：'+str(path))
        return entry,path

    @staticmethod
    def running():
        result=subprocess.run(['tasklist','/FO','CSV','/NH','/FI','IMAGENAME eq JianyingPro.exe'],capture_output=True,check=True,
                              creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        return b'JianyingPro.exe' in result.stdout

    def bindings(self):
        value=read_json(self.root/'bindings.json',{'schema':1,'episodes':{}})
        if not isinstance(value,dict) or not isinstance(value.get('episodes'),dict):raise ValueError('剪映关联记录损坏，请检查备份')
        return value

    def overview(self):
        rows=[]
        for e in self.entries():
            path=Path(e['draft_fold_path'])
            rows.append(dict(key=self.key(path),name=e.get('draft_name',path.name),draft_id=e.get('draft_id'),
                path=str(path),exists=path.is_dir(),modified=e.get('tm_draft_modified',0),duration_us=e.get('tm_duration',0)))
        rows.sort(key=lambda e:e['modified'],reverse=True)
        return dict(drafts=rows,bindings=self.bindings()['episodes'],editor_running=self.running(),
                    install=str(self.install),index=str(self.index),launch_executable=str(discover_launcher(self.install) or ''))

    def inspect(self,key):
        entry,path=self.resolve(key)
        # Cache full native objects only behind a newly verified collection
        # fingerprint. A simplified Baimu timeline is never used for writeback.
        revision=bridge.fingerprint(path)['revision']
        with self.lock:
            cached=self.cache.get(key)
            if cached and cached['state']['revision']==revision:
                state,meta=cached['state'],cached['meta']
                if bridge.fingerprint(path)['revision']!=revision:raise ValueError('读取期间草稿改变，请重试')
            else:
                state=bridge.load(path,str(self.install));meta={}
                meta_path=path/'draft_meta_info.json'
                if meta_path.is_file():meta,_=bridge.decode(bridge.stable_bytes(meta_path),str(self.install))
                if bridge.fingerprint(path)['revision']!=state['revision']:raise ValueError('读取期间草稿改变，请重试')
                if len(self.cache)>=3:self.cache.pop(next(iter(self.cache)))
                self.cache[key]={'state':state,'meta':meta}
        if entry.get('draft_id') and meta.get('draft_id') and entry['draft_id']!=meta['draft_id']:
            raise ValueError('首页索引与草稿项目ID不符，已拒绝接管该草稿')
        first=state['documents'][state['main_mirrors'][0]]['object']
        if state['main_timeline_id'] is None:raise ValueError('无法确定主时间线')
        text_rows=[]
        for t in first['materials'].get('texts',[]):
            try:text=json.loads(t['content']).get('text','')
            except (ValueError,KeyError):text=''
            linked=bool(t.get('words') or t.get('text_to_audio_ids') or t.get('recognize_task_id') or t.get('base_content'))
            try:
                styles=json.loads(t['content']).get('styles',[])
                simple=len(styles)==1 and styles[0].get('range') in ([0,len(text)],[0,len(text.encode('utf-16-le'))//2])
            except (ValueError,KeyError,TypeError,AttributeError):simple=False
            text_rows.append(dict(id=t['id'],text=text,editable=not linked and simple,
                reason='智能识别、关联或多样式文字；完整保留，当前只读' if linked or not simple else '支持单一样式原生文字修改'))
        summary=bridge.summary(state)
        all_materials={m['id']:m for rows in first['materials'].values() if isinstance(rows,list) for m in rows if isinstance(m,dict) and 'id' in m}
        def segment_row(segment):
            from .native_defaults import timerange
            material=all_materials.get(segment.get('material_id'),{});label=material.get('name','');font_size=None
            if material.get('content'):
                try:
                    rich=json.loads(material['content']);label=rich.get('text',label)
                    if rich.get('styles'):font_size=rich['styles'][0].get('size')
                except (ValueError,TypeError):pass
            tr=timerange(segment.get('target_timerange',{}))
            return dict(id=segment['id'],material_id=segment.get('material_id'),name=label or Path(material.get('path','')).name,
                start_us=tr['start'],duration_us=tr['duration'],volume=segment.get('volume',1),font_size=font_size,group_id=segment.get('group_id'))
        return dict(key=key,name=entry.get('draft_name',path.name),draft_id=entry.get('draft_id'),
            path=str(path),revision=state['revision'],main_timeline_id=state['main_timeline_id'],
            duration_us=first.get('duration',0),width=first.get('canvas_config',{}).get('width'),
            height=first.get('canvas_config',{}).get('height'),
            tracks=[dict(id=t.get('id'),name=t.get('name',''),type=t.get('type'),segments=len(t.get('segments',[])),
                items=[segment_row(s) for s in t.get('segments',[])]) for t in first['tracks']],
            timeline_count=len({d['object'].get('id') for d in state['documents'].values()}),
            texts=text_rows,media=summary['media_references'],editor_running=self.running(),
            mirror_files=state['main_mirrors'],identity_note='项目ID与时间线ID分别保存；当前草稿保持原生结构')

    def bind(self,body):
        project=self.store.get(body['project_id'])
        detail=self.inspect(body['key'])
        if body.get('revision') and body['revision']!=detail['revision']:raise ValueError('草稿已改变，请重新读取后关联')
        with self.lock:
            data=self.bindings();data['episodes'][project['id']]=dict(key=detail['key'],draft_id=detail['draft_id'],
                main_timeline_id=detail['main_timeline_id'],draft_path=detail['path'],name=detail['name'],
                observed_revision=detail['revision'],linked_at=time.time(),legacy_project_retained=True,
                shared=body.get('shared',True))
            write_json(self.root/'bindings.json',data)
        return dict(binding=data['episodes'][project['id']],project_id=project['id'])

    def _observed(self,key,revision):
        with self.lock:
            data=self.bindings();changed=False
            for row in data['episodes'].values():
                if row.get('key')==key:
                    row.update(observed_revision=revision,last_read=time.time());changed=True
            if changed:write_json(self.root/'bindings.json',data)

    def refresh(self,key):
        detail=self.inspect(key);self._observed(key,detail['revision']);return detail

    def snapshot(self,key):
        entry,path=self.resolve(key)
        box=self.root/'history'/key
        target=box/str(time.time_ns())
        result=bridge.snapshot(path,target,box,str(self.install))
        return dict(path=str(result),scope='当前控制文件备份，不包含全部外部媒体',name=entry.get('draft_name'))

    def verify(self,key):
        _,path=self.resolve(key);state=bridge.load(path,str(self.install));checks=[]
        for rel,doc in state['documents'].items():
            obj=doc['object'];raw=json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode()
            encoded=bridge.encrypt_draft_bytes(raw,jy_install_dir=str(self.install),timeout=30) if doc['encoding']=='jianying_local_dll' else raw
            reread,encoding=bridge.decode(encoded,str(self.install))
            diff=bridge.changes(obj,reread)
            if diff or encoding!=doc['encoding']:raise ValueError('编解码改变原生字段，已停止：'+rel)
            checks.append(dict(file=rel,changed_json_paths=diff,encoding=encoding))
        if bridge.fingerprint(path)['revision']!=state['revision']:raise ValueError('检查期间剪映改变了工程，请保存后重试')
        report=dict(key=key,revision=state['revision'],checked_at=time.time(),passed=True,files=checks,
            original_files_written=0,scope='当前全部活动时间线的字段编解码完整性；不等于修改后视觉无损验收')
        write_json(self.root/'checks'/(key+'.json'),report)
        return report

    def save_text(self,body):
        with self.lock:
            if not all(isinstance(body.get(k),str) for k in ('key','revision','material_id','old','new')):
                raise ValueError('文字、旧值、素材标识与版本不能为空，且应为字符串')
            if len(body['new'])>50000:raise ValueError('单条文字超出当前支持范围')
            key=body['key'];_,path=self.resolve(key)
            if self.pending_commits(key):raise ValueError('该草稿有未完成交接，请先恢复最近一次未完成提交')
            self.inspect(key)  # Includes index/sidecar identity checks.
            cached=self.cache.get(key)
            state=copy.deepcopy(cached['state']) if cached and bridge.fingerprint(path)['revision']==cached['state']['revision'] else bridge.load(path,str(self.install))
            if state['revision']!=body.get('revision'):raise ValueError('剪映草稿已有新版本，请重新读取；没有覆盖任何文件')
            if body['old']==body['new']:raise ValueError('文字没有改变，无需保存')
            if len(body['old'])!=len(body['new']) or len(body['old'].encode('utf-16-le'))!=len(body['new'].encode('utf-16-le')):
                raise ValueError(f"当前支持等长文字：原文 {len(body['old'])} 字，新文 {len(body['new'])} 字。原草稿未改动。")
            plan=bridge.plan_text(state,body['material_id'],body['old'],body['new'])
            box=self.root/'history'/key/str(time.time_ns());box.mkdir(parents=True)
            before=box/'before';staged=box/'prepared';before.mkdir();staged.mkdir()
            for rel,expected in state['files'].items():
                raw=bridge.stable_bytes(path/rel)
                if bridge.digest(raw)!=expected:raise ValueError('备份期间草稿改变，原草稿未写入')
                for dest in (before/rel,staged/rel):dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
            if bridge.fingerprint(path)['revision']!=state['revision']:raise ValueError('备份期间草稿改变，原草稿未写入')
            obj=copy.deepcopy(state['documents'][state['main_mirrors'][0]]['object'])
            ti=next(i for i,t in enumerate(obj['materials']['texts']) if t['id']==plan['material_id'])
            material=obj['materials']['texts'][ti];rich=json.loads(material['content']);old_rich=copy.deepcopy(rich)
            rich['text']=plan['new'];material['content']=json.dumps(rich,ensure_ascii=False,separators=(',',':'))
            if bridge.changes(old_rich,rich)!=['/text']:raise ValueError('文字差异检查未通过')
            raw=json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode();encoded={};changed_files=[]
            for rel in state['main_mirrors']:
                doc=state['documents'][rel];encoding=doc['encoding']
                diff=bridge.changes(doc['object'],obj)
                if diff!=[f'/materials/texts/{ti}/content']:raise ValueError('出现文字字段以外的改变，提交已停止')
                if encoding not in encoded:
                    candidate=bridge.encrypt_draft_bytes(raw,jy_install_dir=str(self.install),timeout=30) if encoding=='jianying_local_dll' else raw
                    reread,actual_encoding=bridge.decode(candidate,str(self.install))
                    if reread!=obj or actual_encoding!=encoding:raise ValueError('原格式往返检查未通过')
                    encoded[encoding]=candidate
                (staged/rel).write_bytes(encoded[encoding]);changed_files.append(dict(file=rel,changed_json_paths=diff))
            patch=dict(stage='complete_offline_only',changed_files=changed_files,production_files_written=0)
            report=dict(stage='prepared',key=key,source=str(path),before_revision=state['revision'],
                backup=str(before),plan=plan,patch=patch,files=[],created=time.time())
            journal=box/'commit.json';write_json(journal,report)
            if bridge.fingerprint(path)['revision']!=state['revision']:
                raise ValueError('写入前检测到草稿变化；原草稿未改动')
            report['stage']='committing';write_json(journal,report)
            expected_files=dict(state['files'])
            for rel in state['main_mirrors']:
                bridge.write_checked(path,rel,(staged/rel).read_bytes(),expected_files)
                report['files'].append(rel);report['stage']='committing';write_json(journal,report)
            fingerprint=bridge.fingerprint(path)
            if fingerprint['files']!=bridge.fingerprint(staged)['files']:
                raise ValueError('出现非预期文件变化，请查看交接记录：'+str(journal))
            after=copy.deepcopy(state);after.update(fingerprint)
            for rel in state['main_mirrors']:after['documents'][rel]['object']=copy.deepcopy(obj)
            self.cache[key]={'state':after,'meta':cached['meta'] if cached else {}}
            report.update(stage='saved_awaiting_editor_review',after_revision=after['revision'])
            write_json(journal,report);self._observed(key,after['revision'])
            return dict(saved=True,revision=after['revision'],journal=str(journal),backup=str(before),
                        detail=self.inspect(key),message='已保存，原版本已备份；请在剪映重开检查')

    def pending_commits(self,key):
        pending=[]
        for p in (self.root/'history'/key).glob('*/commit.json'):
            data=read_json(p,{})
            if data.get('stage')=='committing':pending.append((p,data))
        return sorted(pending,key=lambda item:str(item[0]))

    def recover(self,key):
        with self.lock:
            _,path=self.resolve(key);pending=self.pending_commits(key)
            if not pending:raise ValueError('没有需要恢复的未完成提交')
            journal,data=pending[-1];box=journal.parent
            if Path(data['source']).resolve()!=path:raise ValueError('恢复记录与当前草稿位置不符')
            original=bridge.fingerprint(box/'before')['files'];current=bridge.fingerprint(path)['files']
            mirrors=data['plan']['mirror_files']
            if set(current)!=set(original):raise ValueError('控制文件集合已改变，拒绝自动恢复')
            for rel,sha in current.items():
                allowed={original[rel]}
                if rel in mirrors:allowed.add(bridge.digest((box/'prepared'/rel).read_bytes()))
                if sha not in allowed:raise ValueError('草稿存在提交记录以外的新变化，拒绝覆盖：'+rel)
            # Capture the partial state as raw files, without calling load(),
            # because its root/main mirrors may deliberately be inconsistent.
            # Keep names short: Windows CopyFile2 rejects otherwise valid
            # deeply nested paths near MAX_PATH in embedded Python runtimes.
            number=0
            while (box/f'p{number}').exists():number+=1
            partial=box/f'p{number}'
            for rel in current:
                dest=partial/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path/rel,dest)
            expected_files=dict(current)
            for rel in mirrors:
                bridge.write_checked(path,rel,(box/'before'/rel).read_bytes(),expected_files)
            restored=bridge.load(path,str(self.install))
            if restored['revision']!=data['before_revision']:raise ValueError('恢复后版本校验未通过，请保留记录检查')
            data.update(stage='rolled_back',recovered=time.time(),partial_backup=str(partial));write_json(journal,data)
            return dict(restored=True,revision=restored['revision'],detail=self.inspect(key))

    def launch(self):
        # Resolve on every click so an upgrade while Baimu is open is detected.
        exe=discover_launcher(self.install)
        if exe is None:raise ValueError('未检测到可启动的剪映程序，请安装剪映或启动一次剪映后重新扫描')
        subprocess.Popen([str(exe)],cwd=str(exe.parent),close_fds=True)
        return dict(launched=True,executable=str(exe),message='已启动剪映，请在首页打开所选草稿；返回百慕会重新读取当前版本')

    def reveal(self,key):
        _,path=self.resolve(key);os.startfile(path)
        return dict(opened=True)

    def migration_report(self,project_id):
        from .native_migration import migration_report
        project=self.store.get(project_id)
        if project.get('native',{}).get('shared'):
            from .core import timeline
            clips,duration=timeline(project)
            return dict(project_id=project_id,revision=project['revision'],name=project['name'],series=project.get('series',''),duration=duration,
                clips=len(clips),audios=len(project['audios']),captions=len(project['captions']),masks=len(project['masks']),missing=[],changed=[],
                editable_available=True,editable_blocked=[],editable_warnings=['登记当前同一份原生草稿，不重新生成时间线或烘焙图层'],
                film_available=False,film_notice='本集已使用原生共同工程，无需复制成片',offline_audio_available=False,source_project_retained=True,
                shared=True,preservation=dict(exact_available=True,exact_verified=False,unresolved=[]))
        return migration_report(self.store,self.store.get(project_id))

    def export_project(self,body):
        from .native_migration import export_project
        project=self.store.get(body['project_id'])
        if project.get('native',{}).get('shared') and body.get('mode','editable')=='editable':
            return self.store.shared_timeline.register(project['id'],body.get('revision'))
        return export_project(self,body)
