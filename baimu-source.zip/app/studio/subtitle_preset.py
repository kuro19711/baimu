"""User-supplied typeface and finished-video preset with explicit unit mappings."""
import copy
from pathlib import Path
from .core import STYLE, validate_style
from .store import write_json

PRESET_ID='noto-semibold-877153-v3-jianying-units'
LEGACY_PRESET_ID='noto-semibold-reference-v1'
PREVIOUS_PRESET_ID='noto-semibold-877153-v2'
# Frozen v1 defaults, including values inherited from STYLE at the time. Never
# infer an old managed baseline from future STYLE defaults or from user data.
LEGACY_MANAGED_STYLE=dict(font_size=64, x=50, y=78.5, color='#ffffff', opacity=.5,
                          outline_color='#000000', outline_opacity=1, outline=2,
                          max_width=84, spacing=0, line_spacing=0, bold=False, shadow=5,
                          shadow_opacity=.1, shadow_angle=-45, shadow_blur=2)
# Internal rendering remains in 1080-canvas pixels; the editor shows this as
# Jianying size 14 through the accepted 64px-to-14 native calibration.
REFERENCE_STYLE=dict(font_size=64, x=50, y=70.9, color='#ffffff', opacity=1,
                     outline_color='#000000', outline_opacity=1, outline=3, max_width=84,
                     spacing=0, line_spacing=2, bold=False, shadow=5,
                     shadow_opacity=.1, shadow_angle=-45, shadow_blur=2)
REFERENCE_NOTE=('参考用户成片877153-1.mp4：百慕与剪映统一显示字号14（内部1080画布渲染为64像素）、水平50%、垂直70.9%、最大宽度84%。'
                '纯白文字、不透明度100%、黑色描边3（1080画布像素，交接约对应剪映面板15）。字号使用剪映数值，描边由百慕按画布像素换算。'
                '额外行距补偿2像素，双行步进约89像素，以烧录结果近似匹配参考，不宣称逐像素一致。'
                '阴影无法从成片可靠反推，因此保留旧参数：黑色、10%不透明度、距离5、角度-45°、模糊2像素；需以烧录审阅版确认。'
                '居中、缩放100%、旋转0°、无动画；长句只断行，不缩小。')


def _managed_previous(settings,font_id):
    previous=settings.get('subtitle_reference_preset')
    if not isinstance(previous,dict) or previous.get('id') not in (LEGACY_PRESET_ID,PREVIOUS_PRESET_ID):
        return False
    current=settings.get('subtitle_default_style')
    if not isinstance(current,dict):return False
    try:validate_style(current)
    except (ValueError,TypeError,KeyError):return False
    # A separately selected default font is also a user choice, even when the
    # old style's font_id happens still to point at the bundled face.
    if settings.get('default_font_id') not in (None,'',font_id):return False
    expected=LEGACY_MANAGED_STYLE if previous.get('id')==LEGACY_PRESET_ID else REFERENCE_STYLE
    return current==dict(expected,font_id=font_id)


def install_reference_preset(store, font_path):
    """Idempotent defaults install. Do not rewrite projects or reset later edits."""
    path=Path(font_path)
    if not path.is_file():
        raise ValueError('默认字体文件缺失，请恢复 assets/fonts/NotoSans-SemiBold.ttf')
    with store.lock:
        font=store.import_font(path)
        previous=store.settings.get('subtitle_reference_preset')
        if isinstance(previous,dict) and previous.get('id')==PRESET_ID:
            return font
        style=dict(STYLE, **REFERENCE_STYLE)
        style['font_id']=font['id']
        validate_style(style)
        settings=copy.deepcopy(store.settings)
        fresh=(previous is None and 'subtitle_default_style' not in settings
               and settings.get('default_font_id') in (None,'',font['id']))
        if fresh or _managed_previous(settings,font['id']):
            settings['subtitle_default_style']=copy.deepcopy(style)
            settings['default_font_id']=font['id']
        # The interface font is independent from a film's subtitle appearance.
        settings.setdefault('ui_font_id',font['id'])
        settings['subtitle_reference_preset']=dict(id=PRESET_ID, name='Noto Sans SemiBold · 877153-1成片参考预设',
                                                   style=copy.deepcopy(style), note=REFERENCE_NOTE, source_font=path.name,
                                                   source_video='877153-1.mp4')
        write_json(store.root/'settings.json',settings)
        store.settings=settings
        return font
