"""Deterministic local FFmpeg pipeline: retained original audio, real mixed preview."""
from __future__ import annotations
import hashlib
import copy
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import wave
from array import array
from pathlib import Path
from .core import ass_text, digest, fps_value, sound_digest, layer_digests, source_end_limit, timeline, uid, wrap_text
from .masking import visual_filter
from .export_quality import export_profile, picture_filter

ROOT = Path(__file__).resolve().parents[1]
RENDER_VERSION = '4-positioned-picture-and-audio'
_MODEL_CACHE = {}
_MODEL_LOCK = threading.Lock()


def binary(name):
    suffix = '.exe' if os.name == 'nt' else ''
    candidates = [os.environ.get(name.upper()+'_PATH', ''), str(ROOT/'bin'/(name+suffix)), shutil.which(name) or '']
    cache = Path(tempfile.gettempdir())/'chatcut-media-cache'
    if cache.exists():
        candidates += [str(p) for p in cache.glob('*/win32-x64/'+name+'.exe')]
    for value in candidates:
        if value and Path(value).is_file():
            return str(Path(value).resolve())
    raise ValueError(f'找不到{name}。请将{name+suffix}放到软件bin目录，或设置{name.upper()}_PATH。')


def process(args, cwd=None, job=None, timeout=3600):
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    # File logs prevent pipe deadlocks and do not keep a full render log in RAM.
    with tempfile.TemporaryFile(mode='w+b') as log:
        p = subprocess.Popen([str(x) for x in args], cwd=cwd, stdout=log, stderr=subprocess.STDOUT,
                             creationflags=flags, stdin=subprocess.DEVNULL)
        start = time.monotonic()
        while p.poll() is None:
            if (job and job.get('cancel_requested')) or time.monotonic()-start > timeout:
                p.terminate()
                try:
                    p.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    p.kill()
                    p.wait()
                raise ValueError('任务已取消或超时；已有工程及原素材未改动')
            time.sleep(.1)
        log.seek(0)
        data = log.read().decode('utf-8', errors='replace')
        if p.returncode:
            raise ValueError('媒体处理失败：'+data[-4500:])
        return data


def media_info(path):
    out = subprocess.check_output([binary('ffprobe'), '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(path)],
                                  creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0, timeout=30)
    return json.loads(out)


def _number(value, default=0):
    try:
        n = float(value)
        return n if math.isfinite(n) else default
    except (ValueError, TypeError):
        return default


def stream_bounds(stream, info):
    """Source times are relative to the container start, as FFmpeg input -ss is."""
    origin = _number(info.get('format', {}).get('start_time'))
    absolute_start = _number(stream.get('start_time'), origin)
    start = max(0, absolute_start - origin)
    duration = _number(stream.get('duration'))
    if duration <= 0 and stream.get('duration_ts') is not None:
        from fractions import Fraction
        try:
            duration = int(stream['duration_ts']) * float(Fraction(stream['time_base']))
        except (ValueError, KeyError, ZeroDivisionError):
            pass
    if duration <= 0:
        tagged = stream.get('tags', {}).get('DURATION', '')
        try:
            h, m, s = tagged.split(':')
            # Matroska's DURATION tag denotes the stream end timestamp.
            duration = max(0, int(h)*3600+int(m)*60+float(s)-absolute_start)
        except (ValueError, AttributeError):
            pass
    verified = duration > 0
    if not verified:
        duration = max(0, _number(info.get('format', {}).get('duration'))-start)
    return dict(start=start, duration=duration, end=start+duration, duration_verified=verified)


def stream_metadata(info):
    return [dict(index=s['index'], codec=s.get('codec_name', ''), channels=s.get('channels', 0),
                 sample_rate=int(s.get('sample_rate') or 0), language=s.get('tags', {}).get('language', ''),
                 title=s.get('tags', {}).get('title', ''), **stream_bounds(s, info))
            for s in info.get('streams', []) if s['codec_type']=='audio']


def picture_only_stream(stream):
    """Album artwork in an audio file is not a playable video track."""
    return bool(stream.get('disposition', {}).get('attached_pic'))


def probe(path):
    path = Path(path)
    info = media_info(path)
    video = next((s for s in info['streams']
                  if s['codec_type']=='video' and not picture_only_stream(s)), None)
    from fractions import Fraction
    fps = float(Fraction(video.get('avg_frame_rate', '0/1'))) if video and video.get('avg_frame_rate') != '0/0' else 0
    bounds = stream_bounds(video, info) if video else None
    streams = stream_metadata(info)
    duration = bounds['end'] if bounds else max((s['end'] for s in streams), default=0)
    if duration <= 0:
        raise ValueError(f'无法确定素材时长：{path.name}')
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024), b''):
            h.update(block)
    stat = path.stat()
    return dict(id=uid(), path=str(path.resolve()), name=path.name, duration=duration, fps=fps,
                fps_fraction=video.get('avg_frame_rate', '24/1') if video else None,
                width=video.get('width', 0) if video else 0, height=video.get('height', 0) if video else 0,
                kind='video' if video else 'audio', has_audio=bool(streams), audio_streams=streams,
                video_stream_index=video['index'] if video else None,
                video_start=bounds['start'] if bounds else None,
                video_duration=bounds['duration'] if bounds else None,
                video_end=bounds['end'] if bounds else None,
                video_duration_verified=bounds['duration_verified'] if bounds else None,
                size=stat.st_size, mtime_ns=stat.st_mtime_ns, sha256=h.hexdigest())


def audio_stream(asset, item, info=None):
    """Return an absolute stream index; never guess among multiple recordings."""
    streams = stream_metadata(info) if info is not None else asset.get('audio_streams')
    if streams is None:
        # Older projects did not store streams; inspect without mutating them.
        streams = stream_metadata(media_info(asset['path']))
    if not streams:
        if item.get('audio_stream') is not None:
            raise ValueError(f'{asset["name"]}没有所选音轨，请重新选择')
        return None
    chosen = item.get('audio_stream')
    if chosen is None:
        if len(streams) != 1:
            raise ValueError(f'{asset["name"]}含{len(streams)}条音轨；请试听并选择人物原声所在音轨，不能默认丢掉其他对白')
        chosen = streams[0]['index']
    if isinstance(chosen, bool) or not isinstance(chosen, int) or chosen not in [s['index'] for s in streams]:
        raise ValueError(f'{asset["name"]}所选音轨不存在，请重新选择')
    return next(s for s in streams if s['index']==chosen)


def ensure_space(target, duration, video=False, width=1080, enhance_hd=False):
    rate = ((5_000_000 if width>540 else 2_500_000) if video else 900_000)
    required = 64*1024*1024 + int(duration * rate * (1.5 if enhance_hd and video else 1))
    free = shutil.disk_usage(target).free
    if free < required:
        raise ValueError(f'工作磁盘空间不足：本次保守预计需要{required/1024**3:.2f} GB，剩余{free/1024**3:.2f} GB。请清理已确认不需要的缓存或更换数据目录；原素材未改动。')


def preflight(project):
    if project.get('native',{}).get('issues'):
        raise ValueError('当前原生工程包含本地渲染尚未支持的内容：'+'；'.join(project['native']['issues']))
    assets = {a['id']:a for a in project['assets']}
    clips, duration = timeline(project)
    if not clips:
        raise ValueError('请先添加视频片段')
    if duration > 3600:
        raise ValueError('当前版本单集限制一小时，请分集处理')
    used = {c['asset_id'] for c in clips} | {a['asset_id'] for a in project['audios']}
    inspected = {}
    for aid in used:
        asset = assets[aid]
        path = Path(asset['path'])
        if not path.is_file() or path.stat().st_size != asset['size'] or path.stat().st_mtime_ns != asset['mtime_ns']:
            raise ValueError(f'素材已移动或改变，请重新导入：{asset["name"]}')
        inspected[aid] = media_info(path)
    streams = {}
    for item in clips + project['audios']:
        asset, info = assets[item['asset_id']], inspected[item['asset_id']]
        stream = None if item.get('audio_detached') else audio_stream(asset, item, info)
        streams[item['id']] = stream
        if item in clips:
            video = next((s for s in info['streams']
                          if s['codec_type']=='video' and not picture_only_stream(s)), None)
            if not video:
                raise ValueError(f'{asset["name"]}没有视频轨道')
            bounds = stream_bounds(video, info)
            if not bounds['duration_verified']:
                raise ValueError(f'无法确认{asset["name"]}实际视频帧结束时间；请先转换为带有效时长的MP4，不能按较长音轨补冻结画面')
            compatible_end=source_end_limit(asset,project['fps'],True,bounds['end'])
            if item['in'] < bounds['start']-0.002 or item['in']+item['duration'] > compatible_end:
                raise ValueError(f'{asset["name"]}所选画面超出实际视频流范围 {bounds["start"]:.3f}–{bounds["end"]:.3f} 秒，请调整入出点')
        else:
            if stream is None:
                raise ValueError(f'音频素材没有音轨：{asset["name"]}')
            if not stream['duration_verified']:
                raise ValueError(f'无法确认{asset["name"]}所选音轨有效时长，请转换为WAV/M4A再导入')
            if item['in'] < stream['start']-0.002 or item['out'] > stream['end']+0.002:
                raise ValueError(f'{asset["name"]}所选音频超过该音轨有效范围 {stream["start"]:.3f}–{stream["end"]:.3f} 秒')
    return assets, clips, duration, streams


def font_info(path):
    from fontTools.ttLib import TTFont
    font = TTFont(str(path), lazy=True)
    try:
        name = font['name']
        family = name.getDebugName(1) or path.stem
        full = name.getDebugName(4) or family
        selection = getattr(font.get('OS/2'), 'fsSelection', 0)
        units=font['head'].unitsPerEm
        os2=font.get('OS/2')
        # libass's requested height is based on Windows ascent+descent, while
        # browser/Pillow font-size is an em. Keep their physical sizes equal.
        ass_scale=(os2.usWinAscent+os2.usWinDescent)/units if os2 else 1
        line_height=(font['hhea'].ascent-font['hhea'].descent+font['hhea'].lineGap)/units
        return dict(family=family, name=full, bold=bool(selection & 32), italic=bool(selection & 1),
                    weight=getattr(os2, 'usWeightClass', 400),ass_size_scale=ass_scale,
                    line_height=line_height)
    finally:
        font.close()


def caption_preflight(project, fonts):
    """Conservative font-metric bounds, not a substitute for libass visual QA."""
    from PIL import ImageFont
    from fontTools.ttLib import TTFont
    wrapped = copy.deepcopy(project)
    cmaps = {}
    for cue in wrapped['captions']:
        st = dict(wrapped['style'], **cue.get('style', {}))
        face = fonts.get(st['font_id'])
        if not face or not Path(face['path']).is_file():
            raise ValueError('字幕字体不存在，请重新选择字体')
        if st['font_id'] not in cmaps:
            font = TTFont(face['path'], lazy=True)
            try:
                cmaps[st['font_id']] = font.getBestCmap() or {}
            finally:
                font.close()
        text = cue['text'].replace('\\', '＼').replace('{', '｛').replace('}', '｝')
        missing = {ch for ch in text if not ch.isspace() and ord(ch) not in cmaps[st['font_id']]}
        if missing:
            raise ValueError('所选字体缺少这些字形，请换字体，不能静默回退：'+''.join(sorted(missing))[:80])
        from .native_caption import layout
        cue['text'] = layout(cue['text'],face['path'],st)['native_text']
        font = ImageFont.truetype(face['path'], round(st['font_size']))
        lines = cue['text'].splitlines() or ['']
        line_width = max(font.getlength(line)+max(0,len(line)-1)*st['spacing'] for line in lines)
        synthetic_bold = bool(st['bold']) and not face.get('bold', False)
        # libass synthetic bold may be wider than the underlying font metrics.
        line_width += st['font_size']*.06 if synthetic_bold else 0
        ascent, descent = font.getmetrics()
        line_height = (ascent+descent)*len(lines)+max(0,len(lines)-1)*st.get('line_spacing',0)
        padding = st['outline']+st['shadow']+st.get('shadow_blur',0)*2+2
        x, y = 1080*st['x']/100, 1920*st['y']/100
        if line_width > 1080*st['max_width']/100+2:
            raise ValueError(f'{cue["start"]:.2f}秒字幕超过设置宽度，请拆行或换字体；不会自动缩小字号')
        if x-line_width/2-padding < 0 or x+line_width/2+padding > 1080 or y-line_height/2-padding < 0 or y+line_height/2+padding > 1920:
            raise ValueError(f'{cue["start"]:.2f}秒字幕可能超出画面，请调整位置或拆成分时字幕；不会自动缩小字号')
    return wrapped


def video_cache_key(asset, clip, width, height, fps, preview, enhance_hd=False):
    # Exclude timeline position/clip id: moving a shot need not re-encode it.
    profile = dict(version=RENDER_VERSION, sha256=asset['sha256'], source_in=clip['in'],
                   duration=clip['duration'], width=width, height=height, fps=str(fps),
                   codec='libx264', preset='ultrafast' if preview else 'veryfast',
                   crf=23 if preview else 18, pix_fmt='yuv420p')
    if enhance_hd:
        # Keep legacy keys unchanged; enhanced and ordinary clips never alias.
        profile['enhancement'] = export_profile(enhance_hd)
        profile['crf'] = profile['enhancement']['crf']
    return hashlib.sha256(json.dumps(profile, sort_keys=True).encode()).hexdigest()


def valid_video_cache(path, width, height, duration, fps, require_marker=True):
    try:
        if require_marker:
            marker = json.loads(path.with_suffix('.complete.json').read_text(encoding='utf-8'))
            stat = path.stat()
            if marker != dict(version=RENDER_VERSION, size=stat.st_size, mtime_ns=stat.st_mtime_ns):
                return False
        info = media_info(path)
        video = next(s for s in info['streams'] if s['codec_type']=='video')
        actual = stream_bounds(video, info)['end']
        return (video.get('width')==width and video.get('height')==height and
                abs(actual-duration)<=max(.025, 1.1/fps_value(fps)))
    except (OSError, ValueError, StopIteration, KeyError, subprocess.SubprocessError):
        return False


def cache_video(asset, clip, width, height, fps, preview, cache, job, enhance_hd=False):
    profile = export_profile(enhance_hd)
    if enhance_hd and preview:
        raise ValueError('请使用审阅版导出检查一键高清效果，不支持低分辨率混音预览')
    out = cache/(video_cache_key(asset,clip,width,height,fps,preview,enhance_hd)+'.mkv')
    if valid_video_cache(out,width,height,clip['duration'],fps):
        return out
    partial = cache/(out.stem+'.'+uid()+'.partial.mkv')
    marker = out.with_suffix('.complete.json')
    marker_tmp = marker.with_name(marker.name+'.'+uid()+'.tmp')
    try:
        process([binary('ffmpeg'),'-hide_banner','-loglevel','warning','-y','-ss',str(clip['in']),'-i',asset['path'],
                 '-t',str(clip['duration']),'-map','0:v:0','-an',
                 '-vf',picture_filter(width,height,fps,enhance_hd),
                 '-c:v','libx264','-preset','ultrafast' if preview else 'veryfast','-crf','23' if preview else str(profile['crf']),
                 '-pix_fmt','yuv420p',str(partial)],job=job)
        if not valid_video_cache(partial,width,height,clip['duration'],fps,False):
            raise ValueError('视频缓存未通过尺寸/时长验收，请检查源片段；不会把未完成缓存用于导出')
        os.replace(partial,out)
        stat=out.stat()
        marker_tmp.write_text(json.dumps(dict(version=RENDER_VERSION,size=stat.st_size,mtime_ns=stat.st_mtime_ns)),encoding='utf-8')
        os.replace(marker_tmp,marker)
        return out
    finally:
        partial.unlink(missing_ok=True)
        marker_tmp.unlink(missing_ok=True)


def _original_audio(assets, clips, streams, target, job):
    """Exactly the same PCM cuts are used for preview, export and ASR preparation."""
    duration=max(c['end'] for c in clips)
    args=[binary('ffmpeg'),'-hide_banner','-loglevel','warning','-y','-f','lavfi','-t',str(duration),'-i','anullsrc=r=48000:cl=stereo']
    filters=[]
    labels=['[0:a]']
    for index,clip in enumerate(clips,1):
        stream=streams[clip['id']]
        if stream is None:
            args += ['-f','lavfi','-i','anullsrc=r=48000:cl=stereo']
            source=f'{index}:a:0'
        else:
            args += ['-ss',str(clip['in']),'-i',assets[clip['asset_id']]['path']]
            source=f'{index}:{stream["index"]}'
        # Round cumulative endpoints, not every duration independently: many
        # rational-fps cuts must not accumulate a sample-clock timing drift.
        count=round(clip['end']*48000)-round(clip['start']*48000)
        filters.append(f'[{source}]aresample=48000:async=1:first_pts=0,aformat=sample_fmts=fltp:channel_layouts=stereo,apad,atrim=end_sample={count},asetpts=PTS-STARTPTS,volume={clip.get("gain",0)}dB,adelay={round(clip["start"]*48000)}S:all=1[c{index}]')
        labels.append(f'[c{index}]')
    filters.append(''.join(labels)+f'amix=inputs={len(labels)}:duration=first:normalize=0[original]')
    graph=target/'original-audio-filter.txt'
    graph.write_text(';'.join(filters),encoding='utf-8')
    output=target/'original.wav'
    # Keep headroom until the final limiter; positive clip gain must not clip here.
    process(args+['-filter_complex_script',str(graph),'-map','[original]','-c:a','pcm_f32le',str(output)],job=job)
    return output


def music_envelope(audio, duration):
    """Short endpoint fades suppress clicks; not beat matching or crossfading."""
    length=audio['out']-audio['in']
    fade=min(.01,length/4)
    filters=f',afade=t=in:st=0:d={fade},afade=t=out:st={max(0,length-fade)}:d={fade}'
    if audio.get('loop'):
        length=min(audio.get('loop_duration',duration),max(0,duration-audio['start']))
        offset=audio.get('loop_offset',0)
        filters+=f',aloop=loop=-1:size={max(1,round((audio["out"]-audio["in"])*48000))},atrim=start={offset}:duration={length},asetpts=PTS-STARTPTS'
    length=min(length,max(0,duration-audio['start']))
    if length>0:
        endfade=min(.08,length/4)
        filters+=f',afade=t=out:st={max(0,length-endfade)}:d={endfade}'
    return filters


def _mix_audio(project, assets, clips, duration, streams, target, job):
    original=_original_audio(assets,clips,streams,target,job)
    args=[binary('ffmpeg'),'-hide_banner','-loglevel','warning','-y','-i',str(original)]
    filters=[f'[0:a]aresample=48000,apad,atrim=duration={duration},asetpts=PTS-STARTPTS[original]']
    voice_labels,bgm_labels=['[original]'],[]
    for index,audio in enumerate(project['audios'],1):
        if audio['start']>=duration:
            raise ValueError('音频起点已超出成片结尾，请移到画面范围内或删除该未使用片段')
        asset=assets[audio['asset_id']]
        stream=streams[audio['id']]
        args += ['-i',asset['path']]
        label=f'a{index}'
        native=project.get('native',{}).get('shared')
        extra=music_envelope(audio,duration) if audio['role']=='bgm' and not native else ''
        if audio.get('fade_in',0)>0:extra+=f',afade=t=in:st=0:d={audio["fade_in"]}'
        if audio.get('fade_out',0)>0:
            length=audio['out']-audio['in'];extra+=f',afade=t=out:st={max(0,length-audio["fade_out"])}:d={audio["fade_out"]}'
        volume='0' if audio.get('muted') else f'{audio.get("gain",0)}dB'
        filters.append(f'[{index}:{stream["index"]}]aresample=48000:async=1:first_pts=0,atrim=start={audio["in"]}:end={audio["out"]},asetpts=PTS-STARTPTS{extra},volume={volume},adelay={round(audio["start"]*48000)}S:all=1[{label}]')
        (bgm_labels if audio['role']=='bgm' else voice_labels).append(f'[{label}]')
    filters.append(''.join(voice_labels)+f'amix=inputs={len(voice_labels)}:duration=first:normalize=0,atrim=duration={duration},asplit=2[voiceout][voiceforbgm]')
    if project.get('native',{}).get('shared'):
        labels=['[voiceforbgm]']+bgm_labels
        filters.append(''.join(labels)+f'amix=inputs={len(labels)}:duration=first:normalize=0,alimiter=limit=1:level=0:latency=1[mixed]')
    elif bgm_labels:
        filters += [''.join(bgm_labels)+f'amix=inputs={len(bgm_labels)}:normalize=0,apad,atrim=duration={duration}[music]',
                    '[voiceforbgm]asplit=2[side][dry]',
                    '[music][side]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=450[ducked]',
                    '[dry][ducked]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95:latency=1[mixed]']
    else:
        filters.append('[voiceforbgm]alimiter=limit=0.95:latency=1[mixed]')
    graph=target/'mix-audio-filter.txt'
    graph.write_text(';'.join(filters),encoding='utf-8')
    job.update(message='生成最终混音（原声检查轨仍包含源片自带音乐/音效）',progress=.66)
    process(args+['-filter_complex_script',str(graph),'-map','[voiceout]','-c:a','pcm_s16le',str(target/'speech.wav'),
                  '-map','[mixed]','-c:a','pcm_s16le',str(target/'final_mix.wav')],job=job)


def prepare_audio(project, target, job):
    """No video encoding: shared mix, same AAC settings, then decoded ASR PCM."""
    target=Path(target)
    target.mkdir(parents=True,exist_ok=True)
    assets,clips,duration,streams=preflight(project)
    ensure_space(target,duration)
    _mix_audio(project,assets,clips,duration,streams,target,job)
    base=[binary('ffmpeg'),'-hide_banner','-loglevel','warning','-y']
    process(base+['-i',str(target/'final_mix.wav'),'-c:a','aac','-b:a','192k','-t',str(duration),str(target/'mixed-audio.m4a')],job=job)
    output=target/'rendered_audio.wav'
    process(base+['-i',str(target/'mixed-audio.m4a'),'-ac','1','-ar','16000','-c:a','pcm_s16le',str(output)],job=job)
    return output


def render(project, target, fonts, job, captions=False, preview=True, enhance_hd=False):
    """One immutable project snapshot per render; no browser audio capture needed."""
    profile = export_profile(enhance_hd)
    if enhance_hd and preview:
        raise ValueError('请使用审阅版导出检查一键高清效果，不支持低分辨率混音预览')
    target = Path(target)
    target.mkdir(parents=True, exist_ok=True)
    assets, clips, duration, streams = preflight(project)
    # Reject missing glyphs and overflow before spending time encoding video.
    wrapped = caption_preflight(project,fonts) if captions and project['captions'] else None
    ff = binary('ffmpeg')
    width = 540 if preview else project['width']
    height = width * 16 // 9
    ensure_space(target,duration,video=True,width=width,enhance_hd=enhance_hd)
    base = [ff, '-hide_banner', '-loglevel', 'warning', '-y']
    part_paths = []
    cache = target.parent.parent/'cache'
    cache.mkdir(exist_ok=True)
    cursor=0
    for index, clip in enumerate(clips):
        if clip['from_frame']>cursor:
            gap=target/f'gap-{index}.mkv'
            process(base+['-f','lavfi','-i',f'color=c=black:s={width}x{height}:r={project["fps"]}',
                          '-frames:v',str(clip['from_frame']-cursor),'-an','-c:v','libx264','-preset','veryfast',
                          '-pix_fmt','yuv420p','-r',str(project['fps']),str(gap)],job=job)
            part_paths.append(gap)
        job.update(message=f'{"一键高清 · " if enhance_hd else ""}保留原声并处理画面 {index+1}/{len(clips)}', progress=.05+.48*index/len(clips))
        asset = assets[clip['asset_id']]
        out=cache_video(asset,clip,width,height,project['fps'],preview,cache,job,enhance_hd)
        part_paths.append(out)
        cursor=clip['to_frame']
    total_frames=round(duration*fps_value(project['fps']))
    if cursor<total_frames:
        tail=target/'tail-black.mkv'
        process(base+['-f','lavfi','-i',f'color=c=black:s={width}x{height}:r={project["fps"]}',
            '-frames:v',str(total_frames-cursor),'-an','-c:v','libx264','-preset','veryfast','-pix_fmt','yuv420p',str(tail)],job=job)
        part_paths.append(tail)
    concat_file = target/'concat.txt'
    concat_file.write_text(''.join("file '"+str(p).replace('\\','/').replace("'", "'\\''")+"'\n" for p in part_paths), encoding='utf-8')
    job.update(message='合并画面；原声使用与识别预览一致的PCM剪接', progress=.56)
    picture = target/'picture.mkv'
    process(base+['-f','concat','-safe','0','-i',str(concat_file),'-c','copy',str(picture)], job=job)
    _mix_audio(project,assets,clips,duration,streams,target,job)
    output = target/('preview.mp4' if preview else 'film.mp4')
    burn_masks=bool(project.get('masks')) and not preview
    args = base+['-i',str(picture),'-i',str(target/'final_mix.wav')]
    if wrapped:
        font_dir = target/'fonts'
        font_dir.mkdir(exist_ok=True)
        ids = {dict(project['style'], **c.get('style', {}))['font_id'] for c in project['captions']}
        for fid in ids:
            src = Path(fonts[fid]['path'])
            shutil.copy2(src, font_dir/(fid+src.suffix))
        (target/'captions.ass').write_text(ass_text(wrapped, fonts), encoding='utf-8-sig')
    if wrapped or burn_masks:
        # Editing previews retain a clean picture; live layers are composited in the UI.
        graph=target/'visual-filter.txt'
        graph.write_text(visual_filter(project,width,bool(wrapped)),encoding='utf-8')
        args += ['-filter_complex_script',str(graph),'-c:v','libx264','-preset','veryfast','-crf',str(profile['crf'])]
    else:
        args += ['-c:v','copy']
    args += ['-map','[visual]' if wrapped or burn_masks else '0:v:0','-map','1:a:0',
             '-c:a','aac','-b:a','192k','-t',str(duration),'-movflags','+faststart',str(output)]
    job.update(message='输出视频（带字幕时使用实际字体渲染）', progress=.80)
    render_log = process(args, cwd=target, job=job)
    (target/'render.log').write_text(render_log, encoding='utf-8')
    # Diagnostics come from the actual muxed final output, including encoder timing.
    process(base+['-i',str(output),'-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',str(target/'rendered_audio.wav')], job=job)
    job.update(message='计算实际输出波形', progress=.93)
    peaks = waveform(target/'rendered_audio.wav')
    (target/'waveform.json').write_text(json.dumps(peaks), encoding='utf-8')
    metadata = dict(project_id=project['id'], project_hash=digest(project), sound_digest=sound_digest(project),
                    width=width, height=height, fps=project['fps'], duration=duration,
                    captions_burned=captions, masks_burned=burn_masks, layers=layer_digests(project),clean_picture=preview,
                    mask_effect_version='rgb-box-v1',output=str(output), actual_listen='pending',
                    audio_measurement=audio_levels(target/'final_mix.wav'),renderer_version=RENDER_VERSION,
                    export_quality=profile,
                    frame_rate_notice='固定帧率转换可能重复/丢帧，仍需实际验收',
                    music_notice='BGM仅进行短接缝淡化及压低；未自动完成节拍衔接或LUFS验收')
    (target/'manifest.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
    (target/'project.json').write_text(json.dumps(project, ensure_ascii=False, indent=2), encoding='utf-8')
    return dict(metadata, file=output.name, waveform=peaks)


def waveform(path):
    with wave.open(str(path), 'rb') as f:
        rate, count = f.getframerate(), f.getnframes()
        step = max(1, round(rate/50))
        peaks = []
        while data := f.readframes(step):
            values = array('h', data)
            peaks.append(round(max((abs(v) for v in values), default=0)/32768, 4))
        return dict(peaks=peaks, step=step/rate, duration=count/rate)


def audio_levels(path):
    """Sample-domain diagnostic, explicitly not integrated LUFS/true peak."""
    import numpy as np
    peak,total,count,clipped=0.0,0.0,0,0
    with wave.open(str(path),'rb') as f:
        if f.getsampwidth()!=2:
            raise ValueError('内部音频诊断要求16位PCM')
        while raw:=f.readframes(48000):
            values=np.frombuffer(raw,dtype='<i2').astype(np.float64)/32768
            peak=max(peak,float(np.max(np.abs(values),initial=0)))
            total+=float(np.dot(values,values))
            count+=values.size
            clipped+=int(np.count_nonzero(np.abs(values)>=32767/32768))
    rms=math.sqrt(total/count) if count else 0
    return dict(sample_peak_dbfs=round(20*math.log10(peak),2) if peak else None,
                rms_dbfs=round(20*math.log10(rms),2) if rms else None,
                clipping_samples=clipped, measurement='PCM样本峰值/RMS；不是LUFS或真峰值，也不是试听结果')


def asr_model(model_path):
    from faster_whisper import WhisperModel
    path=Path(model_path).expanduser().resolve()
    binary_path=path/'model.bin'
    if not binary_path.is_file():
        raise ValueError('请先下载/选择本地faster-whisper模型目录（应含model.bin），本操作不会自动联网')
    stat=binary_path.stat()
    key=(str(path),stat.st_size,stat.st_mtime_ns)
    with _MODEL_LOCK:
        if key not in _MODEL_CACHE:
            model=WhisperModel(str(path),device='cpu',compute_type='int8',local_files_only=True,
                               cpu_threads=max(1,min(6,(os.cpu_count() or 2)-1)))
            # Keep only the active model; loading many episodes must not grow RAM.
            _MODEL_CACHE.clear()
            _MODEL_CACHE[key]=model
        return _MODEL_CACHE[key]


def transcribe(path, model_path, language, job):
    if job.get('cancel_requested'):
        raise ValueError('任务已取消')
    model=asr_model(model_path)
    segments, info = model.transcribe(str(path), language=language or None, word_timestamps=True, vad_filter=True)
    cues, words = [], []
    for segment in segments:
        if job.get('cancel_requested'):
            raise ValueError('任务已取消')
        job.update(message=f'本地识别至 {segment.end:.1f} 秒', progress=min(.95, segment.end/max(1,info.duration)))
        group = [dict(start=w.start,end=w.end,text=w.word, probability=w.probability) for w in (segment.words or []) if w.end>w.start]
        words.extend(group)
        # Split at real pauses and bounded text lengths; these remain ASR drafts.
        chunk = []
        for word in group:
            if chunk and (word['start']-chunk[-1]['end']>.35 or len(''.join(w['text'] for w in chunk))+len(word['text'])>65):
                cues.append(dict(id=uid(), start=chunk[0]['start'], end=chunk[-1]['end'], text=''.join(w['text'] for w in chunk).strip(), style={}))
                chunk=[]
            chunk.append(word)
        if chunk:
            cues.append(dict(id=uid(), start=chunk[0]['start'], end=chunk[-1]['end'], text=''.join(w['text'] for w in chunk).strip(), style={}))
    return dict(captions=cues, words=words, detected_language=info.language,
                language_probability=info.language_probability, status='ASR草稿，必须校对；不是已试听或已翻译')
