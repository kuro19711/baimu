'use strict';
// The HTTP API runs exactly the same operation module that the mouse uses.
const {randomUUID}=require('node:crypto');
const model=require('../web/timeline-model.js');
let input='';
process.stdin.setEncoding('utf8');
process.stdin.on('data',chunk=>{input+=chunk;if(input.length>40*1024*1024)process.exit(2)});
process.stdin.on('end',()=>{
  try{
    const request=JSON.parse(input);let project=request.project,warnings=[],selection=null;
    if(!Array.isArray(request.operations)||!request.operations.length||request.operations.length>100)throw Error('一次提交需要1至100条编辑操作');
    for(const operation of request.operations){
      const result=model.apply(project,operation,()=>randomUUID().replaceAll('-',''));
      project=result.project;warnings.push(...result.warnings);selection=result.selection||selection;
    }
    process.stdout.write(JSON.stringify({project,warnings:[...new Set(warnings)],selection}));
  }catch(error){process.stdout.write(JSON.stringify({error:error.message}));process.exitCode=1}
});
