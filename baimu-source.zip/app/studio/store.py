"""Atomic local persistence; original media is referenced and never overwritten."""
import copy
import hashlib
import json
import os
import re
import shutil
import threading
import time
from pathlib import Path
from .core import VIDEO_EXT, AUDIO_EXT, digest, new_project, uid, validate, timeline
from .media import ROOT, font_info, probe

BATCH_IGNORED_NAMES = {'venv','models','data','bin','cache','__pycache__','node_modules',
                       'site-packages','jobs','renders','history','trash','recovery','batches','test-output'}


def read_json(path, fallback=None):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else fallback


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name+'.'+uid()+'.tmp')
    try:
        with temporary.open('w',encoding='utf-8') as handle:
            handle.write(json.dumps(value, ensure_ascii=False, indent=2))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        try:temporary.unlink(missing_ok=True)
        except OSError:pass


def natural(value):
    return [int(part) if part.isdigit() else part.lower() for part in re.split(r'(\d+)', str(value))]


class Store:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        for name in ['projects', 'fonts', 'jobs', 'renders', 'cache']:
            (self.root/name).mkdir(exist_ok=True)
        self.lock = threading.RLock()
        self.batch_lock = threading.RLock()
        self.issues = []
        self.fonts = self.read_record(self.root/'fonts.json', {}, lambda value:isinstance(value,dict) and all(isinstance(f,dict) and all(k in f for k in ('id','path','family','name')) for f in value.values()))
        self.settings = self.read_record(self.root/'settings.json', {'model_path':''}, lambda value:isinstance(value,dict))

    def read_record(self, path, fallback=None, check=None):
        """Isolate a damaged app-owned record, never let one episode hide others."""
        try:
            value = read_json(path, fallback)
            if check and not check(value):
                raise ValueError('记录结构无效')
            return value
        except (ValueError, TypeError, KeyError) as exc:
            issue=dict(path=str(path),message=str(exc),time=time.time(),kind='damaged_record')
            if path.exists():
                quarantine=self.root/'recovery'/('damaged-'+uid()+'-'+path.name)
                try:
                    quarantine.parent.mkdir(exist_ok=True)
                    os.replace(path,quarantine)
                    issue['recovery_path']=str(quarantine)
                except OSError as error:
                    issue['recovery_error']=str(error)
            self.issues.append(issue)
            return fallback
        except OSError as exc:
            self.issues.append(dict(path=str(path),message=str(exc),time=time.time(),kind='read_error'))
            return fallback

    @staticmethod
    def project_record(value):
        return (isinstance(value,dict) and isinstance(value.get('id'),str)
                and bool(re.fullmatch('[a-f0-9]{32}',value['id']))
                and isinstance(value.get('revision'),int) and isinstance(value.get('name'),str)
                and isinstance(value.get('clips'),list) and isinstance(value.get('captions'),list))

    def path(self, pid):
        if not re.fullmatch('[a-f0-9]{32}', pid):
            raise ValueError('无效的工程ID')
        projects=self.root/'projects'
        target=projects/pid/'project.json'
        if projects.resolve() not in target.resolve().parents:
            raise ValueError('工程路径超出应用数据目录')
        for part in (projects,target.parent,target,target.parent/'history'):
            if os.path.lexists(part) and self.is_link(part):
                raise ValueError('工程目录包含链接或目录联接，已阻止写入')
        return target

    def get(self, pid, include_archived=False):
        value = read_json(self.path(pid))
        if not value:
            raise ValueError('工程不存在')
        if value.get('archived') and not include_archived:
            raise ValueError('该工程已在回收站，请先恢复；未删除源素材、历史版本或导出文件')
        value.setdefault('series','')
        placements={c['id']:c['start'] for c in timeline(value)[0]}
        for clip in value['clips']:clip.setdefault('start',placements[clip['id']])
        if not hasattr(self,'shared_timeline') and (self.root/'jianying/bindings.json').is_file():
            from .native_drafts import NativeDrafts
            NativeDrafts(self)
        shared=getattr(self,'shared_timeline',None)
        if shared and shared.binding(pid):value=shared.project(pid,value)
        if value.get('archived') and not include_archived:raise ValueError('该工程已在回收站，请先恢复')
        return value

    def maybe_native(self,project):
        if self.settings.get('native_authority') and project.get('clips'):
            if not hasattr(self,'shared_timeline'):
                from .native_drafts import NativeDrafts
                NativeDrafts(self)
            return self.shared_timeline.activate(project)
        return project

    def list_projects(self, archived=False, refresh_native=True, native_metadata=True):
        # Home/startup use lightweight native management metadata; opening an
        # episode still reads its complete live graph.  The original project
        # record remains provenance and may have an older name/series.
        if (refresh_native or native_metadata) and not hasattr(self,'shared_timeline') and (self.root/'jianying/bindings.json').is_file():
            from .native_drafts import NativeDrafts
            NativeDrafts(self)
        loaded=[]
        for path in sorted((self.root/'projects').glob('*/project.json')):
            try:self.path(path.parent.name)
            except ValueError as exc:
                self.issues.append(dict(path=str(path),message=str(exc),time=time.time(),kind='unsafe_project_path'))
                continue
            p=self.read_record(path,None,lambda value:self.project_record(value) and value['id']==path.parent.name)
            if p is not None:loaded.append((path,p))
        shared=getattr(self,'shared_timeline',None)
        metadata={}
        if not refresh_native and native_metadata and shared:
            metadata=shared.management_summaries([p['id'] for _,p in loaded])
        records=[]
        for path,p in loaded:
            if refresh_native and shared and shared.binding(p['id']):
                try:p=self.get(p['id'],include_archived=True)
                except (ValueError,RuntimeError,OSError) as exc:
                    self.issues.append(dict(kind='native_read_error',project_id=p['id'],message=str(exc)))
            elif p['id'] in metadata:
                p=dict(p,**metadata[p['id']])
            if bool(p.get('archived'))!=bool(archived):continue
            counts=dict(assets=len(p.get('assets',[])),clips=len(p['clips']),captions=len(p['captions']),audios=len(p.get('audios',[])),protected_lines=len(p.get('protected_lines',[])),script_chars=len(str(p.get('script',{}).get('text','')).strip()))
            modified=path.stat().st_mtime
            native_modified=metadata.get(p['id'],{}).get('modified')
            if isinstance(native_modified,(int,float)) and not isinstance(native_modified,bool) and 0<native_modified<float('inf'):
                modified=max(modified,native_modified)
            records.append(dict(id=p['id'], name=p['name'],series=p.get('series',''), revision=p['revision'],**counts,is_empty=not any(counts.values()),modified=modified,archived=bool(p.get('archived')),archived_at=p.get('archived_at')))
        return sorted(records,key=lambda p:p['modified'],reverse=True)

    @staticmethod
    def series_name(value):
        if not isinstance(value,str) or len(value)>150 or any(ord(ch)<32 for ch in value):
            raise ValueError('剧名分组须为不超过150字的单行文字')
        return value.strip()

    def create(self, name, series=''):
        with self.lock:
            value = new_project(name)
            value['series']=self.series_name(series)
            validate(value)
            value['style'].update(self.default_subtitle_style())
            write_json(self.path(value['id']), value)
            return value

    def create_with_script(self, name, series, script, pid=None):
        """Atomically publish a script-only draft, never an intermediate empty project.

        Called by the authenticated script-import service after explicit mapping.
        Reading a document cannot certify the episode or alter any media track.
        """
        if not isinstance(name,str) or not name.strip() or len(name)>150:
            raise ValueError('请填写不超过150字的集名')
        if not isinstance(script,dict) or not isinstance(script.get('text'),str):
            raise ValueError('剧本文字格式无效')
        if not script['text'].strip() or len(script['text'])>1000000:
            raise ValueError('剧本不能为空，且不能超过100万字符')
        value=new_project(name.strip())
        if pid is not None:value['id']=pid
        value['series']=self.series_name(series)
        value['script']=copy.deepcopy(script)
        value['script']['complete']=False
        for key in ('source','start_anchor','end_anchor'):
            if not isinstance(value['script'].get(key,''),str):
                raise ValueError('剧本来源和边界必须是文字')
            value['script'].setdefault(key,'')
        validate(value)
        with self.lock:
            if self.path(value['id']).exists():
                raise ValueError('预留工程已存在，未覆盖其内容')
            value['style'].update(self.default_subtitle_style())
            write_json(self.path(value['id']),value)
        return self.maybe_native(value)

    def set_archived(self,pid,revision,confirmed,archived=True):
        if confirmed is not True:
            raise ValueError('请明确确认移入回收站或恢复；此操作不会删除素材文件')
        if isinstance(revision,bool) or not isinstance(revision,int):
            raise ValueError('工程修订号无效，请刷新后再操作')
        with self.lock:
            before=self.get(pid,include_archived=True)
            if revision!=before['revision']:
                raise ValueError('工程版本已变化，请刷新后再操作')
            if bool(before.get('archived'))==bool(archived):
                raise ValueError('工程已在回收站' if archived else '工程已恢复，无须重复操作')
            result=copy.deepcopy(before)
            result['archived']=bool(archived)
            result['archived_at']=time.time() if archived else None
            if before.get('native',{}).get('shared'):
                return self.shared_timeline.save(pid,before,result)
            result['revision']+=1
            write_json(self.path(pid).parent/'history'/f'{before["revision"]:06}.json',before)
            write_json(self.path(pid),result)
            return result

    def persist_metadata(self,project):
        """Review records are management data, including for native projects."""
        with self.lock:
            before=self.get(project['id'],include_archived=True)
            if project.get('revision')!=before['revision']:raise ValueError('工程版本已变化，请刷新后重试')
            if before.get('native',{}).get('shared'):
                return self.shared_timeline.save(project['id'],before,project)
            project=copy.deepcopy(project);project['revision']+=1
            write_json(self.path(project['id']),project)
            return project

    def create_imported(self,name,series,folder,pid=None):
        """Only publish a new batch episode after media probing actually finds video."""
        files=self.scan_media(folder)['files']
        incoming=[probe(path) for path in files]
        return self.publish_imported(name,series,incoming,pid)

    def publish_imported(self,name,series,assets,pid=None):
        """Publish internally probed assets; never expose this as a raw client API.

        Folder-drop media lives in our private library, which deliberately cannot
        be scanned as user input. The ingestion service probes those paths itself.
        """
        incoming=copy.deepcopy(assets)
        if not any(asset['kind']=='video' for asset in incoming):
            raise ValueError('没有实际视频轨，未创建空工程；音频可稍后导入已建剧集')
        value=new_project(name)
        if pid is not None:value['id']=pid
        value['series']=self.series_name(series)
        value['assets']=incoming
        for asset in incoming:
            if asset['kind']=='video':
                if not value['clips'] and asset['fps']>=1:value['fps']=asset['fps_fraction']
                value['clips'].append(dict(id=uid(),asset_id=asset['id'],**{'in':0,'out':asset['duration']},gain=0))
        validate(value)
        with self.lock:
            if self.path(value['id']).exists():
                raise ValueError('预留工程已存在，未覆盖其内容')
            value['style'].update(self.default_subtitle_style())
            write_json(self.path(value['id']),value)
        return self.maybe_native(value)

    @staticmethod
    def check_track_locks(before, result):
        for kind in before.get('track_locks',[]):
            key={'video':'clips','original':'clips','caption':'captions','mask':'masks'}.get(kind,'audios')
            left,right=before.get(key,[]),result.get(key,[])
            if key=='audios':
                left=[a for a in left if a.get('role')==kind];right=[a for a in right if a.get('role')==kind]
            if left!=right:raise ValueError('轨道已锁定，请先解锁再修改')
            if kind=='caption' and before['style']!=result['style']:
                raise ValueError('字幕轨道已锁定，请先解锁再修改全局样式')

    def save(self, pid, body, allow_assets=False, refreshed_assets=(), relinked_assets=()):
        with self.lock:
            before = self.get(pid)
            if isinstance(body.get('revision'),bool) or body.get('revision') != before['revision']:
                raise ValueError('工程已被另一窗口修改，请刷新后再保存，避免覆盖')
            result = copy.deepcopy(before)
            for key in ['name','series','width','height','fps','clips','audios','captions','masks','style','script','protected_lines','language','track_locks']:
                if key in body:
                    result[key] = body[key]
            if allow_assets:result['assets']=body['assets']
            result['series']=self.series_name(result.get('series',''))
            placements={c['id']:c['start'] for c in timeline(result)[0]}
            for clip in result['clips']:clip.setdefault('start',placements[clip['id']])
            self.check_track_locks(before,result)
            validate(result)
            if before.get('native',{}).get('shared'):
                result['reviews']={} if digest(result)!=digest(before) else before.get('reviews',{})
                saved=self.shared_timeline.save(pid,before,result,refreshed_assets=refreshed_assets,relinked_assets=relinked_assets)
                if refreshed_assets or relinked_assets or digest(result)!=digest(before):
                    write_json(self.path(pid).parent/'history'/f'{before["revision"]:016}.json',before)
                return saved
            if digest(result) != digest(before):
                result['reviews'] = {}
                history = self.path(pid).parent/'history'/f'{before["revision"]:06}.json'
                write_json(history, before)
            result['revision'] += 1
            write_json(self.path(pid), result)
            return self.maybe_native(result)

    @staticmethod
    def is_link(path):
        try:
            return (path.is_symlink() or (hasattr(path,'is_junction') and path.is_junction())
                    or bool(getattr(path.lstat(),'st_file_attributes',0)&0x400))
        except OSError:
            return True

    def excluded_path(self,path):
        """Check the unresolved path first; resolve() would hide reparse origins."""
        absolute=Path(path).expanduser().absolute()
        for part in (absolute,*absolute.parents):
            if self.is_link(part):return '符号链接或目录联接不作为批量素材来源'
            if part.name.startswith('.') or part.name.casefold() in BATCH_IGNORED_NAMES:
                return '隐藏、软件安装或缓存目录已跳过'
        try:
            if getattr(absolute.lstat(),'st_file_attributes',0)&2:return '隐藏目录已跳过'
        except OSError:return '路径不可读取'
        resolved=absolute.resolve()
        for protected in (ROOT.resolve(),self.root):
            if resolved==protected or protected in resolved.parents:
                return '软件安装或工程数据目录不能作为剧集素材来源'
        return None

    def scan_media(self,path):
        raw=Path(path).expanduser().absolute()
        reason=self.excluded_path(raw)
        if reason:raise ValueError(reason)
        folder=raw.resolve()
        if not folder.is_dir() or folder==Path(folder.anchor) or folder==Path.home():
            raise ValueError('请选择具体素材文件夹，不要扫描整个磁盘或用户目录')
        files=[];skipped=[];count=0
        def failed(error):raise ValueError('素材目录不可读取：'+str(error))
        for current,dirs,names in os.walk(folder,topdown=True,followlinks=False,onerror=failed):
            current=Path(current)
            allowed=[]
            for name in dirs:
                entry=current/name;count+=1
                if count>10000:raise ValueError('目录内容超过10000项，请选择更具体的单集素材目录')
                reason=self.excluded_path(entry)
                if reason:skipped.append(dict(path=str(entry),reason=reason))
                else:allowed.append(name)
            dirs[:]=allowed
            for name in names:
                count+=1
                if count>10000:raise ValueError('目录内容超过10000项，请选择更具体的单集素材目录')
                entry=current/name
                if entry.suffix.lower() not in VIDEO_EXT|AUDIO_EXT:continue
                reason=self.excluded_path(entry)
                if reason:
                    skipped.append(dict(path=str(entry),reason=reason));continue
                resolved=entry.resolve()
                if folder not in resolved.parents:
                    skipped.append(dict(path=str(entry),reason='文件超出所选素材目录'));continue
                if resolved.is_file():files.append(resolved)
                if len(files)>300:raise ValueError('一集最多300个媒体文件，请选择更具体的素材目录')
            if count>10000:raise ValueError('目录内容超过10000项，请选择更具体的单集素材目录')
        return dict(files=sorted(files,key=natural),skipped=skipped)

    def batch_preview(self,path):
        raw=Path(str(path).strip().strip('"')).expanduser().absolute()
        reason=self.excluded_path(raw)
        if reason:raise ValueError(reason)
        root=raw.resolve()
        if not root.is_dir() or root==Path(root.anchor) or root==Path.home():
            raise ValueError('请选择包含各集子文件夹的具体目录')
        candidates=[];skipped=[];warnings=[]
        children=[]
        for entry in root.iterdir():
            children.append(entry)
            if len(children)>1000:raise ValueError('目录项目过多，请选择更具体的剧集总目录')
        for child in sorted(children,key=natural):
            reason=self.excluded_path(child)
            if reason:
                skipped.append(dict(name=child.name,path=str(child),reason=reason));continue
            if not child.is_dir():
                if child.suffix.lower() in VIDEO_EXT:warnings.append('总目录中的视频不会自动分集：'+child.name)
                continue
            try:
                scan=self.scan_media(child)
                videos=sum(p.suffix.lower() in VIDEO_EXT for p in scan['files'])
                audios=len(scan['files'])-videos
                if not videos:
                    skipped.append(dict(name=child.name,path=str(child),reason='只有音频，没有视频' if audios else '没有可导入的视频素材'))
                    continue
                candidates.append(dict(name=child.name,path=str(child.resolve()),video_count=videos,audio_count=audios))
                if scan['skipped']:warnings.append(child.name+' 中跳过 '+str(len(scan['skipped']))+' 个不安全或缓存目录/文件')
            except (OSError,ValueError) as exc:
                skipped.append(dict(name=child.name,path=str(child),reason=str(exc)))
        return dict(path=str(root),folders=candidates,skipped=skipped,warnings=warnings)

    def import_paths(self, pid, paths, append=True):
        files=[]
        for raw in paths:
            original=Path(raw.strip().strip('"')).expanduser().absolute()
            reason=self.excluded_path(original)
            if reason:raise ValueError(reason)
            path=original.resolve()
            if not path.exists():
                raise ValueError(f'路径不存在：{path}')
            if path.is_dir():
                if path == Path(path.anchor) or path == Path.home():
                    raise ValueError('请选择具体剧集文件夹，不要扫描整个磁盘或用户目录')
                files.extend(self.scan_media(path)['files'])
            else:
                if path.suffix.lower() not in VIDEO_EXT|AUDIO_EXT:
                    raise ValueError('素材仅支持常见视频/音频格式')
                files.append(path)
        if len(files)>300:
            raise ValueError('一次最多导入300个文件，请按集选择')
        # Probe outside the lock; commit merges into the latest revision.
        existing=self.get(pid)
        known={a['path'] for a in existing['assets']}
        for asset in existing['assets']:
            if asset['path'] in {str(p.resolve()) for p in files}:
                stat=Path(asset['path']).stat()
                if stat.st_size!=asset.get('size') or stat.st_mtime_ns!=asset.get('mtime_ns'):
                    raise ValueError('同路径素材已经改变，未覆盖旧剪辑。请使用“确认更新素材”并重新验收：'+asset['name'])
        incoming=[probe(p) for p in dict.fromkeys(files) if str(p.resolve()) not in known]
        return self.import_prepared(pid,incoming,append)

    def import_prepared(self,pid,incoming,append=True):
        """Merge media already copied and probed by a trusted local ingest service.

        Browser-picked files have no usable absolute source path. FolderIngest
        copies them into this app's private library, probes those owned files,
        then calls this method. Existing edits are preserved and a retry after a
        crash is idempotent because already-owned paths are skipped.
        """
        incoming=copy.deepcopy(incoming)
        if not isinstance(append,bool):raise ValueError('素材追加方式无效')
        if len(incoming)>300:raise ValueError('一次最多导入300个文件，请分批选择')
        if any(not isinstance(asset,dict) or asset.get('kind') not in ('video','audio') for asset in incoming):
            raise ValueError('素材仅支持常见视频或音频格式')
        with self.lock:
            project=self.get(pid)
            before=copy.deepcopy(project)
            known={a['path'] for a in project['assets']}
            added=False
            for asset in incoming:
                if asset['path'] in known:
                    continue
                project['assets'].append(asset)
                known.add(asset['path'])
                added=True
                if asset['kind']=='video' and append:
                    if not project['clips'] and asset['fps']>=1:
                        project['fps']=asset['fps_fraction']
                    project['clips'].append(dict(id=uid(),asset_id=asset['id'], **{'in':0,'out':asset['duration']},gain=0))
            if not added:return project
            project['reviews']={}
            if before.get('native',{}).get('shared'):
                return self.save(pid,project,allow_assets=True)
            if digest(before)!=digest(project):
                write_json(self.path(pid).parent/'history'/f'{before["revision"]:06}.json',before)
                project['revision']+=1
                write_json(self.path(pid),project)
            return self.maybe_native(project)

    def media_status(self,pid):
        project=self.get(pid)
        return dict(revision=project['revision'],assets=[dict(id=a['id'],name=a['name'],path=a['path'],
                    missing=not Path(a['path']).is_file()) for a in project['assets']])

    def relink_preview(self,pid,asset_id,path,revision):
        before=self.get(pid)
        if isinstance(revision,bool) or revision!=before['revision']:raise ValueError('工程已变化，请重新选择素材')
        old=next((a for a in before['assets'] if a['id']==asset_id),None)
        if not old:raise ValueError('素材ID无效')
        if not isinstance(path,str) or not path.strip():raise ValueError('请选择具体媒体文件')
        candidate=Path(path.strip().strip('"')).expanduser().resolve()
        if not candidate.is_file():raise ValueError('所选素材文件不存在')
        actual=dict(probe(candidate),id=asset_id)
        if actual['kind']!=old['kind']:raise ValueError('新文件的媒体类型与原素材不一致')
        result=copy.deepcopy(before)
        result['assets']=[actual if a['id']==asset_id else a for a in result['assets']]
        validate(result)
        # A relink is not a content replacement. Do not match by filename alone.
        identical=bool(old.get('sha256')) and actual['sha256']==old['sha256']
        return dict(revision=revision,asset=actual,original=old,identical=identical,
                    notice='内容校验一致；保留全部原裁剪与时间位置' if identical else '内容无法确认为原素材；请使用替换功能，不会按同名文件自动重连')

    def relink_asset(self,pid,asset_id,path,revision,confirmed=False,expected_sha256=None):
        if confirmed is not True:raise ValueError('请确认重连素材')
        preview=self.relink_preview(pid,asset_id,path,revision)
        if not preview['identical']:raise ValueError('新文件与登记的原素材内容不一致，未重连；请确认是否选错文件或需要替换素材')
        if expected_sha256!=preview['asset']['sha256']:raise ValueError('待确认文件已变化，请重新检查')
        with self.lock:
            current=self.get(pid)
            if current['revision']!=revision:raise ValueError('重连期间工程已变化，原工程未改动')
            result=copy.deepcopy(current)
            result['assets']=[preview['asset'] if a['id']==asset_id else a for a in result['assets']]
            result['reviews']={}
            for cue in result['captions']:cue.pop('speech',None)
            return self.save(pid,result,allow_assets=True,relinked_assets=[asset_id])

    def refresh_assets(self,pid,asset_ids,revision,confirmed=False):
        """Explicit same-path relink. Keep IDs; reject trims beyond new media length."""
        if confirmed is not True:
            raise ValueError('更新素材会使旧检查结果失效，必须明确确认')
        if not isinstance(asset_ids,list) or not asset_ids:
            raise ValueError('请选择要更新的素材')
        before=self.get(pid)
        if revision!=before['revision']:
            raise ValueError('工程已变化，请刷新后再更新素材')
        requested=set(asset_ids)
        assets={a['id']:a for a in before['assets']}
        if not requested.issubset(assets):
            raise ValueError('素材ID无效')
        replacements={aid:dict(probe(Path(assets[aid]['path'])),id=aid) for aid in requested}
        with self.lock:
            current=self.get(pid)
            if current['revision']!=revision:
                raise ValueError('更新期间工程已变化，请重试；原工程未改动')
            result=copy.deepcopy(current)
            result['assets']=[replacements.get(a['id'],a) for a in result['assets']]
            validate(result)
            if current.get('native',{}).get('shared'):
                return self.save(pid,result,allow_assets=True,refreshed_assets=requested)
            result['reviews']={}
            result['revision']+=1
            write_json(self.path(pid).parent/'history'/f'{current["revision"]:06}.json',current)
            write_json(self.path(pid),result)
            return result

    @staticmethod
    def font_file_id(path):
        with Path(path).open('rb') as stream:
            return hashlib.file_digest(stream,'sha256').hexdigest()[:32]

    def _publish_original_font(self, source, destination, fid):
        source=Path(source).resolve();destination=Path(destination).resolve()
        if source==destination:
            if self.font_file_id(destination)!=fid:raise ValueError('字体原始副本校验失败')
            return destination
        temporary=destination.with_name(destination.name+'.'+uid()+'.tmp')
        try:
            shutil.copy2(source,temporary)
            if self.font_file_id(temporary)!=fid:raise ValueError('字体在复制期间发生变化，请重试')
            os.replace(temporary,destination)
        finally:
            temporary.unlink(missing_ok=True)
        return destination

    def original_font_path(self, fid):
        """Return an app-owned, unrenamed font for Jianying and portable handoff.

        Older Baimu data only retained the renderer-specific renamed copy. Recover
        the original bytes by their pre-rename content id when they still exist in
        bundled assets or an installed-font directory; never hand Jianying the
        renderer-only face silently.
        """
        font=self.fonts.get(fid)
        if not font:raise ValueError('字幕字体记录缺失，请重新选择字体')
        suffix=Path(font['path']).suffix.lower()
        stored=self.root/'fonts'/(fid+'.original'+suffix)
        candidates=[font.get('original_path'),stored]
        candidates.extend((ROOT/'assets/fonts').glob('*'))
        if os.name=='nt':
            windir=Path(os.environ.get('WINDIR',r'C:\Windows'))/'Fonts'
            local=Path(os.environ.get('LOCALAPPDATA',''))/'Microsoft/Windows/Fonts'
            for folder in (windir,local):
                if folder.is_dir():candidates.extend(folder.glob('*'))
        seen=set()
        for value in candidates:
            if not value:continue
            candidate=Path(value)
            try:key=str(candidate.resolve()).lower()
            except OSError:continue
            if key in seen:continue
            seen.add(key)
            if candidate.suffix.lower() not in ('.ttf','.otf') or not candidate.is_file():continue
            try:
                if self.font_file_id(candidate)!=fid:continue
                self._publish_original_font(candidate,stored,fid)
            except OSError:continue
            with self.lock:
                current=copy.deepcopy(self.fonts[fid]);current['original_path']=str(stored)
                self.fonts[fid]=current;write_json(self.root/'fonts.json',self.fonts)
            return stored
        raise ValueError('剪映交接所需的原始字体已缺失，请在百慕中重新导入该字体：'+font.get('name',fid))

    def import_font(self, path):
        path=Path(path).resolve()
        if path.suffix.lower() not in ('.ttf','.otf') or not path.is_file() or path.stat().st_size>30*1024*1024:
            raise ValueError('请选择不超过30MB的TTF或OTF字体文件')
        info=font_info(path)
        fid=self.font_file_id(path)
        dst=self.root/'fonts'/(fid+path.suffix.lower())
        original=self.root/'fonts'/(fid+'.original'+path.suffix.lower())
        self._publish_original_font(path,original,fid)
        if original!=dst:
            # Unique internal family avoids libass choosing a different installed
            # face with the same family name. Jianying receives original instead.
            from fontTools.ttLib import TTFont
            face=TTFont(str(original))
            family='Studio_'+fid
            try:
                for record in face['name'].names:
                    if record.nameID in (1,4,6,16):
                        record.string=family.encode(record.getEncoding(),errors='replace')
                face.save(str(dst))
            finally:
                face.close()
            info['family']=family
        with self.lock:
            self.fonts[fid]=dict(info,id=fid,path=str(dst),original_path=str(original))
            write_json(self.root/'fonts.json',self.fonts)
        return self.fonts[fid]

    def default_subtitle_style(self):
        """An explicit default, not whichever font happened to be imported first."""
        from .core import STYLE, validate_style
        style=copy.deepcopy(STYLE)
        style.update(self.settings.get('subtitle_default_style',{}))
        fid=style.get('font_id') or self.settings.get('default_font_id')
        if fid not in self.fonts:
            fid=next(iter(self.fonts),'')
        style['font_id']=fid
        validate_style(style)
        return style

    def history(self,pid):
        folder=self.path(pid).parent/'history'
        records=[]
        # Native revisions are fingerprint hashes, not increasing counters.
        # Sort the durable snapshots by save time before applying the UI limit.
        for path in sorted(folder.glob('*.json'),key=lambda p:(p.stat().st_mtime_ns,p.name),reverse=True):
            p=self.read_record(path,None,self.project_record)
            if p is not None:
                records.append(dict(revision=p['revision'],name=p['name'],clips=len(p['clips']),captions=len(p['captions'])))
            if len(records)>=100:break
        return records

    def restore(self,pid,revision,current_revision):
        if not isinstance(revision,int) or revision<0:
            raise ValueError('无效历史版本')
        with self.lock:
            before=self.get(pid)
            if current_revision!=before['revision']:
                raise ValueError('工程已变化，请刷新后恢复')
            previous=read_json(self.path(pid).parent/'history'/f'{revision:06}.json') or read_json(self.path(pid).parent/'history'/f'{revision:016}.json')
            if not previous or previous['id']!=pid:
                raise ValueError('历史版本不存在')
            validate(previous)
            if before.get('native',{}).get('shared'):
                previous['revision']=before['revision']
                return self.save(pid,previous,allow_assets=True)
            self.check_track_locks(before,previous)
            write_json(self.path(pid).parent/'history'/f'{before["revision"]:06}.json',before)
            previous['revision']=before['revision']+1
            previous['reviews']={}
            # Editing history cannot bypass the dedicated archive confirmation/queue gate.
            previous['archived']=bool(before.get('archived'))
            previous['archived_at']=before.get('archived_at')
            write_json(self.path(pid),previous)
            return previous

    def asset_path(self, pid, aid):
        asset=next((a for a in self.get(pid)['assets'] if a['id']==aid),None)
        if not asset:
            raise ValueError('素材不存在')
        return Path(asset['path'])
