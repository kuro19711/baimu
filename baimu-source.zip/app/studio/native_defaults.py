"""Comparison-only defaults observed after Jianying saved our test drafts.

Never fill these into the stored raw draft: omission is part of its format.
"""


def timerange(value):
    return dict(start=value.get('start',0),duration=value.get('duration',0))


def keyframe(value):
    return dict(time_offset=value.get('time_offset',0),values=value.get('values',[]),
        curveType=value.get('curveType','Line'),
        left_control=value.get('left_control',dict(x=0.,y=0.)),
        right_control=value.get('right_control',dict(x=0.,y=0.)))


def inert_attachment(category, material):
    """Only observed empty/default records are inert; populated effects stay blocked."""
    defaults={
        'canvases':{'type':('canvas_color',)},
        'sound_channel_mappings':{'type':('', 'none')},
        'material_colors':{},
        'loudnesses':{},
        'vocal_separations':{'type':('vocal_separation',)},
    }
    if category not in defaults:return False
    allowed=defaults[category]
    return all(key=='id' or key in allowed and value in allowed[key] for key,value in material.items())
