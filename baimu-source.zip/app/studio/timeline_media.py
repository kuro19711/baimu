"""Bounded local source thumbnails/waveforms, never delivery or speech evidence.

Route adapter: create ``TimelineMedia(store)`` once, then call
``get(project_id, asset_id, stream=None)`` after ordinary app authentication.
``stream`` is the absolute FFmpeg audio stream index, not an audio ordinal.
Long-source unknown waveform intervals remain None, never fabricated silence.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import io
import json
import math
import os
import shutil
import subprocess
import tempfile
import threading
import time
from array import array
from pathlib import Path

from .media import audio_stream, binary, picture_only_stream, stream_bounds, stream_metadata
from .store import write_json

VERSION = 'timeline-source-v1'
THUMBNAILS = 6
THUMB_EDGE = 160
WAVE_POINTS = 256
SAMPLE_RATE = 8000
FULL_WAVE_SECONDS = 120
SAMPLE_WINDOWS = 8
SAMPLE_SECONDS = 2
REQUEST_SECONDS = 20
PROBE_SECONDS = 4
DECODE_SECONDS = 6
MAX_CACHE_BYTES = 2 * 1024 * 1024
MAX_JPEG_BYTES = 96 * 1024
MAX_SOURCE_SECONDS = 24 * 3600
MIN_FREE_BYTES = 64 * 1024 * 1024
SOURCE_CHANGED_WARNING = '原文件状态与导入记录不同；预览反映当前文件，请先确认更新素材，不能据此放行原剪辑。'
_WORKERS = threading.BoundedSemaphore(2)
_ACTIVE_LOCK = threading.Lock()
_ACTIVE = set()


def _run(args, timeout, limit=65536):
    """Bound log output, process wall time and reader lifetime, without a shell."""
    if timeout <= 0:
        raise ValueError('时间线预览生成已到时间上限，可稍后重试；工程未改动')
    process = subprocess.Popen([str(arg) for arg in args], stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    output = bytearray()
    overflow = threading.Event()

    def drain():
        try:
            while block := process.stdout.read(16384):
                if len(output) + len(block) > limit:
                    overflow.set()
                    process.kill()
                    break
                output.extend(block)
        except (OSError, ValueError):
            pass
        finally:
            process.stdout.close()

    reader = threading.Thread(target=drain, daemon=True)
    reader.start()
    try:
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired as exc:
            process.kill()
            process.wait(timeout=2)
            raise ValueError('时间线缩略图/波形解码超时，可稍后重试；不会阻止保存工程') from exc
    finally:
        if process.poll() is None:
            process.kill()
            process.wait(timeout=2)
        reader.join(timeout=2)
    if overflow.is_set():
        raise ValueError('媒体预览日志超过安全限额，请检查素材格式')
    if process.returncode:
        raise ValueError('无法生成媒体预览：' + bytes(output).decode('utf-8', errors='replace')[-600:])
    return bytes(output)


def _info(path, deadline):
    fields = ('format=start_time,duration:stream=index,codec_type,start_time,duration,duration_ts,'
              'time_base,sample_rate,channels,width,height:stream_tags=DURATION:stream_disposition=attached_pic')
    raw = _run([binary('ffprobe'), '-v', 'error', '-protocol_whitelist', 'file,pipe',
                '-probesize', '4194304', '-analyzeduration', '2000000', '-show_entries', fields,
                '-of', 'json', str(path)], min(PROBE_SECONDS, deadline-time.monotonic()), 256*1024)
    info = json.loads(raw)
    if not isinstance(info, dict) or not isinstance(info.get('streams'), list) or len(info['streams']) > 64:
        raise ValueError('素材轨道结构无效或超过64轨，无法生成轻量时间线预览')
    return info


def _stamp(path):
    value = path.stat()
    return dict(path=os.path.normcase(str(path)), size=value.st_size, mtime_ns=value.st_mtime_ns,
                ctime_ns=value.st_ctime_ns, device=value.st_dev, inode=value.st_ino)


def _key(stamp, stream):
    value = dict(version=VERSION, source=stamp, stream=stream, thumbnails=THUMBNAILS,
                 thumbnail_edge=THUMB_EDGE, points=WAVE_POINTS, sample_rate=SAMPLE_RATE,
                 full_seconds=FULL_WAVE_SECONDS, windows=SAMPLE_WINDOWS, window_seconds=SAMPLE_SECONDS)
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _source_warning(result, asset, stamp):
    # Shared physical-file cache entries must not carry another project's
    # imported metadata state after that project refreshes its asset record.
    result['warnings'] = [item for item in result.get('warnings', []) if item != SOURCE_CHANGED_WARNING]
    result.pop('source_changed', None)
    if asset.get('size') != stamp['size'] or asset.get('mtime_ns') != stamp['mtime_ns']:
        result['warnings'].append(SOURCE_CHANGED_WARNING)
        result['source_changed'] = True


def _source(store, asset):
    value = asset.get('path')
    if not isinstance(value, str) or not value or value.startswith(('\\\\', '//')):
        raise ValueError('素材路径无效；时间线预览只读取工程登记的本机文件')
    path = Path(value)
    if not path.is_absolute():
        raise ValueError('素材必须使用已登记的本机绝对路径')
    for part in (path, *path.parents):
        if os.path.lexists(part) and store.is_link(part):
            raise ValueError('素材路径包含符号链接或目录联接，请重新导入实际文件')
    if not path.is_file():
        raise ValueError('素材文件已移动或缺失，请重新关联；工程和剪辑仍然保留')
    return path.resolve()


def _cache_path(store, name=None):
    directory = store.root/'cache'/'timeline-media'
    target = directory/name if name else directory
    if store.root not in target.resolve().parents:
        raise ValueError('时间线缓存路径超出软件数据目录')
    current = store.root
    for part in target.relative_to(store.root).parts:
        current = current/part
        if os.path.lexists(current) and store.is_link(current):
            raise ValueError('时间线缓存包含链接，已停止写入')
    return target


def _cache_read(path, key):
    try:
        if not path.is_file() or path.stat().st_size > MAX_CACHE_BYTES:
            return None
        saved = json.loads(path.read_text(encoding='utf-8'))
        if saved.get('key') != key or saved.get('version') != VERSION:
            return None
        value = saved['value']
        if (not isinstance(value, dict) or value.get('status') not in ('ready', 'partial')
                or not isinstance(value.get('thumbnails'), list) or len(value['thumbnails']) > THUMBNAILS
                or not isinstance(value.get('duration'), (int, float))
                or not math.isfinite(value['duration']) or not 0 < value['duration'] <= MAX_SOURCE_SECONDS):
            return None
        for thumbnail in value['thumbnails']:
            if not isinstance(thumbnail, dict) or not isinstance(thumbnail.get('data_url'), str):
                return None
            prefix = 'data:image/jpeg;base64,'
            if not thumbnail['data_url'].startswith(prefix):
                return None
            data = base64.b64decode(thumbnail['data_url'][len(prefix):], validate=True)
            if not 0 < len(data) <= MAX_JPEG_BYTES or not data.startswith(b'\xff\xd8') or not data.endswith(b'\xff\xd9'):
                return None
            if not isinstance(thumbnail.get('time'), (int, float)) or not 0 <= thumbnail['time'] <= value['duration']:
                return None
        waveform = value.get('waveform')
        if waveform is not None:
            if (not isinstance(waveform, dict) or not isinstance(waveform.get('points'), list)
                    or len(waveform['points']) != WAVE_POINTS):
                return None
            if any(point is not None and (isinstance(point, bool) or not isinstance(point, (int, float))
                                         or not math.isfinite(point) or not 0 <= point <= 1)
                   for point in waveform['points']):
                return None
        return value
    except (OSError, ValueError, TypeError, KeyError):
        return None


def _windows(duration):
    if duration <= FULL_WAVE_SECONDS:
        return [(0.0, duration)]
    span = min(SAMPLE_SECONDS, duration)
    return [(index*(duration-span)/(SAMPLE_WINDOWS-1), span) for index in range(SAMPLE_WINDOWS)]


def _waveform(path, duration, stream, work, deadline):
    channels = min(2, max(1, int(stream.get('channels') or 1)))
    points = [None]*WAVE_POINTS
    windows = []
    errors = []
    full = duration <= FULL_WAVE_SECONDS
    for index, (start, length) in enumerate(_windows(duration)):
        output = work/('wave-'+str(index)+'.pcm')
        expected = round(length*SAMPLE_RATE)*channels*2
        try:
            _run([binary('ffmpeg'), '-hide_banner', '-loglevel', 'error', '-nostdin', '-y',
                  '-threads', '1', '-filter_threads', '1', '-protocol_whitelist', 'file,pipe',
                  '-ss', f'{start:.9f}', '-i', str(path), '-map', '0:'+str(stream['index']),
                  '-vn', '-sn', '-dn', '-af',
                  f'aresample={SAMPLE_RATE}:async=1:first_pts=0,apad,atrim=duration={length:.9f}',
                  '-t', f'{length:.9f}', '-ac', str(channels), '-ar', str(SAMPLE_RATE),
                  '-c:a', 'pcm_s16le', '-f', 's16le', '-fs', str(expected+16384), str(output)],
                 min(DECODE_SECONDS, deadline-time.monotonic()))
            if not output.is_file() or not 0 < output.stat().st_size <= expected+16384:
                raise ValueError('波形采样输出为空或超出大小限额')
            samples = array('h')
            raw = output.read_bytes()
            if len(raw) % (channels*2):
                raise ValueError('波形采样字节未按音频帧对齐')
            samples.frombytes(raw)
            import sys
            if sys.byteorder != 'little':
                samples.byteswap()
            frames = len(samples)//channels
            if abs(frames-round(length*SAMPLE_RATE)) > 2:
                raise ValueError('波形采样时长不完整，未将缺失部分假装静音')
            for frame in range(frames):
                absolute = start+frame/SAMPLE_RATE
                bucket = min(WAVE_POINTS-1, int(absolute/duration*WAVE_POINTS))
                peak = max(abs(samples[frame*channels+channel]) for channel in range(channels))/32768
                points[bucket] = max(points[bucket] or 0, min(1.0, peak))
            windows.append(dict(start=round(start, 6), end=round(start+length, 6)))
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            errors.append(str(exc))
            if time.monotonic() >= deadline:
                break
    if not windows:
        return None, errors
    # At sub-32ms durations some display bins have no sample centre; this is
    # still complete decoded audio, not missing windows. Leave unknown as None.
    return dict(duration=duration, stream=stream['index'], start=0, end=duration,
                points=[round(point, 5) if point is not None else None for point in points],
                complete=full and not errors, sampled=not full, windows=windows,
                sample_rate=SAMPLE_RATE, channels=channels,
                stream_start=stream.get('start', 0), stream_end=stream.get('end', duration)), errors


def _thumbnails(path, video, info, work, deadline):
    from PIL import Image
    bounds = stream_bounds(video, info)
    images, errors = [], []
    for index in range(THUMBNAILS):
        moment = bounds['start']+bounds['duration']*(index+.5)/THUMBNAILS
        output = work/('thumb-'+str(index)+'.jpg')
        try:
            _run([binary('ffmpeg'), '-hide_banner', '-loglevel', 'error', '-nostdin', '-y',
                  '-threads', '1', '-filter_threads', '1', '-protocol_whitelist', 'file,pipe',
                  '-ss', f'{moment:.9f}', '-i', str(path), '-map', '0:'+str(video['index']),
                  '-an', '-sn', '-dn', '-frames:v', '1', '-vf',
                  f'scale={THUMB_EDGE}:{THUMB_EDGE}:force_original_aspect_ratio=decrease,setsar=1',
                  '-c:v', 'mjpeg', '-threads', '1', '-q:v', '5', '-f', 'image2', '-update', '1',
                  '-fs', str(MAX_JPEG_BYTES), str(output)], min(3, deadline-time.monotonic()))
            if not output.is_file() or not 0 < output.stat().st_size <= MAX_JPEG_BYTES:
                raise ValueError('缩略图输出为空或超过大小限额')
            raw = output.read_bytes()
            with Image.open(io.BytesIO(raw)) as picture:
                width, height = picture.size
                if picture.format != 'JPEG' or not 0 < width <= THUMB_EDGE or not 0 < height <= THUMB_EDGE:
                    raise ValueError('缩略图格式或尺寸无效')
                picture.verify()
            images.append(dict(time=round(moment, 6), width=width, height=height,
                               data_url='data:image/jpeg;base64,'+base64.b64encode(raw).decode('ascii')))
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            errors.append(str(exc))
            if time.monotonic() >= deadline:
                break
    return images, errors


class TimelineMedia:
    def __init__(self, store):
        self.store = store

    def get(self, project_id, asset_id, stream=None):
        result = dict(ok=False, status='error', asset_id=asset_id, duration=None, stream=stream,
                      thumbnails=[], waveform=None, warnings=[], cached=False)
        acquired = False
        active_key = None
        try:
            if not isinstance(asset_id, str) or not asset_id or len(asset_id) > 128:
                raise ValueError('素材ID无效')
            if stream is not None and (isinstance(stream, bool) or not isinstance(stream, int) or not 0 <= stream <= 65535):
                raise ValueError('音轨索引必须为有效的绝对流编号')
            project = self.store.get(project_id)
            asset = next((asset for asset in project['assets'] if asset['id'] == asset_id), None)
            if asset is None:
                raise ValueError('素材不在当前工程中，未读取其他文件')
            path = _source(self.store, asset)
            stamp = _stamp(path)
            key = _key(stamp, stream)
            cache = _cache_path(self.store, key+'.json')
            saved = _cache_read(cache, key)
            if saved is not None:
                if _stamp(path) != stamp:
                    raise ValueError('素材在预览读取期间发生改变，请重试')
                saved.update(asset_id=asset_id, cached=True)
                _source_warning(saved, asset, stamp)
                return saved
            active_key = str(self.store.root)+'/'+key
            with _ACTIVE_LOCK:
                if active_key in _ACTIVE or not _WORKERS.acquire(blocking=False):
                    return dict(result, status='busy', error='时间线预览正在生成，请稍后重试', retry_after_ms=1200)
                _ACTIVE.add(active_key)
                acquired = True
            directory = _cache_path(self.store)
            directory.mkdir(parents=True, exist_ok=True)
            if shutil.disk_usage(directory).free < MIN_FREE_BYTES:
                raise ValueError('时间线缓存磁盘可用空间不足64MiB；已停止生成，工程仍可操作')
            deadline = time.monotonic()+REQUEST_SECONDS
            info = _info(path, deadline)
            video = next((item for item in info['streams'] if item.get('codec_type') == 'video' and not picture_only_stream(item)), None)
            streams = stream_metadata(info)
            duration = stream_bounds(video, info)['end'] if video else max((item['end'] for item in streams), default=0)
            if not math.isfinite(duration) or not 0 < duration <= MAX_SOURCE_SECONDS:
                raise ValueError('素材时长无效或超过24小时，请拆分后生成时间线预览')
            result.update(duration=duration, audio_streams=streams, kind='video' if video else 'audio')
            selection_error = None
            try:
                selected = audio_stream(asset, {'audio_stream': stream}, info)
            except ValueError as exc:
                selected = None
                selection_error = str(exc)
                result['requires_audio_selection'] = True
            result['stream'] = selected['index'] if selected else stream
            _source_warning(result, asset, stamp)
            errors = []
            with tempfile.TemporaryDirectory(prefix='work-', dir=directory) as temporary:
                work = Path(temporary)
                if selected is not None:
                    result['waveform'], wave_errors = _waveform(path, duration, selected, work, deadline)
                    errors.extend(wave_errors)
                    if duration > FULL_WAVE_SECONDS:
                        result['warnings'].append('长素材仅抽样8个短窗；波形空缺为未采样，不代表静音。')
                if video is not None:
                    result['thumbnails'], image_errors = _thumbnails(path, video, info, work, deadline)
                    errors.extend(image_errors)
            if _stamp(path) != stamp:
                raise ValueError('素材在预览生成期间发生改变，已丢弃本次结果，请重试')
            result['warnings'].append('此处是源素材低分辨率波形，仅供定位，不是最终混音，也不能用作字幕对齐或人声完整性验收。')
            result.update(ok=bool(result['thumbnails'] or result['waveform']), status='partial' if errors or selection_error else 'ready')
            if selection_error:
                result['error'] = selection_error
            if errors:
                result['error'] = (result.get('error', '')+'；'+errors[0]).strip('；')[:800]
            if not result['ok']:
                result['status'] = 'error'
            if result['ok'] and not errors:
                record = dict(version=VERSION, key=key, value=copy.deepcopy(result))
                if len(json.dumps(record, ensure_ascii=False).encode('utf-8')) <= MAX_CACHE_BYTES:
                    try:
                        write_json(_cache_path(self.store, key+'.json'), record)
                    except OSError:
                        result['warnings'].append('预览已生成，但缓存未能保存；下次可能重新生成。')
            return result
        except (OSError, ValueError, TypeError, KeyError, subprocess.SubprocessError) as exc:
            return dict(result, ok=False, status='error', thumbnails=[], waveform=None, error=str(exc)[:800])
        finally:
            if acquired:
                with _ACTIVE_LOCK:
                    _ACTIVE.discard(active_key)
                    _WORKERS.release()
