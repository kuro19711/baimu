"""Reuse unburned picture/audio tracks; remux legacy outputs without re-encoding."""
import copy,contextlib,os,threading
from pathlib import Path
from .core import picture_digest,sound_digest,layer_digests,view_reference
from .media import binary,process,media_info

class EditingPreviews:
    def __init__(self,store,jobs):
        self.store=store;self.jobs=jobs;self.guard=threading.RLock();self.locks={};self.active=0
    def busy(self):
        with self.guard:return self.active>0
    @contextlib.contextmanager
    def activity(self):
        with self.guard:self.active+=1
        try:yield
        finally:
            with self.guard:self.active-=1
    def prepare(self,pid):
        with self.activity():
            project=self.store.get(pid);picture=picture_digest(project);sound=sound_digest(project)
            candidates=[]
            for job in list(self.jobs.items.values()):
                result=job.get('result',{})
                if job['project_id']!=pid or job['state']!='complete' or job['kind'] not in ('preview','draft','final'):continue
                target=self.store.root/'renders'/job['id'];filename=result.get('file')
                if filename not in ('preview.mp4','film.mp4') or not (target/filename).is_file():continue
                clean=result.get('clean_picture') or not result.get('captions_burned') and not result.get('masks_burned')
                if not clean and not (target/'picture.mkv').is_file():continue
                snap=job['snapshot'];same_picture=picture_digest(snap)==picture;same_sound=result.get('sound_digest')==sound
                candidates.append((not (same_picture and same_sound),not same_picture,-job['created'],job,clean))
            if not candidates:return dict(job=None)
            *_,job,clean=min(candidates,key=lambda x:x[:3]);target=self.store.root/'renders'/job['id']
            with self.guard:lock=self.locks.setdefault(job['id'],threading.Lock())
            with lock:
                if clean:filename=job['result']['file']
                else:
                    filename='edit.mp4';output=target/filename
                    if not output.is_file():
                        temporary=target/'edit.partial.mp4'
                        try:
                            process([binary('ffmpeg'),'-y','-v','error','-i',str(target/'picture.mkv'),'-i',str(target/job['result']['file']),
                                     '-map','0:v:0','-map','1:a:0','-c','copy','-shortest','-movflags','+faststart',str(temporary)],timeout=180)
                            info=media_info(temporary)
                            kinds={s['codec_type'] for s in info['streams']}
                            duration=float(info.get('format',{}).get('duration',0))
                            if not {'video','audio'}<=kinds or abs(duration-job['result']['duration'])>.25:raise ValueError('编辑底图音画校验失败')
                            os.replace(temporary,output)
                        finally:temporary.unlink(missing_ok=True)
                public=self.jobs.public(job,detail=True)
                public['editing_preview']=True;public['view_reference']=view_reference(job['snapshot'])
                public['result']=dict(copy.deepcopy(public['result']),file=filename,captions_burned=False,masks_burned=False,
                                      clean_picture=True,layers=layer_digests(job['snapshot']))
                return dict(job=public)
