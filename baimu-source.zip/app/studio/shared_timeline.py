"""The native graph is authoritative; the browser model is a disposable view.

Only fields changed by an edit are patched. Native effects/unknown fields are
never reconstructed from the browser view. Unrenderable layers block local
preview/export instead of silently rendering an older legacy project.
"""
import copy,hashlib,json,math,os,re,time,unicodedata,uuid
from pathlib import Path
from .core import STYLE,new_project,uid,canonical_numbers,timeline,fps_value,clamp_native_audio_out
from .store import read_json,write_json
from .media import probe
from .native_defaults import timerange,inert_attachment
from .native_blur import compatible_native_effect,native_mask,POSITION_PROPERTIES,SIZE_PROPERTIES,FEATHER_PROPERTY,SUPPORTED_PROPERTIES
from .jianying_bridge import bridge

ROLES={'分离原声':'dialogue','人物原声':'dialogue','旁白':'narration','背景音乐':'bgm','音效':'sfx'}
NAMES={'video':'画面','caption':'字幕','mask':'白色打码','dialogue':'分离原声','narration':'旁白 / 配音','bgm':'背景音乐','sfx':'音效','original':'人物原声（联动）'}
FIELDS=('name','series','style','script','protected_lines','language','reviews','renders','archived','archived_at')
INVALID_DRAFT_NAME=re.compile(r'[<>:"/\\|?*\x00-\x1f]')
WINDOWS_DEVICE_NAMES={'CON','PRN','AUX','NUL','CLOCK$','CONIN$','CONOUT$'}|{
    prefix+str(number) for prefix in ('COM','LPT') for number in range(1,10)
}

def gain(value):return max(-60,min(12,20*math.log10(value))) if value>0 else -60
def sec(value):return value/1_000_000
def us(value):return round(value*1_000_000)
def rgb(value):return '#'+''.join(f'{max(0,min(255,round(x*255))):02x}' for x in value)
def merged(old,new):
    result=copy.deepcopy(old)
    for k,v in new.items():result[k]=merged(result[k],v) if isinstance(v,dict) and isinstance(result.get(k),dict) else copy.deepcopy(v)
    return result


def _episode_number(value):
    """Read an explicit episode marker without treating arbitrary title digits as an episode."""
    value=str(value or '').strip()
    if re.fullmatch(r'\d{1,4}',value):return int(value)
    matches=list(re.finditer(r'(?<![A-Za-z0-9])(?:episode|ep)\.?[\s_.-]*0*(\d{1,4})(?!\d)',value,re.I))
    if matches:return int(matches[-1].group(1))
    match=re.search(r'第\s*(\d{1,4})\s*[集话話回]',value)
    if match:return int(match.group(1))
    # Folder/script import already normalizes Chinese numerals in ordinary
    # cases. Keep a small explicit parser here for legacy names such as 第十集审阅版.
    match=re.search(r'第\s*([零〇一二三四五六七八九十百千两]{1,12})\s*[集话話回]',value)
    if not match:return None
    digits=dict(zip('零〇一二三四五六七八九两',(0,0,1,2,3,4,5,6,7,8,9,2)))
    units={'十':10,'百':100,'千':1000};total=0;digit=None;last=10000
    try:
        for char in match.group(1):
            if char in digits:
                number=digits[char]
                if digit not in (None,0) and number!=0:return None
                digit=number
            else:
                unit=units[char]
                if unit>=last or digit==0:return None
                total+=(1 if digit is None else digit)*unit;digit=None;last=unit
        number=total+(digit or 0)
        return number if 0<=number<=9999 else None
    except KeyError:
        return None


def _safe_draft_component(value,limit=120):
    value=unicodedata.normalize('NFC',str(value or ''))
    value=INVALID_DRAFT_NAME.sub(' ',value)
    value=re.sub(r'\s+',' ',value).strip(' .')
    if not value:value='百慕草稿'
    if value.split('.',1)[0].upper() in WINDOWS_DEVICE_NAMES:value='百慕-'+value
    return value[:limit].rstrip(' .') or '百慕草稿'


def jianying_draft_name(project):
    """Stable Jianying title: drama name + episode number, with the number last."""
    episode=_episode_number(project.get('name',''))
    series=str(project.get('series','')).strip()
    if episode is None:
        name=str(project.get('name','')).strip()
        combined=series if series and (not name or name.casefold() in series.casefold()) else series+name
        return _safe_draft_component(combined)
    suffix=str(episode)
    if series:
        base=series
    else:
        # There is no drama title to invent. Preserve useful text but move the
        # explicit episode marker out of it so the numeric episode stays last.
        base=re.sub(r'第\s*(?:\d{1,4}|[零〇一二三四五六七八九十百千两]{1,12})\s*[集话話回]|(?<![A-Za-z0-9])(?:episode|ep)\.?[\s_.-]*0*\d{1,4}(?!\d)',
                    '',str(project.get('name','')),flags=re.I).strip(' _-.·') or '分集'
    base=_safe_draft_component(base,max(1,120-len(suffix)))
    return base+suffix

def black_picture(material):
    path=Path(material.get('path',''))
    if path.suffix.lower() not in ('.png','.jpg','.jpeg','.bmp','.webp') or not path.is_file():return False
    from PIL import Image
    try:
        with Image.open(path) as picture:return picture.convert('RGB').getbbox() is None
    except (ValueError,OSError):return False

def caption_tag(cue):
    return hashlib.sha256(json.dumps([cue['text'],round(cue['start'],6),round(cue['end'],6)],ensure_ascii=False).encode()).hexdigest()

def caption_metadata(project):
    return {c['id']:dict(tag=caption_tag(c),**{k:copy.deepcopy(c[k]) for k in ('speech','spoken_language') if k in c}) for c in project.get('captions',[])}


def style_equal(left,right):
    if isinstance(left,(int,float)) and isinstance(right,(int,float)):
        return math.isclose(left,right,rel_tol=1e-8,abs_tol=1e-6)
    return left==right


def caption_overrides(actual,global_style,record):
    """Keep inheritance explicit; native edits become only the changed fields."""
    defaults=dict(STYLE,italic=False,underline=False)
    baseline=dict(defaults,**global_style)
    if 'source_style_overrides' not in record:
        return {k:v for k,v in actual.items() if not style_equal(v,baseline.get(k))}
    overrides=copy.deepcopy(record['source_style_overrides'])
    expected=dict(defaults,**record.get('source_style',baseline))
    for key,value in actual.items():
        if not style_equal(value,expected.get(key)):overrides[key]=value
    return overrides


def synchronize_pairs(content,before,after):
    """Apply one timing edit to both native group members, from either lane."""
    previous={s['id']:s for key in ('clips','audios') for s in before[key]}
    current={s['id']:s for key in ('clips','audios') for s in after[key]}
    videos={s['id'] for s in before['clips']};audios={s['id'] for s in before['audios']}
    for group in (content.get('group_container') or {}).get('groups',[]):
        members=group.get('group_members',[])
        if len(members)!=2 or len(set(members)&videos)!=1 or len(set(members)&audios)!=1:continue
        if any(sid not in current for sid in members):
            for key in ('clips','audios'):after[key]=[s for s in after[key] if s['id'] not in members]
            continue
        changes=[]
        for sid in members:
            delta=tuple(current[sid].get(k,0)-previous[sid].get(k,0) for k in ('start','in','out'))
            if any(abs(v)>1e-7 for v in delta):changes.append(delta)
        if not changes:continue
        if any(any(abs(a-b)>1e-6 for a,b in zip(changes[0],delta)) for delta in changes[1:]):
            raise ValueError('同一组画面与原声收到不同的时间修改，请选择其中一条联动编辑')
        for sid in members:
            for key,delta in zip(('start','in','out'),changes[0]):current[sid][key]=previous[sid].get(key,0)+delta


class SharedTimeline:
    def __init__(self,store,service):self.store=store;self.service=service;self.assets={};self.fonts={}

    def _owned_folder(self,folder):
        try:return folder.resolve().parent==(self.service.root/'local-drafts').resolve()
        except OSError:return False

    @staticmethod
    def _unique_folder(root,name,current=None):
        target=root/name
        if target==current or not target.exists():return target
        match=re.fullmatch(r'(.*?)(\d+)',name)
        prefix,episode=(match.group(1),match.group(2)) if match else (name,'')
        for copy_number in range(2,10000):
            candidate=root/(f'{prefix}（{copy_number}）{episode}' if episode else f'{prefix}（{copy_number}）')
            if candidate==current or not candidate.exists():return candidate
        raise ValueError('同名剪映草稿过多，请先整理草稿目录')

    def _new_folder(self,project):
        root=self.service.root/'local-drafts';root.mkdir(parents=True,exist_ok=True)
        target=self._unique_folder(root,jianying_draft_name(project))
        target.mkdir()
        return target

    def _rename_owned_folder(self,pid,project,binding,folder):
        """Rename only Baimu-owned draft directories; never move an external draft.

        Jianying treats the directory component as the durable draft title and
        rewrites its homepage index from that value after opening a draft.
        """
        desired=jianying_draft_name(project)
        if not self._owned_folder(folder) or folder.name==desired:return binding,folder,False
        if self.service.running():return binding,folder,True
        root=(self.service.root/'local-drafts').resolve();target=self._unique_folder(root,desired,folder)
        for path in (root,folder,target):
            if os.path.lexists(path) and self.store.is_link(path):raise ValueError('共同草稿目录包含链接或目录联接，未自动改名')
        index=self.service.index;raw=None;payload=None;entry=None
        if index.is_file():
            raw=bridge.stable_bytes(index);payload=json.loads(raw.decode('utf-8-sig'))
            old_path=os.path.normcase(str(folder.resolve()))
            matches=[row for row in payload.get('all_draft_store',[]) if isinstance(row,dict) and
                     (os.path.normcase(str(Path(row.get('draft_fold_path','')).resolve()))==old_path or
                      binding.get('draft_id') and row.get('draft_id')==binding.get('draft_id'))]
            if len(matches)>1:raise ValueError('剪映索引中同一草稿出现多条记录，未自动移动')
            entry=matches[0] if matches else None
        bindings=self.service.bindings();previous=copy.deepcopy(bindings)
        folder.rename(target);index_written=False
        try:
            if entry is not None:
                entry.update(draft_name=target.name,draft_fold_path=str(target),draft_root_path=str(root),
                             draft_json_file=str(target/'draft_content.json'))
                backup=self.service.root/'index-backups'/(str(time.time_ns())+'.json')
                backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(raw)
                bridge.write_index_checked(index,payload,raw);index_written=True
            updated=dict(binding,key=self.service.key(target),draft_path=str(target),name=target.name)
            bindings['episodes'][pid]=updated;write_json(self.service.root/'bindings.json',bindings)
        except Exception:
            try:
                if index_written:
                    current=bridge.stable_bytes(index)
                    bridge.write_index_checked(index,json.loads(raw.decode('utf-8-sig')),current)
                write_json(self.service.root/'bindings.json',previous)
                if target.exists() and not folder.exists():target.rename(folder)
            finally:
                self.service.cache.pop(binding.get('key'),None);self.service.cache.pop(self.service.key(target),None)
            raise
        self.service.cache.pop(binding.get('key'),None);self.service.cache.pop(updated['key'],None)
        return updated,target,False

    def caption_handoff_repairs(self,content,mapping):
        """Return managed caption IDs whose font, outline or line layout is stale.

        Only captions recorded in Baimu's native mapping are inspected. Native
        captions created or restyled in Jianying are deliberately left alone.
        """
        segments={s['id']:s for track in content.get('tracks',[]) for s in track.get('segments',[])}
        texts={m['id']:m for m in content.get('materials',{}).get('texts',[]) if isinstance(m,dict) and m.get('id')}
        expected_hashes={};repairs=set()
        required=('font_category_id','font_category_name','font_id','font_name','font_path',
                  'font_resource_id','font_source_platform','font_team_id','font_title','font_url','fonts')
        for record in mapping:
            if record.get('source_kind')!='caption':continue
            source_id=record.get('source_id');font_id=record.get('source_style',{}).get('font_id')
            for segment_id in record.get('segments',[]):
                material=texts.get(segments.get(segment_id,{}).get('material_id'))
                if not material:continue
                try:rich=json.loads(material.get('content',''))
                except (TypeError,ValueError):continue
                # A user-created multi-style/recognized caption is outside the
                # simple caption editor and must not be normalized here.
                if len(rich.get('styles',[]))!=1 or any(material.get(k) for k in ('words','text_to_audio_ids','recognize_task_id','base_content')):continue
                path=Path(material.get('font_path',''))
                stale=any(field not in material for field in required) or not path.is_file()
                if not stale and font_id:
                    try:
                        if font_id not in expected_hashes:
                            expected_hashes[font_id]=hashlib.sha256(self.store.original_font_path(font_id).read_bytes()).hexdigest()
                        stale=hashlib.sha256(path.read_bytes()).hexdigest()!=expected_hashes[font_id]
                    except (OSError,ValueError):
                        stale=True
                if not stale:
                    stale=any(style.get('font')!=dict(path=str(path),id='') for style in rich['styles'])
                # Before outline mapping schema 1, Baimu wrote its canvas-pixel
                # value straight into Jianying's panel value. Repair only when
                # the native value still equals that old generated value; a
                # user-edited Jianying outline remains authoritative.
                if not stale and not record.get('native_outline_mapping'):
                    source_outline=record.get('source_style',{}).get('outline')
                    strokes=rich['styles'][0].get('strokes',[])
                    if isinstance(source_outline,(int,float)) and not isinstance(source_outline,bool):
                        old_width=source_outline*.002
                        actual_width=strokes[0].get('width',0) if strokes else 0
                        stale=math.isclose(actual_width,old_width,rel_tol=1e-9,abs_tol=1e-12)
                if not stale:
                    from .native_caption import legacy_layout
                    stale=legacy_layout(material,segments[segment_id],record)
                if stale and source_id:repairs.add(source_id)
        return repairs

    def binding(self,pid):
        row=self.service.bindings()['episodes'].get(pid)
        return row if row and row.get('shared',True) else None

    def management_summaries(self,project_ids):
        """Read authoritative lightweight metadata without decoding every timeline.

        Shared native projects deliberately keep their original project.json as
        provenance.  Name/series/archive changes live in Baimu's native sidecar,
        so home/library summaries must consult that sidecar or they can group an
        episode under a stale pre-handoff series.  Resolve all bindings in one
        pass to keep startup cheap and reject ambiguous or mismatched drafts.
        """
        wanted=set(project_ids)
        if not wanted:return {}
        try:
            bindings=self.service.bindings()['episodes']
            entries=self.service.entries()
        except (OSError,ValueError,RuntimeError) as exc:
            self.store.issues.append(dict(kind='native_metadata_read_error',message=str(exc)))
            return {}
        resolved={};ambiguous=set()
        for entry in entries:
            try:
                folder=Path(entry['draft_fold_path']).resolve();key=self.service.key(folder)
            except (KeyError,TypeError,ValueError,OSError):
                continue
            if key in resolved:
                ambiguous.add(key)
            else:
                resolved[key]=(entry,folder)
        result={}
        for pid in wanted:
            binding=bindings.get(pid)
            if not isinstance(binding,dict) or binding.get('shared',True) is False:continue
            key=binding.get('key')
            if key in ambiguous or key not in resolved:continue
            entry,folder=resolved[key]
            if binding.get('draft_id') and entry.get('draft_id') and binding['draft_id']!=entry['draft_id']:continue
            try:extra=read_json(folder/'BRIDGE_MANAGEMENT.json',{})
            except (OSError,ValueError,TypeError):continue
            management=extra.get('management',{}) if isinstance(extra,dict) else {}
            if not isinstance(management,dict):continue
            summary={}
            # Shared edits leave the legacy project.json untouched. Stat the
            # native files without decoding timelines on the home page.
            modified=[]
            indexed=entry.get('tm_draft_modified')
            if isinstance(indexed,(int,float)) and not isinstance(indexed,bool) and math.isfinite(indexed) and indexed>0:
                modified.append(indexed/1_000_000)
            for name in ('draft_content.json','draft_info.json','draft_meta_info.json','BRIDGE_MANAGEMENT.json'):
                try:modified.append((folder/name).stat().st_mtime)
                except OSError:pass
            if modified:summary['modified']=max(modified)
            if isinstance(management.get('name'),str):summary['name']=management['name']
            if isinstance(management.get('series'),str):summary['series']=management['series']
            if isinstance(management.get('archived'),bool):summary['archived']=management['archived']
            if management.get('archived_at') is None or isinstance(management.get('archived_at'),(int,float)):
                summary['archived_at']=management.get('archived_at')
            if summary:result[pid]=summary
        return result

    def activate(self,project):
        """Convert once into an app-owned native draft; legacy JSON is provenance."""
        if self.binding(project['id']):return self.project(project['id'],project)
        if any(m.get('mode','blur')=='blur' and m.get('white',0)>0 for m in project.get('masks',[])):
            raise ValueError('现有模糊增白尚不能等效转入共同工程，原工程保留；可使用白色打码或原有兼容迁移入口')
        from .native_migration import build_content,load_builder
        folder=self._new_folder(project);draft_name=folder.name
        report=dict(editable_available=True,editable_blocked=[],editable_warnings=[],preservation={})
        content,proof=build_content(self.store,project,folder,'editable',report,allow_offline_audio=True)
        content['baimu']=dict(schema=1,management={k:copy.deepcopy(project[k]) for k in FIELDS if k in project},assets=copy.deepcopy(project['assets']),mapping=proof['mapping'],caption_metadata=caption_metadata(project))
        from .native_resources import stabilize
        content=stabilize(content,folder,self.service.root/'resources')
        write_json(folder/'BRIDGE_MANAGEMENT.json',content['baimu'])
        content['name']=draft_name
        write_json(folder/'draft_content.json',content)
        now=time.time_ns()//1000;project_id=str(uuid.uuid4()).upper();tid=content['id']
        write_json(folder/'Timelines'/tid/'draft_content.json',content)
        write_json(folder/'Timelines/project.json',dict(config={},id=project_id,main_timeline_id=tid,timelines=[dict(id=tid,name='时间线01',is_marked_delete=False)],version=0))
        d=load_builder();meta=json.loads((Path(d.__file__).parent/'assets/draft_meta_info.json').read_text(encoding='utf-8'))
        meta.update(draft_id=project_id,draft_name=draft_name,draft_fold_path=str(folder.resolve()),draft_root_path=str(folder.parent.resolve()),tm_draft_create=now,tm_draft_modified=now,tm_duration=content.get('duration',0))
        write_json(folder/'draft_meta_info.json',meta)
        state=bridge.load(folder,str(self.service.install))
        self.service.bind(dict(project_id=project['id'],key=self.service.key(folder),revision=state['revision']))
        return self.project(project['id'],project)

    def register(self,pid,revision):
        """Register the same canonical directory in Jianying, without rebuilding."""
        p=self.store.get(pid)
        if p['revision']!=revision:raise ValueError('工程版本已变化，请重新读取后交给剪映')
        binding,folder,state,content=self.state(pid)
        extra=content.get('baimu') or read_json(folder/'BRIDGE_MANAGEMENT.json',{})
        mapping=extra.get('mapping',read_json(folder/'BAIMU_TRACK_MAP.json',{}).get('mapping',[]))
        if self.caption_handoff_repairs(content,mapping):
            # Upgrade old Baimu captions in place before exposing this exact
            # directory to Jianying. save() performs a field-level patch and
            # preserves every unrelated native/unknown field.
            p=self.save(pid,p,p)
            binding,folder,state,content=self.state(pid)
        previous_folder=folder
        binding,folder,name_migration_deferred=self._rename_owned_folder(pid,p,binding,folder)
        draft_name=folder.name
        index=self.service.index
        if not index.is_file():raise ValueError('请先启动一次剪映，建立本机草稿索引')
        from .native_resources import stabilize,validate_audio_paths
        ordered=copy.deepcopy(content)
        if not ordered.get('baimu'):
            metadata=read_json(folder/'BRIDGE_MANAGEMENT.json',{})
            if metadata:ordered['baimu']=metadata
        ordered=stabilize(ordered,folder,self.service.root/'resources',legacy_folders=[self.service.root/'local-drafts'/pid,previous_folder])
        validate_audio_paths(ordered)
        for track in ordered['tracks']:track['segments'].sort(key=lambda s:timerange(s['target_timerange'])['start'])
        ordered['name']=draft_name
        meta,_=bridge.decode(bridge.stable_bytes(folder/'draft_meta_info.json'),str(self.service.install))
        meta_changed=(meta.get('draft_name')!=draft_name or Path(meta.get('draft_fold_path','')).resolve()!=folder.resolve())
        if ordered!=content or meta_changed:
            from .native_patch import save as commit
            commit(self.service,dict(key=binding['key'],revision=state['revision'],operation=dict(type='prepare_handoff')),
                transform=lambda original:ordered,meta_updates=dict(draft_name=draft_name,draft_fold_path=str(folder.resolve()),
                    draft_root_path=str(folder.parent.resolve()),tm_duration=ordered.get('duration',0),tm_draft_modified=time.time_ns()//1000))
            binding,folder,state,content=self.state(pid)
            if content.get('baimu'):write_json(folder/'BRIDGE_MANAGEMENT.json',content['baimu'])
        raw=bridge.stable_bytes(index);payload=json.loads(raw.decode('utf-8-sig'))
        existing=next((e for e in payload.get('all_draft_store',[]) if Path(e.get('draft_fold_path','')).resolve()==folder.resolve()),None)
        now=time.time_ns()//1000
        if existing:
            # An explicit re-import must surface the existing draft again, even
            # when its title and duration have not changed.
            existing.update(draft_name=draft_name,tm_duration=content.get('duration',0),tm_draft_modified=now,
                draft_is_invisible=False,tm_draft_removed=0,draft_json_file=str(folder/'draft_content.json'))
            payload['all_draft_store'].remove(existing);payload['all_draft_store'].insert(0,existing)
        if not existing:
            meta,_=bridge.decode(bridge.stable_bytes(folder/'draft_meta_info.json'),str(self.service.install))
            entry=dict(draft_id=meta['draft_id'],draft_name=draft_name,draft_fold_path=str(folder),draft_root_path=str(folder.parent),
                draft_json_file=str(folder/'draft_content.json'),draft_cover='',draft_type='',draft_new_version='',draft_is_invisible=False,
                draft_is_cloud_temp_draft=False,cloud_draft_cover=False,cloud_draft_sync=False,tm_draft_create=meta.get('tm_draft_create',now),
                tm_draft_modified=now,tm_draft_removed=0,tm_duration=content.get('duration',0),draft_timeline_materials_size=0)
            payload.setdefault('all_draft_store',[]).insert(0,entry)
            existing=entry
        if isinstance(payload.get('draft_ids'),list) and existing['draft_id'] not in payload['draft_ids']:payload['draft_ids'].append(existing['draft_id'])
        if index.read_bytes()!=raw or bridge.fingerprint(folder)['revision']!=state['revision']:
            raise ValueError('登记期间工程或索引改变，请重试')
        backup=self.service.root/'index-backups'/(str(time.time_ns())+'.json');backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(raw)
        bridge.write_index_checked(index,payload,raw)
        registered=json.loads(bridge.stable_bytes(index).decode('utf-8-sig'))
        verified=[e for e in registered.get('all_draft_store',[]) if e.get('draft_id')==existing['draft_id'] and Path(e.get('draft_fold_path','')).resolve()==folder.resolve()]
        if len(verified)!=1 or verified[0].get('draft_is_invisible') or verified[0].get('tm_draft_removed',0) or verified[0].get('draft_name')!=draft_name:
            raise ValueError('登记后剪映草稿列表又发生变化，请先在剪映保存并返回首页后重试；若仍持续变化，再退出剪映重开')
        editor_running=self.service.running()
        return dict(key=binding['key'],path=str(folder),name=draft_name,same_timeline=True,registered=True,
            editor_running=editor_running,refresh_required=editor_running,modified_us=now,
            name_migration_deferred=name_migration_deferred,
            message=('旧草稿目录正被剪映使用；关闭剪映后再交接一次会完成永久改名。' if name_migration_deferred else '已登记并更新最近修改时间。')+
                    ('剪映正在运行，请保存当前页面并返回首页后打开这一集；若首页仍缓存旧列表，再重启剪映。' if editor_running else '打开剪映，在本地草稿按最近修改查找。'))

    def state(self,pid):
        binding=self.binding(pid)
        if not binding:return None
        try:entry,folder=self.service.resolve(binding['key'])
        except ValueError:
            matches=[e for e in self.service.entries() if binding.get('draft_id') and e.get('draft_id')==binding['draft_id']]
            if len(matches)!=1:raise ValueError('原生草稿已移动或同ID存在多个候选，请重新关联')
            entry=matches[0];folder=Path(entry['draft_fold_path']).resolve()
            binding=dict(binding,key=self.service.key(folder),draft_path=str(folder))
            with self.service.lock:
                bindings=self.service.bindings();bindings['episodes'][pid]=binding;write_json(self.service.root/'bindings.json',bindings)
        # Baimu readers and writers share the native transaction mutex. External
        # changes still use the before/after fingerprint checks in bridge.load.
        with self.service.lock:
            fingerprint=bridge.fingerprint(folder)['revision'];cached=self.service.cache.get(binding['key'])
            if cached and cached['state']['revision']==fingerprint and cached.get('meta'):
                state,meta=cached['state'],cached['meta']
            else:
                state=bridge.load(folder,str(self.service.install))
                meta,_=bridge.decode(bridge.stable_bytes(folder/'draft_meta_info.json'),str(self.service.install))
                if len(self.service.cache)>=3:self.service.cache.pop(next(iter(self.service.cache)))
                self.service.cache[binding['key']]={'state':state,'meta':meta}
            if bridge.fingerprint(folder)['revision']!=state['revision']:raise ValueError('读取期间原生工程改变，请稍后重试')
            if binding.get('draft_id') and meta.get('draft_id')!=binding['draft_id']:
                raise ValueError('关联的草稿ID与当前目录不符，未读取其他工程')
            if entry.get('draft_id') and meta.get('draft_id')!=entry['draft_id']:
                raise ValueError('剪映索引与草稿ID不符，未读取其他工程')
        return binding,folder,state,state['documents'][state['main_mirrors'][0]]['object']

    def asset(self,material,kind,base):
        path=material.get('path','');source=Path(path)
        old=next((a for a in base.get('assets',[]) if Path(a.get('path','')).as_posix()==source.as_posix()),None)
        stat=source.stat() if source.is_file() else None
        key=(path,kind,stat.st_size if stat else None,stat.st_mtime_ns if stat else None)
        if key not in self.assets:
            if stat:
                a=probe(source)
                native_name=material.get('name') or material.get('material_name')
                if native_name and native_name!=source.name:a['name']=native_name
                elif old and old.get('name'):a['name']=old['name']
                if old and old.get('source_relative_path'):a['source_relative_path']=old['source_relative_path']
            else:
                a=copy.deepcopy(old) if old else dict(duration=sec(material.get('duration',0)),has_audio=kind=='audio',audio_streams=[],size=0,mtime_ns=0,sha256='')
                a.update(path=path,name=material.get('name',material.get('material_name',source.name)),kind=kind)
            a['id']=old['id'] if old else uuid.uuid5(uuid.NAMESPACE_URL,kind+':'+path).hex
            self.assets[key]=a
        result=copy.deepcopy(self.assets[key])
        raw_native_duration=material.get('duration')
        if isinstance(raw_native_duration,(int,float)) and not isinstance(raw_native_duration,bool) and math.isfinite(raw_native_duration) and raw_native_duration>0:
            result['native_duration']=sec(raw_native_duration)
        return result

    def font(self,path,default):
        if not path or not Path(path).is_file():return default
        stat=Path(path).stat();key=(path,stat.st_size,stat.st_mtime_ns)
        if key not in self.fonts:
            from .native_caption import font_hash
            signature=font_hash(path)
            existing=next((f for f in self.store.fonts.values() if Path(f['path']).is_file() and font_hash(f['path'])==signature),None)
            self.fonts[key]=(existing or self.store.import_font(path))['id']
        return self.fonts[key]

    def project(self,pid,base):
        data=self.state(pid)
        if data is None:return base
        binding,folder,state,content=data
        extra=content.get('baimu') or read_json(folder/'BRIDGE_MANAGEMENT.json',{})
        seed=read_json(folder/'BAIMU_SOURCE_PROJECT.json',base)
        mapping=extra.get('mapping',read_json(folder/'BAIMU_TRACK_MAP.json',{}).get('mapping',[]))
        records={sid:r for r in mapping if r.get('representation')!='silent_source_video' for sid in r.get('segments',[])}
        p=copy.deepcopy(base)
        p.update(copy.deepcopy(extra.get('management',{})))
        p.update(width=content.get('canvas_config',{}).get('width',base['width']),height=content.get('canvas_config',{}).get('height',base['height']),fps=str(content.get('fps',base['fps'])))
        p.update(clips=[],audios=[],captions=[],masks=[],assets=copy.deepcopy(extra.get('assets',seed.get('assets',[]))),track_locks=[])
        p['style']=copy.deepcopy(extra.get('management',{}).get('style',seed.get('style',STYLE)))
        materials={m['id']:m for rows in content['materials'].values() if isinstance(rows,list) for m in rows if isinstance(m,dict) and m.get('id')}
        categories={m['id']:kind for kind,rows in content['materials'].items() if isinstance(rows,list) for m in rows if isinstance(m,dict) and m.get('id')}
        caption_layers=[(timerange(s['target_timerange']),s.get('render_index',i)) for i,t in enumerate(content['tracks']) if t['type']=='text' for s in t.get('segments',[])]
        links={};issues=[];gaps=[];asset_ids={a['id']:i for i,a in enumerate(p['assets'])}
        def add_asset(mat,kind):
            a=self.asset(mat,kind,dict(assets=p['assets']))
            if a['id'] in asset_ids:p['assets'][asset_ids[a['id']]]=a
            else:asset_ids[a['id']]=len(p['assets']);p['assets'].append(a)
            return a
        for track in content['tracks']:
            for s in track.get('segments',[]):
                sid=s['id'];mat=materials.get(s.get('material_id'),{});record=records.get(sid,{})
                kind=record.get('source_kind')
                if kind=='original':kind='dialogue'
                if kind not in ('video','caption','mask','dialogue','narration','bgm','sfx'):
                    kind='caption' if track['type']=='text' else next((role for name,role in ROLES.items() if track.get('name','').startswith(name)), 'dialogue') if track['type']=='audio' else 'video' if track['type']=='video' and not track.get('flag',0)&2 else 'mask' if track['type']=='effect' and compatible_native_effect(s,mat) else None
                if not record and track['type']=='video' and black_picture(mat):
                    gap=timerange(s['target_timerange']);gaps.append((sec(gap['start']),sec(gap['start']+gap['duration'])));continue
                tr=timerange(s.get('target_timerange',{}));sr=timerange(s.get('source_timerange') or {})
                start,end=sec(tr['start']),sec(tr['start']+tr['duration'])
                if s.get('visible',True) is False or track.get('attribute',0)&2:
                    issues.append('隐藏或静音轨道暂不支持本地合成：'+track.get('name',''));continue
                if s.get('reverse') or not math.isclose(s.get('speed',1),1):issues.append('变速或倒放：'+sid)
                if s.get('keyframe_refs'):issues.append('关联关键帧：'+sid)
                if kind=='video':
                    if Path(mat.get('path','')).suffix.lower() in ('.png','.jpg','.jpeg','.bmp','.webp'):
                        issues.append('原生图片画面需在剪映合成：'+sid);continue
                    a=add_asset(mat,'video')
                    length=sec(sr['duration']);fps=fps_value(p['fps']);quantized=round(length*fps)/fps
                    if abs(length-quantized)<=.0000011:length=quantized
                    p['clips'].append(dict(id=sid,asset_id=a['id'],start=start,**{'in':sec(sr['start']),'out':sec(sr['start'])+length},gain=gain(s.get('volume',1)),audio_detached=s.get('volume',1)==0))
                    clip=s.get('clip') or {}
                    if any(abs(clip.get('transform',{}).get(k,0))>1e-7 or abs(clip.get('scale',{}).get(k,1)-1)>1e-7 for k in ('x','y')) or clip.get('rotation',0) or clip.get('alpha',1)!=1 or any(clip.get('flip',{}).values()):issues.append('画面变换：'+sid)
                    if s.get('common_keyframes'):issues.append('画面关键帧：'+sid)
                    crop=mat.get('crop',{})
                    expected_crop={'upper_left_x':0,'upper_left_y':0,'upper_right_x':1,'upper_right_y':0,'lower_left_x':0,'lower_left_y':1,'lower_right_x':1,'lower_right_y':1}
                    if any(abs(crop.get(k,v)-v)>1e-7 for k,v in expected_crop.items()):issues.append('画面裁切：'+sid)
                elif kind in ROLES.values():
                    a=add_asset(mat,'audio')
                    streams=a.get('audio_streams',[])
                    item=dict(id=sid,asset_id=a['id'],role=kind,start=start,**{'in':sec(sr['start']),'out':sec(sr['start']+sr['duration'])},gain=gain(s.get('volume',1)),loop=False)
                    item['out']=clamp_native_audio_out(a,p['fps'],item['out'])
                    if s.get('volume',1)==0:item['muted']=True
                    if len(streams)==1:item['audio_stream']=streams[0]['index']
                    extraction=record.get('extraction',{})
                    if kind=='dialogue' and extraction.get('file_sha256')==a.get('sha256'):
                        origin=next((asset for asset in extra.get('assets',seed.get('assets',[])) if asset.get('path')==extraction.get('source_path')),None)
                        if origin:item.update(source_asset_id=origin['id'],source_audio_stream=extraction.get('source_stream'))
                    for ref in s.get('extra_material_refs',[]):
                        fade=materials.get(ref,{})
                        if fade.get('type')=='audio_fade':item.update(fade_in=sec(fade.get('fade_in_duration',0)),fade_out=sec(fade.get('fade_out_duration',0)))
                    p['audios'].append(item)
                    if s.get('common_keyframes'):issues.append('音量关键帧：'+sid)
                elif kind=='caption':
                    try:
                        rich=json.loads(mat['content']);styles=rich.get('styles',[])
                        if len(styles)!=1:issues.append('多样式字幕：'+sid)
                        st=styles[0] if styles else {};source_style=record.get('source_style',p['style']);style=copy.deepcopy(source_style)
                        style['font_id']=self.font(mat.get('font_path',st.get('font',{}).get('path','')),style.get('font_id',''))
                        size_map=record.get('native_font_mapping',{});ratio=(size_map.get('calibration') or {}).get('native_units_per_1080px',1/8)
                        # A font changed in Jianying invalidates the old face's
                        # calibration, even if the old mapping record remains.
                        calibration_path=(self.store.fonts.get(style['font_id'],{}).get('path','')
                                          if size_map and style['font_id']!=source_style.get('font_id') else mat.get('font_path',''))
                        if (not size_map or style['font_id']!=source_style.get('font_id')) and Path(calibration_path).is_file():
                            from .native_caption import conversion
                            calibrated=conversion(self.store,p,style,calibration_path)
                            ratio=calibrated['native_font_size']/calibrated['source_font_size_px']
                        style.update(font_size=st.get('size',style['font_size']*ratio)/ratio,bold=st.get('bold',False),italic=st.get('italic',False),underline=st.get('underline',False),opacity=mat.get('global_alpha',1),
                            x=((s.get('clip') or {}).get('transform',{}).get('x',0)+1)*50,y=(1-(s.get('clip') or {}).get('transform',{}).get('y',0))*50,
                            spacing=mat.get('letter_spacing',0)/.05,line_spacing=(mat.get('line_spacing',.02)-.02)/.05,max_width=mat.get('line_max_width',.84)*100)
                        fill=st.get('fill',{}).get('content',{}).get('solid',{})
                        if fill.get('color'):style['color']=rgb(fill['color'])
                        strokes=st.get('strokes',[])
                        native_outline=strokes[0].get('width',0)/.002 if strokes else 0
                        outline_map=record.get('native_outline_mapping')
                        # Preserve an untouched legacy Baimu value so handoff can
                        # upgrade it. If Jianying changed it, read the actual
                        # panel value back through the calibrated 5:1 mapping.
                        source_outline=source_style.get('outline',0)
                        if not outline_map and math.isclose(native_outline,source_outline,rel_tol=1e-9,abs_tol=1e-9):
                            style['outline']=source_outline
                        else:
                            from .native_caption import canvas_outline
                            style['outline']=canvas_outline(native_outline)
                        if strokes:
                            solid=strokes[0].get('content',{}).get('solid',{});style.update(outline_color=rgb(solid.get('color',[0,0,0])),outline_opacity=solid.get('alpha',1))
                        shadows=st.get('shadows',[])
                        style.update(shadow=shadows[0].get('distance',0) if shadows else 0,shadow_opacity=shadows[0].get('alpha',0) if shadows else 0,
                            shadow_angle=shadows[0].get('angle',45) if shadows else 45,shadow_blur=shadows[0].get('diffuse',0)*600 if shadows else 0)
                        from .native_caption import source_text
                        cue=dict(id=sid,start=start,end=end,text=source_text(rich.get('text',''),record),style=caption_overrides(style,p['style'],record))
                        annotations=extra.get('caption_metadata',{}).get(sid,{})
                        if annotations.get('tag')==caption_tag(cue) and 'speech' in annotations:cue['speech']=copy.deepcopy(annotations['speech'])
                        if 'spoken_language' in annotations:cue['spoken_language']=annotations['spoken_language']
                        p['captions'].append(cue)
                        if s.get('common_keyframes') or (s.get('clip') or {}).get('rotation',0):issues.append('字幕动画或旋转：'+sid)
                        scale=(s.get('clip') or {}).get('scale') or {}
                        if any(not math.isclose(scale.get(axis,1),1,abs_tol=1e-9) for axis in ('x','y')):
                            issues.append('字幕缩放需在剪映预览/导出，原生效果已保留：'+sid)
                        clip=s.get('clip') or {}
                        if clip.get('alpha',1)!=1 or any((clip.get('flip') or {}).values()):
                            issues.append('字幕片段透明度或翻转需在剪映合成：'+sid)
                        if st.get('fill',{}).get('alpha',1)!=1 or fill.get('alpha',1)!=1 or len(strokes)>1 or len(shadows)>1:
                            issues.append('字幕分层透明度、多重描边或阴影需在剪映合成：'+sid)
                        if mat.get('alignment',1)!=1 or mat.get('typesetting',0)!=0:
                            issues.append('字幕非居中对齐或竖排需在剪映合成：'+sid)
                        if mat.get('background_style',0) and mat.get('background_alpha',1)>0:
                            issues.append('字幕背景样式需在剪映合成：'+sid)
                        if st.get('fill',{}).get('content',{}).get('render_type','solid')!='solid' or any(
                                any(abs(v)>1e-9 for v in shadow.get('content',{}).get('solid',{}).get('color',[0,0,0])) for shadow in shadows):
                            issues.append('字幕渐变或彩色阴影需在剪映合成：'+sid)
                    except (ValueError,KeyError,TypeError):issues.append('无法解析字幕：'+sid);continue
                elif kind=='mask':
                    mid=sid if re.fullmatch('[a-f0-9]{32}',sid) else uuid.uuid5(uuid.NAMESPACE_URL,sid).hex
                    mask=copy.deepcopy(record.get('source_mask',{}));mode='solid' if track['type']=='video' else 'blur'
                    if mode=='solid':
                        clip=s.get('clip') or {};scale=clip.get('scale',{});pos=clip.get('transform',{})
                        w=scale.get('x',1)*1080;h=scale.get('y',1)*1080;x=(pos.get('x',0)+1)*540-w/2;y=(1-pos.get('y',0))*960-h/2
                        kinds=('KFTypePositionX','KFTypePositionY')
                        frames={k['property_type']:k.get('keyframe_list',[]) for k in s.get('common_keyframes',[])}
                        xs={f.get('time_offset',0):f['values'][0] for f in frames.get(kinds[0],[])};ys={f.get('time_offset',0):f['values'][0] for f in frames.get(kinds[1],[])}
                        def at(points,offset,initial):
                            items=sorted({0:initial,**points}.items());value=items[0][1]
                            for (t0,v0),(t1,v1) in zip(items,items[1:]):
                                if offset<t1:return v0+(v1-v0)*(offset-t0)/(t1-t0)
                                value=v1
                            return value
                        x=(xs.get(0,(x+w/2)/540-1)+1)*540-w/2;y=(1-ys.get(0,1-(y+h/2)/960))*960-h/2
                        points=[]
                        for offset in sorted(set(xs)|set(ys)):
                            if offset==0 or offset>=tr['duration']:continue
                            points.append(dict(time=start+sec(offset),x=(at(xs,offset,(x+w/2)/540-1)+1)*540-w/2,y=(1-at(ys,offset,1-(y+h/2)/960))*960-h/2))
                        mask.update(id=mid,start=start,end=end,x=round(x,6),y=round(y,6),w=round(w,6),h=round(h,6),mode=mode,blur=mask.get('blur',18),white=mask.get('white',0),feather=0,keyframes=points)
                    else:
                        mask=native_mask(p,s,mat,mask);mask['id']=mid
                    overlapping=[order for target,order in caption_layers if target['start']<tr['start']+tr['duration'] and tr['start']<target['start']+target['duration']]
                    if overlapping:
                        order=s.get('render_index',content['tracks'].index(track))
                        mask['layer']='above_captions' if order>max(overlapping) else 'below_captions'
                        if min(overlapping)<order<max(overlapping):issues.append('打码位于多层字幕之间，需在剪映合成')
                    else:mask.setdefault('layer','below_captions')
                    p['masks'].append(mask);sid_view=mid
                else:issues.append('不支持的原生图层：'+track.get('name',track['type']));continue
                viewid=mid if kind=='mask' else sid
                links[viewid]=dict(segment_id=sid,track_id=track['id'],kind=kind)
                if track.get('attribute',0)&4 and kind not in p['track_locks']:p['track_locks'].append(kind)
                # These references change output and must never be silently ignored.
                for ref in s.get('extra_material_refs',[]):
                    referenced=materials.get(ref,{})
                    if referenced and referenced.get('type') not in ('speed','audio_fade','placeholder_info') and not inert_attachment(categories.get(ref),referenced):
                        issues.append('未支持的原生附加效果：'+str(referenced.get('type') or categories.get(ref) or '未知效果'))
                    if referenced.get('type')=='speed' and (referenced.get('curve_speed') or referenced.get('speed',1)!=1):issues.append('曲线或附加变速：'+sid)
        p['clips'].sort(key=lambda c:c['start']);p['captions'].sort(key=lambda c:c['start']);p['audios'].sort(key=lambda a:(a['role'],a['start']))
        if any(b['start']<a['start']+a['out']-a['in']-1e-6 for a,b in zip(p['clips'],p['clips'][1:])):
            issues.append('多层重叠画面需在剪映合成')
        if any(max(start,c['start'])<min(end,c['start']+c['out']-c['in'])-1e-6 for start,end in gaps for c in p['clips']):
            issues.append('原生黑场图层与画面重叠，需在剪映合成')
        if p['style'].get('font_id') not in self.store.fonts and p['captions']:p['style']['font_id']=p['captions'][0]['style'].get('font_id',p['style'].get('font_id',''))
        for group in (content.get('group_container') or {}).get('groups',[]):
            members=group.get('group_members',[])
            video=[sid for sid in members if links.get(sid,{}).get('kind')=='video']
            audio=[sid for sid in members if links.get(sid,{}).get('kind')=='dialogue']
            if len(members)==2 and len(video)==len(audio)==1:
                links[audio[0]]['linked_video_id']=video[0]
                links[video[0]]['linked_audio_id']=audio[0]
        revision_material=state['revision']+json.dumps(extra.get('management',{}),sort_keys=True)
        p['revision']=int(hashlib.sha256(revision_material.encode()).hexdigest()[:13],16)
        p['native']=dict(key=binding['key'],revision=state['revision'],path=str(folder),duration_us=content.get('duration',0),issues=sorted(set(issues)),shared=True)
        p['native_render_hash']=hashlib.sha256(json.dumps(canonical_numbers({k:v for k,v in content.items() if k!='baimu'}),sort_keys=True,separators=(',',':')).encode()).hexdigest()
        p['native_links']=links
        for audio in p['audios']:audio['linked_video_id']=links.get(audio['id'],{}).get('linked_video_id')
        p['reviews']=copy.deepcopy(extra.get('management',{}).get('reviews',{}))
        return p

    def save(self,pid,before,after,refreshed_assets=(),relinked_assets=()):
        data=self.state(pid)
        if data is None:raise ValueError('工程未绑定原生时间线')
        binding,folder,state,content=data
        if before['native']['revision']!=state['revision']:raise ValueError('工程已在剪映改变，请重新读取当前版本')
        after=copy.deepcopy(after)
        from .native_linking import prepare,restore,media_view
        working,restored_pairs=prepare(content,before,after)
        synchronize_pairs(working,before,after)
        from .native_replacement import prepare_originals
        replacement_originals=prepare_originals(before,after,folder/'Resources')
        from .core import validate
        validate(after)
        if any(m.get('mode','blur')=='blur' and m.get('white',0)>0 for m in after.get('masks',[])):
            raise ValueError('剪映共同工程的模糊不含增白参数，请设为0或使用白色打码')
        from .native_migration import build_content
        from .native_patch import save as commit
        obj=working
        extra=working.get('baimu') or read_json(folder/'BRIDGE_MANAGEMENT.json',{})
        mapping=copy.deepcopy(extra.get('mapping',read_json(folder/'BAIMU_TRACK_MAP.json',{}).get('mapping',[])))
        editing_keys=('width','height','fps','clips','audios','captions','masks','style','track_locks')
        caption_repairs=self.caption_handoff_repairs(working,mapping)
        changed=bool(caption_repairs) or any(canonical_numbers(media_view(before,k))!=canonical_numbers(media_view(after,k)) for k in editing_keys)
        if changed:
            if before.get('native',{}).get('issues'):
                raise ValueError('此工程包含简易编辑尚未支持的效果，请使用原生参数接口或剪映编辑：'+'；'.join(before['native']['issues']))
            previous_audio={a['id']:a for a in before['audios']}
            for audio in after['audios']:
                if audio['id'] in previous_audio and audio.get('gain')!=previous_audio[audio['id']].get('gain'):audio.pop('muted',None)
            report=dict(editable_available=True,editable_blocked=[],editable_warnings=[],preservation={})
            build_project=after
            # Overlay-only changes never rebuild or rehash the episode's AV media.
            if all(canonical_numbers(before.get(k))==canonical_numbers(after.get(k)) for k in ('width','height','fps','clips','audios','track_locks')):
                build_project=copy.deepcopy(after)
                build_project.update(clips=[],audios=[])
                if before['captions']==after['captions'] and before['style']==after['style'] and not caption_repairs:build_project['captions']=[]
                if before['masks']==after['masks']:build_project['masks']=[]
            candidate,proof=build_content(self.store,build_project,folder,'editable',report,allow_offline_audio=True,write_sidecars=False)
            obj,mapping=self.patch(working,candidate,before,after,proof['mapping'],mapping,caption_repairs)
        restore(obj,restored_pairs)
        for record in mapping:
            for sid in record.get('segments',[]):
                if sid in replacement_originals:record['extraction']=copy.deepcopy(replacement_originals[sid])
        if relinked_assets:
            from .native_refresh import relink_graph
            obj,mapping=relink_graph(obj,mapping,before,after,relinked_assets)
        if refreshed_assets:
            from .native_refresh import refresh_graph
            obj,mapping=refresh_graph(obj,mapping,after,refreshed_assets,folder/'Resources')
            after['reviews']={}
            for cue in after['captions']:cue.pop('speech',None)
        management={k:copy.deepcopy(after[k]) for k in FIELDS if k in after}
        metadata=copy.deepcopy(extra)
        metadata.update(schema=1,management=dict(metadata.get('management',{}),**management),assets=copy.deepcopy(after['assets']),mapping=mapping,caption_metadata=caption_metadata(after))
        obj['baimu']=metadata
        from .native_resources import stabilize
        obj=stabilize(obj,folder,self.service.root/'resources',legacy_folders=[self.service.root/'local-drafts'/pid])
        native_name=folder.name
        if obj.get('name')!=native_name:obj['name']=native_name
        if obj!=content:
            commit(self.service,dict(key=binding['key'],revision=state['revision'],operation=dict(type='editor_save',project_id=pid)),transform=lambda original:obj,
                meta_updates=dict(draft_name=native_name,draft_fold_path=str(folder.resolve()),draft_root_path=str(folder.parent.resolve()),
                                  tm_duration=obj.get('duration',0),tm_draft_modified=time.time_ns()//1000))
            write_json(folder/'BRIDGE_MANAGEMENT.json',obj['baimu'])
            if ((before.get('name')!=after.get('name') or before.get('series')!=after.get('series')) and not self.service.running()
                    and any(not e.get('internal') and self.service.key(e['draft_fold_path'])==binding['key'] for e in self.service.entries())):
                current=self.project(pid,read_json(self.store.path(pid)))
                self.register(pid,current['revision'])
        if refreshed_assets or relinked_assets:self.assets.clear()
        return self.project(pid,read_json(self.store.path(pid)))

    def patch(self,content,candidate,before,after,mapping,old_mapping,caption_repairs=None):
        caption_repairs=caption_repairs or set()
        obj=copy.deepcopy(content)
        tracks={t['id']:t for t in obj['tracks']};segs={s['id']:s for t in obj['tracks'] for s in t.get('segments',[])}
        candidate_segs={s['id']:(t,s) for t in candidate['tracks'] for s in t.get('segments',[])}
        candidate_mats={m['id']:(kind,m) for kind,rows in candidate['materials'].items() if isinstance(rows,list) for m in rows if isinstance(m,dict) and 'id' in m}
        old_mats={m['id']:m for rows in obj['materials'].values() if isinstance(rows,list) for m in rows if isinstance(m,dict) and 'id' in m}
        old_records={r['source_id']:r for r in old_mapping if r.get('source_kind')!='original'}
        new_records={r['source_id']:r for r in mapping if r.get('source_kind')!='original'}
        def import_material(mid):
            if mid in old_mats or mid not in candidate_mats:return
            kind,mat=candidate_mats[mid];obj['materials'].setdefault(kind,[]).append(copy.deepcopy(mat));old_mats[mid]=obj['materials'][kind][-1]
        def attach(s,track,derived=False):
            if not derived and track.get('attribute',0)&4:raise ValueError('目标原生轨道已锁定，请先解锁')
            import_material(s['material_id'])
            for ref in s.get('extra_material_refs',[]):import_material(ref)
            track['segments'].append(copy.deepcopy(s));segs[s['id']]=track['segments'][-1]
        def lane(record,ct):
            existing=tracks.get(record.get('track_id'))
            if existing:return existing
            existing=next((t for t in obj['tracks'] if t['type']==ct['type'] and t.get('name')==ct.get('name')),None)
            if existing:return existing
            t=copy.deepcopy(ct);t['segments']=[];obj['tracks'].append(t);tracks[t['id']]=t;return t
        def unlocked(sid):
            t=next((t for t in obj['tracks'] if any(s['id']==sid for s in t['segments'])),None)
            if t and t.get('attribute',0)&4:raise ValueError('原生轨道已锁定，请先解锁再修改')
        def remove(sid):
            unlocked(sid)
            for t in obj['tracks']:t['segments']=[s for s in t['segments'] if s['id']!=sid]
            segs.pop(sid,None)
            for group in (obj.get('group_container') or {}).get('groups',[]):
                group['group_members']=[s for s in group['group_members'] if s!=sid]
        arrays=('clips','audios','captions','masks')
        # Filler clips are generated from gaps, never an independent edit layer.
        picture_changed=before['clips']!=after['clips'] or before['fps']!=after['fps']
        if picture_changed:
            for track in obj['tracks']:
                track['segments']=[s for s in track['segments'] if not (track['type']=='video' and s['id'] not in before.get('native_links',{}) and black_picture(old_mats.get(s.get('material_id'),{})))]
        changed_ids=set();new_originals=[]
        for array in arrays:
            left={s['id']:s for s in before.get(array,[])};right={s['id']:s for s in after.get(array,[])}
            # Visit existing IDs then new IDs deterministically. A set here made
            # new native segments depend on Python's randomized hash order.
            for viewid in dict.fromkeys([*left,*right]):
                if canonical_numbers(left.get(viewid))==canonical_numbers(right.get(viewid)) and not (array=='captions' and (before['style']!=after['style'] or viewid in caption_repairs)):continue
                changed_ids.add(viewid);link=before.get('native_links',{}).get(viewid,{})
                sid=link.get('segment_id',viewid);old=segs.get(sid)
                if viewid not in right:
                    group=next((g for g in (obj.get('group_container') or {}).get('groups',[]) if g.get('id')==(old or {}).get('group_id')),None)
                    members=list(group['group_members']) if group and array=='clips' else [sid]
                    for member in members:remove(member)
                    continue
                record=new_records.get(viewid)
                if record is None:raise ValueError('编辑后的片段没有原生表示')
                candidate_parts=[candidate_segs[s] for s in record['segments']]
                if old is None:
                    for ct,s in candidate_parts:attach(s,lane(record,ct))
                    if array=='clips':
                        native_group=next((g for g in (candidate.get('group_container') or {}).get('groups',[]) if g.get('group_main_id')==viewid),None)
                        if native_group:
                            for member in native_group['group_members']:
                                if member!=viewid:
                                    mt,ms=candidate_segs[member];attach(ms,lane({},mt))
                            obj.setdefault('group_container',{}).setdefault('groups',[]).append(copy.deepcopy(native_group))
                            segs[viewid]['group_id']=native_group['id']
                        else:
                            prior=next((clip for clip in before['clips'] if clip['asset_id']==right[viewid]['asset_id'] and clip['in']<=right[viewid]['in']<clip['out']),None)
                            prior_segment=segs.get(prior['id']) if prior else None
                            group=next((g for g in (obj.get('group_container') or {}).get('groups',[]) if g.get('id')==(prior_segment or {}).get('group_id')),None)
                            if group:
                                gid=uid();members=[viewid]
                                for member in group['group_members']:
                                    if member==prior['id'] or member not in segs:continue
                                    unlocked(member);peer=copy.deepcopy(segs[member]);peer.update(id=uid(),group_id=gid,
                                        target_timerange=copy.deepcopy(candidate_parts[0][1]['target_timerange']),source_timerange=copy.deepcopy(candidate_parts[0][1]['source_timerange']))
                                    pt=next(t for t in obj['tracks'] if any(s['id']==member for s in t['segments']));attach(peer,pt);members.append(peer['id'])
                                    provenance=next((r for r in old_mapping if r.get('source_kind')=='original' and member in r.get('segments',[])),None)
                                    if provenance:
                                        record_copy=copy.deepcopy(provenance);record_copy.update(source_id=viewid,segments=[peer['id']],track_id=pt['id']);new_originals.append(record_copy)
                                segs[viewid]['group_id']=gid
                                new_group=copy.deepcopy(group);new_group.update(id=gid,group_main_id=viewid,group_members=members)
                                obj['group_container']['groups'].append(new_group)
                    continue
                unlocked(sid)
                ct,new=candidate_parts[0]
                fields=set(k for k in set(left.get(viewid,{}))|set(right[viewid]) if left.get(viewid,{}).get(k)!=right[viewid].get(k))
                if array=='clips':
                    if 'asset_id' in fields:
                        import_material(new['material_id'])
                        # A new source is a new material, not a mutation shared by
                        # other clips. Retain unknown old material fields as well.
                        fresh=old_mats[new['material_id']];retained=copy.deepcopy(old_mats[old['material_id']]);retained.update(copy.deepcopy(fresh))
                        fresh.clear();fresh.update(retained);old['material_id']=new['material_id']
                    if 'audio_stream' in fields and 'asset_id' not in fields:raise ValueError('请通过分离原声音轨选择或替换声音，当前原生画面不支持直接改内部选轨')
                    if 'gain' in fields and old.get('group_id') and right[viewid].get('audio_detached'):
                        raise ValueError('画面已静音并关联独立原声，请修改人物原声音轨的音量')
                    target_changed=any(k in fields for k in ('start','in','out','asset_id')) or before['fps']!=after['fps']
                    if target_changed:
                        old_target=timerange(old['target_timerange']);delta=new['target_timerange']['start']-old_target['start']
                        old['target_timerange']=copy.deepcopy(new['target_timerange']);old['source_timerange']=copy.deepcopy(new['source_timerange'])
                        # Paired originals were synchronized before building the candidate.
                        # Preserve the existing movement semantics of larger native groups.
                        if not before.get('native_links',{}).get(viewid,{}).get('linked_audio_id'):
                            group=next((g for g in (obj.get('group_container') or {}).get('groups',[]) if g['id']==old.get('group_id')),None)
                            if group:
                                for member in group['group_members']:
                                    if member==sid or member not in segs:continue
                                    unlocked(member);peer=segs[member]
                                    peer['target_timerange']['start']=timerange(peer['target_timerange'])['start']+delta
                                    if 'in' in fields or 'out' in fields:
                                        peer['source_timerange']=copy.deepcopy(new['source_timerange']);peer['target_timerange']['duration']=new['target_timerange']['duration']
                    if 'gain' in fields and not right[viewid].get('audio_detached'):old['volume']=10**(right[viewid].get('gain',0)/20)
                    if right[viewid].get('audio_detached'):old['volume']=0
                elif array=='audios':
                    if fields.intersection(('start','in','out','loop','loop_duration','loop_offset')):
                        old['target_timerange']=copy.deepcopy(new['target_timerange']);old['source_timerange']=copy.deepcopy(new['source_timerange'])
                    if fields.intersection(('gain','muted')):old['volume']=new['volume']
                    if 'asset_id' in fields or 'audio_stream' in fields:import_material(new['material_id']);old['material_id']=new['material_id']
                    if any(k in fields for k in ('fade_in','fade_out')):
                        refs=[r for r in old.get('extra_material_refs',[]) if old_mats.get(r,{}).get('type')!='audio_fade']
                        for ref in new.get('extra_material_refs',[]):
                            if candidate_mats.get(ref,('',{}))[1].get('type')=='audio_fade':import_material(ref);refs.append(ref)
                        old['extra_material_refs']=refs
                    if 'role' in fields:
                        for t in obj['tracks']:t['segments']=[s for s in t['segments'] if s['id']!=sid]
                        lane({},ct)['segments'].append(old)
                    for extra_track,extra_segment in candidate_parts[1:]:attach(extra_segment,lane(record,extra_track))
                elif array=='captions':
                    mat=old_mats[old['material_id']];rich=json.loads(mat['content'])
                    if len(rich.get('styles',[]))!=1 or any(mat.get(k) for k in ('words','text_to_audio_ids','recognize_task_id','base_content')):
                        raise ValueError('关联或多样式字幕暂不支持在简易编辑页修改，请在剪映编辑')
                    _,nmat=candidate_mats[new['material_id']];nrich=json.loads(nmat['content'])
                    previous_style=dict(before['style'],**left[viewid].get('style',{}));next_style=dict(after['style'],**right[viewid].get('style',{}))
                    style_fields={k for k in set(previous_style)|set(next_style) if previous_style.get(k)!=next_style.get(k)}
                    style=rich['styles'][0];fresh=nrich['styles'][0]
                    layout_changed=('text' in fields or viewid in caption_repairs or
                                    bool(style_fields.intersection(('font_id','font_size','spacing','max_width','bold','italic'))))
                    if layout_changed and rich['text']!=nrich['text']:
                        old_text=rich['text'];utf16=style['range'][1]==len(old_text.encode('utf-16-le'))//2
                        rich['text']=nrich['text'];style['range']=[0,len(rich['text'].encode('utf-16-le'))//2 if utf16 else len(rich['text'])]
                    if layout_changed:
                        # Copy only the layout fields of this caption; leave all
                        # unrelated/unknown native properties and AV intact.
                        mat['type']=nmat['type']
                        for key in ('line_feed','force_apply_line_max_width'):mat[key]=nmat[key]
                    else:
                        record.pop('native_layout_mapping',None)
                        previous_layout=old_records.get(viewid,{}).get('native_layout_mapping')
                        if previous_layout:record['native_layout_mapping']=copy.deepcopy(previous_layout)
                    for field,native_key in (('font_size','size'),('bold','bold'),('italic','italic'),('underline','underline')):
                        if field in style_fields or field=='font_size' and 'font_id' in style_fields:
                            style[native_key]=copy.deepcopy(fresh[native_key])
                    # Repair legacy Baimu drafts even when the user did not toggle
                    # the font again: old drafts pointed at the renderer-only face
                    # and omitted the identity fields Jianying uses for selection.
                    style['font']=copy.deepcopy(fresh['font'])
                    for field in ('font_category_id','font_category_name','font_id','font_name','font_path',
                                  'font_resource_id','font_source_platform','font_team_id','font_title','font_url','fonts'):
                        if field in nmat:mat[field]=copy.deepcopy(nmat[field])
                    if style_fields.intersection(('color','opacity')):style['fill']=merged(style.get('fill',{}),fresh['fill'])
                    if 'opacity' in style_fields:mat['global_alpha']=nmat.get('global_alpha',1)
                    if viewid in caption_repairs or style_fields.intersection(('outline','outline_color','outline_opacity')):style['strokes']=copy.deepcopy(fresh.get('strokes',[]))
                    if style_fields.intersection(('shadow','shadow_opacity','shadow_angle','shadow_blur')):style['shadows']=copy.deepcopy(fresh.get('shadows',[]))
                    for field,native_key in (('spacing','letter_spacing'),('line_spacing','line_spacing'),('max_width','line_max_width')):
                        if field in style_fields:mat[native_key]=nmat[native_key]
                    mat['content']=json.dumps(rich,ensure_ascii=False,separators=(',',':'))
                    if fields.intersection(('start','end')):old['target_timerange']=copy.deepcopy(new['target_timerange'])
                    if style_fields.intersection(('x','y')):
                        old.setdefault('clip',{}).setdefault('transform',{}).update(new['clip']['transform'])
                else:
                    _,nmat=candidate_mats[new['material_id']];mat=old_mats[old['material_id']]
                    if ct['type']!=tracks[link['track_id']]['type']:
                        remove(sid);replacement=copy.deepcopy(new);replacement['id']=sid;target=lane({},ct);attach(replacement,target)
                        record['track_id']=target['id'];record['segments']=[sid]
                        continue
                    if ct['type']=='effect':
                        old_mask=mat['effect_mask'][0];fresh_config=nmat['effect_mask'][0]['config']
                        config_fields=set()
                        if fields.intersection(('x','w')):config_fields.add('centerX')
                        if fields.intersection(('y','h')):config_fields.add('centerY')
                        if 'w' in fields:config_fields.add('width')
                        if 'h' in fields:config_fields.add('height')
                        if 'feather' in fields:config_fields.add('feather')
                        for field in config_fields:old_mask['config'][field]=copy.deepcopy(fresh_config[field])
                        if 'blur' in fields:
                            fresh_param=next(a for a in nmat['adjust_params'] if a['name']=='effects_adjust_blur')
                            next(a for a in mat['adjust_params'] if a['name']=='effects_adjust_blur')['value']=fresh_param['value']
                        rewrite_geometry_frames=('keyframes' in fields
                            or 'w' in fields and any('w' not in point for point in right[viewid].get('keyframes',[]))
                            or 'h' in fields and any('h' not in point for point in right[viewid].get('keyframes',[])))
                        if rewrite_geometry_frames:
                            managed=set(POSITION_PROPERTIES+SIZE_PROPERTIES)
                            fresh={entry['property_type']:entry for entry in new.get('common_keyframes',[]) if entry.get('property_type') in managed}
                            previous={entry.get('property_type'):entry for entry in old.get('common_keyframes',[]) if entry.get('property_type') in managed}
                            replacements={}
                            for prop in POSITION_PROPERTIES+SIZE_PROPERTIES:
                                if prop not in fresh:continue
                                entry=copy.deepcopy(fresh[prop]);prior=previous.get(prop)
                                if prior:
                                    # Keep native IDs and fields that Baimu does not own. Frames
                                    # at the same timestamp are the same native entities; only
                                    # their geometry values and interpolation are managed here.
                                    entry=merged(prior,{k:v for k,v in entry.items() if k not in ('id','keyframe_list')})
                                    old_frames={frame.get('time_offset'):frame for frame in prior.get('keyframe_list',[]) if isinstance(frame,dict)}
                                    frames=[]
                                    for frame in fresh[prop].get('keyframe_list',[]):
                                        prior_frame=old_frames.get(frame.get('time_offset'))
                                        frames.append(merged(prior_frame,{k:v for k,v in frame.items() if k!='id'}) if prior_frame else copy.deepcopy(frame))
                                    entry['keyframe_list']=frames
                                replacements[prop]=entry
                            retained=[]
                            for entry in old.get('common_keyframes',[]):
                                prop=entry.get('property_type')
                                if prop not in managed:retained.append(entry)
                                elif prop in replacements:retained.append(replacements.pop(prop))
                            for prop in POSITION_PROPERTIES+SIZE_PROPERTIES:
                                if prop in replacements:retained.append(replacements[prop])
                            old['common_keyframes']=retained
                        if 'feather' in fields:
                            for entry in old.get('common_keyframes',[]):
                                if entry.get('property_type')==FEATHER_PROPERTY:
                                    for frame in entry.get('keyframe_list',[]):frame['values']=[right[viewid]['feather']]
                        for frame in old.get('common_keyframes',[]):
                            if frame.get('property_type') in SUPPORTED_PROPERTIES:
                                frame['material_id']=mat['effect_mask'][0]['constant_material_id']
                        if fields.intersection(('start','end')):old['target_timerange']=copy.deepcopy(new['target_timerange'])
                    else:
                        for k in ('target_timerange','clip','common_keyframes'):
                            if k in new:old[k]=copy.deepcopy(new[k])
                record['track_id']=link.get('track_id',record['track_id']);record['segments']=[sid]+[s['id'] for _,s in candidate_parts[1:]]
        # Native group members may only survive together, including splits/removes.
        groups=(obj.get('group_container') or {}).get('groups',[])
        for group in groups:
            if len(group.get('group_members',[]))<2:
                for sid in group.get('group_members',[]):segs.get(sid,{}).pop('group_id',None)
        if groups:obj['group_container']['groups']=[g for g in groups if len(g.get('group_members',[]))>=2]
        for ct in candidate['tracks']:
            for segment in ct['segments']:
                mat=candidate_mats.get(segment.get('material_id'),('',{}))[1]
                if ct['type']=='video' and Path(mat.get('path','')).name=='black.png':attach(segment,lane({},ct),derived=True)
        for track in obj['tracks']:
            track['segments'].sort(key=lambda s:timerange(s['target_timerange'])['start'])
            kinds={v['kind'] for v in before.get('native_links',{}).values() if v['track_id']==track['id']}
            if before.get('track_locks')!=after.get('track_locks') and kinds:
                locked=any(kind in after.get('track_locks',[]) for kind in kinds)
                track['attribute']=(track.get('attribute',0)|4) if locked else track.get('attribute',0)&~4
        if before['width']!=after['width'] or before['height']!=after['height']:
            obj['canvas_config']=merged(obj.get('canvas_config',{}),candidate['canvas_config'])
        if before['fps']!=after['fps']:obj['fps']=candidate['fps']
        obj['duration']=max((sum(timerange(s['target_timerange']).values()) for t in obj['tracks'] for s in t['segments']),default=0)
        # Keep calibration/provenance records for unchanged native entities.
        records=[r for r in old_mapping if (r.get('source_kind')=='original' and any(s in segs for s in r.get('segments',[]))) or (r.get('source_kind')!='original' and r.get('source_id') not in changed_ids)]
        for record in mapping:
            if record.get('source_id') not in changed_ids:continue
            if record.get('source_kind')=='dialogue':
                provenance=next((r for r in old_mapping if r.get('extraction') and set(r.get('segments',[]))&set(record.get('segments',[]))),None)
                if provenance:record['extraction']=copy.deepcopy(provenance['extraction'])
            records.append(record)
        records.extend(new_originals)
        from .native_layers import apply_mask_layers
        apply_mask_layers(obj,after,records,changed_ids,before)
        return obj,records
