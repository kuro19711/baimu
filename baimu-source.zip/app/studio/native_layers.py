"""Editable native visual layers; source pixel geometry stays explicit.

Only opaque solid masks have a direct representation here. A blur filter must
not be silently replaced by a white rectangle or a rendered overlay movie.
"""
from pathlib import Path
import math
from .native_defaults import timerange as native_range


def us(value):return round(value*1_000_000)


def apply_mask_layers(content,project,mapping,changed_ids=None,previous_project=None):
    segments={s['id']:s for t in content['tracks'] for s in t['segments']}
    orders=[s.get('render_index',i) for i,t in enumerate(content['tracks']) if t['type']=='text' for s in t['segments']]
    lower=max(0,min(orders,default=14000)-1);upper=max(orders,default=14000)+1
    masks={m['id']:m for m in project.get('masks',[])}
    previous={m['id']:m for m in (previous_project or {}).get('masks',[])}
    for record in mapping:
        mid=record.get('source_id')
        if record.get('source_kind')!='mask' or mid not in masks or changed_ids is not None and mid not in changed_ids:continue
        if mid in previous and previous[mid].get('layer','below_captions')==masks[mid].get('layer','below_captions'):continue
        for sid in record['segments']:
            if sid in segments:segments[sid]['render_index']=upper if masks[mid].get('layer')=='above_captions' else lower


def solid_geometry(project,mask,x=None,y=None):
    width,height=project['width'],project['height'];scale=width/1080
    x=mask['x'] if x is None else x;y=mask['y'] if y is None else y
    fit=min(width,height)
    return dict(scale=dict(x=mask['w']*scale/fit,y=mask['h']*scale/fit),
        transform=dict(x=2*(x+mask['w']/2)*scale/width-1,
                       y=1-2*(y+mask['h']/2)*scale/height))


def add_solid_layers(script,d,project,resources,mapping):
    lanes=[];track_ids=[]
    for mask in sorted(project.get('masks',[]),key=lambda x:(x['start'],x['end'])):
        if mask.get('mode','blur')!='solid':continue
        lane=next((x for x in lanes if x['end']<=us(mask['start'])),None)
        if lane is None:
            track=script.append_track(d.TrackSpec(d.TrackType.video,'白色打码'+('' if not lanes else f' · 重叠 {len(lanes)+1}')))
            lane=dict(track=track,end=0);lanes.append(lane);track_ids.append(track.track_id)
        lane['end']=us(mask['end']);image=resources/'opaque-white-square.png'
        if not image.is_file():
            from PIL import Image
            Image.new('RGB',(4,4),(255,255,255)).save(image)
        geometry=solid_geometry(project,mask);length=us(mask['end'])-us(mask['start'])
        settings=d.ClipSettings(scale_x=geometry['scale']['x'],scale_y=geometry['scale']['y'],
            transform_x=geometry['transform']['x'],transform_y=geometry['transform']['y'])
        segment=d.VideoSegment(str(image),d.Timerange(us(mask['start']),length),volume=0,clip_settings=settings)
        segment.segment_id=mask['id'];segment.uniform_scale=False
        points=[dict(time=mask['start'],x=mask['x'],y=mask['y'])]+mask.get('keyframes',[])
        if mask.get('keyframes'):
            points.append(dict(time=mask['end'],x=points[-1]['x'],y=points[-1]['y']))
            for point in points:
                pos=solid_geometry(project,mask,point['x'],point['y'])['transform']
                segment.add_keyframe(d.KeyframeProperty.position_x,us(point['time'])-us(mask['start']),pos['x'])
                segment.add_keyframe(d.KeyframeProperty.position_y,us(point['time'])-us(mask['start']),pos['y'])
        script.add_segment(segment,lane['track'])
        mapping.append(dict(source_kind='mask',source_id=mask['id'],track_id=lane['track'].track_id,
            segments=[segment.segment_id],representation='editable_solid_rectangle_with_position_keyframes',
            source_mask=mask,geometry=geometry))
    return track_ids


def verify_solid_layers(project,content,mapping):
    masks={m['id']:m for m in project.get('masks',[]) if m.get('mode','blur')=='solid'}
    segments={s['id']:(t,s) for t in content['tracks'] for s in t['segments']}
    records={r['source_id']:r for r in mapping if r['source_kind']=='mask' and r.get('representation')=='editable_solid_rectangle_with_position_keyframes'}
    def check(value,label):
        if not value:raise ValueError('打码结构核对失败：'+label)
    check(set(records)==set(masks),'图层丢失')
    for mid,mask in masks.items():
        r=records[mid];check(r['source_mask']==mask,'源参数丢失')
        check(len(r['segments'])==1,'打码被烘焙或拆散')
        track,segment=segments[r['segments'][0]]
        check(track['id']==r['track_id'] and track.get('flag')==2,'副画面轨道错误')
        check(native_range(segment['target_timerange'])==dict(start=us(mask['start']),duration=us(mask['end'])-us(mask['start'])),'时间范围改变')
        geometry=solid_geometry(project,mask)
        for kind in ('scale','transform'):
            for axis in ('x','y'):check(math.isclose(segment['clip'][kind][axis],geometry[kind][axis],abs_tol=1e-12),'矩形尺寸或位置改变')
        check(not segment.get('uniform_scale',{}).get('on',False),'矩形宽高被强制等比')
        native={k['property_type']:k['keyframe_list'] for k in segment.get('common_keyframes',[])}
        points=[dict(time=mask['start'],x=mask['x'],y=mask['y'])]+mask.get('keyframes',[])
        if mask.get('keyframes'):
            points.append(dict(time=mask['end'],x=points[-1]['x'],y=points[-1]['y']))
            for axis in ('x','y'):
                frames=native.get('KFTypePosition'+axis.upper(),[])
                check(len(frames)==len(points),'位置关键帧丢失')
                for frame,point in zip(frames,points):
                    expected=solid_geometry(project,mask,point['x'],point['y'])['transform'][axis]
                    check(frame.get('time_offset',0)==us(point['time'])-us(mask['start']),'关键帧时间改变')
                    check(frame.get('curveType','Line')=='Line' and math.isclose(frame['values'][0],expected,abs_tol=1e-12),'关键帧值或插值改变')
    return len(records)
