"""Bounded script previews and explicitly mapped, retry-safe draft application."""
from __future__ import annotations
import base64
import contextlib
import copy
import hashlib
import json
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

from .core import uid

MAX_BYTES=16*1024*1024
MAX_TEXT=1_000_000
MAX_OUTPUT=8*1024*1024
TTL=30*60
EXTENSIONS={'.pdf','.docx','.txt','.md'}
WORKERS=threading.BoundedSemaphore(2)


class ScriptImportError(ValueError):
    def __init__(self,message,http_status=400,**details):
        super().__init__(message)
        self.status=http_status
        self.payload=dict(error=message,status='failed',results=[])
        self.payload.update(details)


def parse_document(payload):
    """Isolate third-party PDF/DOCX parsing; bound wall time and pipe output."""
    if not WORKERS.acquire(blocking=False):
        raise ScriptImportError('已有剧本正在解析，请稍后重试',503)
    process=None
    try:
        process=subprocess.Popen([sys.executable,'-m','studio.script_import','--worker'],
            cwd=Path(__file__).resolve().parents[1],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        buffers={'stdout':bytearray(),'stderr':bytearray()};overflow=threading.Event()
        def read_pipe(name,limit):
            pipe=getattr(process,name)
            try:
                while block:=pipe.read(65536):
                    if len(buffers[name])+len(block)>limit:
                        overflow.set();process.kill();break
                    buffers[name].extend(block)
            except (OSError,ValueError):pass
            finally:pipe.close()
        def feed():
            try:process.stdin.write(json.dumps(payload,ensure_ascii=False).encode('utf-8'));process.stdin.flush()
            except (BrokenPipeError,OSError):pass
            finally:process.stdin.close()
        threads=[threading.Thread(target=read_pipe,args=('stdout',MAX_OUTPUT),daemon=True),
                 threading.Thread(target=read_pipe,args=('stderr',65536),daemon=True),
                 threading.Thread(target=feed,daemon=True)]
        for thread in threads:thread.start()
        try:process.wait(timeout=45)
        except subprocess.TimeoutExpired:
            process.kill();process.wait(timeout=5)
            raise ScriptImportError('剧本解析超过45秒，已停止；请拆小文件或转换为TXT后重试',408)
        finally:
            for thread in threads:thread.join(timeout=2)
        if overflow.is_set():raise ScriptImportError('剧本解析输出超过安全限制，请拆分文件后重试',413)
        try:result=json.loads(bytes(buffers['stdout']))
        except (ValueError,UnicodeError):raise ScriptImportError('剧本解析进程未返回有效结果；请检查文件，或转换为TXT后重试')
        if process.returncode or not isinstance(result,dict) or result.get('error'):
            raise ScriptImportError(str(result.get('error','剧本解析失败，请检查文件格式')))
        return result
    except OSError as exc:
        raise ScriptImportError('无法启动本机剧本解析器：'+str(exc))
    finally:
        if process is not None and process.poll() is None:process.kill()
        WORKERS.release()


class ScriptImports:
    def __init__(self,store,jobs=None):
        self.store=store;self.jobs=jobs
        self.lock=threading.RLock();self.sessions={};self.activity_lock=threading.Lock();self.active=0

    def busy(self):
        with self.activity_lock:return self.active>0

    @contextlib.contextmanager
    def activity(self):
        with self.activity_lock:self.active+=1
        try:yield
        finally:
            with self.activity_lock:self.active-=1

    def purge(self):
        for sid,session in list(self.sessions.items()):
            if session['expires_at']<=time.time():del self.sessions[sid]

    def get(self,sid):
        self.purge()
        if sid not in self.sessions:
            raise ScriptImportError('剧本预览不存在或已过期（30分钟／软件重启后失效），请重新选择文件并核对分配',410)
        return self.sessions[sid]

    def discard(self,sid):
        # Apply owns this same lock for all validation/writes. Explicit closing
        # waits for it, so a processing session cannot lose its retry record.
        with self.lock:
            self.purge()
            removed=self.sessions.pop(sid,None)
            return dict(ok=True,id=sid,discarded=removed is not None,
                        notice='仅释放本次内存预览，原剧本、工程及历史版本均未删除；再次应用需重新预览并核对目标。')

    def input(self,body):
        if not isinstance(body,dict):raise ScriptImportError('剧本请求必须是对象')
        modes=[key for key in ('path','text','content_base64') if key in body]
        if len(modes)!=1:raise ScriptImportError('请选择一种剧本来源：本机路径、文本或文件内容，不能混用')
        mode=modes[0]
        if mode=='path':
            value=body['path']
            if not isinstance(value,str) or not value.strip():raise ScriptImportError('请填写具体剧本文件路径')
            if value.startswith(('\\\\','//')):raise ScriptImportError('请选择本机剧本文件，不读取网络共享路径')
            source=Path(value).expanduser().absolute()
            reason=self.store.excluded_path(source)
            if reason:raise ScriptImportError('此路径不能作为剧本来源：'+reason)
            if source.suffix.lower() not in EXTENSIONS or not source.is_file():
                raise ScriptImportError('请选择PDF、DOCX、TXT或MD剧本文件，不接受文件夹或其他文件类型')
            if source.stat().st_size>MAX_BYTES:raise ScriptImportError('剧本文件不能超过16MiB，请拆分后导入',413)
            with source.open('rb') as handle:data=handle.read(MAX_BYTES+1)
            name=source.name
        else:
            name=body.get('name','粘贴剧本.txt' if mode=='text' else '')
            if not isinstance(name,str) or not name or len(name)>255 or any(ord(c)<32 for c in name) or Path(name).name!=name or '\\' in name:
                raise ScriptImportError('请提供不含路径的剧本文件名')
            if Path(name).suffix.lower() not in EXTENSIONS:raise ScriptImportError('剧本仅支持PDF、DOCX、TXT和MD格式')
            if mode=='text':
                text=body['text']
                if not isinstance(text,str) or not text.strip():raise ScriptImportError('剧本文本不能为空')
                if len(text)>MAX_TEXT:raise ScriptImportError('剧本正文最多100万字符，请拆分后导入',413)
                return dict(name=name,text=text)
            value=body['content_base64']
            if not isinstance(value,str) or len(value)>((MAX_BYTES+2)//3)*4:
                raise ScriptImportError('剧本文件不能超过16MiB，请拆分后导入',413)
            try:data=base64.b64decode(value,validate=True)
            except (ValueError,TypeError):raise ScriptImportError('剧本文件内容编码损坏，请重新选择文件')
        if len(data)>MAX_BYTES:raise ScriptImportError('剧本文件不能超过16MiB，请拆分后导入',413)
        if not data:raise ScriptImportError('剧本文件为空')
        return dict(name=name,content_base64=base64.b64encode(data).decode('ascii'))

    def preview(self,body):
        with self.activity():return self._preview(body)

    def _preview(self,body):
        with self.lock:
            self.purge()
            if len(self.sessions)>=10:
                raise ScriptImportError('保留的剧本预览已达10份上限，请等待旧预览过期或重启软件后重新选择',429)
        payload=self.input(body)
        parsed=parse_document(payload)
        sections=parsed.get('sections')
        if not isinstance(sections,list) or not 1<=len(sections)<=1000:
            raise ScriptImportError('剧本没有可用正文，或分段过多，请拆分文件后重试')
        ids=set();total=0
        for item in sections:
            if (not isinstance(item,dict) or not re.fullmatch('[a-f0-9]{32}',str(item.get('id','')))
                or item['id'] in ids or not isinstance(item.get('text'),str) or not item['text'].strip()):
                raise ScriptImportError('剧本解析结果结构无效，请重新选择文件')
            ids.add(item['id']);total+=len(item['text'])
        if total>MAX_TEXT:raise ScriptImportError('剧本正文最多100万字符，请拆分后导入',413)
        with self.lock:
            self.purge()
            if len(self.sessions)>=10 or sum(s['size'] for s in self.sessions.values())+total>20_000_000:
                raise ScriptImportError('保留的剧本预览已达上限（10份／2000万字符），请等待旧预览过期或重启软件后重新选择',429)
            session=dict(id=uid(),source_name=payload['name'],sections=copy.deepcopy(sections),warnings=copy.deepcopy(parsed.get('warnings',[])),
                         expires_at=time.time()+TTL,size=total,plans=None,mapping=None,results=[],status='preview')
            self.sessions[session['id']]=session
            result={key:copy.deepcopy(session[key]) for key in ('id','source_name','sections','warnings','expires_at')}
            result['notice']='这里只预览剧本文字，尚未修改工程；请逐集核对开头、结尾及完整性。预览30分钟有效，软件重启后需重新选择。'
            return result

    @staticmethod
    def script(session,section):
        return dict(text=section['text'],source=session['source_name'],start_anchor=section.get('start_anchor',''),
                    end_anchor=section.get('end_anchor',''),complete=False,import_id=session['id']+':'+section['id'])

    def rows(self,session,reused=False):
        results=[]
        for plan in session.get('plans') or []:
            if plan.get('state')!='complete':continue
            try:
                p=self.store.get(plan['project_id'],include_archived=True)
                results.append(dict(id=p['id'],project_id=p['id'],name=p['name'],revision=p['revision'],section_id=plan['section_id'],
                                    state='reused' if reused else ('created' if plan['create_new'] else 'applied'),archived=bool(p.get('archived'))))
            except (OSError,ValueError) as exc:
                results.append(dict(id=plan['project_id'],project_id=plan['project_id'],section_id=plan['section_id'],name=plan['name'],state='reused',unavailable=True,error=str(exc)))
        return results

    def validate_target(self,plan):
        if plan.get('state')=='complete':return
        if plan['create_new']:
            if self.store.path(plan['project_id']).exists():raise ScriptImportError('预留工程ID已存在，未覆盖任何编辑')
            return
        project=self.store.get(plan['project_id'])
        if project['revision']!=plan['revision']:raise ScriptImportError('工程“'+project['name']+'”已被修改，请刷新版本并重新核对分配',409)
        old_script=project.get('script',{})
        if (str(old_script.get('text','')).strip() or str(old_script.get('source','')).strip()) and plan.get('replace_confirmed') is not True:
            raise ScriptImportError('工程“'+project['name']+'”已有剧本，请明确确认替换；原剧本将保留在历史版本')
        if any(j.get('project_id')==project['id'] and j.get('state') in ('queued','running') for j in list(getattr(self.jobs,'items',{}).values())):
            raise ScriptImportError('工程“'+project['name']+'”仍有排队或运行任务，请等待或取消后导入剧本',409)

    def apply(self,sid,body):
        with self.activity():return self._apply(sid,body)

    def _apply(self,sid,body):
        if not isinstance(body,dict) or body.get('confirmed') is not True:raise ScriptImportError('请先核对分集和目标工程，再明确确认应用剧本')
        items=body.get('items')
        if not isinstance(items,list) or not 1<=len(items)<=1000:raise ScriptImportError('请选择1至1000个剧本分段，并明确分配到不同工程')
        with self.lock, getattr(self.jobs,'lock',contextlib.nullcontext()), self.store.lock:
            session=self.get(sid);sections={s['id']:s for s in session['sections']}
            clean=[];seen_sections=set();seen_targets=set()
            for item in items:
                if not isinstance(item,dict) or item.get('section_id') not in sections or item['section_id'] in seen_sections:
                    raise ScriptImportError('剧本分段无效或重复，请每段只分配一次')
                section_id=item['section_id'];seen_sections.add(section_id)
                if item.get('create_new') is True:
                    if item.get('project_id'):raise ScriptImportError('同一段不能同时新建工程和覆盖现有工程')
                    name=item.get('name');series=self.store.series_name(item.get('series',''))
                    if not isinstance(name,str) or not name.strip() or len(name)>150 or any(ord(c)<32 for c in name):
                        raise ScriptImportError('新建工程名称应为1至150字的单行文字')
                    clean.append(dict(section_id=section_id,create_new=True,name=name.strip(),series=series))
                else:
                    pid=item.get('project_id');revision=item.get('revision')
                    if not isinstance(pid,str) or not re.fullmatch('[a-f0-9]{32}',pid) or pid in seen_targets:
                        raise ScriptImportError('目标工程无效或重复；禁止用多段剧本相互覆盖同一工程')
                    if isinstance(revision,bool) or not isinstance(revision,int) or revision<0:raise ScriptImportError('请提供目标工程当前版本号')
                    seen_targets.add(pid)
                    clean.append(dict(section_id=section_id,create_new=False,project_id=pid,revision=revision,replace_confirmed=item.get('replace_confirmed') is True))
            clean.sort(key=lambda item:item['section_id'])
            mapping=hashlib.sha256(json.dumps(clean,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
            if session['mapping'] is not None and session['mapping']!=mapping:
                raise ScriptImportError('此预览已经开始应用，重试时不能更换分配；请重新预览后确认新的分配',409,results=self.rows(session,True))
            if session['plans'] is None:
                plans=[]
                by_section={item['section_id']:item for item in clean}
                for section in session['sections']:
                    if section['id'] not in by_section:continue
                    plan=copy.deepcopy(by_section[section['id']])
                    if plan['create_new']:plan['project_id']=uid()
                    else:plan['name']=self.store.get(plan['project_id'])['name']
                    plan.update(state='pending',script=self.script(session,section));plans.append(plan)
                for plan in plans:self.validate_target(plan)
                session.update(plans=plans,mapping=mapping)
            try:
                # A write may have succeeded even if the caller lost its reply.
                for plan in session['plans']:
                    if plan['state']=='complete':continue
                    if self.store.path(plan['project_id']).exists():
                        p=self.store.get(plan['project_id'],include_archived=True)
                        if p.get('script',{}).get('import_id')==plan['script']['import_id']:plan['state']='complete'
                for plan in session['plans']:self.validate_target(plan)
                already_complete=all(plan['state']=='complete' for plan in session['plans'])
                for plan in session['plans']:
                    if plan['state']=='complete':continue
                    if plan['create_new']:
                        self.store.create_with_script(plan['name'],plan['series'],plan['script'],pid=plan['project_id'])
                    else:
                        self.store.save(plan['project_id'],dict(revision=plan['revision'],script=plan['script']))
                    plan['state']='complete'
                session['status']='complete'
                return dict(id=sid,status='complete',results=self.rows(session,already_complete))
            except Exception as exc:
                for plan in session['plans']:
                    if plan['state']=='complete':continue
                    try:
                        p=self.store.get(plan['project_id'],include_archived=True)
                        if p.get('script',{}).get('import_id')==plan['script']['import_id']:plan['state']='complete'
                    except (OSError,ValueError):pass
                rows=self.rows(session);session['status']='partial' if rows else 'failed'
                error=exc if isinstance(exc,ScriptImportError) else ScriptImportError('剧本应用未全部完成：'+str(exc),507 if isinstance(exc,OSError) else 400)
                error.payload.update(id=sid,status=session['status'],results=rows)
                raise error


def worker():
    try:
        from .script_reader import extract_script,split_script
        raw=sys.stdin.buffer.read(24*1024*1024+1)
        if len(raw)>24*1024*1024:raise ValueError('剧本输入过大')
        payload=json.loads(raw)
        if 'text' in payload:text=payload['text'];warnings=[]
        else:
            extracted=extract_script(payload['name'],base64.b64decode(payload['content_base64'],validate=True))
            text=extracted['text'];warnings=extracted.get('warnings',[])
        result=split_script(text,payload['name'])
        result['warnings']=list(dict.fromkeys(warnings+result.get('warnings',[])))
    except Exception as exc:result={'error':'无法解析剧本：'+str(exc)}
    sys.stdout.buffer.write(json.dumps(result,ensure_ascii=False).encode('utf-8'));sys.stdout.buffer.flush()


if __name__=='__main__' and '--worker' in sys.argv:worker()
