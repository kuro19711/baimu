"""Project model, subtitles and fail-closed quality checks (no network I/O)."""
from __future__ import annotations
import copy
import hashlib
import json
import math
import re
import uuid
import unicodedata
from fractions import Fraction
from pathlib import Path
from .branding import APP_NAME

VERSION = '0.6.0-shared.3'
AUDIO_PIPELINE_VERSION = 'mix-v4-native-fades'
SUBTITLE_PIPELINE_VERSION = 'em-font-size-opacity-v1'
VIDEO_EXT = {'.mp4', '.mov', '.mkv', '.webm', '.avi', '.m4v'}
AUDIO_EXT = {'.wav', '.mp3', '.m4a', '.aac', '.flac', '.ogg'}
STYLE = dict(font_id='', font_size=64, color='#ffffff', outline_color='#000000',
             outline=2, shadow=1, shadow_opacity=0.10, x=50, y=72,
             max_width=84, spacing=0, bold=False, shadow_angle=45,
             shadow_blur=0, line_spacing=0, opacity=1, outline_opacity=1)


def uid():
    return uuid.uuid4().hex


def fps_value(value):
    try:
        fps = float(Fraction(str(value)))
    except (ValueError, ZeroDivisionError):
        raise ValueError('帧率必须为有效数字，例如24、30或24000/1001')
    if not math.isfinite(fps) or not 1 <= fps <= 120:
        raise ValueError('帧率范围为1–120')
    return fps


def source_end_limit(asset, project_fps, is_video, observed_duration=None):
    """Compatible source endpoint without granting another editable frame.

    Native drafts can store a frame/material endpoint a few milliseconds past
    FFprobe's stream timestamp. Only a nearby server-derived native duration is
    trusted; ordinary projects and implausible native metadata stay strict.
    """
    duration = asset['duration'] if observed_duration is None else observed_duration
    end = duration
    native = asset.get('native_duration')
    if is_video and isinstance(native, (float, int)) and not isinstance(native, bool) and math.isfinite(native):
        rate = asset.get('fps')
        if isinstance(rate, bool) or not isinstance(rate, (float, int)) or not math.isfinite(rate) or rate <= 0:
            rate = fps_value(project_fps)
        drift = max(.05, 1 / rate + 1e-7)
        if duration - 1e-7 <= native <= duration + drift + 1e-7:
            end = max(end, native)
    return round(end + .00001, 6)


def clamp_native_audio_out(asset, project_fps, value):
    """Clamp a frame-aligned Jianying audio endpoint to the sampled media end.

    Jianying may store an audio segment/material duration on the video frame
    grid even when the WAV's final sample is slightly earlier.  The native
    material duration proves that the overhang came from that graph.  Keep the
    compatibility narrow (at most one project frame); larger or unproven
    overruns must still reach validate() and fail closed.
    """
    duration=asset.get('duration');native=asset.get('native_duration')
    numbers=(duration,native,value)
    if any(isinstance(number,bool) or not isinstance(number,(int,float)) or not math.isfinite(number) for number in numbers):
        return value
    tolerance=1/fps_value(project_fps)+1e-6
    if duration < value <= native+1e-6 and value <= duration+tolerance:
        return duration
    return value


def finite(value, low, high, label):
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError(f'{label}应在{low}–{high}之间')
    return value


def digest(project):
    data = {k: v for k, v in project.items() if k not in {'revision', 'updated', 'reviews', 'renders',
                                                       'series', 'archived', 'archived_at','native','native_links'}}
    data['subtitle_pipeline']=SUBTITLE_PIPELINE_VERSION
    if project.get('masks'):data['mask_pipeline']='rgb-box-v1'
    return hashlib.sha256(json.dumps(canonical_numbers(data), ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def canonical_numbers(value):
    """A browser serializes 2.0 as 2; that must not expire identical media proof."""
    if isinstance(value, dict):
        return {key: canonical_numbers(item) for key, item in value.items()}
    if isinstance(value, list):
        return [canonical_numbers(item) for item in value]
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return int(value)
    return value


def sound_digest(project):
    # Media-library housekeeping and unused assets must not invalidate a mix.
    # Include the renderer version so changed audio processing invalidates old proof.
    clips = [{k:c.get(k) for k in ('asset_id', 'in', 'out', 'start', 'gain', 'audio_stream', 'audio_detached')}
             for c in project['clips']]
    audios = [{k:a.get(k) for k in ('asset_id', 'in', 'out', 'start', 'gain', 'role',
                                   'loop', 'audio_stream', 'fade_in', 'fade_out','loop_duration','loop_offset','muted')}
              for a in project['audios']]
    used = {i['asset_id'] for i in clips + audios}
    assets = sorted([{k:a.get(k) for k in ('id', 'sha256', 'has_audio', 'audio_streams',
                                         'duration', 'video_duration')}
                     for a in project['assets'] if a['id'] in used], key=lambda a:a['id'])
    data = dict(pipeline=AUDIO_PIPELINE_VERSION, fps=project['fps'], clips=clips,
                audios=audios, assets=assets)
    if project.get('native',{}).get('shared'):data['native_duration_us']=project['native'].get('duration_us',0)
    return hashlib.sha256(json.dumps(canonical_numbers(data), sort_keys=True).encode()).hexdigest()


def picture_digest(project):
    clips=[{k:c.get(k) for k in ('asset_id','in','out','start')} for c in project['clips']]
    used={c['asset_id'] for c in clips}
    assets=sorted([dict(id=a['id'],sha256=a.get('sha256')) for a in project['assets'] if a['id'] in used],key=lambda a:a['id'])
    value=dict(clips=clips,assets=assets,fps=project['fps'],width=project['width'],height=project['height'])
    return hashlib.sha256(json.dumps(canonical_numbers(value),sort_keys=True).encode()).hexdigest()


def layer_digests(project):
    def hash_value(value):return hashlib.sha256(json.dumps(canonical_numbers(value),sort_keys=True).encode()).hexdigest()
    return dict(picture=picture_digest(project),sound=sound_digest(project),
                masks=hash_value(project.get('masks',[])),
                subtitles=hash_value(dict(style=project['style'],captions=project['captions'])))


def view_reference(project):
    return {k:copy.deepcopy(project.get(k,[])) for k in ['width','height','fps','assets','clips','audios','captions','masks','style']}


def new_project(name):
    return dict(id=uid(), name=name or '未命名剧集', version=1, revision=0,
                width=1080, height=1920, fps='24', assets=[], clips=[], audios=[],
                captions=[], masks=[], style=copy.deepcopy(STYLE), protected_lines=[],
                script=dict(text='', source='', start_anchor='', end_anchor='', complete=False),
                reviews={}, renders=[], language='pt', series='', created_by=APP_NAME)


def timeline(project):
    fps, cursor, result = fps_value(project['fps']), 0, []
    for clip in project['clips']:
        # Quantize output duration down: never read past a source endpoint.
        count = max(1, math.floor((clip['out'] - clip['in']) * fps + 1e-7))
        start=math.floor(clip['start']*fps+.5) if 'start' in clip else cursor
        result.append(dict(clip, from_frame=start, to_frame=start + count,
                           start=start / fps, end=(start + count) / fps,
                           duration=count / fps))
        cursor = max(cursor,start+count)
    duration=cursor/fps
    if project.get('native',{}).get('shared'):duration=max(duration,math.ceil(project['native'].get('duration_us',0)/1e6*fps-1e-7)/fps)
    return sorted(result,key=lambda c:c['start']), duration


def validate(project):
    allowed_locks={'video','original','caption','mask','dialogue','narration','bgm','sfx'}
    if not isinstance(project.get('track_locks',[]),list) or any(k not in allowed_locks for k in project.get('track_locks',[])):
        raise ValueError('轨道锁定记录无效')
    if len(project.get('name', '')) > 150:
        raise ValueError('剧集名称过长')
    if not isinstance(project.get('series', ''), str) or len(project.get('series', '')) > 150:
        raise ValueError('剧名分组必须是150字以内的文字')
    fps_value(project['fps'])
    if project['width'] not in (540, 720, 1080) or project['height'] != project['width'] * 16 // 9:
        raise ValueError('当前版本支持540×960、720×1280、1080×1920')
    assets = {a['id']: a for a in project['assets']}
    for key in ('clips', 'audios', 'captions', 'protected_lines'):
        if not isinstance(project[key], list) or len(project[key]) > 10000:
            raise ValueError(f'{key}数量无效')
        ids = [i['id'] for i in project[key]]
        if len(set(ids)) != len(ids):
            raise ValueError(f'{key}存在重复ID')
    for item in project['clips'] + project['audios']:
        asset = assets.get(item.get('asset_id'))
        if not asset:
            raise ValueError('片段引用了不存在的素材')
        is_video = item in project['clips']
        finite(item['in'], 0, asset['duration'], '源入点')
        finite(item['out'], 0, source_end_limit(asset, project['fps'], is_video), '源出点')
        if item['out'] <= item['in']:
            raise ValueError('源出点必须晚于入点')
        if is_video:
            if 'start' in item:finite(item['start'],0,86400,'画面开始时间')
            if not isinstance(item.get('audio_detached',False),bool):
                raise ValueError('原声分离标记必须为布尔值')
            if asset.get('kind')!='video':
                raise ValueError('画面片段必须使用视频素材')
            if item['out']-item['in'] < 1/fps_value(project['fps'])-1e-7:
                raise ValueError('画面片段不能短于一个输出帧')
        finite(item.get('gain', 0), -60, 12, '音量dB')
        streams = asset.get('audio_streams', [])
        selected = item.get('audio_stream')
        if selected is not None and (isinstance(selected, bool) or not isinstance(selected, int)
                                     or selected not in [s['index'] for s in streams]):
            raise ValueError('所选音轨不存在，请重新确认原声音轨')
        if item in project['audios']:
            finite(item['start'], 0, 86400, '音频起点')
            if 'loop_duration' in item:finite(item['loop_duration'],1/fps_value(project['fps']),86400,'循环时长')
            if 'loop_offset' in item:finite(item['loop_offset'],0,item['out']-item['in'],'循环偏移')
            if item['role'] not in ('dialogue', 'narration', 'bgm', 'sfx'):
                raise ValueError('音频类型无效')
    placed,_=timeline(project)
    if any(right['start']<left['end']-1e-7 for left,right in zip(placed,placed[1:])):
        raise ValueError('画面片段重叠，请移到空白区或先移动相邻镜头')
    for cue in project['captions']:
        finite(cue['start'], 0, 86400, '字幕起点')
        finite(cue['end'], 0, 86400, '字幕终点')
        if cue['end'] <= cue['start'] or not isinstance(cue['text'], str) or len(cue['text']) > 3000:
            raise ValueError('字幕起止或字数无效')
        validate_style(dict(project['style'], **cue.get('style', {})))
    masks=project.get('masks',[])
    if not isinstance(masks,list) or len(masks)>200:
        raise ValueError('打码片段不能超过200个')
    if len({m.get('id') for m in masks if isinstance(m,dict)})!=len(masks):
        raise ValueError('打码片段ID无效或重复')
    for mask in masks:
        if not isinstance(mask,dict) or not isinstance(mask.get('id'),str) or not re.fullmatch('[a-f0-9]{32}',mask['id']):
            raise ValueError('打码片段ID无效')
        if mask.get('mode','blur') not in ('blur','solid'):raise ValueError('打码类型无效')
        if mask.get('layer','below_captions') not in ('below_captions','above_captions'):raise ValueError('打码层级无效')
        finite(mask.get('start'),0,86400,'打码开始')
        finite(mask.get('end'),0,86400,'打码结束')
        if mask['end']-mask['start']<1/fps_value(project['fps'])-1e-7:
            raise ValueError('打码片段至少持续一帧')
        for key,lo,hi in [('w',16,4320),('h',16,7680),('blur',1,40),('white',0,0.6),('feather',0,1)]:
            finite(mask.get(key,0) if key=='feather' else mask.get(key),lo,hi,'打码'+key)
        finite(mask.get('x'),-mask['w'],1080,'打码x');finite(mask.get('y'),-mask['h'],1920,'打码y')
        if mask['x']>=1080 or mask['y']>=1920 or mask['x']+mask['w']<=0 or mask['y']+mask['h']<=0:
            raise ValueError('打码区域必须与画面相交')
        keys=mask.get('keyframes',[])
        if not isinstance(keys,list) or len(keys)>100:
            raise ValueError('打码位置关键帧不能超过100个')
        last=mask['start']
        for key in keys:
            if not isinstance(key,dict):raise ValueError('打码关键帧格式无效')
            finite(key.get('time'),mask['start'],mask['end'],'关键帧时间')
            if key['time']<=last or key['time']>=mask['end']:
                raise ValueError('关键帧必须位于打码片段内部并按时间排序')
            width=key.get('w',mask['w']);height=key.get('h',mask['h'])
            finite(width,16,4320,'关键帧宽度');finite(height,16,7680,'关键帧高度')
            finite(key.get('x'),-width,1080,'关键帧X');finite(key.get('y'),-height,1920,'关键帧Y')
            if key['x']>=1080 or key['y']>=1920 or key['x']+width<=0 or key['y']+height<=0:
                raise ValueError('关键帧打码区域必须与画面相交')
            last=key['time']
    validate_style(project['style'])
    for line in project['protected_lines']:
        if line['asset_id'] not in assets or line['kind'] not in ('original_dialogue', 'necessary_narration'):
            raise ValueError('必保台词的来源或类别无效')
        finite(line['start'], 0, assets[line['asset_id']]['duration'], '台词源入点')
        finite(line['end'], 0, assets[line['asset_id']]['duration'], '台词源出点')
        if line['end'] <= line['start']:
            raise ValueError('必保台词源时间无效')
        if not isinstance(line.get('text'), str) or not line['text'].strip():
            raise ValueError('必保台词必须填写文字或明确的角色说明')
    return project


def validate_style(style):
    # font_size stays as internal 1080-canvas pixels; the editor presents and
    # accepts Jianying's 1-100 native units through a per-font conversion.
    for key, low, high in [('font_size', 4, 800), ('outline', 0, 15), ('shadow', 0, 20),
                           ('shadow_opacity', 0, 1), ('x', 0, 100), ('y', 0, 100),
                           ('max_width', 20, 98), ('spacing', 0, 20)]:
        finite(style[key], low, high, key)
    for key, low, high in [('shadow_angle', -180, 180), ('shadow_blur', 0, 30), ('line_spacing', 0, 100),
                          ('opacity', 0, 1), ('outline_opacity', 0, 1)]:
        finite(style.get(key, STYLE[key]), low, high, key)
    for key in ('color', 'outline_color'):
        if not re.fullmatch(r'#[0-9a-fA-F]{6}', style[key]):
            raise ValueError('颜色格式必须为#RRGGBB')


def parse_srt(text):
    result = []
    for block in re.split(r'\n\s*\n', text.replace('\r', '').strip().lstrip('\ufeff')):
        lines = block.splitlines()
        index = next((i for i, line in enumerate(lines) if '-->' in line), None)
        if index is None:
            continue
        parts = lines[index].split('-->')
        if len(parts) != 2:
            raise ValueError('字幕时间格式无效')
        start, end = [parse_time(p.strip().split()[0]) for p in parts]
        value = '\n'.join(lines[index + 1:]).strip()
        if end <= start or not value:
            raise ValueError('字幕必须有文字且终点晚于起点')
        result.append(dict(id=uid(), start=start, end=end, text=value, style={}))
    if not result:
        raise ValueError('没有读到有效SRT/VTT字幕')
    return sorted(result, key=lambda c: c['start'])


def parse_time(text):
    parts = text.replace(',', '.').split(':')
    if len(parts) not in (2, 3):
        raise ValueError('时间应为00:00:01.200')
    value = 0.0
    for part in parts:
        value = value * 60 + float(part)
    finite(value, 0, 86400, '时间')
    return value


def srt_time(seconds):
    total = round(seconds * 1000)
    return f'{total // 3600000:02}:{total // 60000 % 60:02}:{total // 1000 % 60:02},{total % 1000:03}'


def srt_text(cues):
    return '\n\n'.join(f'{i+1}\n{srt_time(c["start"])} --> {srt_time(c["end"])}\n{c["text"]}' for i, c in enumerate(sorted(cues, key=lambda c: c['start']))) + '\n'


def wrap_text(text, font_path, font_size, max_pixels, spacing=0):
    from PIL import ImageFont
    font = ImageFont.truetype(str(font_path), round(font_size))
    def width(value):
        return font.getlength(value) + max(0, len(value)-1) * spacing
    lines = []
    for paragraph in text.split('\n'):
        # Preserve ordinary words, but an overlong token must not leave the frame.
        words = re.findall(r'[\u3400-\u9fff]|[^\s\u3400-\u9fff]+', paragraph)
        current = ''
        for word in words:
            sep = '' if not current or re.search(r'[\u3400-\u9fff]$', current) or re.match(r'[\u3400-\u9fff]', word) else ' '
            candidate = current + sep + word
            if current and width(candidate) > max_pixels:
                lines.append(current)
                current = word
            else:
                current = candidate
            if width(current) > max_pixels:
                # Keep combining marks, variation selectors and ZWJ sequences
                # attached; never reduce the requested font size to hide overflow.
                clusters = []
                for char in current:
                    join = (unicodedata.category(char) in ('Mn', 'Mc', 'Me') or char == '\u200d'
                            or 0x1F3FB <= ord(char) <= 0x1F3FF
                            or (clusters and (clusters[-1].endswith('\u200d') or
                                'VIRAMA' in unicodedata.name(clusters[-1][-1], ''))))
                    if join and clusters:
                        clusters[-1] += char
                    else:
                        clusters.append(char)
                current = ''
                for cluster in clusters:
                    if width(cluster) > max_pixels:
                        raise ValueError('一个字形已超出字幕宽度，请调整安全区或手动检查，字号未缩小')
                    if current and width(current + cluster) > max_pixels:
                        lines.append(current)
                        current = cluster
                    else:
                        current += cluster
        lines.append(current)
    return '\n'.join(lines)


def ass_color(value, opacity=1):
    r, g, b = value[1:3], value[3:5], value[5:7]
    return f'&H{round((1-opacity)*255):02X}{b}{g}{r}'


def ass_time(seconds):
    # libass clocks use centiseconds. Quantize forward, never before the cue.
    n = math.ceil(seconds * 100 - 1e-7)
    return f'{n // 360000}:{n // 6000 % 60:02}:{n // 100 % 60:02}.{n % 100:02}'


def ass_text(project, fonts):
    header = ['[Script Info]', 'ScriptType: v4.00+', f'PlayResX: {project["width"]}',
              f'PlayResY: {project["height"]}', 'WrapStyle: 2', 'ScaledBorderAndShadow: yes', '',
              '[V4+ Styles]', 'Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding']
    styles, events, metrics = [], [], {}
    for index, cue in enumerate(project['captions']):
        st = dict(project['style'], **cue.get('style', {}))
        font = fonts.get(st['font_id'])
        if not font:
            raise ValueError('请先为字幕选择或导入有效字体')
        family = font['family'].replace(',', ' ').replace('\n', '')
        scale = project['width'] / 1080
        if st['font_id'] not in metrics:
            if font.get('path'):
                from .media import font_info
                metrics[st['font_id']]=font_info(Path(font['path']))
            else:
                metrics[st['font_id']]=font
        metric=metrics[st['font_id']]
        fs = st['font_size'] * scale * metric.get('ass_size_scale',1)
        weight = -1 if st['bold'] or font.get('bold') else 0
        italic = -1 if font.get('italic') or st.get('italic') else 0
        underline = -1 if st.get('underline') else 0
        opacity = st.get('opacity', 1)
        shadow_opacity = st['shadow_opacity'] * opacity
        styles.append(f'Style: C{index},{family},{fs},{ass_color(st["color"], opacity)},&H00FFFFFF,{ass_color(st["outline_color"], st.get("outline_opacity", 1)*opacity)},{ass_color("#000000", shadow_opacity)},{weight},{italic},{underline},0,100,100,{st["spacing"]*scale},0,1,{st["outline"]*scale},0,5,0,0,0,1')
        # Escape ASS control sequences; text is data, never renderer commands.
        text = cue['text'].replace('\\', '＼').replace('{', '｛').replace('}', '｝').replace('\r', '').replace('\n', r'\N')
        x, y = project['width'] * st['x'] / 100, project['height'] * st['y'] / 100
        angle = math.radians(st.get('shadow_angle', 45))
        dx, dy = st['shadow'] * scale * math.cos(angle), st['shadow'] * scale * math.sin(angle)
        blur = st.get('shadow_blur', 0) * scale
        pieces = [(text, y)]
        if r'\N' in text:
            line_height = st['font_size'] * metric.get('line_height',1.2)
            rows = text.split(r'\N')
            step = (line_height + st['line_spacing']) * scale
            pieces = [(row, y + (i - (len(rows)-1)/2) * step) for i, row in enumerate(rows)]
        if blur and st['shadow_opacity'] > 0:
            black = ass_color('#000000', shadow_opacity)
            styles.append(f'Style: S{index},{family},{fs},{black},{black},{black},{black},{weight},{italic},0,0,100,100,{st["spacing"]*scale},0,1,{st["outline"]*scale},0,5,0,0,0,1')
        for row, row_y in pieces:
            if blur and st['shadow_opacity'] > 0:
                events.append(f'Dialogue: 0,{ass_time(cue["start"])},{ass_time(cue["end"])},S{index},,0,0,0,,{{\\pos({x+dx:.2f},{row_y+dy:.2f})\\blur{blur:.2f}}}{row}')
            shadow = '' if blur else f'\\xshad{dx:.2f}\\yshad{dy:.2f}'
            events.append(f'Dialogue: 1,{ass_time(cue["start"])},{ass_time(cue["end"])},C{index},,0,0,0,,{{\\pos({x:.2f},{row_y:.2f}){shadow}}}{row}')
    return '\n'.join(header + styles + ['', '[Events]', 'Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text'] + events) + '\n'


def quality(project):
    clips, duration = timeline(project)
    fps = fps_value(project['fps'])
    assets = {a['id']: a for a in project['assets']}
    issues = []
    def issue(level, code, text, time=None):
        issues.append(dict(level=level, code=code, text=text, time=time))
    for reason in project.get('native',{}).get('issues',[]):
        issue('error','NATIVE_UNSUPPORTED',reason+'；保留原生数据，请在剪映预览/导出')
    for mask in project.get('masks',[]):
        if mask['end']>duration+1e-6:
            issue('error','MASK_PAST_END','打码片段超出画面结尾，导出无法完整显示',mask['start'])
    if not clips:
        issue('error', 'NO_VIDEO', '还没有画面片段')
    for item in clips:
        asset = assets[item['asset_id']]
        if not item.get('audio_detached') and len(asset.get('audio_streams', [])) > 1 and item.get('audio_stream') is None:
            issue('error', 'AUDIO_TRACK_UNCONFIRMED', f'{asset["name"]}有多条音轨，请试听并选择人物原声轨', item['start'])
        if not item.get('audio_detached') and asset['has_audio'] and item.get('gain', 0) <= -50:
            issue('error', 'MUTED_ORIGINAL', f'{asset["name"]}原声被降至近静音，需要逐句验证保留情况', item['start'])
        if item['duration'] < .5:
            issue('review', 'SHORT_SHOT', '短于0.5秒的镜头需复核，不会自动删除', item['start'])
        if abs(asset.get('fps', fps) - fps) > .001:
            issue('review', 'CADENCE', f'{asset["name"]}源帧率与输出不同，需检查真实输出', item['start'])
    for i, left in enumerate(clips):
        for right in clips[i+1:]:
            if assets[left['asset_id']]['sha256'] == assets[right['asset_id']]['sha256']:
                if min(left['in']+left['duration'], right['in']+right['duration']) > max(left['in'], right['in']) + .00001:
                    issue('error', 'REUSED_SOURCE', '重复使用同一源画面区间', right['start'])
    placed = [dict(c, role='original_dialogue') for c in clips if not c.get('audio_detached')]
    placed += [dict(a, role='original_dialogue', duration=a['out']-a['in']) for a in project['audios'] if a['role']=='dialogue']
    placed += [dict(a, duration=a['out']-a['in']) for a in project['audios'] if a['role'] == 'narration']
    speech = []
    for a in project['audios']:
        if len(assets[a['asset_id']].get('audio_streams', [])) > 1 and a.get('audio_stream') is None:
            issue('error', 'AUDIO_TRACK_UNCONFIRMED', '附加音频有多条音轨，必须明确选择', a['start'])
        if a['role']=='dialogue' and a['start']+a['out']-a['in']>duration+.001:
            issue('error','DIALOGUE_PAST_END','分离原声超出画面结尾，会被导出截断',a['start'])
        if a['role']=='narration' and a['start']+a['out']-a['in']>duration+.001:
            issue('error','NARRATION_PAST_END','旁白超出画面结尾，会被导出截断',a['start'])
    if not project['protected_lines']:
        issue('review', 'NO_BASELINE', '缺少剪前必保台词清单；不能证明人物对白没有漏掉')
    for line in project['protected_lines']:
        source = assets[line['asset_id']]
        if not source.get('has_audio'):
            issue('error', 'BASELINE_NO_AUDIO', '必保台词来源没有音轨：'+line['text'])
        if len(source.get('audio_streams', [])) > 1 and line.get('audio_stream') is None:
            issue('error', 'BASELINE_TRACK_UNCONFIRMED', '必保台词必须指明源音轨：'+line['text'])
        spans = []
        for item in placed:
            if line['asset_id'] not in (item['asset_id'],item.get('source_asset_id')) or item.get('gain', 0) <= -50 or item.get('muted') or not source.get('has_audio'):
                continue
            if (line['kind'] == 'original_dialogue') != (item['role'] == 'original_dialogue'):
                continue
            selected_stream = item.get('source_audio_stream') if item.get('source_asset_id')==line['asset_id'] else item.get('audio_stream')
            if selected_stream is None and len(source.get('audio_streams', [])) == 1:
                selected_stream = source['audio_streams'][0]['index']
            if line.get('audio_stream') is not None and line['audio_stream'] != selected_stream:
                continue
            start, end = max(item['in'], line['start']), min(item['in']+item['duration'], line['end'])
            if end > start:
                spans.append((start, end))
                speech.append(dict(id=line['id'], kind=line['kind'], placement=(item['role'], item['id']), source_start=start, source_end=end,
                                   start=item['start']+start-item['in'], end=item['start']+end-item['in']))
        cursor = line['start']
        for start, end in sorted(spans):
            if start > cursor + .00001:
                break
            cursor = max(cursor, end)
        if cursor < line['end'] - .00001:
            issue('error', 'MISSING_SPEECH', f'必保台词缺失或被截断：{line["text"]}')
        pieces = sorted([p for p in speech if p['id'] == line['id']], key=lambda p:p['start'])
        if sum(b-a for a,b in spans) > line['end']-line['start'] + .00001:
            issue('error', 'REPEATED_SPEECH', f'必保台词被重复放置：{line["text"]}')
        for a, b in zip(pieces, pieces[1:]):
            if b['source_start'] < a['source_end'] - .00001:
                issue('error', 'SPEECH_ORDER', f'一句台词被重复或逆序：{line["text"]}', b['start'])
            if abs(b['start']-a['end']) > 1/fps + .00001:
                issue('error', 'SPEECH_GAP', f'一句台词被新增空档打断：{line["text"]}', a['end'])
    for i, a in enumerate(speech):
        for b in speech[i+1:]:
            if a['placement'] != b['placement'] and min(a['end'], b['end']) > max(a['start'], b['start']) + .00001:
                issue('error', 'VOICE_OVERLAP', '不同人声音轨发生重叠（包括两条旁白）', max(a['start'], b['start']))
    bgm = [a for a in project['audios'] if a['role'] == 'bgm' and a.get('gain', 0) > -50]
    cursor = 0
    for a in sorted(bgm, key=lambda a:a['start']):
        if a['start'] > cursor + 1/fps:
            break
        cursor = max(cursor, duration if a.get('loop', False) else a['start']+a['out']-a['in'])
    if cursor < duration - 1/fps:
        issue('error', 'BGM_GAP', 'BGM未覆盖整片，请添加音乐并覆盖片尾')
    cues = sorted(project['captions'], key=lambda c:c['start'])
    current_sound = sound_digest(project)
    tolerance = 1 / fps + .01
    def covers(start, end, intervals):
        cursor = start
        for a, b in sorted(intervals):
            if b <= cursor:
                continue
            if a > cursor + tolerance:
                break
            cursor = max(cursor, b)
        return cursor >= end - tolerance
    speech_ranges = [(s['start'], s['end']) for s in speech]
    verified_ranges = []
    if not cues:
        issue('review', 'NO_CAPTIONS', '还没有字幕')
    for i, cue in enumerate(cues):
        if not str(cue.get('text', '')).strip():
            issue('error', 'EMPTY_CAPTION', '字幕文字为空，不能交付', cue['start'])
        if cue['end'] > duration + .01:
            issue('error', 'CAPTION_PAST_END', '字幕超出成片结尾', cue['start'])
        if i and cue['start'] < cues[i-1]['end'] - .00001:
            issue('error', 'CAPTION_OVERLAP', '两条字幕同时显示', cue['start'])
        evidence = cue.get('speech')
        if not isinstance(evidence, dict):
            issue('error', 'CAPTION_UNVERIFIED', '字幕尚未关联最终混音的真实发声时间', cue['start'])
            continue
        if evidence.get('sound_digest') != current_sound:
            issue('error', 'CAPTION_SYNC_STALE', '声音或镜头已改变，字幕时间依据已过期，必须按新混音重新确认', cue['start'])
            continue
        try:
            finite(evidence['start'], 0, duration, '语音起点')
            finite(evidence['end'], 0, duration, '语音终点')
            if evidence['end'] <= evidence['start']:
                raise ValueError('语音时间无效')
        except (ValueError, KeyError, TypeError):
            issue('error', 'CAPTION_EVIDENCE_INVALID', '字幕语音依据的时间无效', cue['start'])
            continue
        confirmed = evidence.get('method') == 'manual_verified' and bool(evidence.get('render_id'))
        if not confirmed:
            issue('error', 'CAPTION_UNVERIFIED', '识别结果只是草稿，需在当前最终混音上逐条确认时间', cue['start'])
        if evidence.get('sound_digest') == current_sound:
            if cue['start'] < evidence['start'] - .00001:
                tentative=evidence.get('method')=='ASR_unverified'
                issue('review' if tentative else 'error', 'CAPTION_EARLY',
                      '字幕早于ASR估计起点，必须按实际声音复核（识别时间不是真值）' if tentative else '字幕早于关联语音起点', cue['start'])
            if cue['start'] > evidence['start'] + tolerance:
                issue('error', 'CAPTION_LATE', '字幕晚于关联语音起点', cue['start'])
            if cue['end'] > evidence['end'] + tolerance:
                issue('error', 'CAPTION_HANG', '字幕延续至关联语音结束之后', cue['end'])
            if cue['end'] < evidence['end'] - tolerance:
                issue('error', 'CAPTION_END_EARLY', '字幕在关联语音说完前消失', cue['end'])
        if not covers(evidence['start'], evidence['end'], speech_ranges):
            issue('error', 'CAPTION_OUTSIDE_SPEECH', '字幕语音区间不在必保发声清单内，请核实是否漏登记或静音段误加字幕', cue['start'])
        if confirmed and str(cue.get('text', '')).strip():
            verified_ranges.append((max(cue['start'], evidence['start']), min(cue['end'], evidence['end'])))
    for span in speech:
        if not covers(span['start'], span['end'], verified_ranges):
            issue('error', 'MISSING_CAPTION', '已登记的人物对白或旁白没有完整对应的已确认字幕', span['start'])
    script = project['script']
    if not str(script.get('text', '')).strip():
        issue('error', 'SCRIPT_TEXT_EMPTY', '剧本正文为空')
    if not (script.get('complete') and script.get('start_anchor') and script.get('end_anchor')):
        issue('review', 'SCRIPT_BOUNDARY', '剧本章节起止未确认；不能把页尾当分集边界')
    current = digest(project)
    return dict(duration=duration, hash=current, sound_hash=sound_digest(project), issues=issues,
                can_deliver=not any(i['level']=='error' for i in issues),
                note='这些是自动检查提示，不是审批流程，也不阻止导出。')
