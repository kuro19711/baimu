"""Keep generated media outside draft folders that Jianying renames in place."""
import hashlib,json,os,shutil,tempfile
from pathlib import Path


def file_hash(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def stabilize(content,folder,bank,legacy_folders=()):
    folder=Path(folder).resolve();bank=Path(bank).resolve()
    roots=[(Path(p).resolve()/'Resources') for p in (folder,*legacy_folders)]
    replacements={}
    def path_value(value):
        if value in replacements:return replacements[value]
        if len(value)>2000:return value
        try:
            source=Path(value)
            if not source.is_absolute():return value
            source=source.resolve()
            relative=None
            for root in roots:
                if source.is_relative_to(root):relative=source.relative_to(root);break
            if relative is None or not relative.parts:return value
            if not source.is_file():source=(folder/'Resources'/relative).resolve()
            if not source.is_relative_to(folder/'Resources') and not any(source.is_relative_to(root) for root in roots):
                raise ValueError('工程资源路径越界')
            if not source.is_file():raise ValueError('工程资源缺失，未交给剪映：'+value)
            before=source.stat();digest=file_hash(source)
            destination=bank/digest[:2]/(digest+source.suffix.lower())
            destination.parent.mkdir(parents=True,exist_ok=True)
            if destination.exists():
                if file_hash(destination)!=digest:raise ValueError('固定资源副本校验失败：'+str(destination))
            else:
                fd,temp=tempfile.mkstemp(dir=destination.parent,suffix='.tmp')
                try:
                    with os.fdopen(fd,'wb') as out,source.open('rb') as inp:shutil.copyfileobj(inp,out)
                    if file_hash(Path(temp))!=digest:raise ValueError('复制期间工程资源改变，请重试')
                    os.replace(temp,destination)
                finally:Path(temp).unlink(missing_ok=True)
            after=source.stat()
            if (before.st_mtime_ns,before.st_size)!=(after.st_mtime_ns,after.st_size):raise ValueError('复制期间工程资源改变，请重试')
            replacements[value]=str(destination);return str(destination)
        except OSError as error:raise ValueError('无法固定工程资源：'+str(error)) from error
    def visit(value,key=''):
        if isinstance(value,dict):return {k:visit(v,k) for k,v in value.items()}
        if isinstance(value,list):return [visit(v,key) for v in value]
        if not isinstance(value,str):return value
        # Native text styles store font paths inside JSON-encoded rich text.
        if value.startswith(('{','[')):
            try:decoded=json.loads(value)
            except ValueError:return value
            changed=visit(decoded)
            return json.dumps(changed,ensure_ascii=False,separators=(',',':')) if changed!=decoded else value
        return path_value(value) if key.lower().endswith('path') else value
    return visit(content)


def validate_audio_paths(content):
    materials={m['id']:m for m in content.get('materials',{}).get('audios',[])}
    for track in content.get('tracks',[]):
        if track.get('type')!='audio':continue
        for segment in track.get('segments',[]):
            material=materials.get(segment.get('material_id'),{})
            path=material.get('path','')
            if not path or not Path(path).is_file():
                raise ValueError('音频文件缺失，未交给剪映：'+str(material.get('name') or path or segment.get('id')))
