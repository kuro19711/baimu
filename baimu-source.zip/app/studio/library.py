"""Stable drama folders over existing per-episode records; source files stay put."""
import time,re,copy,math
from .core import uid
from .store import write_json,natural
from .episode_folders import episode_name


def modified_time(*values):
    return max((v for v in values if isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>=0),default=0)


class Library:
    def __init__(self,store):
        self.store=store
        self.path=store.root/'library.json'

    def load(self):
        def valid(value):
            return (isinstance(value,dict) and value.get('version')==1 and isinstance(value.get('folders'),list)
                    and all(isinstance(f,dict) and re.fullmatch('[a-f0-9]{32}',str(f.get('id','')))
                            and isinstance(f.get('series'),str) and isinstance(f.get('name'),str) for f in value['folders'])
                    and len({f['id'] for f in value['folders']})==len(value['folders'])
                    and len({f['series'] for f in value['folders']})==len(value['folders']))
        return self.store.read_record(self.path,dict(version=1,folders=[]),valid)

    def list(self):
        with self.store.lock:
            value=self.load();projects=self.store.list_projects(refresh_native=False)
            stored=self.store.list_projects(refresh_native=False,native_metadata=False)
            stored_by_id={p['id']:p for p in stored};known={f['series'] for f in value['folders']};changed=False
            for project in projects:
                series=project.get('series','')
                if series not in known:
                    value['folders'].append(dict(id=uid(),name=series or '历史未分组',series=series,created=time.time()))
                    known.add(series);changed=True
            if changed:write_json(self.path,value)
            aliases={}
            stale=set()
            available={f['series'] for f in value['folders']}
            for folder in value['folders']:
                if any(p.get('series','')==folder['series'] for p in projects):continue
                redirected={p.get('series','') for p in projects
                            if stored_by_id.get(p['id'],{}).get('series','')==folder['series'] and p.get('series','')!=folder['series']}
                if len(redirected)==1 and next(iter(redirected)) in available:
                    target=next(iter(redirected));stale.add(folder['id']);aliases.setdefault(target,[]).append(folder['id'])
            result=[]
            for folder in value['folders']:
                if folder['id'] in stale:continue
                episodes=[copy.deepcopy(p) for p in projects if p.get('series','')==folder['series']]
                for episode in episodes:
                    parsed=episode_name(episode['name']);episode['episode_number']=parsed[0] if parsed else None
                episodes.sort(key=lambda p:(p['episode_number'] is None,p['episode_number'] or 0,natural(p['name']),p['id']))
                result.append(dict(folder,aliases=sorted(aliases.get(folder['series'],[])),episodes=episodes,episode_count=len(episodes),
                                   modified=modified_time(folder.get('created'),folder.get('modified'),*(p.get('modified') for p in episodes)),
                                   with_video=sum(bool(p['clips']) for p in episodes),with_captions=sum(bool(p['captions']) for p in episodes)))
            return sorted(result,key=lambda f:(natural(f['name']),f['id']))

    def get(self,folder_id):
        folder=next((f for f in self.list() if f['id']==folder_id or folder_id in f.get('aliases',[])),None)
        if folder is None:raise ValueError('剧文件夹不存在，请从首页重新选择')
        return folder

    def create(self,name):
        name=self.store.series_name(name)
        if not name:raise ValueError('请填写剧名')
        with self.store.lock:
            self.list();value=self.load()
            if any(f['series'].casefold()==name.casefold() for f in value['folders']):
                raise ValueError('同名剧文件夹已存在，请直接打开')
            folder=dict(id=uid(),name=name,series=name,created=time.time())
            value['folders'].append(folder);write_json(self.path,value)
            return dict(folder,modified=folder['created'],episodes=[],episode_count=0,with_video=0,with_captions=0)
