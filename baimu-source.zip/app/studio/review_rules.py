"""Editable review instructions and per-episode scope, separate from timelines."""
from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path

from .store import read_json, write_json


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':')).encode('utf-8')).hexdigest()


def parse_review(markdown):
    """Only top-level ATX ## headings outside fenced code become checkboxes."""
    if not isinstance(markdown, str) or not markdown.strip() or len(markdown.encode('utf-8')) > 262144:
        raise ValueError('审核要求不能为空，且不能超过 256 KiB')
    sections, intro, current, fence = [], [], None, None
    for line in markdown.replace('\r\n', '\n').splitlines():
        marker = re.match(r'^ {0,3}(`{3,}|~{3,})(.*)$', line)
        if fence:
            if marker and marker[1][0] == fence[0] and len(marker[1]) >= len(fence) and not marker[2].strip():
                fence = None
            (current['lines'] if current else intro).append(line)
            continue
        if marker:
            fence = marker[1]
            (current['lines'] if current else intro).append(line)
            continue
        heading = re.match(r'^ {0,3}##[ \t]+(.+?)\s*$', line)
        if heading:
            title = re.sub(r'[ \t]+#+[ \t]*$', '', heading[1]).strip()
            if not title or len(title) > 120:
                raise ValueError('审核小标题需为 1～120 个字符')
            if any(s['title'].casefold() == title.casefold() for s in sections):
                raise ValueError('审核小标题不能重复：'+title)
            current = dict(id='rule-'+fingerprint(title)[:24], title=title, lines=[])
            sections.append(current)
        else:
            (current['lines'] if current else intro).append(line)
    if fence:
        raise ValueError('Markdown 代码块没有闭合，请补齐结尾围栏')
    if not sections or len(sections) > 100:
        raise ValueError('请使用 ## 小标题创建 1～100 个审核项')
    for section in sections:
        section['body'] = '\n'.join(section.pop('lines')).strip()
        section['hash'] = fingerprint([section['title'], section['body']])
    return '\n'.join(intro).strip(), sections


class ReviewRules:
    def __init__(self, store):
        self.store = store
        self.root = store.root/'review'
        defaults = Path(__file__).resolve().parents[1]/'skills'
        self.defaults = {kind: (defaults/kind/'SKILL.md').read_text(encoding='utf-8')
                         for kind in ('review', 'repair')}

    def _document(self, raw):
        if not isinstance(raw, dict) or not isinstance(raw.get('repair'), str):
            raise ValueError('审核规则记录损坏；保留原文件，请检查后重试')
        intro, sections = parse_review(raw.get('review'))
        if not raw['repair'].strip() or len(raw['repair'].encode('utf-8')) > 262144:
            raise ValueError('返工方法不能为空，且不能超过 256 KiB')
        return dict(raw, revision=fingerprint([raw['review'], raw['repair']]),
                    intro=intro, sections=sections)

    def documents(self):
        with self.store.lock:
            return self._document(read_json(self.root/'skills.json', self.defaults))

    def save_documents(self, body):
        with self.store.lock:
            old = self.documents()
            if not isinstance(body, dict) or body.get('revision') != old['revision']:
                raise ValueError('审核规则已变化，请保留输入并重新读取后合并')
            new = self._document(dict(review=body.get('review'), repair=body.get('repair')))
            if old['revision'] != new['revision']:
                write_json(self.root/'history'/(old['revision']+'.json'),
                           {k: old[k] for k in ('review', 'repair', 'revision')})
                write_json(self.root/'skills.json', {k: new[k] for k in ('review', 'repair')})
            return new

    def _state(self, pid):
        self.store.path(pid)  # Validate ID before constructing any path.
        raw = read_json(self.root/'projects'/(pid+'.json'), dict(excluded=[]))
        if (not isinstance(raw, dict) or not isinstance(raw.get('excluded'), list)
                or not all(isinstance(x, str) for x in raw['excluded'])):
            raise ValueError('本集审核配置损坏；保留原文件，请检查后重试')
        return raw

    def _confirmations(self):
        raw = read_json(self.root/'interpretations.json', {})
        if (not isinstance(raw, dict) or not all(isinstance(v, dict) and isinstance(v.get('hash'), str)
                and isinstance(v.get('interpretation'), str) for v in raw.values())):
            raise ValueError('规则理解记录损坏；保留原文件，请检查后重试')
        return raw

    def context(self, pid):
        with self.store.lock:
            project = self.store.get(pid)
            docs, state = self.documents(), self._state(pid)
            confirmations = self._confirmations()
            base = self._document(self.defaults)
            baseline = {s['id']: s['hash'] for s in base['sections']}
            baseline.update({'review-intro': fingerprint(base['intro']), 'repair': fingerprint(base['repair'])})
            items = [dict(s, selected=s['id'] not in state['excluded']) for s in docs['sections']]
            common = [dict(id='review-intro', title='审核通用说明', body=docs['intro'], hash=fingerprint(docs['intro']), selected=True),
                      dict(id='repair', title='返工方法', body=docs['repair'], hash=fingerprint(docs['repair']), selected=True)]
            for item in items+common:
                saved = confirmations.get(item['id'], {})
                accepted = saved.get('hash', baseline.get(item['id']))
                item['needs_clarification'] = item['hash'] != accepted
                item['interpretation'] = saved.get('interpretation', '')
                item['interpretation_current'] = bool(saved) and not item['needs_clarification']
            selected = [s for s in items if s['selected']]
            return dict(project_id=pid, project_revision=project['revision'],
                        rules_revision=docs['revision'], scope_revision=fingerprint([state, confirmations]),
                        review_skill=docs['review'], repair_skill=docs['repair'],
                        sections=items, common=common, selected_ids=[s['id'] for s in selected],
                        selected_review_markdown=docs['intro']+'\n\n'+'\n\n'.join('## '+s['title']+'\n'+s['body'] for s in selected),
                        needs_clarification=[s for s in selected+common if s['needs_clarification']],
                        notice='勾选表示检查范围，不是审核通过或修改授权。新增项默认勾选；改名视为新项。先核对待确认内容，不自动确认自己的解释。')

    def update_scope(self, pid, body, confirm=False):
        with self.store.lock:
            current = self.context(pid)
            if (not isinstance(body, dict) or body.get('rules_revision') != current['rules_revision']
                    or body.get('scope_revision') != current['scope_revision']):
                raise ValueError('审核规则或本集选择已变化，请重新读取后再保存')
            state = self._state(pid)
            if confirm:
                candidates = {s['id']: s for s in current['sections']+current['common']}
                key, note = body.get('id'), body.get('interpretation')
                if not isinstance(key, str) or key not in candidates or not isinstance(note, str) or not note.strip() or len(note) > 8000:
                    raise ValueError('请选择有效规则，并填写 1～8000 字的已确认理解')
                if body.get('confirmed_by_user') is not True:
                    raise ValueError('只有人工已确认的解释才能记录')
                confirmations = self._confirmations()
                confirmations[key] = dict(hash=candidates[key]['hash'], interpretation=note.strip(), confirmed_at=time.time())
                write_json(self.root/'interpretations.json', confirmations)
            else:
                chosen = body.get('selected_ids')
                allowed = {s['id'] for s in current['sections']}
                if (not isinstance(chosen, list) or not all(isinstance(x, str) for x in chosen)
                        or len(chosen) != len(set(chosen)) or not set(chosen) <= allowed):
                    raise ValueError('审核选择包含未知项或重复项，请重新读取')
                # Keep exclusions for temporarily removed headings; new headings default to selected.
                state['excluded'] = sorted((set(state['excluded'])-allowed) | (allowed-set(chosen)))
                write_json(self.root/'projects'/(pid+'.json'), state)
            return self.context(pid)
