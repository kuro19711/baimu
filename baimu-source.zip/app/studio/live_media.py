"""Project-scoped audio proxies for browser mixing, exact stream selection."""
import hashlib
import json
import os
import threading
from .media import binary, process
from .timeline_media import _source


class LiveMedia:
    def __init__(self,store):
        self.store=store
        self.guard=threading.Lock()
        self.locks={}
        self.slots=threading.BoundedSemaphore(2)

    def audio(self,pid,aid,stream=None):
        project=self.store.get(pid)
        asset=next((a for a in project['assets'] if a['id']==aid),None)
        if asset is None:raise ValueError('此素材未登记在当前工程')
        source=_source(self.store,asset);stat=source.stat()
        if stat.st_size!=asset.get('size') or stat.st_mtime_ns!=asset.get('mtime_ns'):
            raise ValueError('素材文件已变化，请先刷新素材记录')
        streams=asset.get('audio_streams',[])
        selected=(streams[0] if len(streams)==1 else None) if stream is None else next((s for s in streams if s['index']==stream),None)
        if selected is None:raise ValueError('请明确选择此素材中的音轨')
        key=hashlib.sha256(json.dumps([str(source),stat.st_size,stat.st_mtime_ns,selected['index'],'aac-v1']).encode()).hexdigest()
        folder=self.store.root/'cache'/'live-audio'
        for path in (self.store.root,self.store.root/'cache',folder):
            if path.exists() and self.store.is_link(path):raise ValueError('实时音频缓存路径包含链接')
        folder.mkdir(parents=True,exist_ok=True)
        output=folder/(key+'.m4a')
        if self.store.is_link(folder) or (output.exists() and self.store.is_link(output)):
            raise ValueError('实时音频缓存路径包含链接')
        with self.guard:lock=self.locks.setdefault(key,threading.Lock())
        with lock:
            if output.is_file():return output
            if not self.slots.acquire(timeout=30):raise ValueError('音频预览正在准备，请稍后重试')
            temporary=folder/(key+'.partial.m4a')
            try:
                process([binary('ffmpeg'),'-hide_banner','-v','error','-y','-i',str(source),
                         '-map',f'0:{selected["index"]}','-vn','-af','aresample=48000:async=1:first_pts=0',
                         '-ac','2','-c:a','aac','-b:a','192k','-movflags','+faststart',str(temporary)],timeout=180)
                if source.stat().st_mtime_ns!=stat.st_mtime_ns:raise ValueError('素材准备时发生变化，请重试')
                os.replace(temporary,output)
            finally:
                temporary.unlink(missing_ok=True);self.slots.release()
        return output
