"""Revision-checked, atomic edit batches using the browser's actual JS engine."""
import copy
import json
import os
import subprocess
import time
from pathlib import Path
from .core import digest, validate, uid
from .store import read_json, write_json


class EditorCommands:
    def __init__(self, store):
        self.store=store
        self.root=Path(__file__).resolve().parents[1]

    def execute(self, pid, body):
        operations=body.get('operations')
        if not isinstance(operations,list) or not 1<=len(operations)<=100:
            raise ValueError('一次提交需要1至100条编辑操作')
        with self.store.lock:
            before=self.store.get(pid)
            if isinstance(body.get('revision'),bool) or body.get('revision')!=before['revision']:
                raise ValueError('工程版本已变化，请重新读取后提交编辑')
            node=self.root.parent/'engine'/'node.exe'
            if not node.is_file():raise ValueError('缺少编辑引擎运行时，请修复安装')
            request=json.dumps(dict(project=before,operations=operations),ensure_ascii=False)
            try:
                run=subprocess.run([str(node),str(self.root/'studio'/'editor_bridge.cjs')],
                    input=request,encoding='utf-8',capture_output=True,timeout=10,
                    creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            except subprocess.TimeoutExpired as exc:
                raise ValueError('编辑计算超时，工程未修改') from exc
            try:result=json.loads(run.stdout)
            except ValueError as exc:raise ValueError('编辑引擎返回无效结果，工程未修改') from exc
            if run.returncode or result.get('error'):raise ValueError(result.get('error','编辑计算失败'))
            project=result['project'];validate(project)
            if digest(project)==digest(before):
                return dict(result,project=before,changed=False)
            # Store.save provides the same durable before-version history as manual saves.
            saved=self.store.save(pid,project)
            return dict(result,project=saved,changed=True,transaction_id=uid())
