"""Offline Jianying bridge. Reads originals; writes only below an explicit sandbox.

Python 3.10+, standard library. The adjacent draft_crypto.py calls the installed
Jianying DLL in a disposable subprocess. No DLL is distributed with this tool.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import time
from datetime import datetime, timezone
from .draft_crypto import decrypt_draft_bytes, encrypt_draft_bytes


DEFAULT_INSTALL = r"D:\JianyingPro\11.6.0.14552"
MAX_FILE = 128 * 1024 * 1024


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def decode(raw, install):
    try:
        obj = json.loads(raw.decode("utf-8-sig"))
        encoding = "plain_json"
    except (ValueError, UnicodeError):
        plain = decrypt_draft_bytes(raw, jy_install_dir=install, timeout=30)
        obj = json.loads(plain.decode("utf-8-sig"))
        encoding = "jianying_local_dll"
    if not isinstance(obj, dict):
        raise ValueError("Expected JSON object")
    return obj, encoding


def stable_bytes(path):
    before = path.stat()
    if before.st_size > MAX_FILE:
        raise ValueError(f"File too large: {path}")
    raw = path.read_bytes()
    after = path.stat()
    if (before.st_mtime_ns, before.st_size) != (after.st_mtime_ns, after.st_size):
        raise RuntimeError(f"Changed during read: {path}")
    return raw


def control_files(folder):
    """Current control files plus sidecars, without cached media or backups.

    Snapshot is deliberately a control-file snapshot, not a media backup.
    Never follows a symlink/junction or promotes *.bak/template-*.tmp.
    """
    names = {"draft_content.json", "draft_info.json", "draft_meta_info.json",
             "draft_settings", "draft.extra"}
    result = []
    candidates=[]
    for base, dirs, files in os.walk(folder, followlinks=False):
        for name in dirs + files:
            p=Path(base)/name
            if p.is_symlink() or getattr(p.lstat(), 'st_file_attributes', 0) & 0x400:
                raise ValueError(f"Symlink/junction in draft: {p}")
        candidates.extend(Path(base)/name for name in files)
    for p in candidates:
        rel = p.relative_to(folder)
        if not p.is_file():
            continue
        if p.name.startswith(("BRIDGE_", "SNAPSHOT_")):
            continue
        if len(rel.parts) == 1 and (p.name in names or p.suffix == ".json"):
            result.append(p)
        elif rel.parts[0] in {"Timelines", "common_attachment", "subdraft"} and p.suffix == ".json":
            result.append(p)
    return sorted(result)


def fingerprint(folder):
    files = {p.relative_to(folder).as_posix(): digest(stable_bytes(p))
             for p in control_files(folder)}
    return {"revision": digest(json.dumps(files, sort_keys=True).encode()), "files": files}


def write_checked(folder, relative, raw, expected_files):
    """Compare every control file immediately before replacing one mirror.

    This detects observed external writes, including edits to an already written
    mirror. It cannot prevent a later save from another application's memory.
    """
    target = folder / relative
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix=".baimu-", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        if fingerprint(folder)['files'] != expected_files:
            raise ValueError('工程在另一边发生变化，本次提交已暂停；修改与备份已保留')
        os.replace(temporary, target)
        expected_files[relative] = digest(raw)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def write_index_checked(index, payload, expected_raw):
    """Check the shared home index after staging, immediately before replace."""
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=index.parent, prefix='.baimu-index-', suffix='.tmp', delete=False) as handle:
            temporary = Path(handle.name)
            handle.write(json.dumps(payload, ensure_ascii=False, indent=2).encode('utf-8'))
            handle.flush()
            os.fsync(handle.fileno())
        if stable_bytes(index) != expected_raw:
            raise ValueError('剪映工程列表已改变，请重新读取后登记；未覆盖列表')
        os.replace(temporary, index)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def timeline_paths(folder, install):
    roots = [folder / n for n in ("draft_content.json", "draft_info.json")
             if (folder / n).is_file()]
    if not roots:
        raise ValueError("No current draft main file; backups are not candidates")
    index = folder / "Timelines/project.json"
    main_id = None
    active = []
    if index.is_file():
        obj, _ = decode(stable_bytes(index), install)
        main_id = obj.get("main_timeline_id")
        for t in obj.get("timelines", []):
            if t.get("is_marked_delete"):
                continue
            tid = str(t["id"])
            if Path(tid).name != tid or tid in {".", ".."} or ":" in tid or "\\" in tid:
                raise ValueError("Invalid timeline id")
            candidates = [folder / "Timelines" / tid / n
                          for n in ("draft_content.json", "draft_info.json")]
            found = [p for p in candidates if p.is_file()]
            if not found:
                raise ValueError(f"Missing active timeline: {tid}")
            active.extend(found)
    return roots, active, main_id


def load(folder, install, _allow_incomplete=False):
    folder = Path(folder).resolve()
    if (folder / 'SNAPSHOT_INCOMPLETE.json').exists():
        raise RuntimeError('Snapshot was marked incomplete')
    patch_marker=folder/'BRIDGE_PATCH_RESULT.json'
    if patch_marker.exists() and not _allow_incomplete:
        marker=json.loads(patch_marker.read_text(encoding='utf-8'))
        if marker.get('stage')!='complete_offline_only':
            raise RuntimeError('Patch copy is incomplete; do not use as a current draft')
    before = fingerprint(folder)
    roots, active, main_id = timeline_paths(folder, install)
    docs = {}
    for p in dict.fromkeys(roots + active):
        obj, encoding = decode(stable_bytes(p), install)
        if not isinstance(obj.get("tracks"), list) or not isinstance(obj.get("materials"), dict):
            raise ValueError(f"Not a timeline: {p}")
        docs[p.relative_to(folder).as_posix()] = {"object": obj, "encoding": encoding}
    if fingerprint(folder) != before:
        raise RuntimeError("Draft changed during multi-file read; retry after handoff")
    root_keys = [p.relative_to(folder).as_posix() for p in roots]
    first = docs[root_keys[0]]["object"]
    if any(docs[k]["object"] != first for k in root_keys):
        raise ValueError("Ambiguous main files: draft_info and draft_content differ")
    mirror_keys = list(root_keys)
    if main_id:
        matches = [k for k, d in docs.items()
                   if k.startswith("Timelines/") and d["object"].get("id") == main_id]
        if not matches:
            raise ValueError("Main timeline not found by stable id")
        if first.get("id") != main_id or any(docs[k]["object"] != first for k in matches):
            raise ValueError("Root/main timeline diverge; refusing to guess authority")
        mirror_keys.extend(matches)
    return {"path": str(folder), **before, "main_timeline_id": main_id or first.get("id"),
            "documents": docs, "main_mirrors": mirror_keys}


def summary(state):
    main = state["documents"][state["main_mirrors"][0]]["object"]
    media = []
    for kind, materials in main["materials"].items():
        if isinstance(materials, list):
            for mat in materials:
                p = mat.get("path") if isinstance(mat, dict) else None
                if isinstance(p, str) and p:
                    media.append({"kind": kind, "id": mat.get("id"), "path": p,
                                  "exists": Path(p).exists()})
    return {k: state[k] for k in ("path", "revision", "main_timeline_id", "main_mirrors")} | {
        "capabilities": {"filesystem_discoverable": True, "editor_home_visible": "unverified", "readable": True,
                         "offline_same_length_text_patch": "simple unlinked text only; ASR/words rejected",
                         "production_write": False, "jianying_reopen": "unverified"},
        "documents": [{"file": k, "encoding": d["encoding"], "id": d["object"].get("id"),
                       "track_count": len(d["object"]["tracks"]),
                       "segment_count": sum(len(t.get("segments", [])) for t in d["object"]["tracks"]),
                       "text_count": len(d["object"]["materials"].get("texts", []))}
                      for k, d in state["documents"].items()],
        "duration_us": main.get("duration"), "media_references": media,
        "snapshot_scope": "control files only; external and cached media are not backed up"}


def require_destination(destination, sandbox, source=None):
    dest, box = Path(destination).resolve(), Path(sandbox).resolve()
    if not dest.is_relative_to(box) or dest == box or dest.exists():
        raise ValueError("Destination must be a new child directory of sandbox")
    if source:
        src = Path(source).resolve()
        if src == dest or src.is_relative_to(dest) or dest.is_relative_to(src):
            raise ValueError("Source and destination must not overlap")
    dest.parent.mkdir(parents=True, exist_ok=True)
    return dest


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def snapshot(folder, destination, sandbox, install):
    folder = Path(folder).resolve()
    dest = require_destination(destination, sandbox, folder)
    state = load(folder, install)
    dest.mkdir()
    for rel in state["files"]:
        p = dest / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(folder / rel, p)
    if fingerprint(folder)["files"] != state["files"] or fingerprint(dest)["files"] != state["files"]:
        write_json(dest / "SNAPSHOT_INCOMPLETE.json", {"error": "changed while copying"})
        raise RuntimeError("Snapshot incomplete; source or copy changed")
    write_json(dest / "BRIDGE_SNAPSHOT.json", {"source": str(folder), "created_at": datetime.now(timezone.utc).isoformat(),
        "revision": state["revision"], "files": state["files"], "scope": "control files; not a full media backup"})
    return dest


def changes(a, b, path=""):
    if type(a) is not type(b):
        return [path]
    if isinstance(a, dict):
        return [q for k in a.keys() | b.keys()
                for q in ([path + "/" + k] if k not in a or k not in b
                          else changes(a[k], b[k], path + "/" + k))]
    if isinstance(a, list):
        if len(a) != len(b):
            return [path]
        return [q for i, (x, y) in enumerate(zip(a, b)) for q in changes(x, y, f"{path}/{i}")]
    return [] if a == b else [path]


def plan_text(state, material_id, old, new):
    if old == new or len(old) != len(new) or len(old.encode("utf-16-le")) != len(new.encode("utf-16-le")):
        raise ValueError("Only different text with equal codepoint/UTF-16 length is supported")
    obj = state["documents"][state["main_mirrors"][0]]["object"]
    hits = [t for t in obj["materials"].get("texts", []) if t.get("id") == material_id]
    if len(hits) != 1:
        raise ValueError("Text material id is not unique")
    rich = json.loads(hits[0]["content"])
    if rich.get("text") != old:
        raise ValueError("Expected old text differs")
    # Timed karaoke/word-level transcripts need separate regeneration. Reject
    # even equal-length edits if synchronized representations contain old text.
    material = hits[0]
    for k, v in material.items():
        if k != "content" and old and old in json.dumps(v, ensure_ascii=False):
            raise ValueError(f"Linked text in {k}; unsupported synchronized representation")
    if material.get("words") or material.get("text_to_audio_ids"):
        raise ValueError("Timed words/TTS-linked text is unsupported")
    return {"schema": 1, "source": state["path"], "revision": state["revision"],
            "operation": "simple_text",
            "main_timeline_id": state["main_timeline_id"], "material_id": material_id,
            "old": old, "new": new, "mirror_files": state["main_mirrors"],
            "affected_segments": [s["id"] for t in obj["tracks"] for s in t.get("segments", [])
                                  if s.get("material_id") == material_id]}


def plan_volume(state, segment_id, old, new):
    if isinstance(new, bool) or not isinstance(new, (int, float)) or not 0 <= new <= 4:
        raise ValueError("Volume must be a finite linear gain between 0 and 4")
    obj = state["documents"][state["main_mirrors"][0]]["object"]
    hits = [s for t in obj["tracks"] if t.get("type") in {"video", "audio"}
            for s in t.get("segments", []) if s.get("id") == segment_id]
    if len(hits) != 1 or hits[0].get("volume") != old or new == old:
        raise ValueError("Segment id/expected volume mismatch or no-op")
    return {"schema": 1, "operation": "volume", "source": state["path"], "revision": state["revision"],
            "main_timeline_id": state["main_timeline_id"], "segment_id": segment_id,
            "old": old, "new": new, "mirror_files": state["main_mirrors"]}


def apply_copy(plan, destination, sandbox, install):
    src = Path(plan["source"])
    state = load(src, install)
    if state["revision"] != plan["revision"] or state["main_timeline_id"] != plan["main_timeline_id"]:
        raise RuntimeError("Stale plan: source changed")
    if plan.get("operation") == "volume":
        checked = plan_volume(state, plan["segment_id"], plan["old"], plan["new"])
    elif plan.get("operation") == "simple_text":
        checked = plan_text(state, plan["material_id"], plan["old"], plan["new"])
    else:
        raise ValueError("Unsupported operation")
    if checked != plan:
        raise ValueError("Plan does not match current draft")
    dest = snapshot(src, destination, sandbox, install)
    report = {"source_revision": state["revision"], "production_files_written": 0,
              "jianying_reopen": "unverified", "stage": "applying", "changed_files": []}
    write_json(dest / "BRIDGE_PATCH_RESULT.json", report)
    for rel in state["main_mirrors"]:
        doc = state["documents"][rel]
        obj = copy.deepcopy(doc["object"])
        if plan["operation"] == "simple_text":
            texts = obj["materials"]["texts"]
            i = next(i for i, t in enumerate(texts) if t.get("id") == plan["material_id"])
            rich = json.loads(texts[i]["content"])
            before_rich = copy.deepcopy(rich)
            rich["text"] = plan["new"]
            texts[i]["content"] = json.dumps(rich, ensure_ascii=False, separators=(",", ":"))
            expected_path = f"/materials/texts/{i}/content"
            if changes(before_rich, rich) != ["/text"]:
                raise RuntimeError("Unexpected rich text edit")
        else:
            hits = [(ti, si, s) for ti, t in enumerate(obj["tracks"])
                    for si, s in enumerate(t.get("segments", [])) if s.get("id") == plan["segment_id"]]
            if len(hits) != 1:
                raise RuntimeError("Ambiguous segment id")
            ti, si, segment = hits[0]
            segment["volume"] = plan["new"]
            expected_path = f"/tracks/{ti}/segments/{si}/volume"
        diff = changes(doc["object"], obj)
        if diff != [expected_path]:
            raise RuntimeError("Unexpected semantic edit")
        raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode()
        if doc["encoding"] == "jianying_local_dll":
            raw = encrypt_draft_bytes(raw, jy_install_dir=install, timeout=30, validate_roundtrip=True)
        reread, encoding = decode(raw, install)
        if reread != obj or encoding != doc["encoding"]:
            raise RuntimeError("Codec roundtrip differs")
        (dest / rel).write_bytes(raw)
        report["changed_files"].append({"file": rel, "changed_json_paths": diff,
                                        "encoding_preserved": True})
    # Sources are never written. A failed copy remains explicitly unverified.
    if fingerprint(src) != {"revision": state["revision"], "files": state["files"]}:
        raise RuntimeError("Source changed during patch; discard this copy")
    loaded = load(dest, install, _allow_incomplete=True)
    report["copy_revision"] = loaded["revision"]
    report["stage"] = "complete_offline_only"
    report["unmodified_control_files_equal"] = all(
        digest(stable_bytes(dest / rel)) == sha
        for rel, sha in state["files"].items() if rel not in state["main_mirrors"])
    write_json(dest / "BRIDGE_PATCH_RESULT.json", report)
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--install", default=DEFAULT_INSTALL)
    sub = p.add_subparsers(dest="command", required=True)
    q = sub.add_parser("inspect"); q.add_argument("draft")
    q = sub.add_parser("snapshot"); q.add_argument("draft"); q.add_argument("destination"); q.add_argument("--sandbox", required=True)
    q = sub.add_parser("plan-text"); q.add_argument("draft"); q.add_argument("material_id"); q.add_argument("old"); q.add_argument("new"); q.add_argument("--output", required=True)
    q = sub.add_parser("plan-volume"); q.add_argument("draft"); q.add_argument("segment_id"); q.add_argument("old", type=float); q.add_argument("new", type=float); q.add_argument("--output", required=True)
    q = sub.add_parser("apply-copy"); q.add_argument("plan"); q.add_argument("destination"); q.add_argument("--sandbox", required=True)
    a = p.parse_args()
    if a.command == "inspect":
        result = summary(load(a.draft, a.install))
    elif a.command == "snapshot":
        result = {"snapshot": str(snapshot(a.draft, a.destination, a.sandbox, a.install))}
    elif a.command in {"plan-text", "plan-volume"}:
        state = load(a.draft, a.install)
        result = (plan_text(state, a.material_id, a.old, a.new) if a.command == "plan-text"
                  else plan_volume(state, a.segment_id, a.old, a.new))
        # A plan is an ordinary deliverable. Do not allow writing it in the source draft.
        if Path(a.output).resolve().is_relative_to(Path(a.draft).resolve()):
            raise ValueError("Plan output must be outside source draft")
        write_json(Path(a.output), result)
    else:
        result = apply_copy(json.loads(Path(a.plan).read_text(encoding="utf-8")), a.destination, a.sandbox, a.install)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
