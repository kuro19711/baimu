"""Vendored local draft codec and builder. No editor DLL is redistributed."""
