"""Refresh registered same-path media without rebuilding native edits or groups."""
import copy
import os
from pathlib import Path
from .media import probe
from .native_audio import extract_original
from .native_defaults import timerange
from .native_resources import file_hash


def path_key(value):
    return os.path.normcase(str(Path(value).resolve()))


def relink_graph(content,mapping,before,after,asset_ids):
    """Same bytes at a new location: patch references, never rebuild segments."""
    obj=copy.deepcopy(content);records=copy.deepcopy(mapping)
    previous={a['id']:a for a in before['assets']};current={a['id']:a for a in after['assets']}
    paths={path_key(previous[aid]['path']):current[aid] for aid in asset_ids}
    materials={m['id']:m for rows in obj['materials'].values() if isinstance(rows,list)
               for m in rows if isinstance(m,dict) and m.get('id')}
    for track in obj['tracks']:
        for segment in track.get('segments',[]):
            material=materials.get(segment.get('material_id'),{})
            selected=paths.get(path_key(material['path'])) if material.get('path') else None
            if selected and track.get('attribute',0)&4:raise ValueError('引用该素材的轨道已锁定，请先解锁再重连')
    for material in materials.values():
        selected=paths.get(path_key(material['path'])) if material.get('path') else None
        if selected:material['path']=selected['path']
    for record in records:
        extraction=record.get('extraction') or {}
        selected=paths.get(path_key(extraction['source_path'])) if extraction.get('source_path') else None
        if selected:extraction['source_path']=selected['path']
        # Relinking a missing derived original also updates its provenance path.
        selected=paths.get(path_key(extraction['path'])) if extraction.get('path') else None
        if selected:extraction['path']=selected['path']
    for asset in paths.values():
        if file_hash(Path(asset['path']))!=asset['sha256']:raise ValueError('重连期间所选素材发生变化，原工程未改动')
    return obj,records


def refresh_graph(content,mapping,project,asset_ids,resources):
    obj=copy.deepcopy(content);records=copy.deepcopy(mapping)
    assets={a['id']:a for a in project['assets']}
    selected={path_key(assets[aid]['path']):assets[aid] for aid in asset_ids}
    segments={s['id']:(t,s) for t in obj['tracks'] for s in t.get('segments',[])}
    materials={m['id']:m for rows in obj['materials'].values() if isinstance(rows,list)
               for m in rows if isinstance(m,dict) and m.get('id')}
    active={s.get('material_id') for _,s in segments.values()}

    def unlocked(ids):
        if any(segments[sid][0].get('attribute',0)&4 for sid in ids):
            raise ValueError('引用该素材的轨道已锁定，请先解锁再更新素材')

    # Refresh source metadata only. Keep material IDs, crop/transform settings,
    # segment ranges, fades, gains, groups, and every unrecognized field intact.
    for mid in active:
        material=materials.get(mid,{})
        path=material.get('path')
        asset=selected.get(path_key(path)) if path else None
        if not asset:continue
        unlocked([sid for sid,(_,s) in segments.items() if s.get('material_id')==mid])
        material['duration']=round(asset['duration']*1_000_000)
        if asset['kind']=='video':
            material.update(width=asset['width'],height=asset['height'])

    # Regenerate only proven Baimu extractions. A separately replaced native
    # audio file is a user edit, not a cache we may silently overwrite.
    resources.mkdir(parents=True,exist_ok=True)
    cache={};duration_updates={};requirements={}
    for record in records:
        extraction=record.get('extraction') or {}
        origin=extraction.get('source_path')
        asset=selected.get(path_key(origin)) if origin else None
        if not asset:continue
        key=(asset['id'],extraction.get('source_stream'))
        for sid in record.get('segments',[]):
            if sid not in segments or segments[sid][0]['type']!='audio':continue
            source=timerange(segments[sid][1].get('source_timerange') or {})
            requirements[key]=max(requirements.get(key,0),source['start']+source['duration'])
    for record in records:
        extraction=record.get('extraction') or {}
        origin=extraction.get('source_path')
        asset=selected.get(path_key(origin)) if origin else None
        if not asset:continue
        ids=[sid for sid in record.get('segments',[]) if sid in segments and segments[sid][0]['type']=='audio']
        if not ids:continue
        unlocked(ids)
        for sid in ids:
            material=materials[segments[sid][1]['material_id']]
            if not material.get('path') or path_key(material['path'])!=path_key(extraction.get('path','')):
                raise ValueError('原声素材已被单独替换，请保留该编辑并在剪映核对，未覆盖原声')
            registered=next((a for a in project['assets'] if path_key(a['path'])==path_key(material['path'])),None)
            if (not registered or registered.get('sha256')!=extraction.get('file_sha256') or
                    file_hash(Path(material['path']))!=extraction.get('file_sha256')):
                raise ValueError('原声文件已被单独修改，未用源视频覆盖该声音')
        required=requirements[(asset['id'],extraction.get('source_stream'))]
        updated=extract_original(asset,dict(audio_stream=extraction.get('source_stream')),resources,cache,required)
        if updated is None:
            raise ValueError('替换后的素材没有原声音轨，无法更新现有人物原声；原时间线已保留')
        if updated['duration_us']<required:
            raise ValueError('替换后的原声不足以覆盖现有裁切，原时间线已保留')
        for sid in ids:
            material=materials[segments[sid][1]['material_id']]
            previous=duration_updates.get(material['id'])
            if previous and path_key(previous['path'])!=path_key(updated['path']):
                raise ValueError('共享原声素材需要不同替换文件，未覆盖其他声音')
            duration_updates[material['id']]=updated
        record['extraction']=updated
    for mid,updated in duration_updates.items():
        materials[mid].update(path=updated['path'],duration=updated['duration_us'])

    # Extraction can be slow. Do not commit if the selected source changed
    # again while decoding it; native revision checks also run at commit time.
    for asset in selected.values():
        actual=probe(Path(asset['path']))
        if any(actual.get(k)!=asset.get(k) for k in ('size','mtime_ns','sha256')):
            raise ValueError('更新期间源素材又发生变化，原时间线未改动，请重新读取后重试')
    return obj,records
