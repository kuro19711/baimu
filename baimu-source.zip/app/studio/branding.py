"""Display identity only. Storage keys and installation identity stay compatible."""

APP_NAME = '九州百慕'
