"""Detach one selected original stream without rewriting media or duplicating sound."""
import copy
from .core import timeline, uid, validate


def detach_audio(project, clip_id):
    next_project=copy.deepcopy(project)
    clips,_=timeline(next_project)
    placed=next((c for c in clips if c['id']==clip_id),None)
    if placed is None:
        raise ValueError('画面片段已不存在，请重新选择')
    clip=next(c for c in next_project['clips'] if c['id']==clip_id)
    if clip.get('audio_detached'):
        raise ValueError('这段画面的原声已分离，不会重复添加音频')
    asset=next(a for a in next_project['assets'] if a['id']==clip['asset_id'])
    streams=asset.get('audio_streams',[])
    chosen=clip.get('audio_stream')
    if not streams:
        raise ValueError('这段视频没有可分离的音轨')
    if chosen is None and len(streams)!=1:
        raise ValueError('视频含多条音轨，请先选择人物原声轨，再分离音频')
    selected=streams[0] if chosen is None else next((s for s in streams if s['index']==chosen),None)
    if selected is None:
        raise ValueError('所选音轨不存在，请重新选择')
    if not selected.get('duration_verified'):
        raise ValueError('所选音轨的真实时长未确认，暂不能安全分离')
    # Video trims can include silent leading/trailing padding. Only create the
    # audible overlap, retaining its original absolute position in the episode.
    source_in=max(clip['in'],selected.get('start',0))
    source_out=min(clip['in']+placed['duration'],selected['end'])
    if source_out<=source_in:
        raise ValueError('当前画面选段内没有所选音轨的有效声音')
    audio=dict(id=uid(),asset_id=asset['id'],role='dialogue',start=placed['start']+source_in-clip['in'],
               **{'in':source_in,'out':source_out},gain=clip.get('gain',0),audio_stream=selected['index'],loop=False,
               detached_from=clip_id)
    next_project['audios'].append(audio)
    clip['audio_detached']=True
    next_project['reviews']={}
    for cue in next_project['captions']:
        cue.pop('speech',None)
    validate(next_project)
    return next_project
