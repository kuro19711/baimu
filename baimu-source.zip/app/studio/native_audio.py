"""Separate native original-audio lanes with explicit video/audio grouping."""
import copy,hashlib,json,math,subprocess,uuid
from pathlib import Path
from .media import binary,media_info,stream_bounds
from .native_defaults import timerange as native_range


def run(args):
    r=subprocess.run(args,capture_output=True,timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if r.returncode:raise ValueError('原声无损提取失败：'+r.stderr.decode('utf-8','replace')[-1800:])
    return r.stdout.decode('utf-8','replace').strip()


def decoded_hash(path,stream,filters=None):
    return run([binary('ffmpeg'),'-v','error','-i',str(path),'-map',f'0:{stream}',
        *(['-af',filters] if filters else []),'-c:a','pcm_f32le','-f','hash','-hash','sha256','-'])


def audio_material(d,path,duration_us=None,name=None):
    material=d.AudioMaterial(str(path),material_name=name)
    # MediaInfo rounds some PCM/AAC lengths to milliseconds. The timeline uses
    # microseconds, so validate against the actual audio stream instead.
    if duration_us is None:
        info=media_info(path)
        stream=next(s for s in info['streams'] if s['codec_type']=='audio')
        duration_us=math.ceil(stream_bounds(stream,info)['duration']*1e6)
    material.duration=duration_us
    return material


def align_original(result,asset,stream,resources,required_end_us):
    info=media_info(result['path'])
    audio=next(s for s in info['streams'] if s['codec_type']=='audio')
    duration_us=math.ceil(stream_bounds(audio,info)['duration']*1e6)
    if 'start' in stream:
        start=stream['start']
    else:
        original=media_info(asset['path'])
        source=next(s for s in original['streams'] if s['index']==stream['index'])
        start=stream_bounds(source,original)['start']
    rate=int(audio['sample_rate']);delay=round(start*rate)
    if not delay and required_end_us<=duration_us:
        return dict(result,duration_us=duration_us)
    # Video and audio stream ends may differ. Keep every decoded sample and
    # use silence for missing head/tail samples; never stretch or shorten video.
    samples=math.ceil(required_end_us*rate/1e6)
    filters=f'adelay={delay}S:all=1,apad=whole_len={samples}'
    destination=resources/(Path(result['path']).stem+f'-aligned-{delay}-{samples}.wav')
    if not destination.exists():
        partial=destination.with_name(destination.stem+'-'+uuid.uuid4().hex+'.wav')
        try:
            run([binary('ffmpeg'),'-v','error','-nostdin','-n','-i',result['path'],
                '-map','0:a:0','-af',filters,'-c:a','pcm_f32le',str(partial)])
            if decoded_hash(asset['path'],stream['index'],filters)!=decoded_hash(partial,0):
                raise ValueError('原声补齐后解码样本不一致，停止交接：'+asset['name'])
            partial.replace(destination)
        finally:partial.unlink(missing_ok=True)
    info=media_info(destination)
    audio=next(s for s in info['streams'] if s['codec_type']=='audio')
    return dict(result,path=str(destination),duration_us=math.ceil(stream_bounds(audio,info)['duration']*1e6),
        source_decoded_pcm_sha256=result['decoded_pcm_sha256'],
        decoded_pcm_sha256=decoded_hash(destination,0).split('=')[-1],compressed_packets_copied=False,
        file_sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),
        alignment=dict(delay_samples=delay,minimum_samples=samples,sample_rate=rate,required_end_us=required_end_us))


def extract_original(asset,clip,resources,cache,required_end_us=0):
    streams=asset.get('audio_streams',[])
    if not asset.get('has_audio'):return None
    selected=clip.get('audio_stream')
    if selected is None:
        if len(streams)!=1:raise ValueError('原声选轨不明确，不能猜测提取')
        selected=streams[0]['index']
    stream=next((s for s in streams if s['index']==selected),None)
    if not stream:raise ValueError('原声选轨记录缺失')
    key=(asset['id'],selected)
    if key in cache:return align_original(cache[key],asset,stream,resources,required_end_us)
    # Remux known codecs. Compare decoded sample hashes, not file sizes.
    codec=stream.get('codec','');remux=codec in ('aac','alac','mp3')
    suffix='.mp3' if codec=='mp3' else '.m4a' if remux else '.wav'
    signature=asset.get('sha256','')[:12]
    destination=resources/f'original-{asset["id"]}-{selected}-{signature}{suffix}'
    args=[binary('ffmpeg'),'-v','error','-nostdin','-n','-i',asset['path'],'-map',f'0:{selected}','-vn',
          '-c:a','copy' if remux else 'pcm_f32le',str(destination)]
    if not destination.exists():run(args)
    source_hash=decoded_hash(asset['path'],selected);target_hash=decoded_hash(destination,0)
    if source_hash!=target_hash:raise ValueError('原声提取后解码样本不一致，停止交接：'+asset['name'])
    result=dict(path=str(destination),source_path=asset['path'],source_stream=selected,
        decoded_pcm_sha256=source_hash.split('=')[-1],compressed_packets_copied=remux,
        file_sha256=hashlib.sha256(destination.read_bytes()).hexdigest())
    cache[key]=result;return align_original(result,asset,stream,resources,required_end_us)


def append_linked_audio(script,d,project,assets,clips,resources,mapping):
    track=None;cache={};pairs=[]
    for clip in clips:
        if clip.get('audio_detached'):continue
        asset=assets[clip['asset_id']]
        start=round(clip['start']*1e6);length=round(clip['end']*1e6)-start
        extracted=extract_original(asset,clip,resources,cache,round(clip['in']*1e6)+length)
        if extracted is None:
            mapping.append(dict(source_kind='original',source_id=clip['id'],track_id=mapping_by_video(mapping,clip['id'])['track_id'],
                segments=[clip['id']],representation='silent_source_video',separate_visible_track=False))
            continue
        if track is None:track=script.append_track(d.TrackSpec(d.TrackType.audio,'人物原声（联动）'))
        audio=d.AudioSegment(audio_material(d,extracted['path'],extracted['duration_us'],asset['name']+' · 原声'),d.Timerange(start,length),
            source_timerange=d.Timerange(round(clip['in']*1e6),length),volume=10**(clip.get('gain',0)/20))
        script.add_segment(audio,track)
        record=dict(source_kind='original',source_id=clip['id'],track_id=track.track_id,segments=[audio.segment_id],
            representation='separate_audio_linked_by_native_group',separate_visible_track=True,extraction=extracted)
        mapping.append(record);pairs.append((clip['id'],audio.segment_id))
    return pairs


def mapping_by_video(mapping,cid):return next(r for r in mapping if r['source_kind']=='video' and r['source_id']==cid)


def apply_native_groups(content,pairs):
    segments={s['id']:s for t in content['tracks'] for s in t['segments']}
    groups=[]
    for i,(video,audio) in enumerate(pairs):
        gid=uuid.uuid4().hex
        segments[video]['group_id']=gid;segments[audio]['group_id']=gid
        # Explicit native group members preserve separately visible tracks.
        # material_draft is the model's empty composition cache, not flattened media.
        empty=dict(id=uuid.uuid4().hex,version=360000,new_version=content.get('new_version',''),
            config={},canvas_config={},materials={},keyframes={},platform={},last_modified_platform={},path='',
            uneven_animation_template_info={},smart_ads_info={},function_assistant_info={'fps':{}})
        material=dict(id=uuid.uuid4().hex,type='composition',name='',category_id='',category_name='',formula_id='',
            combination_id='',combination_type='none',precompile_combination=False,draft=empty,
            draft_file_path='',draft_cover_path='',draft_config_path='')
        groups.append(dict(id=gid,group_index=i,group_main_id=video,group_members=[video,audio],
            is_expand=True,name='画面与原声',material_draft=material))
    if groups:content['group_container']={'groups':groups}


def verify_linked_audio(project,content,mapping):
    records={r['source_id']:r for r in mapping if r['source_kind']=='original'}
    segments={s['id']:(t,s) for t in content['tracks'] for s in t['segments']}
    groups={g['id']:g for g in (content.get('group_container') or {}).get('groups',[])}
    materials={m['id']:m for m in content['materials'].get('audios',[])};assets={a['id']:a for a in project['assets']}
    checked=0
    for clip in project['clips']:
        if clip.get('audio_detached'):continue
        record=records[clip['id']];video=segments[clip['id']][1]
        if record['representation']=='silent_source_video':continue
        track,audio=segments[record['segments'][0]]
        extraction=record['extraction'];path=Path(extraction['path'])
        if Path(materials[audio['material_id']]['path']).resolve()!=path.resolve() or Path(extraction['source_path']).resolve()!=Path(assets[clip['asset_id']]['path']).resolve():
            raise ValueError('联动原声素材引用不一致')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=extraction['file_sha256']:
            raise ValueError('联动原声提取文件已改变')
        if video.get('volume',1)!=0 or audio.get('volume',1)!=10**(clip.get('gain',0)/20):raise ValueError('联动原声重复播放或音量不一致')
        if track['name']!='人物原声（联动）' or native_range(audio['target_timerange'])!=native_range(video['target_timerange']) or native_range(audio['source_timerange'])!=native_range(video['source_timerange']):
            raise ValueError('联动原声时间或轨道不一致')
        gid=video.get('group_id');group=groups.get(gid)
        if not group or audio.get('group_id')!=gid or set(group['group_members'])!={video['id'],audio['id']}:
            raise ValueError('原声与视频的原生分组关系丢失')
        checked+=1
    return checked
