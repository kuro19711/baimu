"""Align supplied subtitle lines to local ASR word timestamps, without editing projects."""
import math
import re
import unicodedata
from difflib import SequenceMatcher
from .core import uid

MAX_BYTES = 1024 * 1024
MAX_CHARACTERS = 20000


def normalized(text):
    return ''.join(c for c in unicodedata.normalize('NFKC', text).casefold() if c.isalnum())


def split_text(text, mode='lines'):
    if not isinstance(text, str) or len(text.encode('utf-8')) > MAX_BYTES:
        raise ValueError('字幕文字必须为不超过 1 MiB 的文本')
    if mode not in ('lines', 'sentences'):
        raise ValueError('请选择有效的分句方式')
    text = text.lstrip('\ufeff').replace('\r\n', '\n').replace('\r', '\n')
    if '\0' in text or '\ufffd' in text:
        raise ValueError('文本编码无效，请另存为 UTF-8 后重试')
    if mode == 'sentences':
        text = re.sub(r'''([。！？!?；;]+[”’」』"']*|\.(?=\s|$))''', r'\1\n', text)
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    if not lines or len(lines) > 10000:
        raise ValueError('请输入 1 至 10000 条字幕文字')
    if any(not normalized(line) for line in lines):
        raise ValueError('每条字幕需包含对白文字，不能只有标点或符号')
    if sum(len(normalized(line)) for line in lines) > MAX_CHARACTERS:
        raise ValueError('一次最多对齐 20000 个对白字符，请按分集输入')
    return lines


def align_text(text, words, mode='lines', job=None):
    lines = split_text(text, mode)
    script = [normalized(line) for line in lines]
    target = ''.join(script)
    heard, times = [], []
    previous = 0
    for word in words:
        value = normalized(word.get('text', ''))
        if not value:
            continue
        start, end = word.get('start'), word.get('end')
        if (not all(isinstance(t, (int, float)) and not isinstance(t, bool) and math.isfinite(t) for t in (start, end))
                or not 0 <= start < end <= 86400 or start < previous - 1e-6):
            raise ValueError('音频识别的逐词时间无效，请重新识别')
        previous = end
        # ASR timestamps are word boundaries. Divide a word only when a TXT line
        # boundary falls inside it; these estimates still require listening QA.
        heard.append(value)
        times.extend((start + (end-start)*i/len(value), start + (end-start)*(i+1)/len(value)) for i in range(len(value)))
    source = ''.join(heard)
    if not source:
        raise ValueError('未识别到有效对白，不覆盖现有字幕；请检查音轨和语音模型')
    if len(source) > MAX_CHARACTERS * 2:
        raise ValueError('音轨对白过长，请按分集对齐')
    if job and job.get('cancel_requested'):
        raise ValueError('任务已取消')
    anchors = {}
    for block in SequenceMatcher(None, target, source, autojunk=False).get_matching_blocks():
        for offset in range(block.size):
            anchors[block.a + offset] = block.b + offset
    if job and job.get('cancel_requested'):
        raise ValueError('任务已取消')
    cues, report, cursor = [], [], 0
    for index, (line, value) in enumerate(zip(lines, script)):
        matches = [anchors[i] for i in range(cursor, cursor+len(value)) if i in anchors]
        ratio = len(matches)/len(value)
        if not matches or ratio < .65:
            raise ValueError(f'第 {index+1} 条文字与音频对白匹配不足（{ratio:.0%}），未生成可应用字幕。请核对 TXT 是否为本集原语言对白、删除角色名和动作说明，或更换更准确的本地模型')
        start, end = times[matches[0]][0], times[matches[-1]][1]
        cues.append(dict(id=uid(), start=start, end=end, text=line, style={}))
        report.append(dict(line=index+1, coverage=round(ratio, 4)))
        cursor += len(value)
    return dict(captions=cues, alignment=dict(method='ASR_word_anchors', coverage=round(len(anchors)/len(target), 4), lines=report,
                notice='按最终音轨的本地识别逐词时间匹配 TXT 原文；词内边界为估计，漏字、同音字及低匹配句需试听校对。'),
                status='TXT 音频对齐草稿，保留输入原文；必须试听校对')
