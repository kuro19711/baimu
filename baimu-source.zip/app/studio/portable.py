"""Single-episode portable bundles. Never restore sender paths or overwrite projects."""
import contextlib,copy,hashlib,json,os,re,shutil,stat,threading,zipfile
from pathlib import Path,PurePosixPath
from .core import VERSION,VIDEO_EXT,AUDIO_EXT,new_project,uid,validate
from .media import probe
from .store import write_json

class PortableProjects:
    def __init__(self,store):
        self.store=store;self.lock=threading.Lock();self.active=0

    def busy(self):
        with self.lock:return self.active>0

    @contextlib.contextmanager
    def activity(self):
        with self.lock:self.active+=1
        try:yield
        finally:
            with self.lock:self.active-=1

    def owned(self,*parts):
        path=self.store.root.joinpath(*parts)
        if self.store.root not in path.resolve().parents:raise ValueError('工程包目录超出本机数据范围')
        current=self.store.root
        for part in path.relative_to(self.store.root).parts:
            current=current/part
            if os.path.lexists(current) and self.store.is_link(current):raise ValueError('工程包目录不可包含目录联接')
        return path

    def export(self,pid,revision):
        with self.activity():
            project=copy.deepcopy(self.store.get(pid))
            if project['revision']!=revision:raise ValueError('工程已变化，请保存后重新打包')
            bid=uid();target=self.owned('packages',bid+'.zip');target.parent.mkdir(exist_ok=True)
            partial=target.with_suffix('.partial')
            records=[]
            for asset in project['assets']:
                aid=asset['id']
                if not re.fullmatch('[a-f0-9]{32}',str(aid)):raise ValueError('素材ID无效')
                source=Path(asset['path']);ext=source.suffix.lower()
                if ext not in VIDEO_EXT|AUDIO_EXT or not source.is_file():raise ValueError('素材缺失，不能生成完整工程包：'+asset['name'])
                records.append(dict(path='media/'+aid+ext,source=source,asset_id=aid,expected=asset.get('sha256')))
            font_ids={dict(project['style'],**cue.get('style',{}))['font_id'] for cue in project['captions']}
            if project['style'].get('font_id'):font_ids.add(project['style']['font_id'])
            for fid in sorted(font_ids):
                font=self.store.fonts.get(fid);source=self.store.original_font_path(fid) if font else None
                if not source or not source.is_file():raise ValueError('工程字体缺失，请先选择有效字体')
                records.append(dict(path='fonts/'+fid+source.suffix.lower(),source=source,font_id=fid))
            if len(records)>500:raise ValueError('单集工程包最多包含500个素材与字体，请先整理素材库')
            required=sum(r['source'].stat().st_size for r in records)+64*1024*1024
            if required-64*1024*1024>32*1024**3:raise ValueError('单集工程包素材总量不能超过32GB')
            if shutil.disk_usage(target.parent).free<required:raise ValueError('磁盘空间不足，未开始打包')
            # Portable JSON contains no sender absolute media/font/script paths.
            for asset in project['assets']:
                asset['path']=next(r['path'] for r in records if r.get('asset_id')==asset['id'])
                asset.pop('source_relative_path',None)
            project['script']['source']='';project['reviews']={};project['renders']=[]
            try:
                with zipfile.ZipFile(partial,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as archive:
                    for record in records:
                        digest=hashlib.sha256();size=0
                        with record['source'].open('rb') as src,archive.open(record['path'],'w',force_zip64=True) as dst:
                            for block in iter(lambda:src.read(4*1024*1024),b''):dst.write(block);digest.update(block);size+=len(block)
                        if record.get('expected') and digest.hexdigest()!=record['expected']:raise ValueError('素材内容已变化，请确认更新素材后再打包')
                        record.update(size=size,sha256=digest.hexdigest())
                    manifest=dict(format='baimu-project',version=1,app_version=VERSION,project=project,
                                  files=[{k:v for k,v in r.items() if k not in ('source','expected')} for r in records])
                    archive.writestr('project.json',json.dumps(manifest,ensure_ascii=False,indent=2))
                os.replace(partial,target)
            except Exception:
                partial.unlink(missing_ok=True);raise
            return dict(id=bid,name=project['name'],file=target.name,size=target.stat().st_size,
                        note='包含当前单集工程、素材库和所需字体；不含历史版本、旧导出和外部剧本原文件。')

    def import_package(self,path,series=None):
        with self.activity():
            source=Path(str(path).strip().strip('"')).expanduser()
            if source.suffix.lower()!='.zip' or not source.is_file():raise ValueError('请选择本机的九州百慕工程ZIP包')
            stage=self.owned('imports','portable-'+uid());published=False
            try:
                with zipfile.ZipFile(source) as archive:
                    entries=archive.infolist();names=[e.filename for e in entries]
                    if len(entries)>501 or len(names)!=len(set(names)):raise ValueError('工程包文件数量过多或路径重复')
                    for entry in entries:
                        parts=PurePosixPath(entry.filename)
                        if (parts.is_absolute() or '..' in parts.parts or '\\' in entry.filename or ':' in entry.filename
                                or stat.S_ISLNK(entry.external_attr>>16) or entry.is_dir()):raise ValueError('工程包包含不安全路径')
                    info=archive.getinfo('project.json')
                    if info.file_size>8*1024*1024:raise ValueError('工程清单过大')
                    manifest=json.loads(archive.read(info));records=manifest['files'];original=manifest['project']
                    if manifest.get('format')!='baimu-project' or manifest.get('version')!=1 or not isinstance(records,list):raise ValueError('不是支持的九州百慕工程包')
                    if len(records)>500 or len({r['path'] for r in records})!=len(records):raise ValueError('素材清单重复或过多')
                    if set(names)!={'project.json',*(r['path'] for r in records)}:raise ValueError('工程包存在未登记文件')
                    ids={'asset_id':set(),'font_id':set()}
                    for r in records:
                        kind='asset_id' if 'asset_id' in r else 'font_id';rid=r[kind]
                        if not re.fullmatch('[a-f0-9]{32}',str(rid)) or rid in ids[kind]:raise ValueError('工程包素材或字体ID无效')
                        ids[kind].add(rid);ext=PurePosixPath(r['path']).suffix.lower()
                        allowed=VIDEO_EXT|AUDIO_EXT if kind=='asset_id' else {'.ttf','.otf'}
                        expected=('media/' if kind=='asset_id' else 'fonts/')+rid+ext
                        if r['path']!=expected or ext not in allowed:raise ValueError('工程包文件类型或名称无效')
                        if r['size']!=archive.getinfo(r['path']).file_size or r['size']<0:raise ValueError('工程包文件大小不符')
                        if not re.fullmatch('[a-f0-9]{64}',str(r.get('sha256',''))):raise ValueError('工程包缺少校验值')
                        if kind=='font_id' and r['size']>30*1024*1024:raise ValueError('字体不能超过30MB')
                    total=sum(r['size'] for r in records)
                    if total>32*1024**3 or shutil.disk_usage(self.store.root).free<total+64*1024**2:raise ValueError('工程包超过32GB或磁盘空间不足')
                    stage.mkdir(parents=True,exist_ok=False)
                    for r in records:
                        target=stage/r['path'];target.parent.mkdir(exist_ok=True)
                        digest=hashlib.sha256();written=0
                        with archive.open(r['path']) as src,target.open('xb') as dst:
                            for block in iter(lambda:src.read(4*1024*1024),b''):
                                written+=len(block)
                                if written>r['size']:raise ValueError('解压长度超过清单')
                                dst.write(block);digest.update(block)
                        if written!=r['size'] or digest.hexdigest()!=r['sha256']:raise ValueError('工程包校验失败，未建立工程')
                # Re-probe bytes; sender metadata and paths are never used to open media.
                assets=[]
                originals={a['id']:a for a in original['assets']}
                if set(originals)!=ids['asset_id'] or len(originals)!=len(original['assets']):raise ValueError('素材引用与清单不一致')
                for r in records:
                    if 'asset_id' not in r:continue
                    asset=probe(stage/r['path']);asset['id']=r['asset_id'];asset['name']=Path(str(originals[asset['id']].get('name','素材'))).name
                    assets.append(asset)
                project=new_project(str(original['name'])[:150]+'（副本）' if len(str(original['name']))<146 else str(original['name'])[:146]+'副本')
                for key in ['width','height','fps','clips','audios','captions','masks','style','script','protected_lines','language']:
                    if key in original:project[key]=copy.deepcopy(original[key])
                if not isinstance(project['script'],dict):raise ValueError('剧本数据格式无效')
                project['script']['source']='';project['assets']=assets
                project['series']=self.store.series_name(original.get('series','') if series is None else series)
                styles=[project['style']]+[c.setdefault('style',{}) for c in project['captions']]
                needed={s['font_id'] for s in styles if s.get('font_id')}
                if not needed<=ids['font_id']:raise ValueError('工程包缺少引用字体')
                validate(project)
                font_map={}
                for r in records:
                    if 'font_id' in r:font_map[r['font_id']]=self.store.import_font(stage/r['path'])['id']
                for style in styles:
                    if style.get('font_id'):style['font_id']=font_map[style['font_id']]
                for cue in project['captions']:cue.pop('speech',None)
                validate(project)
                with self.store.lock:
                    destination=self.store.path(project['id'])
                    if destination.exists():raise ValueError('新工程ID冲突，未覆盖工程')
                    write_json(destination,project);published=True
                return self.store.maybe_native(project)
            except (KeyError,TypeError,zipfile.BadZipFile,AttributeError) as exc:
                raise ValueError('工程包结构损坏或不是九州百慕工程包') from exc
            finally:
                if not published and stage.exists() and stage.parent==self.owned('imports') and stage.name.startswith('portable-'):
                    shutil.rmtree(stage)
