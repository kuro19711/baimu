"""Review findings, human dispositions and frozen repair batches; no media edits."""
from __future__ import annotations
import copy
import math
import re
import time
from pathlib import Path

from .core import uid
from .media import probe
from .review_rules import fingerprint
from .store import read_json, write_json


def text(value, label, limit=8000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(label+'不能为空或过长')
    return value.strip()


def artifact(value):
    if not isinstance(value, dict): raise ValueError('请提供实际成片的 path 与 sha256')
    path = Path(text(value.get('path'), '成片路径')).expanduser().resolve()
    expected = value.get('sha256')
    if not isinstance(expected, str) or not re.fullmatch('[a-f0-9]{64}', expected):
        raise ValueError('成片 SHA-256 无效')
    if not path.is_file(): raise ValueError('实际成片文件不存在')
    media = probe(path)
    if media['kind']!='video': raise ValueError('审核对象必须是实际视频')
    if media['sha256'] != expected: raise ValueError('成片内容已变化，请重新检查实际文件')
    return dict(path=str(path), sha256=media['sha256'], duration=media['duration'], fps=media['fps'])


def submission(value):
    keys = ['artifact', 'coverage', 'findings']
    if 'checks' in value:
        keys.append('checks')
    return {key: value.get(key) for key in keys}


def checked_results(rows, allowed, findings):
    if not isinstance(rows, list) or len(rows) > 100:
        raise ValueError('审核项结果必须是最多 100 项的数组')
    result, seen = [], set()
    for row in rows:
        if not isinstance(row, dict) or row.get('rule_id') not in allowed or row['rule_id'] in seen:
            raise ValueError('审核项结果包含未知、未选中或重复项目')
        seen.add(row['rule_id'])
        status = row.get('status')
        if status not in ('pass', 'issues', 'needs_review', 'not_checked'):
            raise ValueError('审核项结果状态无效')
        hits = [f for f in findings if f['rule_id'] == row['rule_id']]
        if status == 'pass' and hits:
            raise ValueError('存在具体问题的审核项不能标为无问题')
        if status == 'issues' and not hits:
            raise ValueError('有问题的审核项需要关联具体问题')
        result.append(dict(rule_id=row['rule_id'], status=status,
                           evidence=text(row.get('evidence'), '审核项检查说明', 4000)))
    return result


class ReviewWorkflow:
    def __init__(self, store, rules):
        self.store, self.rules = store, rules

    def path(self, pid):
        self.store.path(pid)
        return self.store.root/'review/workflows'/(pid+'.json')

    def read(self, pid):
        self.store.get(pid)
        value = read_json(self.path(pid), dict(requests=[], reports=[], batches=[]))
        if not isinstance(value, dict) or not all(isinstance(value.get(k), list) for k in ('requests','reports','batches')):
            raise ValueError('审核结果记录损坏；保留原文件，请检查')
        return value

    def context(self, pid):
        with self.store.lock:
            state, current = self.read(pid), self.rules.context(pid)
            report = copy.deepcopy(state['reports'][-1]) if state['reports'] else None
            active = [b for b in state['batches'] if b['status'] in ('queued','running')]
            if report:
                report['stale'] = not self.matches(report, current)
                for finding in report['findings']:
                    finding['status'] = 'pending' if finding['selected'] else 'kept'
                    for batch in state['batches']:
                        if finding['selected'] and batch['report_id']==report['id'] and finding['id'] in batch['outcomes']:
                            outcome = batch['outcomes'][finding['id']]['status']
                            if batch['status']!='cancelled': finding['status']=outcome
                            elif outcome!='pending':
                                finding['status']='interrupted' if outcome=='working' else outcome
                    finding['locked'] = any(b['report_id']==report['id'] for b in active)
            results = []
            checks = {r['rule_id']: r for r in (report or {}).get('checks', [])}
            waiting = any(r['status'] == 'waiting' for r in state['requests'])
            for rule in current['sections']:
                hits = [f for f in (report or {}).get('findings', []) if f['rule_id'] == rule['id']]
                explicit = checks.get(rule['id'])
                status = explicit['status'] if explicit else ('issues' if hits else 'not_checked')
                if not rule['selected']:
                    status = 'not_selected'
                elif (report or {}).get('stale'):
                    status = 'outdated'
                elif waiting:
                    status = 'pending'
                results.append(dict(rule_id=rule['id'], title=rule['title'], body=rule['body'],
                                    status=status, finding_count=len(hits),
                                    evidence=explicit['evidence'] if explicit else '',
                                    selected=rule['selected']))
            active_batch = copy.deepcopy(active[-1]) if active else None
            if active_batch:
                active_batch['stale'] = (any(active_batch[k] != current[k] for k in ('rules_revision', 'scope_revision'))
                                         or active_batch['expected_project_revision'] != current['project_revision'])
            return dict(project_id=pid, workflow_revision=fingerprint(state), report=report,
                        requests=state['requests'][-10:], batches=state['batches'][-10:],
                        review_results=results, active_batch=active_batch,
                        notice='审核栏显示逐项检查结果，修改栏编辑最终修改意见；按清单修改固定所选问题与最终意见，等待 Codex 执行。')

    @staticmethod
    def matches(snapshot, current):
        return all(snapshot[k]==current[k] for k in ('project_revision','rules_revision','scope_revision'))

    @staticmethod
    def snapshot(current):
        return {k:copy.deepcopy(current[k]) for k in ('project_revision','rules_revision','scope_revision',
                  'selected_ids','selected_review_markdown','repair_skill','sections','common')}

    def mutate(self, pid, body):
        with self.store.lock:
            state = self.read(pid)
            if not isinstance(body, dict): raise ValueError('审核操作应为对象')
            action = body.get('action')
            # Idempotency protects repeated delivery without restoring machine marks.
            if action in ('request_review','create_repair'):
                key = text(body.get('request_id'), '请求 ID', 120)
                rows = state['requests'] if action=='request_review' else state['batches']
                previous = next((r for r in rows if r['request_id']==key), None)
                if previous:
                    if action=='create_repair' and previous['report_id']!=body.get('report_id'):
                        raise ValueError('请求 ID 已用于其它问题单')
                    return self.context(pid)
            if action=='submit_report':
                previous = next((r for r in state['reports'] if r['request_id']==body.get('request_id')), None)
                if previous:
                    if previous['submission_hash']!=fingerprint(submission(body)):
                        raise ValueError('该初审请求已提交不同结果，请创建新的审核请求')
                    return self.context(pid)
            if body.get('workflow_revision')!=fingerprint(state):
                raise ValueError('问题清单已变化，请刷新后重试；不会覆盖人工选择')
            current = self.rules.context(pid)
            if action=='request_review':
                if not current['selected_ids']: raise ValueError('请先选择检查范围')
                if any(b['status'] in ('queued','running') for b in state['batches']):
                    raise ValueError('本轮修改尚未结束，请先完成或取消')
                # A new explicit audit request supersedes unconsumed requests.
                for request in state['requests']:
                    if request['status']=='waiting': request['status']='superseded'
                state['requests'].append(dict(self.snapshot(current), id=uid(), request_id=key,
                                              created=time.time(), status='waiting'))
            elif action=='submit_report':
                request = next((r for r in state['requests'] if r['id']==body.get('request_id')), None)
                if not request or request['status']!='waiting': raise ValueError('没有对应的待执行初审请求')
                if not self.matches(request,current): raise ValueError('工程、规则或检查范围已变化，请重新发起审核')
                source = artifact(body.get('artifact'))
                coverage = text(body.get('coverage'), '检查覆盖说明')
                rows = body.get('findings')
                if not isinstance(rows,list) or len(rows)>500: raise ValueError('一次问题单最多包含 500 项')
                allowed = {s['id']:s for s in current['sections'] if s['selected']}
                findings, ids = [], set()
                for row in rows:
                    if not isinstance(row,dict) or row.get('rule_id') not in allowed: raise ValueError('问题必须关联本次勾选的审核项')
                    start,end = row.get('start'),row.get('end')
                    if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) for x in (start,end)) or not 0<=start<end<=source['duration']+.001:
                        raise ValueError('问题起止时间无效（单位：秒）')
                    identity = fingerprint([source['sha256'],row['rule_id'],round(start*source['fps']),round(end*source['fps'])])[:32]
                    if identity in ids: raise ValueError('同规则、同时间段的问题请合并描述')
                    ids.add(identity)
                    item = dict(id=identity,rule_id=row['rule_id'],category=allowed[row['rule_id']]['title'],
                                start=start,end=end,title=text(row.get('title'),'问题描述',300),
                                evidence=text(row.get('evidence'),'观测依据'),plan=text(row.get('plan'),'拟处理方式'),
                                certainty=text(row.get('certainty'),'确认程度',100), selected=True, human_note='', plan_source='machine')
                    for old in reversed(state['reports']):
                        if self.matches(old,current) and old['artifact']['sha256']==source['sha256']:
                            prior = next((f for f in old['findings'] if f['id']==identity),None)
                            if prior:
                                item['selected']=prior['selected'];item['human_note']=prior['human_note']
                                if prior.get('plan_source') == 'human':
                                    item['plan'] = prior['plan'];item['plan_source'] = 'human'
                                break
                    findings.append(item)
                findings.sort(key=lambda f:(f['start'],f['end'],f['id']))
                checks = checked_results(body.get('checks', []), allowed, findings)
                state['reports'].append(dict(self.snapshot(current),id=uid(),request_id=request['id'],
                    artifact=source,coverage=coverage,created=time.time(),findings=findings,checks=checks,
                    submission_hash=fingerprint(submission(body))))
                request['status']='complete'
            elif action=='mark':
                report = self._report(state,body)
                if any(b['report_id']==report['id'] and b['status'] in ('queued','running') for b in state['batches']):
                    raise ValueError('本轮清单已固定；需先取消任务才能重新选择')
                row = next((f for f in report['findings'] if f['id']==body.get('finding_id')),None)
                if not row or not isinstance(body.get('selected'),bool): raise ValueError('标注项或选择无效')
                note = body.get('human_note',row['human_note'])
                if not isinstance(note,str) or len(note)>2000: raise ValueError('保留理由最多 2000 字')
                if 'plan' in body:
                    row['plan'] = text(body['plan'], '最终修改意见')
                    row['plan_source'] = 'human'
                row['selected']=body['selected'];row['human_note']=note
            elif action=='create_repair':
                report = self._report(state,body)
                if any(b['status'] in ('queued','running') for b in state['batches']): raise ValueError('已有待执行或执行中的修改任务')
                if not self.matches(report,current): raise ValueError('工程、规则或范围已变化，请重新审核后再修改')
                if current['needs_clarification']: raise ValueError('有新增或修改的规则尚未确认理解，请先核对')
                artifact(report['artifact'])
                chosen = [copy.deepcopy(f) for f in report['findings'] if f['selected']]
                completed = {fid for b in state['batches'] if b['report_id']==report['id']
                             for fid,result in b['outcomes'].items() if result['status']=='resolved'}
                chosen = [f for f in chosen if f['id'] not in completed]
                if not chosen: raise ValueError('没有待修改的标注')
                state['batches'].append(dict(self.snapshot(current),id=uid(),request_id=key,report_id=report['id'],
                    artifact=report['artifact'],created=time.time(),status='queued',findings=chosen,
                    expected_project_revision=current['project_revision'],
                    outcomes={f['id']:dict(status='pending',note='',verification=None) for f in chosen}))
            elif action=='cancel_repair':
                batch = self._batch(state,body)
                if batch['status'] not in ('queued','running'): raise ValueError('任务已经结束')
                batch['status']='cancelled';batch['cancelled_at']=time.time()
            elif action=='repair_progress':
                batch = self._batch(state,body)
                if batch['status'] not in ('queued','running'): raise ValueError('任务已结束或被取消，不能继续回写')
                if any(batch[k]!=current[k] for k in ('rules_revision','scope_revision')):
                    raise ValueError('规则或范围已变化，请停止本轮修改并重新核对')
                item = batch['outcomes'].get(body.get('finding_id'))
                if item is None: raise ValueError('该问题不在本轮固定清单中')
                status = body.get('status')
                transitions={'pending':('working','unresolved'),'working':('awaiting_verification','unresolved'),
                             'awaiting_verification':('resolved','unresolved')}
                if status not in transitions.get(item['status'],()): raise ValueError('状态转换无效；执行修改后必须复审才能标已解决')
                if body.get('project_revision')!=current['project_revision']: raise ValueError('工程版本不匹配，请重新读取')
                if status!='awaiting_verification' and current['project_revision']!=batch['expected_project_revision']:
                    raise ValueError('工程在任务外发生变化，请停止并重新核对')
                note = text(body.get('note'), '处理说明')
                verification = None
                if status=='resolved':
                    verification = artifact(body.get('verification'))
                    if verification['sha256']==batch['artifact']['sha256']:
                        raise ValueError('复审仍是初审原片；请提供本轮修改后新导出的实际成片')
                    verification['note']=text(body['verification'].get('note'),'实际复审证据')
                if status=='awaiting_verification': batch['expected_project_revision']=current['project_revision']
                item.update(status=status,note=note,verification=verification,updated=time.time())
                batch['status']='complete' if all(v['status'] in ('resolved','unresolved') for v in batch['outcomes'].values()) else 'running'
            else:
                raise ValueError('未知审核操作')
            write_json(self.path(pid),state)
            return self.context(pid)

    @staticmethod
    def _report(state,body):
        if not state['reports'] or state['reports'][-1]['id']!=body.get('report_id'):
            raise ValueError('请操作当前问题单')
        return state['reports'][-1]

    @staticmethod
    def _batch(state,body):
        batch=next((b for b in state['batches'] if b['id']==body.get('batch_id')),None)
        if not batch: raise ValueError('修改任务不存在')
        return batch
