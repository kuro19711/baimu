"""Change explicit picture/original pairs without touching media or timing."""
import copy
from .native_audio import apply_native_groups


def prepare(content,before,after):
    obj=copy.deepcopy(content)
    previous={a['id']:a for a in before['audios']}
    videos={c['id']:c for c in after['clips']}
    segments={s['id']:(t,s) for t in obj['tracks'] for s in t['segments']}
    groups=(obj.get('group_container') or {}).get('groups',[])
    additions=[]
    for audio in after['audios']:
        aid=audio['id']
        if aid not in previous:continue
        old=previous[aid].get('linked_video_id',before.get('native_links',{}).get(aid,{}).get('linked_video_id'))
        new=audio.get('linked_video_id',old)
        if old==new:continue
        if new is not None and (not isinstance(new,str) or new not in videos or audio['role']!='dialogue' or not videos[new].get('audio_detached')):
            raise ValueError('原声联动目标无效')
        for sid in (aid,old,new):
            if sid and sid in segments and segments[sid][0].get('attribute',0)&4:
                raise ValueError('画面或原声轨道已锁定，请先解锁再解除联动')
        if old:
            group=next((g for g in groups if set(g.get('group_members',[]))=={aid,old} and len(g['group_members'])==2),None)
            if group is None:raise ValueError('联动关系已改变，请重新读取工程')
            obj.setdefault('baimu',{}).setdefault('unlinked_audio_groups',{})[aid]=copy.deepcopy(group)
            groups.remove(group)
            for sid in (aid,old):segments[sid][1].pop('group_id',None)
        if new:additions.append((new,aid))
    return obj,additions


def restore(content,pairs):
    """Undo can restore the pair after restoring its two independent segments."""
    if not pairs:return
    segments={s['id']:s for t in content['tracks'] for s in t['segments']}
    existing=content.setdefault('group_container',{}).setdefault('groups',[])
    occupied={sid for group in existing for sid in group.get('group_members',[])}
    for video,audio in pairs:
        if video not in segments or audio not in segments or video in occupied or audio in occupied:
            raise ValueError('片段已不存在或已有联动，无法恢复原声联动')
        occupied.update((video,audio))
    archived=(content.get('baimu') or {}).get('unlinked_audio_groups',{})
    for video,audio in pairs:
        saved=archived.get(audio)
        if saved and set(saved.get('group_members',[]))=={video,audio} and all(g['id']!=saved['id'] for g in existing):
            group=copy.deepcopy(saved)
            for sid in (video,audio):segments[sid]['group_id']=group['id']
        else:
            scratch=dict(tracks=content['tracks'],new_version=content.get('new_version',''))
            apply_native_groups(scratch,[(video,audio)])
            group=scratch['group_container']['groups'][0]
            group['group_index']=max((g.get('group_index',-1) for g in existing),default=-1)+1
        existing.append(group)


def media_view(project,key):
    value=project.get(key)
    if key=='audios':return [{k:v for k,v in a.items() if k!='linked_video_id'} for a in value]
    return value
