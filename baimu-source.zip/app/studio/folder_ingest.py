"""Resumable browser-folder copies, exclusively into this local app's data folder."""
from __future__ import annotations
import contextlib
import copy
import hashlib
import json
import os
import re
import shutil
import threading
import time
from pathlib import Path

from .core import AUDIO_EXT, VIDEO_EXT, uid
from .media import probe
from .store import read_json, write_json

MAX_CHUNK = 8 * 1024 * 1024
RESERVE_BYTES = 64 * 1024 * 1024


class FolderDropError(ValueError):
    def __init__(self,message,status=400,**details):
        super().__init__(message)
        self.status=status
        self.payload=dict(error=message,**details)


class FolderIngest:
    def __init__(self,store):
        self.store=store
        self.root=store.root/'imports'
        self._lock=threading.RLock()
        self._sessions={}
        self._cancel={}
        self._active=0

    def busy(self):
        with self._lock:return self._active>0

    @contextlib.contextmanager
    def activity(self):
        with self._lock:self._active+=1
        try:yield
        finally:
            with self._lock:self._active-=1

    def lock(self,sid):
        if not isinstance(sid,str) or not re.fullmatch('[a-f0-9]{32}',sid):
            raise FolderDropError('导入会话ID无效')
        with self._lock:
            self._cancel.setdefault(sid,threading.Event())
            return self._sessions.setdefault(sid,threading.RLock())

    def safe_path(self,*parts):
        path=self.root.joinpath(*parts)
        if self.store.root not in path.resolve().parents:
            raise FolderDropError('导入文件路径超出本机应用数据目录')
        current=self.store.root
        for part in path.relative_to(self.store.root).parts:
            current=current/part
            if os.path.lexists(current) and self.store.is_link(current):
                raise FolderDropError('导入缓存包含符号链接或目录联接，已拒绝写入')
        return path

    def load(self,sid):
        self.lock(sid)
        path=self.safe_path(sid,'session.json')
        try:session=read_json(path)
        except (ValueError,OSError) as exc:raise FolderDropError('导入记录不可读取，未覆盖任何数据：'+str(exc))
        if not isinstance(session,dict) or session.get('id')!=sid or not isinstance(session.get('files'),list) or not isinstance(session.get('episodes'),list):
            raise FolderDropError('导入会话不存在或结构损坏')
        if len(session['files'])>10000 or len(session['episodes'])>30:
            raise FolderDropError('导入记录超过安全限额')
        for item in session['files']:
            if not isinstance(item,dict) or not re.fullmatch('[a-f0-9]{32}',str(item.get('id',''))):
                raise FolderDropError('导入文件记录无效')
            if not isinstance(item.get('size'),int) or not isinstance(item.get('offset'),int) or not 0<=item['offset']<=item['size']:
                raise FolderDropError('导入断点记录无效')
        file_ids={item['id'] for item in session['files']}
        if len(file_ids)!=len(session['files']):raise FolderDropError('导入文件记录重复')
        if session.get('status') not in ('uploading','committing','failed','cancelled','complete'):
            raise FolderDropError('导入状态记录无效')
        if session.get('mode','episodes') not in ('episodes','project'):
            raise FolderDropError('导入目标记录无效')
        if session.get('mode')=='project':
            target=session.get('target')
            if (not isinstance(target,dict) or not re.fullmatch('[a-f0-9]{32}',str(target.get('project_id','')))
                    or not isinstance(target.get('append'),bool)):
                raise FolderDropError('当前工程素材导入目标损坏，未覆盖任何工程')
        for episode in session['episodes']:
            if (not isinstance(episode,dict) or not re.fullmatch('[a-f0-9]{32}',str(episode.get('project_id','')))
                or not isinstance(episode.get('name'),str) or not isinstance(episode.get('file_ids'),list)
                or not episode['file_ids'] or any(not isinstance(fid,str) or fid not in file_ids for fid in episode['file_ids'])):
                raise FolderDropError('分集导入记录损坏，未创建或覆盖任何工程')
        return session

    def persist(self,session):
        session['updated']=time.time()
        try:write_json(self.safe_path(session['id'],'session.json'),session)
        except OSError as exc:raise FolderDropError('无法保存本机导入断点，请检查磁盘空间或写入权限：'+str(exc),507)

    def file_path(self,session,item):
        ext=Path(item['relative_path']).suffix.lower()
        if ext not in VIDEO_EXT|AUDIO_EXT:raise FolderDropError('导入文件格式无效')
        # User-supplied relative paths are never used as writable filesystem paths.
        return self.safe_path(session['id'],'media',item['id']+ext)

    @staticmethod
    def preview(files,roots=None,allow_audio_only=False):
        from .episode_folders import preview_episode_folders
        return preview_episode_folders(files,roots,allow_audio_only)

    def budget(self,remaining):
        free=shutil.disk_usage(self.store.root).free
        if remaining+RESERVE_BYTES>free:
            raise FolderDropError('本机磁盘空间不足，未开始复制；请腾出空间后重试',507,required_bytes=remaining+RESERVE_BYTES,free_bytes=free)

    def result_rows(self,session):
        rows=[]
        for episode in session['episodes']:
            if episode.get('state')!='complete':continue
            try:
                project=self.store.get(episode['project_id'],include_archived=True)
                archived=bool(project.get('archived'))
                state=('已在回收站，请明确恢复' if archived else
                       '已添加到当前工程' if session.get('mode')=='project' else '已导入，保留当前编辑')
                rows.append(dict(id=project['id'],name=project['name'],series=project.get('series',''),archived=archived,state=state))
            except (ValueError,OSError) as exc:
                rows.append(dict(id=episode['project_id'],name=episode['name'],unavailable=True,state=str(exc)))
        return rows

    def public(self,session):
        result={key:copy.deepcopy(value) for key,value in session.items() if key not in ('fingerprint',)}
        result['max_chunk_size']=MAX_CHUNK
        result['total_size']=sum(f['size'] for f in session['files'])
        result['copied_size']=sum(f['offset'] for f in session['files'])
        result['results']=self.result_rows(session)
        return result

    def start(self,files,roots,selected,confirmed=False,series=None,target_project_id=None,append=True):
        if confirmed is not True:raise FolderDropError('请先明确选择要添加的素材')
        plan=self.preview(files,roots,target_project_id is not None)
        selection_limit=1 if target_project_id is not None else 30
        if not isinstance(selected,list) or not selected or len(selected)>selection_limit or not all(isinstance(x,str) for x in selected) or len(set(selected))!=len(selected):
            if target_project_id is not None and isinstance(selected,list) and len(selected)>1:
                raise FolderDropError('向当前分集添加文件夹时只能选择一个素材分组，不能把不同集素材合并到这一集')
            raise FolderDropError('请选择有效且不重复的素材分组')
        available={e['id']:e for e in plan['episodes']}
        if any(key not in available for key in selected):raise FolderDropError('所选分集不在重新校验的目录名单中')
        selected=sorted(selected)
        target=None
        if target_project_id is not None:
            if not isinstance(target_project_id,str) or not re.fullmatch('[a-f0-9]{32}',target_project_id):
                raise FolderDropError('目标工程无效，请重新打开工程后添加素材')
            if not isinstance(append,bool):raise FolderDropError('素材追加方式无效')
            project=self.store.get(target_project_id)
            target=dict(project_id=project['id'],append=append,name=project['name'])
        effective_series={key:self.store.series_name(series if series is not None else available[key].get('series','')) for key in selected}
        selected_files={fid for key in selected for fid in available[key]['file_ids']}
        normalized=sorted([f for f in plan['normalized_files'] if f['id'] in selected_files],key=lambda f:f['relative_path'])
        if target and len(normalized)>300:raise FolderDropError('一次最多添加300个素材，请分批选择')
        target_key={k:target[k] for k in ('project_id','append')} if target else None
        fingerprint=hashlib.sha256(json.dumps(dict(selected=selected,series=effective_series,target=target_key,files=[{k:f.get(k) for k in ('relative_path','size','last_modified')} for f in normalized]),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()
        sid=fingerprint[:32]
        with self.activity(),self.lock(sid):
            existing=self.safe_path(sid,'session.json')
            if existing.exists():
                session=self.load(sid)
                if session.get('fingerprint')!=fingerprint:raise FolderDropError('导入标识冲突，原会话未改动')
                if session['status']=='complete':
                    result=self.public(session)
                    if session.get('mode')=='project':
                        result.update(existing=True,notice='这些素材已经添加到当前工程，没有重复建立镜头或覆盖编辑。')
                    else:
                        result.update(existing=True,requires_reuse_confirmation=True,notice='只有分组、文件夹名、文件名、大小和修改时间一致；本次未重读新文件内容，也未重新进行SHA校验。仅可确认打开已有工程，不会覆盖已有编辑。素材实际改变时请使用确认更新素材流程。')
                    return result
                # Recover interrupted partial writes to the last durable offset.
                for item in session['files']:
                    path=self.file_path(session,item)
                    actual=path.stat().st_size if path.exists() else 0
                    if actual<item['offset']:
                        item.update(offset=actual,sha256=None,state='pending')
                self.budget(sum(f['size']-f['offset'] for f in session['files']))
                session.update(status='uploading',error=None)
                self._cancel[sid].clear();self.persist(session)
                result=self.public(session)
                result['resume_warning']='继续本机断点复制仅比较路径、大小和修改时间，请确保选择的仍是原始文件；本次未验证新文件内容。若换了素材，不要继续旧断点，请先取消并使用不同目录名称重新导入。'
                return result
            self.budget(sum(f['size'] for f in normalized))
            copied_files=[dict(f,offset=0,sha256=None,state='pending') for f in normalized]
            if target:
                episodes=[dict(id='target',project_id=target['project_id'],name=target['name'],series=project.get('series',''),
                               file_ids=[f['id'] for f in normalized],state='pending')]
            else:
                episodes=[]
                for episode in plan['episodes']:
                    if episode['id'] not in selected:continue
                    item=copy.deepcopy(episode)
                    item.update(project_id=uid(),state='pending',series=effective_series[item['id']])
                    episodes.append(item)
            session=dict(id=sid,fingerprint=fingerprint,status='uploading',created=time.time(),files=copied_files,episodes=episodes,
                         roots=plan.get('roots',roots),warnings=plan.get('warnings',[]),mode='project' if target else 'episodes')
            if target:session['target']=target
            self.safe_path(sid,'media').mkdir(parents=True,exist_ok=True)
            self.persist(session)
            return self.public(session)

    def status(self,sid):
        with self.lock(sid):return self.public(self.load(sid))

    def put(self,sid,fid,offset,length,stream):
        if not isinstance(length,int) or not 0<length<=MAX_CHUNK:
            raise FolderDropError('每个复制分片必须为1至8MiB',413)
        if not isinstance(offset,int) or isinstance(offset,bool) or offset<0:
            raise FolderDropError('复制偏移量无效')
        with self.activity(),self.lock(sid):
            session=self.load(sid)
            if session['status'] not in ('uploading','failed'):
                raise FolderDropError('会话当前不能继续复制，请重新选择原文件夹恢复或查看已有工程',409)
            item=next((f for f in session['files'] if f['id']==fid),None)
            if item is None:raise FolderDropError('文件不在本次已确认的分集名单中')
            if offset!=item['offset']:raise FolderDropError('复制断点已变化，请读取会话状态再继续',409,expected_offset=item['offset'])
            if offset+length>item['size']:raise FolderDropError('分片超出声明的文件大小')
            self.budget(sum(f['size']-f['offset'] for f in session['files']))
            path=self.file_path(session,item)
            if not path.parent.is_dir():raise FolderDropError('导入目录丢失，请重新选择原文件夹恢复')
            actual=path.stat().st_size if path.exists() else 0
            if actual<offset:raise FolderDropError('本机复制缓存缺失，请重新开始此导入以恢复断点',409)
            try:
                with path.open('r+b' if path.exists() else 'w+b') as destination:
                    destination.truncate(offset);destination.seek(offset)
                    remaining=length
                    while remaining:
                        if self._cancel[sid].is_set():raise FolderDropError('复制已取消；源文件未改动',409)
                        block=stream.read(min(128*1024,remaining))
                        if not block:raise FolderDropError('分片没有完整收到，请从已保存断点重试',409,expected_offset=offset)
                        destination.write(block);remaining-=len(block)
                    destination.flush();os.fsync(destination.fileno())
            except OSError as exc:raise FolderDropError('本机复制失败，源文件未改动：'+str(exc),507)
            item.update(offset=offset+length,state='copied' if offset+length==item['size'] else 'uploading',sha256=None)
            session.update(status='uploading',error=None);self.persist(session)
            return dict(session_id=sid,file=copy.deepcopy(item))

    def cancel(self,sid):
        lock=self.lock(sid)
        self._cancel[sid].set()
        with lock:
            session=self.load(sid)
            if session['status']!='complete':session['status']='cancelled';self.persist(session)
            result=self.public(session);result['notice']='已暂停本机复制；源文件、已复制缓存和已建立的工程均未删除。重新拖入同一目录可继续。'
            return result

    def commit(self,sid):
        with self.activity(),self.lock(sid):
            session=self.load(sid)
            if session['status']=='complete':return self.public(session)
            if session['status']=='cancelled':raise FolderDropError('会话已取消，请先重新拖入原文件夹恢复',409)
            if any(f['offset']!=f['size'] for f in session['files']):
                raise FolderDropError('所选媒体尚未完整复制，未建立空工程',409)
            session.update(status='committing',error=None);self.persist(session)
            try:
                for item in session['files']:
                    path=self.file_path(session,item)
                    if not path.is_file() or path.stat().st_size!=item['size']:raise FolderDropError('本机媒体复制不完整，请恢复上传：'+item['relative_path'])
                    digest=hashlib.sha256()
                    with path.open('rb') as source:
                        while block:=source.read(4*1024*1024):
                            if self._cancel[sid].is_set():raise FolderDropError('复制验证已取消',409)
                            digest.update(block)
                    item.update(sha256=digest.hexdigest(),state='verified')
                self.persist(session)
                by_id={item['id']:item for item in session['files']}
                if session.get('mode')=='project':
                    episode=session['episodes'][0]
                    assets=[]
                    for fid in episode['file_ids']:
                        item=by_id[fid]
                        asset=probe(self.file_path(session,item))
                        if asset.get('sha256')!=item['sha256']:raise FolderDropError('复制缓存验证期间发生改变，未导入：'+item['relative_path'])
                        asset['name']=Path(item['relative_path']).name
                        asset['source_relative_path']=item['relative_path']
                        assets.append(asset)
                    if self._cancel[sid].is_set():raise FolderDropError('导入已取消',409)
                    self.store.import_prepared(session['target']['project_id'],assets,session['target']['append'])
                    episode['state']='complete';self.persist(session)
                else:
                    for episode in session['episodes']:
                        if self._cancel[sid].is_set():raise FolderDropError('导入已取消，已建立的工程和源文件均保留',409)
                        pid=episode['project_id']
                        if self.store.path(pid).exists():
                            # Crash after publishing but before session save: preserve that ID/edit.
                            self.store.get(pid,include_archived=True)
                            episode['state']='complete';self.persist(session);continue
                        if episode.get('state')=='complete':raise FolderDropError('已建立的工程文件缺失，不会静默重建覆盖旧编辑')
                        assets=[]
                        for fid in episode['file_ids']:
                            item=by_id[fid]
                            asset=probe(self.file_path(session,item))
                            if asset.get('sha256')!=item['sha256']:raise FolderDropError('复制缓存验证期间发生改变，未导入：'+item['relative_path'])
                            asset['name']=Path(item['relative_path']).name
                            asset['source_relative_path']=item['relative_path']
                            assets.append(asset)
                        if self._cancel[sid].is_set():raise FolderDropError('导入已取消',409)
                        self.store.publish_imported(episode['name'],episode.get('series',''),assets,pid=pid)
                        episode['state']='complete';self.persist(session)
                session.update(status='complete',error=None);self.persist(session)
                return self.public(session)
            except Exception as exc:
                session.update(status='cancelled' if self._cancel[sid].is_set() else 'failed',error=str(exc))
                details=dict(session_id=sid,status=session['status'],results=self.result_rows(session))
                try:self.persist(session)
                except FolderDropError as persistence_error:
                    persistence_error.payload.update(details)
                    raise
                if isinstance(exc,FolderDropError):
                    exc.payload.update(details);raise
                error=FolderDropError('本机导入未完成，已复制缓存保留，可重试：'+str(exc))
                error.payload.update(details)
                raise error
