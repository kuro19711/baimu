"""Portable authoritative native timelines with content-addressed media.

The recipient edits the same native graph in Baimu's native workspace or Jianying.
Unknown graph fields survive; unsupported external resource directories fail closed.
"""
import copy,hashlib,json,os,re,shutil,stat,time,uuid,zipfile
from pathlib import Path,PurePosixPath
from .jianying_bridge import bridge
from .store import write_json
from .native_blur import EFFECT_ID,MASK_ID,resources
from .core import VIDEO_EXT,AUDIO_EXT

FORMAT='baimu-native-project'
PATH_FIELDS={'path','font_path','file_Path','draft_file_path','draft_cover_path','draft_config_path'}
EXTENSIONS=VIDEO_EXT|AUDIO_EXT|{'.png','.jpg','.jpeg','.webp','.bmp','.gif','.ttf','.otf'}
MAX_BYTES=32*1024**3

def transform(value,convert,key=''):
    if isinstance(value,dict):return {k:transform(v,convert,k) for k,v in value.items()}
    if isinstance(value,list):return [transform(v,convert,key) for v in value]
    if isinstance(value,str):
        if key=='content':
            try:rich=json.loads(value)
            except ValueError:return value
            if isinstance(rich,(dict,list)):return json.dumps(transform(rich,convert),ensure_ascii=False,separators=(',',':'))
        if (key in PATH_FIELDS or key.lower().endswith('_path')) and value:return convert(value)
        if key!='text' and absolute(value):raise ValueError('发现尚不能定位的原生绝对路径字段：'+key)
    return value

def absolute(value):return bool(re.match(r'^[a-zA-Z]:[\\/]|^\\\\',value)) or Path(value).is_absolute()
def file_hash(path):
    with path.open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()

def export(service,body):
    with service.lock:
        _,folder=service.resolve(body['key']);state=bridge.load(folder,str(service.install))
        if body.get('revision')!=state['revision']:raise ValueError('工程已改变，请重新读取后打包')
        if len(state['documents'])!=len(state['main_mirrors']):raise ValueError('多时间线工程尚未完成可移植核对，未打包')
        main=copy.deepcopy(state['documents'][state['main_mirrors'][0]]['object'])
        if isinstance(main.get('baimu',{}).get('management',{}).get('script'),dict):main['baimu']['management']['script']['source']=''
        external={};files={};offline={}
        try:
            ep,mp=resources();external={os.path.normcase(str(Path(ep).resolve())):EFFECT_ID,os.path.normcase(str(Path(mp).resolve())):MASK_ID}
        except ValueError:pass
        def collect(value):
            if not absolute(value):
                if '..' in PurePosixPath(value.replace('\\','/')).parts:raise ValueError('原生工程包含未定位的相对路径')
                return value
            path=Path(value);normal=os.path.normcase(str(path.resolve()))
            if path.resolve()==folder:return 'bundle-root:'
            if normal in external:return 'native-resource:'+external[normal]
            if path.is_dir():raise ValueError('该外部资源目录暂不能完整交接：'+path.name)
            if path.suffix.lower() not in EXTENSIONS:raise ValueError('尚未支持的工程依赖：'+path.name)
            if not path.is_file():
                token='offline:'+hashlib.sha256(normal.encode()).hexdigest()[:24]+path.suffix.lower()
                offline[token]=dict(token=token,name=path.name);return token
            before=path.stat();digest=file_hash(path);after=path.stat()
            if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise ValueError('素材正在变化，未打包')
            relative='media/'+digest+path.suffix.lower()
            files.setdefault(relative,dict(path=relative,source=path,size=before.st_size,sha256=digest))
            return 'bundle:'+relative
        portable=transform(main,collect)
        if offline and body.get('allow_offline') is not True:raise ValueError('工程含缺失素材；请明确选择保留离线引用，或先找回素材')
        if len(files)>500 or sum(f['size'] for f in files.values())>MAX_BYTES:raise ValueError('工程包最多500个文件、32GB')
        target=service.root/'packages'/(uuid.uuid4().hex+'.zip');target.parent.mkdir(parents=True,exist_ok=True)
        if shutil.disk_usage(target.parent).free<sum(f['size'] for f in files.values())+64*1024**2:raise ValueError('打包空间不足')
        entry,_=service.resolve(body['key'])
        manifest=dict(format=FORMAT,version=1,name=entry.get('draft_name',folder.name),
            shared_project_id=main['id'],timeline=portable,offline=list(offline.values()),
            files=[{k:v for k,v in f.items() if k!='source'} for f in files.values()],
            limitations=['剪映专有特效资源不随包分发；接收方需安装并具备对应资源',
                          '百慕原生工程模式保留完整字段，当前只提供受支持的参数编辑'],
            source_revision=state['revision'])
        partial=target.with_suffix('.partial')
        try:
            with zipfile.ZipFile(partial,'w',zipfile.ZIP_STORED,allowZip64=True) as z:
                for record in files.values():
                    digest=hashlib.sha256();written=0
                    with record['source'].open('rb') as src,z.open(record['path'],'w',force_zip64=True) as dst:
                        for block in iter(lambda:src.read(4*1024**2),b''):digest.update(block);dst.write(block);written+=len(block)
                    if digest.hexdigest()!=record['sha256'] or written!=record['size']:raise ValueError('复制期间素材改变，未交付半成品')
                z.writestr('project.json',json.dumps(manifest,ensure_ascii=False,separators=(',',':')))
            if bridge.fingerprint(folder)['revision']!=state['revision']:raise ValueError('打包期间工程改变，请重新读取后打包')
            os.replace(partial,target)
        except Exception:partial.unlink(missing_ok=True);raise
        return dict(id=target.stem,size=target.stat().st_size,file=target.name,kind='native',
            name=manifest['name'],offline=len(offline),media_files=len(files),
            note='包含完整原生时间线与可用媒体、字体；接收方在百慕导入后可打开同一份剪映草稿。'+
                (f'保留{len(offline)}个离线引用，丢失的文件声音或画面无法恢复。' if offline else ''))

def import_package(service,source):
    with service.lock:
        index_before=bridge.stable_bytes(service.index);index=json.loads(index_before.decode('utf-8-sig'))
        entries=index.get('all_draft_store',[])
        if not entries:raise ValueError('请先在剪映建立一份空白草稿，确定本机工程目录')
        root=Path(entries[0]['draft_fold_path']).resolve().parent
        if not root.is_dir():raise ValueError('本机剪映工程目录不存在')
        with zipfile.ZipFile(source) as z:
            infos=z.infolist();names=[i.filename for i in infos]
            if len(infos)>501 or len(names)!=len(set(n.casefold() for n in names)):raise ValueError('工程包路径重复或文件数量超出范围')
            for i in infos:
                p=PurePosixPath(i.filename)
                if p.is_absolute() or '..' in p.parts or '\\' in i.filename or ':' in i.filename or i.is_dir() or stat.S_ISLNK(i.external_attr>>16):raise ValueError('工程包包含不安全路径')
            if z.getinfo('project.json').file_size>64*1024**2:raise ValueError('工程清单过大')
            m=json.loads(z.read('project.json'))
            if m.get('format')!=FORMAT or m.get('version')!=1 or not isinstance(m.get('timeline'),dict):raise ValueError('不是受支持的原生工程包')
            records=m.get('files',[])
            if not isinstance(records,list) or len(records)>500 or set(names)!={'project.json',*(r['path'] for r in records)} or len(records)!=len(set(r['path'] for r in records)):raise ValueError('工程文件与清单不一致')
            for r in records:
                if not re.fullmatch(r'media/[a-f0-9]{64}\.[a-z0-9]+',r['path']) or PurePosixPath(r['path']).suffix not in EXTENSIONS:raise ValueError('素材类型或路径无效')
                if not isinstance(r.get('size'),int) or not 0<=r['size']<=MAX_BYTES or r['size']!=z.getinfo(r['path']).file_size or not re.fullmatch('[a-f0-9]{64}',r.get('sha256','')):raise ValueError('素材校验信息无效')
            total=sum(r['size'] for r in records)
            if total>MAX_BYTES or shutil.disk_usage(root).free<total+64*1024**2:raise ValueError('工程超过32GB或空间不足')
            name=re.sub(r'[<>:"/\\|?*\x00-\x1f]','_',str(m.get('name','共同工程')))[:75]+'-接收-'+uuid.uuid4().hex[:8]
            destination=root/name;destination.mkdir(exist_ok=False)
            write_json(destination/'BRIDGE_IMPORT_PENDING.json',dict(stage='copying',created=time.time()))
            known={r['path']:destination/'Resources'/Path(r['path']).name for r in records}
            for r in records:
                path=known[r['path']];path.parent.mkdir(exist_ok=True);digest=hashlib.sha256();written=0
                with z.open(r['path']) as src,path.open('xb') as dst:
                    for block in iter(lambda:src.read(4*1024**2),b''):
                        written+=len(block)
                        if written>r['size']:raise ValueError('素材超出清单长度')
                        digest.update(block);dst.write(block)
                if written!=r['size'] or digest.hexdigest()!=r['sha256']:raise ValueError('工程素材校验失败，未登记草稿')
        missing={r['token']:r for r in m.get('offline',[])}
        for token in missing:
            if not re.fullmatch(r'offline:[a-f0-9]{24}\.[a-z0-9]+',token):raise ValueError('离线引用格式无效')
        def relocate(value):
            if value=='bundle-root:':return str(destination)
            if value.startswith('bundle:'):
                relative=value[7:]
                if relative not in known:raise ValueError('引用了包外素材')
                return str(known[relative])
            if value.startswith('offline:'):
                if value not in missing:raise ValueError('离线引用未登记')
                return str(destination/'OfflineMedia'/value[8:])
            if value.startswith('native-resource:'):
                ep,mp=resources();choices={EFFECT_ID:ep,MASK_ID:mp}
                if value[16:] not in choices:raise ValueError('接收方缺少对应剪映特效资源')
                return choices[value[16:]]
            if absolute(value):raise ValueError('工程仍引用发送方绝对路径，未登记草稿')
            if '..' in PurePosixPath(value.replace('\\','/')).parts:raise ValueError('原生工程包含包外相对路径')
            return value
        content=transform(m['timeline'],relocate)
        if not isinstance(content.get('tracks'),list) or not isinstance(content.get('materials'),dict):raise ValueError('原生时间线结构无效')
        old_id=content['id'];timeline_id=str(uuid.uuid4()).upper();project_id=str(uuid.uuid4()).upper()
        if json.dumps(content).count(old_id)!=1:raise ValueError('该工程的时间线交叉引用尚不能安全迁移')
        content['id']=timeline_id;now=time.time_ns()//1000
        encoded=bridge.encrypt_draft_bytes(json.dumps(content,ensure_ascii=False,separators=(',',':')).encode(),jy_install_dir=str(service.install),timeout=30)
        (destination/'draft_content.json').write_bytes(encoded)
        td=destination/'Timelines'/timeline_id;td.mkdir(parents=True);(td/'draft_content.json').write_bytes(encoded)
        write_json(destination/'Timelines/project.json',dict(config={},create_time=now,update_time=now,id=project_id,
            main_timeline_id=timeline_id,timelines=[dict(create_time=now,id=timeline_id,is_marked_delete=False,name='时间线01',update_time=now)],version=0))
        from .native_migration import load_builder
        d=load_builder();meta=json.loads((Path(d.__file__).parent/'assets/draft_meta_info.json').read_text(encoding='utf-8'))
        meta.update(draft_id=project_id,draft_name=name,draft_fold_path=str(destination),draft_root_path=str(root),tm_draft_create=now,tm_draft_modified=now,tm_duration=content.get('duration',0),draft_new_version='')
        bucket=next(x for x in meta['draft_materials'] if x['type']==0)
        for kind in ('videos','audios'):
            for mat in content['materials'].get(kind,[]):
                if not mat.get('path'):continue
                bucket['value'].append(dict(duration=mat.get('duration',0),height=mat.get('height',0),width=mat.get('width',0),md5='',
                    metetype='music' if kind=='audios' else mat.get('type','video'),type=0,create_time=0,extra_info=Path(mat['path']).name,
                    file_Path=mat['path'],import_time=0,import_time_ms=0,item_source=1,
                    roughcut_time_range=dict(duration=mat.get('duration',0),start=0),sub_time_range=dict(duration=-1,start=-1)))
        (destination/'draft_meta_info.json').write_bytes(bridge.encrypt_draft_bytes(json.dumps(meta,ensure_ascii=False).encode(),jy_install_dir=str(service.install),timeout=30))
        state=bridge.load(destination,str(service.install))
        if any(doc['object']!=content for doc in state['documents'].values()):raise ValueError('接收草稿读回不一致')
        entry=dict(cloud_draft_cover=False,cloud_draft_sync=False,draft_is_cloud_temp_draft=False,
            draft_is_invisible=False,draft_type='',draft_new_version='')
        entry.update(draft_id=project_id,draft_name=name,draft_fold_path=str(destination),
            draft_root_path=str(root),draft_json_file=str(destination/'draft_content.json'),draft_cover='',
            tm_draft_create=now,tm_draft_modified=now,tm_draft_removed=0,tm_duration=content.get('duration',0),
            draft_timeline_materials_size=total,draft_is_invisible=False)
        if service.index.read_bytes()!=index_before:raise ValueError('导入期间索引改变，副本尚未登记')
        backup=service.root/'index-backups'/(str(time.time_ns())+'.json');backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(index_before)
        index['all_draft_store'].insert(0,entry)
        if isinstance(index.get('draft_ids'),list):index['draft_ids'].append(project_id)
        bridge.write_index_checked(service.index,index,index_before)
        write_json(destination/'BRIDGE_IMPORT_PENDING.json',dict(stage='registered',shared_project_id=m.get('shared_project_id'),offline=len(missing)))
        project=service.store.create(name,(content.get('baimu',{}).get('management') or {}).get('series',''))
        key=service.key(destination)
        service.bind(dict(project_id=project['id'],key=key,revision=state['revision']))
        return dict(kind='native',id=project['id'],key=key,name=name,path=str(destination),offline=len(missing),
            message='已导入完整原生工程副本，素材已重新定位；百慕和剪映读取此同一草稿。')
