"""Explicit legacy-project migration: exact finished file OR editable approximation.

Neither route overwrites the legacy project or an existing native draft.
An exact media-file copy is not represented as preserving editable layers.
"""
from __future__ import annotations
import copy,json,math,os,re,shutil,sys,tempfile,time,uuid
from pathlib import Path
from .core import canonical_numbers, fps_value, timeline
from .store import read_json,write_json
from .jianying_bridge import bridge
from .native_layers import add_solid_layers,verify_solid_layers
from .native_audio import append_linked_audio,apply_native_groups,verify_linked_audio,extract_original,audio_material
from .native_blur import resources as blur_resources,append_blur_layers,verify_blur_layers
from .native_defaults import timerange as native_range
from .native_offline import eligible as offline_eligible,material as offline_material,verify as verify_offline_audio
from .native_caption import conversion as caption_conversion,outline_conversion,jianying_outline,verify as verify_caption_size,font_hash
from .native_caption import layout as caption_layout,LAYOUT_METHOD

AUDIO_ROLES=('dialogue','narration','bgm','sfx')
TRACK_NAMES={'dialogue':'分离原声','narration':'旁白 / 配音','bgm':'背景音乐','sfx':'音效','video':'画面','caption':'字幕'}


def audio_end(audio,duration):
    # This is the editor's layout rule, rather than the renderer's cropped range.
    if audio.get('role')=='bgm' and audio.get('loop') is True:
        return audio['start']+audio.get('loop_duration',max(0,duration-audio['start']))
    return audio['start']+audio['out']-audio['in']


def fidelity_report(project):
    """Unverified conversions cannot be presented as the requested exact handoff."""
    issues=[]
    if project.get('captions'):
        issues.append('字幕字体度量、描边、阴影、断行与位置尚未完成剪映渲染对照')
    if project.get('clips'):
        issues.append('已建立独立原声轨与原生分组，尚待剪映内验证分组联动行为')
    if project.get('audios') or project.get('clips'):
        issues.append('百慕最终限幅与BGM侧链压低尚未映射为等效的剪映处理')
    if project.get('track_locks'):
        issues.append('已写入原生轨道锁定位，尚待剪映内验证锁定行为')
    if project.get('masks'):
        if any(m.get('mode','blur')!='solid' for m in project['masks']):
            issues.append('模糊区域与移动关键帧可编辑；剪映高斯模糊与百慕双次方框模糊及增白不等效，尚待校准')
        else:issues.append('白色打码图层与位置关键帧已建立，尚待剪映内验证几何与插值')
    return dict(requirement='保留全部编辑结果、图层与原轨道组织',exact_available=not issues,
                exact_verified=False,unresolved=issues)


def effective(project):
    keys=('width','height','clips','audios','captions','masks','style')
    data={k:copy.deepcopy(project.get(k,[] if k not in ('width','height','style') else {})) for k in keys}
    data['fps']=fps_value(project['fps'])
    placed,_=timeline(project)
    starts={c['id']:c['start'] for c in placed}
    for c in data['clips']:c['start']=starts[c['id']]
    used={x['asset_id'] for kind in ('clips','audios') for x in project.get(kind,[])}
    data['assets']=sorted([{k:a.get(k) for k in ('id','sha256','duration','width','height','has_audio','audio_streams')}
                           for a in project.get('assets',[]) if a['id'] in used],key=lambda a:a['id'])
    return canonical_numbers(data)


def matching_render(store,project):
    roots=[store.root]
    source=read_json(store.root/'jianying'/'legacy-source.json',{})
    if source.get('data_root'):roots.append(Path(source['data_root']).resolve())
    expected=effective(project);matches=[]
    for root in roots:
        for p in (root/'jobs').glob('*.json'):
            try:
                j=read_json(p)
                if not re.fullmatch('[a-f0-9]{32}',str(j.get('id',''))):continue
                if j.get('project_id')!=project['id'] or j.get('state')!='complete' or j.get('kind') not in ('draft','final'):continue
                result=j.get('result',{})
                if result.get('captions_burned') is not True:continue
                if effective(j['snapshot'])!=expected:continue
                movie=root/'renders'/j['id']/'film.mp4'
                if movie.is_file():matches.append(dict(path=str(movie),job_id=j['id'],created=j.get('created',0),
                    project_hash=result.get('project_hash'),kind=j['kind'],exact_snapshot=True))
            except (ValueError,KeyError,TypeError,OSError):continue
    return max(matches,key=lambda x:x['created']) if matches else None


def migration_report(store,project):
    assets={a['id']:a for a in project['assets']};used={x['asset_id'] for kind in ('clips','audios') for x in project.get(kind,[])}
    missing=[];changed=[]
    for aid in used:
        a=assets.get(aid,{});path=Path(a.get('path',''))
        if not a.get('path') or not path.is_file():missing.append(dict(id=aid,name=a.get('name',aid),path=a.get('path')))
        elif a.get('size') is not None and path.stat().st_size!=a['size']:
            changed.append(dict(id=aid,name=a.get('name',aid),path=str(path),reason='文件大小与导入记录不同'))
    blocked=[];warnings=[]
    if not project['clips']:blocked.append('没有视频片段')
    if changed:blocked.append(f'{len(changed)} 个源素材与导入记录不同')
    if any(m.get('mode','blur')!='solid' for m in project.get('masks',[])):
        try:blur_resources()
        except ValueError as e:blocked.append(str(e))
        warnings.append('模糊打码保留独立特效轨、矩形蒙版和移动关键帧；模糊算法不同，强度未实测校准，增白尚未映射，不是原样效果')
    masks=project.get('masks',[])
    if any(a.get('mode','blur')!=b.get('mode','blur') and max(a['start'],b['start'])<min(a['end'],b['end'])
           for i,a in enumerate(masks) for b in masks[i+1:]):
        blocked.append('白色打码与模糊打码在时间上重叠，原图层合成顺序尚未核对')
    clips,duration=timeline(project)
    if any(clips[i]['start']<clips[i-1]['end']-1e-6 for i in range(1,len(clips))):blocked.append('主视频轨有重叠')
    if project['captions']:warnings.append('字幕字体、字号、阴影、描边、断行及坐标使用兼容映射，不能承诺与百慕成片逐像素一致')
    if project.get('audios'):warnings.append('旁白/BGM等可拆成编辑轨道；百慕的侧链压低、循环接缝和最终限幅不能一比一迁移')
    for item in project.get('audios',[]):
        a=assets.get(item['asset_id'],{});streams=a.get('audio_streams',[])
        if streams and item.get('audio_stream',streams[0]['index'])!=streams[0]['index']:
            blocked.append('有片段选择了非默认原声音轨，当前不能完整迁移该选轨')
    movie=matching_render(store,project)
    offline_available=not blocked and offline_eligible(project,missing)
    normal_blocked=blocked+([f'{len(missing)} 个被引用的源素材缺失'] if missing else [])
    preservation=fidelity_report(project)
    if missing:
        preservation['exact_available']=False
        preservation['unresolved'].append('源素材缺失；保留离线片段不等于恢复声音或画面')
    return dict(project_id=project['id'],revision=project['revision'],name=project['name'],series=project.get('series',''),
        duration=duration,clips=len(project['clips']),audios=len(project.get('audios',[])),captions=len(project['captions']),
        masks=len(project.get('masks',[])),missing=missing,changed=changed,
        editable_available=not normal_blocked,editable_blocked=sorted(set(normal_blocked)),editable_warnings=warnings,
        offline_audio_available=offline_available,
        offline_notice='保留缺失音频的原路径、导入时长、时间线片段和音量；剪映会显示素材丢失，该部分声音不能播放，没有创建静音替身',
        editable_lossless_verified=False,film_available=bool(movie),matched_render=movie,
        film_notice='直接复制与当前工程快照一致的已完成成片；不重新编码，字幕/打码/混音保持在单轨成片内，不能分别编辑',
        source_project_retained=True,preservation=preservation)


def load_builder():
    root=Path(__file__).parent/'jianying_bridge'
    for path in (root/'deps',root/'vendor'):
        if str(path) not in sys.path:sys.path.insert(0,str(path))
    import pyJianYingDraft as draft
    return draft


def rgb(value):return tuple(int(value.lstrip('#')[i:i+2],16)/255 for i in (0,2,4))
def us(value):return round(value*1_000_000)


def verify_editable_structure(project,content,mapping):
    """Compare every exported edit with its source, independently of encoding.

    This proves mapped data only; renderer fidelity remains a separate gate.
    """
    def check(test,label):
        if not test:raise ValueError('编辑结构核对失败：'+label)
    tracks={t['id']:t for t in content['tracks']}
    segments={s['id']:(t,s) for t in content['tracks'] for s in t['segments']}
    materials={m['id']:m for kind in ('videos','audios','texts') for m in content['materials'].get(kind,[])}
    assets={a['id']:a for a in project['assets']};clips,duration=timeline(project)
    records={(r['source_kind'],r['source_id']):r for r in mapping}
    expected={(kind,x['id']) for kind,items in [('video',project['clips']),('caption',project['captions'])] for x in items}
    expected.update((x['role'],x['id']) for x in project['audios'])
    expected.update(('original',x['id']) for x in project['clips'] if not x.get('audio_detached'))
    expected.update(('mask',x['id']) for x in project.get('masks',[]))
    check(len(records)==len(mapping) and set(records)==expected,'源片段映射不完整或重复')
    for kind,items in [('video',clips),('caption',project['captions'])]+[(role,[x for x in project['audios'] if x['role']==role]) for role in AUDIO_ROLES]:
        for item in items:
            record=records[(kind,item['id'])];parts=[]
            for sid in record['segments']:
                check(sid in segments,'目标片段不存在')
                track,segment=segments[sid]
                check(track['id']==record['track_id'],'目标轨道错误')
                parts.append(segment)
            check(bool(parts),'片段被丢弃')
            start=item['start'];end=item['end'] if kind in ('video','caption') else audio_end(item,duration)
            check(native_range(parts[0]['target_timerange'])['start']==us(start),'片段起点改变')
            check(sum(native_range(parts[-1]['target_timerange']).values())==us(end),'片段终点改变')
            for a,b in zip(parts,parts[1:]):
                check(sum(native_range(a['target_timerange']).values())==native_range(b['target_timerange'])['start'],'循环接缝不连续')
            if kind=='caption':
                check(len(parts)==1,'字幕被拆分')
                mat=materials[parts[0]['material_id']];rich=json.loads(mat['content']);style=dict(project['style'],**item.get('style',{}))
                layout=record.get('native_layout_mapping')
                if layout:
                    check(layout.get('schema')==1 and layout.get('method')==LAYOUT_METHOD and layout.get('source_text')==item['text'],'字幕断行来源改变')
                    check(rich['text']==layout['native_text'] and mat.get('type')=='text','字幕显式断行改变')
                else:check(rich['text']==item['text'],'字幕内容改变')
                check(record['source_style']==style,'字幕源样式未完整保留')
                check(mat.get('global_alpha',1)==style.get('opacity',1),'字幕透明度改变')
                verify_caption_size(style,mat,parts[0],record)
                if style.get('shadow',0) or style.get('shadow_blur',0):
                    shadow=rich['styles'][0].get('shadows',[])
                    check(len(shadow)==1 and shadow[0]['distance']==style.get('shadow',0),'字幕阴影未写入')
                continue
            source=record.get('extraction',{}).get('path',assets[item['asset_id']]['path'])
            volume=0 if kind=='video' or item.get('muted') else 10**(item.get('gain',0)/20)
            for part in parts:
                mat=materials[part['material_id']]
                check(Path(mat['path']).resolve()==Path(source).resolve(),'素材引用改变')
                check(math.isclose(part.get('volume',1),volume,rel_tol=1e-12),'音量改变')
                check(part['source_timerange']['duration']==part['target_timerange']['duration'],'素材长度改变')
            offset=item.get('loop_offset',0) if kind=='bgm' and item.get('loop') else 0
            check(abs(native_range(parts[0]['source_timerange'])['start']-us(item['in']+offset))<=1,'素材入点改变')
            if kind=='video':
                check(len(parts)==1,'视频被重新切分')
            else:
                check(tracks[record['track_id']]['name'].startswith(TRACK_NAMES[kind]),'音频未按原角色分轨')
    linked=verify_linked_audio(project,content,mapping)
    solid=verify_solid_layers(project,content,mapping)
    blur=verify_blur_layers(project,content,mapping)
    offline=verify_offline_audio(project,content,mapping)
    for record in mapping:
        if record['source_kind'] in project.get('track_locks',[]):
            check(tracks[record['track_id']].get('attribute',0)&4,'轨道锁定丢失')
    return dict(passed=True,source_items=len(expected),mapped_items=len(records),linked_audio_groups=linked,solid_masks=solid,blur_masks=blur,offline_audio=offline,
                native_tracks=[dict(name=t['name'],type=t['type'],segments=len(t['segments'])) for t in content['tracks']],
                scope='映射参数与轨道组织核对；不等于渲染结果一致',exact_verified=False)


def build_content(store,project,destination,mode,report,allow_offline_audio=False,write_sidecars=True):
    if mode=='editable' and not report['editable_available'] and not (allow_offline_audio and report.get('offline_audio_available')):
        raise ValueError('不能丢弃未映射的图层或缺失素材：'+'；'.join(report['editable_blocked']))
    d=load_builder();fps=fps_value(project['fps'])
    script=d.ScriptFile(project['width'],project['height'],fps,False)
    script.content['id']=str(uuid.uuid4()).upper()
    resources=destination/'Resources';resources.mkdir(exist_ok=not write_sidecars)
    video_track=script.append_track(d.TrackSpec(d.TrackType.video,'画面'))
    if mode=='film':
        source=Path(report['matched_render']['path']);target=resources/'百慕原样成片.mp4'
        shutil.copy2(source,target)
        # Hash both files, not just their lengths. Video/audio are byte-for-byte
        # preserved in this route, while editable layers are explicitly flattened.
        source_hash=bridge.digest(source.read_bytes())
        if bridge.digest(target.read_bytes())!=source_hash:raise ValueError('成片复制校验失败')
        segment=d.VideoSegment(str(target),d.Timerange(0,us(report['duration'])))
        script.add_segment(segment,video_track)
        return json.loads(script.dumps()),dict(mode='film',source_film=str(source),copied_film_sha256=source_hash,
            source_job=report['matched_render']['job_id'],reencoded=False,editable_layers_preserved=False)
    assets={a['id']:a for a in project['assets']};mapping=[]
    clips,duration=timeline(project)
    cursor=0
    for c in clips:
        if c['start']>cursor+1e-6:
            black=resources/'black.png'
            if not black.exists():
                from PIL import Image
                Image.new('RGB',(project['width'],project['height']),(0,0,0)).save(black)
            script.add_segment(d.VideoSegment(str(black),d.Timerange(us(cursor),us(c['start'])-us(cursor))),video_track)
        a=assets[c['asset_id']]
        # Round shared boundaries once. Rounding each duration independently at
        # 24fps can make adjacent clips overlap by one microsecond.
        length=us(c['end'])-us(c['start'])
        seg=d.VideoSegment(d.VideoMaterial(a['path'],material_name=a['name']),d.Timerange(us(c['start']),length),
            source_timerange=d.Timerange(us(c['in']),length),
            volume=0)
        seg.segment_id=c['id']
        script.add_segment(seg,video_track);cursor=c['end']
        mapping.append(dict(source_kind='video',source_id=c['id'],track_id=video_track.track_id,segments=[seg.segment_id]))
    pairs=append_linked_audio(script,d,project,assets,clips,resources,mapping)
    # Match the editor's role rows and first-free overlap lanes. Four disjoint
    # narration clips belong to one narration lane, not four unrelated tracks.
    audio_lanes={role:[] for role in AUDIO_ROLES};selected_cache={}
    for audio in sorted(project.get('audios',[]),key=lambda a:(AUDIO_ROLES.index(a['role']),a['start'],audio_end(a,duration))):
        end=audio_end(audio,duration)
        if end<=audio['start']:continue
        lanes=audio_lanes[audio['role']]
        lane=next((lane for lane in lanes if lane['end']<=us(audio['start'])),None)
        if lane is None:
            name=TRACK_NAMES[audio['role']]+('' if not lanes else f' · 重叠 {len(lanes)+1}')
            lane={'track':script.append_track(d.TrackSpec(d.TrackType.audio,name)),'end':0};lanes.append(lane)
        lane['end']=us(end);track=lane['track']
        looping=audio['role']=='bgm' and audio.get('loop') is True
        pos=audio['start'];offset=audio.get('loop_offset',0) if looping else 0
        source_span=audio['out']-audio['in'];repeat=0
        record=dict(source_kind=audio['role'],source_id=audio['id'],track_id=track.track_id,segments=[])
        asset=assets[audio['asset_id']];material=asset['path']
        if not Path(material).is_file():
            if not allow_offline_audio:raise ValueError('源音频缺失；未选择保留离线片段')
            material=offline_material(d,asset)
            record.update(representation='offline_audio_reference',
                offline_asset={k:asset.get(k) for k in ('id','name','path','duration','sha256','size')})
        if Path(asset['path']).is_file() and (asset.get('kind')=='video' or len(asset.get('audio_streams',[]))>1):
            extracted=extract_original(asset,audio,resources,selected_cache,us(audio['out']));material=extracted['path'];record['extraction']=extracted
        if isinstance(material,str):material=audio_material(d,material,name=asset['name'])
        while pos<end-1e-6:
            take=min(source_span-offset,end-pos)
            if take<=0:raise ValueError('循环音频范围无效')
            length=us(pos+take)-us(pos)
            segment=d.AudioSegment(material,d.Timerange(us(pos),length),
                source_timerange=d.Timerange(us(audio['in']+offset),length),volume=0 if audio.get('muted') else 10**(audio.get('gain',0)/20))
            segment.segment_id=audio['id'] if repeat==0 else uuid.uuid4().hex
            segment.add_fade(us(min(audio.get('fade_in',0) if repeat==0 else 0,take)),
                us(min(audio.get('fade_out',0) if pos+take>=end-1e-6 else 0,take)))
            script.add_segment(segment,track);record['segments'].append(segment.segment_id);pos+=take;offset=0;repeat+=1
            if not looping:break
            if repeat>1000:raise ValueError('循环音频片段数超出当前迁移范围')
        mapping.append(record)
    mask_tracks=add_solid_layers(script,d,project,resources,mapping)
    font_paths={};text_styles={};caption_lanes=[]
    for i,c in enumerate(sorted(project['captions'],key=lambda x:(x['start'],x['end']))):
        style=dict(project['style'],**c.get('style',{}));font=store.fonts.get(style['font_id'],{})
        render_source=Path(font.get('path',''))
        if not render_source.is_file():raise ValueError('字幕字体文件缺失：'+style.get('font_id',''))
        if style['font_id'] not in font_paths:
            source=store.original_font_path(style['font_id'])
            target=resources/(style['font_id']+source.suffix);shutil.copy2(source,target);font_paths[style['font_id']]=str(target)
        lane=next((lane for lane in caption_lanes if lane['end']<=us(c['start'])),None)
        if lane is None:
            lane={'track':script.append_track(d.TrackSpec(d.TrackType.text,'字幕'+('' if not caption_lanes else f' · 重叠 {len(caption_lanes)+1}'))),'end':0}
            caption_lanes.append(lane)
        track=lane['track'];lane['end']=us(c['end'])
        # Calibration belongs to Baimu's renderer copy. The verification identity
        # belongs to the original face that Jianying actually receives.
        size_mapping=caption_conversion(store,project,style,render_source)
        size_mapping['source_font_sha256']=font_hash(font_paths[style['font_id']])
        layout=caption_layout(c['text'],render_source,style)
        seg=d.TextSegment(layout['native_text'],d.Timerange(us(c['start']),us(c['end'])-us(c['start'])),
            style=d.TextStyle(size=size_mapping['native_font_size'],color=rgb(style['color']),alpha=style.get('opacity',1),bold=style.get('bold',False),italic=style.get('italic',False),underline=style.get('underline',False),align=1,
                letter_spacing=style.get('spacing',0),line_spacing=style.get('line_spacing',0),
                auto_wrapping=False,max_line_width=style.get('max_width',84)/100),
            clip_settings=d.ClipSettings(transform_x=(style['x']-50)/50,transform_y=(50-style['y'])/50),
            border=d.TextBorder(color=rgb(style['outline_color']),width=jianying_outline(style['outline']),alpha=style.get('outline_opacity',1)) if style.get('outline',0)>0 else None,
            shadow=d.TextShadow(alpha=style.get('shadow_opacity',.1),distance=style.get('shadow',0),
                diffuse=style.get('shadow_blur',0),angle=style.get('shadow_angle',45)) if style.get('shadow',0) or style.get('shadow_blur',0) else None)
        seg.segment_id=c['id']
        script.add_segment(seg,track);text_styles[seg.material_id]=(style,font)
        mapping.append(dict(source_kind='caption',source_id=c['id'],track_id=track.track_id,segments=[seg.segment_id],source_style=style,
            source_style_overrides=copy.deepcopy(c.get('style',{})),native_font_mapping=size_mapping,
            native_outline_mapping=outline_conversion(style.get('outline',0)),native_layout_mapping=layout))
    content=json.loads(script.dumps())
    content['name']=project['name']
    offline_tracks={r['track_id'] for r in mapping if r.get('representation')=='offline_audio_reference'}
    for track in content['tracks']:
        if track['id'] in offline_tracks:track['name']+=' · 素材丢失'
    apply_native_groups(content,pairs)
    append_blur_layers(content,project,mapping)
    from .native_layers import apply_mask_layers
    apply_mask_layers(content,project,mapping)
    for track in content['tracks']:
        if track['id'] in mask_tracks:track['flag']=2
        if any(r['track_id']==track['id'] and r['source_kind'] in project.get('track_locks',[]) for r in mapping):
            track['attribute']|=4
    for t in content['materials']['texts']:
        style,font=text_styles[t['id']];path=font_paths[style['font_id']]
        display_name=font.get('name') or font.get('family') or Path(path).stem
        t.update(font_category_id='',font_category_name='',font_id='',font_name=display_name,
                 font_path=path,font_resource_id='',font_source_platform=0,font_team_id='',
                 font_title=display_name,font_url='',fonts=[])
        rich=json.loads(t['content'])
        for s in rich.get('styles',[]):
            s['font']={'path':path,'id':''}
            s['range']=[0,len(rich['text'].encode('utf-16-le'))//2]
        t['content']=json.dumps(rich,ensure_ascii=False,separators=(',',':'))
    # This map documents actual native representations, including differences.
    # The full source snapshot never substitutes for an unsupported native layer.
    if write_sidecars:
        write_json(destination/'BAIMU_TRACK_MAP.json',dict(schema=1,mapping=mapping,preservation=fidelity_report(project)))
        write_json(destination/'BAIMU_SOURCE_PROJECT.json',project)
    structural=verify_editable_structure(project,content,mapping)
    offline=structural['offline_audio']
    if offline and write_sidecars:write_json(destination/'BAIMU_OFFLINE_MEDIA.json',dict(missing_audio=offline,source_media_restored=False,replacement_files_created=False))
    return content,dict(mode='editable',editable_lossless_verified=False,warnings=report['editable_warnings'],mapping=mapping,
                        preservation=report['preservation'],structural=structural,offline_audio=offline,
                        timing_precision='微秒；片段时间按百慕实际帧时间量化',source_project_retained=True)


def export_project(service,body):
    with service.lock:
        project=service.store.get(body['project_id'])
        if body.get('revision')!=project['revision']:raise ValueError('百慕工程已改变，请重新检查迁移')
        report=migration_report(service.store,project);mode=body.get('mode','editable')
        allow_offline=body.get('allow_offline_audio') is True
        if mode=='film' and not report['film_available']:raise ValueError('没有与当前编辑一致的已完成成片；请先导出审阅版，或选择可编辑迁移')
        if mode=='editable':
            if not report['editable_available'] and not (allow_offline and report['offline_audio_available']):raise ValueError('不能完整迁移：'+'；'.join(report['editable_blocked']))
            if body.get('require_exact',True) and not report['preservation']['exact_available']:
                raise ValueError('尚未达到原样工程交接：'+'；'.join(report['preservation']['unresolved']))
            if report['editable_warnings'] and body.get('accept_approximate') is not True:
                raise ValueError('该路线并非无损，请先查看并接受具体的样式/混音差异')
        if mode not in ('film','editable'):raise ValueError('迁移模式无效')
        original=bridge.stable_bytes(service.index);payload=json.loads(original)
        entries=payload['all_draft_store']
        if not entries:raise ValueError('先在剪映建立一个草稿，以确定真实草稿位置')
        root=Path(entries[0]['draft_fold_path']).resolve().parent
        label='可编辑多轨' if mode=='editable' else '成片单轨'
        if mode=='editable' and allow_offline and report['missing']:label+='-含离线音频'
        name=re.sub(r'[<>:"/\\|?*\x00-\x1f]','_',f"百慕-{project.get('series','')}-{project['name']}-{label}")[:80]+'-'+uuid.uuid4().hex[:8]
        destination=root/name
        destination.mkdir(exist_ok=False)
        journal=service.root/'exports'/(uuid.uuid4().hex+'.json')
        state=dict(stage='building',project_id=project['id'],source_revision=project['revision'],destination=str(destination),mode=mode)
        write_json(journal,state)
        try:
            content,proof=build_content(service.store,project,destination,mode,report,allow_offline_audio=allow_offline)
            project_id=str(uuid.uuid4()).upper();timeline_id=content['id'];now=time.time_ns()//1000
            raw=json.dumps(content,ensure_ascii=False,separators=(',',':')).encode()
            encoded=bridge.encrypt_draft_bytes(raw,jy_install_dir=str(service.install),timeout=30)
            (destination/'draft_content.json').write_bytes(encoded)
            td=destination/'Timelines'/timeline_id;td.mkdir(parents=True)
            (td/'draft_content.json').write_bytes(encoded)
            write_json(destination/'Timelines/project.json',dict(config={'color_space':-1,'hdr_vivid':False,'mixed_track_mode_on':False,
                'render_index_track_mode_on':False,'use_float_render':False},create_time=now,update_time=now,id=project_id,
                main_timeline_id=timeline_id,timelines=[dict(create_time=now,id=timeline_id,is_marked_delete=False,name='时间线01',update_time=now)],version=0))
            draft=load_builder();meta=json.loads((Path(draft.__file__).parent/'assets/draft_meta_info.json').read_text(encoding='utf-8'))
            meta.update(draft_id=project_id,draft_name=name,draft_fold_path=str(destination),draft_root_path=str(root),
                tm_draft_create=now,tm_draft_modified=now,tm_duration=content['duration'],draft_new_version='')
            bucket=next(x for x in meta['draft_materials'] if x['type']==0)
            for kind in ('videos','audios'):
                for mat in content['materials'].get(kind,[]):
                    if not mat.get('path'):continue
                    bucket['value'].append(dict(duration=mat.get('duration',0),height=mat.get('height',0),width=mat.get('width',0),md5='',
                        metetype='music' if kind=='audios' else mat.get('type','video'),type=0,create_time=0,extra_info=Path(mat['path']).name,
                        file_Path=mat['path'],import_time=0,import_time_ms=0,item_source=1,
                        roughcut_time_range=dict(duration=mat.get('duration',0),start=0),sub_time_range=dict(duration=-1,start=-1)))
            (destination/'draft_meta_info.json').write_bytes(bridge.encrypt_draft_bytes(json.dumps(meta,ensure_ascii=False,separators=(',',':')).encode(),jy_install_dir=str(service.install),timeout=30))
            write_json(destination/'BRIDGE_MIGRATION.json',dict(source_project=project,report=report,proof=proof,created=time.time()))
            native=bridge.load(destination,str(service.install))
            if mode=='editable':
                for rel in native['main_mirrors']:
                    verify_editable_structure(project,native['documents'][rel]['object'],proof['mapping'])
            if service.index.read_bytes()!=original or service.store.get(project['id'])['revision']!=project['revision']:
                raise ValueError('生成期间索引或百慕工程改变；已保留未注册新件，没有覆盖原工程')
            backup=service.root/'index-backups'/(str(time.time_ns())+'.json');backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(original)
            entry=dict(cloud_draft_cover=False,cloud_draft_sync=False,draft_cloud_last_action_download=False,draft_cloud_purchase_info='',
                draft_cloud_template_id='',draft_cloud_tutorial_info='',draft_cloud_videocut_purchase_info='',draft_cover='',draft_fold_path=str(destination),
                draft_id=project_id,draft_is_ai_shorts=False,draft_is_cloud_temp_draft=False,draft_is_invisible=False,draft_is_web_article_video=False,
                draft_json_file=str(destination/'draft_content.json'),draft_name=name,draft_new_version='',draft_root_path=str(root),
                draft_timeline_materials_size=sum(p.stat().st_size for p in (destination/'Resources').iterdir() if p.is_file()),draft_type='',
                draft_web_article_video_enter_from='',streaming_edit_draft_ready=True,tm_draft_cloud_completed='',tm_draft_cloud_entry_id=-1,
                tm_draft_cloud_modified=0,tm_draft_cloud_parent_entry_id=-1,tm_draft_cloud_space_id=-1,tm_draft_cloud_user_id=-1,
                tm_draft_create=now,tm_draft_modified=now,tm_draft_removed=0,tm_duration=content['duration'])
            payload['all_draft_store'].insert(0,entry)
            if isinstance(payload.get('draft_ids'),list):payload['draft_ids'].append(project_id)
            state.update(stage='ready_to_register',index_backup=str(backup));write_json(journal,state)
            # Final compare immediately before the atomic single-index replace.
            if service.index.read_bytes()!=original:raise ValueError('注册前检测到索引变化，请重新读取后登记')
            bridge.write_index_checked(service.index,payload,original)
            key=service.key(destination)
            service.bind(dict(project_id=project['id'],key=key,revision=native['revision']))
            state.update(stage='registered',key=key,proof=proof,original_project_written=False,editor_reopen='pending')
            write_json(journal,state)
            return dict(key=key,name=name,path=str(destination),mode=mode,proof=proof,journal=str(journal),
                        source_project_retained=True,editor_reopen='pending',message='已建立并关联独立剪映草稿，请在剪映首页打开验收')
        except Exception as exc:
            state.update(stage='failed_not_overwriting_source',error=str(exc));write_json(journal,state);raise
