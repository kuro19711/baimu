"""Discover the editor launcher independently of the version-specific draft DLL."""
from __future__ import annotations
import configparser
import os
from pathlib import Path
import re


def registry_locations():
    """Use installed application records, including custom installation drives."""
    try:
        import winreg
    except ImportError:
        return []
    locations=[]
    for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
        for view in (winreg.KEY_WOW64_64KEY,winreg.KEY_WOW64_32KEY):
            try:
                with winreg.OpenKey(hive,r'Software\Microsoft\Windows\CurrentVersion\App Paths\JianyingPro.exe',0,winreg.KEY_READ|view) as key:
                    locations.append(Path(winreg.QueryValueEx(key,None)[0].strip('"')))
            except OSError:
                pass
            try:
                with winreg.OpenKey(hive,r'Software\Microsoft\Windows\CurrentVersion\Uninstall',0,winreg.KEY_READ|view) as parent:
                    for i in range(winreg.QueryInfoKey(parent)[0]):
                        try:
                            with winreg.OpenKey(parent,winreg.EnumKey(parent,i)) as key:
                                name=winreg.QueryValueEx(key,'DisplayName')[0]
                                if not re.search(r'剪映|jianying',name,re.I):continue
                                for field in ('InstallLocation','DisplayIcon'):
                                    try:
                                        value=winreg.QueryValueEx(key,field)[0]
                                        value=re.sub(r',\s*-?\d+\s*$','',value).strip().strip('"')
                                        if value:locations.append(Path(os.path.expandvars(value)))
                                    except OSError:pass
                        except OSError:pass
            except OSError:
                pass
    return locations


def install_roots(preferred,roots=()):
    """Only inspect application locations; never recursively scan user disks."""
    preferred=Path(preferred)
    locations=[preferred,*roots,*registry_locations()]
    for variable in ('LOCALAPPDATA','ProgramFiles','ProgramFiles(x86)'):
        value=os.environ.get(variable)
        if value:locations.append(Path(value)/'JianyingPro')
    if os.name=='nt':
        import ctypes
        drives=ctypes.windll.kernel32.GetLogicalDrives()
        for i in range(26):
            drive=chr(65+i)+':/'
            if drives & (1<<i) and ctypes.windll.kernel32.GetDriveTypeW(drive)==3:
                locations.append(Path(drive)/'JianyingPro')
    search=[]
    for location in locations:
        path=Path(location)
        if path.suffix.lower()=='.exe':path=path.parent
        # An old version folder may still exist, but its executable is removed
        # during upgrades. Prefer the stable launcher at its installation root.
        if re.fullmatch(r'\d+(?:\.\d+)+',path.name):path=path.parent
        if path not in search:search.append(path)
    return search


def discover_launcher(preferred,roots=()):
    for root in install_roots(preferred,roots):
        launcher=root/'JianyingPro.exe'
        if launcher.is_file():return launcher
        config=configparser.ConfigParser(interpolation=None)
        try:
            config.read(root/'Configure.ini',encoding='utf-8-sig')
            version=config.get('jianyingpro','last_version',fallback='')
            if re.fullmatch(r'\d+(?:\.\d+)+',version):
                launcher=root/version/'JianyingPro.exe'
                if launcher.is_file():return launcher
        except (OSError,UnicodeError,configparser.Error):pass
        try:
            versions=sorted((p for p in root.iterdir() if p.is_dir() and re.fullmatch(r'\d+(?:\.\d+)+',p.name)),
                            key=lambda p:tuple(int(n) for n in p.name.split('.')),reverse=True)
        except OSError:continue
        for version in versions:
            launcher=version/'JianyingPro.exe'
            if launcher.is_file():return launcher
    return None
