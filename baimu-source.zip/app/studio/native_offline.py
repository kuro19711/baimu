"""Preserve lost audio as native offline references, never replacement media."""
import math,uuid
from pathlib import Path


def eligible(project,missing):
    assets={a['id']:a for a in project['assets']}
    picture={c['asset_id'] for c in project['clips']}
    audio={a['asset_id'] for a in project.get('audios',[])}
    for row in missing:
        a=assets.get(row['id'],{});duration=a.get('duration')
        if row['id'] in picture or row['id'] not in audio or a.get('kind')!='audio':return False
        if not a.get('path') or not isinstance(duration,(int,float)) or not math.isfinite(duration) or duration<=0:return False
        if any(x['out']>duration+1e-6 for x in project['audios'] if x['asset_id']==row['id']):return False
    return bool(missing)


def material(builder,asset):
    """Use retained import metadata instead of probing a file that is lost.

    AudioMaterial.export_json only uses these four fields. Native readers see
    the real missing path and can offer their own relink UI.
    """
    if Path(asset['path']).exists():raise ValueError('离线素材路径已有文件，请重新检查后迁移')
    result=object.__new__(builder.AudioMaterial)
    result.material_id=uuid.uuid4().hex
    result.material_name='【素材丢失】'+asset['name']
    result.path=str(Path(asset['path']).resolve())
    result.duration=round(asset['duration']*1_000_000)
    return result


def verify(project,content,mapping):
    assets={a['id']:a for a in project['assets']}
    materials={m['id']:m for m in content['materials'].get('audios',[])}
    segments={s['id']:s for t in content['tracks'] for s in t['segments']}
    offline=[]
    for record in mapping:
        if record.get('representation')!='offline_audio_reference':continue
        item=next(x for x in project['audios'] if x['id']==record['source_id'])
        a=assets[item['asset_id']]
        expected={k:a.get(k) for k in ('id','name','path','duration','sha256','size')}
        if record['offline_asset']!=expected:raise ValueError('离线音频原导入信息改变')
        for sid in record['segments']:
            m=materials[segments[sid]['material_id']]
            if Path(m['path']).resolve()!=Path(a['path']).resolve():raise ValueError('离线音频引用被替换')
            if m['duration']!=round(a['duration']*1_000_000):raise ValueError('离线音频原时长改变')
            if m['name']!='【素材丢失】'+a['name']:raise ValueError('离线音频未明确标记')
        offline.append(dict(asset=expected,source_segment_id=item['id'],native_segments=record['segments']))
    return offline
