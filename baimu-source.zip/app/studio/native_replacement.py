"""Prepare only proven, still-linked Baimu originals for a video replacement."""
from pathlib import Path
from .media import probe
from .native_audio import extract_original
from .native_resources import file_hash


def prepare_originals(before,after,resources):
    previous={c['id']:c for c in before['clips']}
    assets={a['id']:a for a in after['assets']};extractions={};cache={}
    for clip in after['clips']:
        old=previous.get(clip['id'])
        if not old or old['asset_id']==clip['asset_id']:continue
        audio_id=before.get('native_links',{}).get(clip['id'],{}).get('linked_audio_id')
        if not audio_id:continue  # Deliberately independent recordings stay independent.
        audio=next(a for a in after['audios'] if a['id']==audio_id)
        prior_audio=next(a for a in before['audios'] if a['id']==audio_id)
        if prior_audio.get('source_asset_id')!=old['asset_id']:
            raise ValueError('关联原声已被单独替换，请先解除联动；未覆盖该声音')
        if 'dialogue' in before.get('track_locks',[]):raise ValueError('关联原声轨道已锁定')
        resources.mkdir(parents=True,exist_ok=True)
        source=assets[clip['asset_id']]
        if file_hash(Path(source['path']))!=source['sha256']:raise ValueError('新素材已在磁盘变化，请先更新素材登记')
        extraction=extract_original(source,clip,resources,cache,round(audio['out']*1e6))
        if extraction is None:raise ValueError('新视频没有原声，请先解除旧原声联动再仅替换画面')
        registered=next((a for a in after['assets'] if a.get('sha256')==extraction['file_sha256'] and Path(a['path']).is_file()),None)
        if not registered:
            registered=probe(Path(extraction['path']));after['assets'].append(registered)
        extraction['path']=registered['path']
        audio.update(asset_id=registered['id'],audio_stream=registered['audio_streams'][0]['index'],
                     source_asset_id=source['id'],source_audio_stream=extraction['source_stream'])
        extractions[audio_id]=extraction
        if file_hash(Path(source['path']))!=source['sha256']:raise ValueError('提取期间新素材发生变化，原工程未改动')
    return extractions
