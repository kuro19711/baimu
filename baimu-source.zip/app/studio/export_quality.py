"""Opt-in, spatial-only export enhancement. Never changes the edit/audio clock."""
from __future__ import annotations
import copy


HD_PROFILE_VERSION = 'spatial-hd-v1'
# A small edge-preserving spatial filter, not temporal blending/interpolation.
# Run at source resolution, then scale and sharpen before masks/subtitles.
HD_DENOISE = 'bilateral=sigmaS=1:sigmaR=0.025:planes=1'
HD_SHARPEN = 'unsharp=5:5:0.4:5:5:0'


def validate_export_options(kind, options):
    if not isinstance(options, dict):
        raise ValueError('导出选项必须是对象')
    value = options.get('enhance_hd', False)
    if not isinstance(value, bool):
        raise ValueError('一键高清开关必须为 true 或 false')
    if value and kind not in ('draft', 'final'):
        raise ValueError('一键高清仅用于审阅版或正式成片导出；请先导出高清审阅版检查效果')
    return copy.deepcopy(options)


def export_profile(enhance_hd=False):
    if not isinstance(enhance_hd, bool):
        raise ValueError('一键高清开关必须为 true 或 false')
    return dict(enhance_hd=enhance_hd,
                profile=HD_PROFILE_VERSION if enhance_hd else 'standard',
                label='一键高清' if enhance_hd else '标准画质',
                encoder='libx264', preset='veryfast', crf=16 if enhance_hd else 18,
                denoise=HD_DENOISE if enhance_hd else None,
                scaling='lanczos' if enhance_hd else 'default',
                sharpen=HD_SHARPEN if enhance_hd else None,
                notice=('轻度空间降噪、高清缩放和细节锐化；非AI超分辨率，不补帧，不恢复原片缺失的细节。'
                        '字幕及白色打码在增强后叠加。请先导出审阅版检查人脸、细线和打码遮挡效果。'
                        if enhance_hd else '沿用原有导出画质。'))


def picture_filter(width, height, fps, enhance_hd=False):
    profile = export_profile(enhance_hd)
    scale = f'scale={width}:{height}:force_original_aspect_ratio=decrease'
    filters = []
    if enhance_hd:
        filters.append(profile['denoise'])
        scale += ':flags=lanczos'
    filters.append(scale)
    if enhance_hd:
        filters.append(profile['sharpen'])
    filters += [f'pad={width}:{height}:(ow-iw)/2:(oh-ih)/2', 'setsar=1', f'fps={fps}']
    return ','.join(filters)
