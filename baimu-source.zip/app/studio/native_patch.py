"""Small native edits operate on the authoritative full graph, never a projection."""
import copy,json,math,os,tempfile,time
from pathlib import Path
from .jianying_bridge import bridge
from .store import write_json
from .native_defaults import timerange

def patch_graph(content,operation):
    obj=copy.deepcopy(content);op=operation.get('type')
    segments={s['id']:s for t in obj['tracks'] for s in t.get('segments',[])}
    tracks={s['id']:t for t in obj['tracks'] for s in t.get('segments',[])}
    def unlocked(ids):
        if any(tracks[s].get('attribute',0)&4 for s in ids):
            raise ValueError('轨道已锁定，请先解锁再修改')
    if op=='move':
        sid=operation.get('segment_id');segment=segments.get(sid)
        if not segment:raise ValueError('片段不存在')
        value=operation.get('start_us')
        if isinstance(value,bool) or not isinstance(value,int) or not 0<=value<=86_400_000_000:raise ValueError('片段开始时间无效')
        old_end=max((sum(timerange(s['target_timerange']).values()) for s in segments.values()),default=0)
        old_duration=obj.get('duration',old_end)
        delta=value-timerange(segment['target_timerange'])['start'];members=[sid]
        gid=segment.get('group_id')
        if gid:
            groups=(obj.get('group_container') or {}).get('groups',[])
            found=[g for g in groups if g.get('id')==gid]
            if len(found)!=1 or not found[0].get('group_members'):raise ValueError('分组结构暂不能安全移动')
            members=found[0]['group_members']
            if sid not in members or any(m not in segments or segments[m].get('group_id')!=gid for m in members):raise ValueError('分组成员不完整，未移动')
        unlocked(members)
        for member in members:
            target=segments[member]['target_timerange'];start=timerange(target)['start']+delta
            if start<0:raise ValueError('联动片段不能移到时间线之前')
            target['start']=start
        end=max((sum(timerange(s['target_timerange']).values()) for s in segments.values()),default=0)
        obj['duration']=max(old_duration,end) if old_duration>old_end else end
        for track in obj['tracks']:track['segments'].sort(key=lambda s:timerange(s['target_timerange'])['start'])
    elif op=='volume':
        segment=segments.get(operation.get('segment_id'));value=operation.get('value')
        if not segment or not any(segment in t.get('segments',[]) and t['type'] in ('audio','video') for t in obj['tracks']):raise ValueError('请选择音频或视频片段')
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not 0<=value<=4:raise ValueError('线性音量应为0至4')
        unlocked([segment['id']])
        if tracks[segment['id']]['type']=='video' and segment.get('group_id'):
            groups=(obj.get('group_container') or {}).get('groups',[])
            group=next((g for g in groups if g.get('id')==segment['group_id']),None)
            if group and any(s in tracks and tracks[s]['type']=='audio' for s in group.get('group_members',[])):
                raise ValueError('画面已关联独立原声，请修改人物原声音轨的音量，避免重复播放')
        segment['volume']=value
    elif op=='simple_text':
        found=[m for m in obj['materials'].get('texts',[]) if m['id']==operation.get('material_id')]
        value=operation.get('new')
        if len(found)!=1 or not isinstance(value,str) or len(value)>20000:raise ValueError('字幕内容或素材无效')
        material=found[0]
        unlocked([s['id'] for s in segments.values() if s.get('material_id')==material['id']])
        if any(material.get(k) for k in ('words','text_to_audio_ids','recognize_task_id','base_content')):raise ValueError('智能识别或关联文字暂时只读保留')
        rich=json.loads(material['content']);old=rich.get('text')
        if old!=operation.get('old'):raise ValueError('字幕原文已改变，请重新读取')
        if any(old and old in json.dumps(v,ensure_ascii=False) for k,v in material.items() if k!='content'):
            raise ValueError('文字还存在关联表示，当前只读保留')
        styles=rich.get('styles',[])
        if len(styles)!=1 or styles[0].get('range') not in ([0,len(old)],[0,len(old.encode('utf-16-le'))//2]):raise ValueError('多段富文本暂时只读保留')
        utf16=styles[0]['range'][1]==len(old.encode('utf-16-le'))//2
        styles[0]['range']=[0,len(value.encode('utf-16-le'))//2 if utf16 else len(value)]
        rich['text']=value;material['content']=json.dumps(rich,ensure_ascii=False,separators=(',',':'))
    elif op=='font_size':
        value=operation.get('value')
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not 1<=value<=200:raise ValueError('原生字号应为1至200')
        found=[m for m in obj['materials'].get('texts',[]) if m['id']==operation.get('material_id')]
        if len(found)!=1:raise ValueError('字幕素材不存在')
        unlocked([s['id'] for s in segments.values() if s.get('material_id')==found[0]['id']])
        if any(found[0].get(k) for k in ('words','text_to_audio_ids','recognize_task_id','base_content')):raise ValueError('关联字幕样式暂时只读保留')
        rich=json.loads(found[0]['content'])
        if not rich.get('styles'):raise ValueError('字幕样式结构无法识别')
        for style in rich['styles']:style['size']=value
        found[0]['content']=json.dumps(rich,ensure_ascii=False,separators=(',',':'))
    else:raise ValueError('当前原生工程模式不支持该编辑操作')
    if obj==content:raise ValueError('参数没有变化')
    return obj

def save(service,body,transform=None,meta_updates=None):
    with service.lock:
        key=body['key']
        if service.pending_commits(key):raise ValueError('存在未完成提交，请先恢复')
        _,folder=service.resolve(key)
        cached=service.cache.get(key)
        state=copy.deepcopy(cached['state']) if cached and bridge.fingerprint(folder)['revision']==cached['state']['revision'] else bridge.load(folder,str(service.install))
        if body.get('revision')!=state['revision']:raise ValueError('工程已在另一边改变，请重新读取')
        original=state['documents'][state['main_mirrors'][0]]['object']
        operations=body.get('operations',[body.get('operation',{})])
        if not isinstance(operations,list) or not 1<=len(operations)<=100:
            raise ValueError('一次提交需要1至100条原生编辑操作')
        if transform is not None:obj=transform(original)
        else:
            obj=original
            for operation in operations:obj=patch_graph(obj,operation)
        box=service.root/'history'/key/str(time.time_ns());before=box/'before';prepared=box/'prepared'
        before.mkdir(parents=True);prepared.mkdir()
        for rel,sha in state['files'].items():
            raw=bridge.stable_bytes(folder/rel)
            if bridge.digest(raw)!=sha:raise ValueError('工程在备份期间发生变化')
            for root in (before,prepared):
                p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
        raw=json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode();encodings={}
        for rel in state['main_mirrors']:
            encoding=state['documents'][rel]['encoding']
            if encoding not in encodings:
                encoded=bridge.encrypt_draft_bytes(raw,jy_install_dir=str(service.install),timeout=30) if encoding=='jianying_local_dll' else raw
                check,actual=bridge.decode(encoded,str(service.install))
                if check!=obj or actual!=encoding:raise ValueError('原生字段往返核对失败')
                encodings[encoding]=encoded
            (prepared/rel).write_bytes(encodings[encoding])
        write_files=list(state['main_mirrors'])
        if meta_updates:
            rel='draft_meta_info.json'
            meta,encoding=bridge.decode((before/rel).read_bytes(),str(service.install))
            meta.update(meta_updates)
            raw=json.dumps(meta,ensure_ascii=False,separators=(',',':')).encode()
            encoded=bridge.encrypt_draft_bytes(raw,jy_install_dir=str(service.install),timeout=30) if encoding=='jianying_local_dll' else raw
            if bridge.decode(encoded,str(service.install))!=(meta,encoding):raise ValueError('草稿名称元信息往返核对失败')
            (prepared/rel).write_bytes(encoded);write_files.append(rel)
        report=dict(stage='prepared',key=key,source=str(folder),before_revision=state['revision'],
            backup=str(before),plan=dict(mirror_files=write_files,operations=operations),
            files=[],created=time.time(),changed_json_paths=bridge.changes(original,obj))
        journal=box/'commit.json';write_json(journal,report)
        if bridge.fingerprint(folder)['revision']!=state['revision']:raise ValueError('提交前工程已改变，未写入')
        report['stage']='committing';write_json(journal,report)
        expected_files=dict(state['files'])
        for rel in write_files:
            bridge.write_checked(folder,rel,(prepared/rel).read_bytes(),expected_files)
            report['files'].append(rel);write_json(journal,report)
        actual=bridge.fingerprint(folder)
        if actual['files']!=bridge.fingerprint(prepared)['files']:raise ValueError('保存结果改变，请恢复此次提交')
        report.update(stage='saved_awaiting_editor_review',after_revision=actual['revision']);write_json(journal,report)
        service.cache.pop(key,None);service._observed(key,actual['revision'])
        return dict(saved=True,backup=str(before),journal=str(journal),detail=service.inspect(key),
            message='已保存同一份原生工程；剪映重新打开即可读取。')
