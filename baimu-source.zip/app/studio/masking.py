"""Frame-accurate local rectangular masking for the picture stream.

Mask geometry is stored on a 1080x1920 canvas. Ordinary masks use position
keyframes; imported native rectangles may also animate width and height and may
extend beyond the canvas. Native feather is rendered as a spatially softened
matte while the original Jianying graph remains authoritative for round trips.
"""
from __future__ import annotations
import math
from .core import validate,timeline


def geometry_points(mask):
    result=[dict(time=mask['start'],x=mask['x'],y=mask['y'],w=mask['w'],h=mask['h'])]
    previous=result[0]
    for raw in mask.get('keyframes',[]):
        point=dict(previous,**raw);result.append(point);previous=point
    return result


def _value_expression(mask, field, scale):
    points=geometry_points(mask)
    expression=f'{points[0][field]*scale:.5f}'
    for left,right in zip(points,points[1:]):
        delta=(right[field]-left[field])*scale
        interval=right['time']-left['time']
        if abs(delta)<1e-9:continue
        # FFmpeg expression commas must be escaped inside the filter graph.
        ramp=f'min(max((t-{left["time"]:.6f})/{interval:.6f}\\,0)\\,1)'
        expression+=f'+({delta:.5f})*{ramp}'
    return expression


def visual_filter(project, output_width, subtitles=False):
    """Return an FFmpeg filter_complex_script ending in [visual]."""
    validate(project)
    scale=output_width/1080
    output_height=round(output_width*project['height']/project['width'])
    duration=timeline(project)[1]
    parts=[]
    incoming='0:v'
    subtitles_applied=False
    masks=sorted(project.get('masks',[]),key=lambda m:m.get('layer')=='above_captions')
    for index,mask in enumerate(masks):
        if subtitles and not subtitles_applied and mask.get('layer')=='above_captions':
            parts.append(f'[{incoming}]format=yuv420p,ass=captions.ass:fontsdir=fonts[captioned]')
            incoming='captioned';subtitles_applied=True
        points=geometry_points(mask)
        w=max(2,math.floor(mask['w']*scale+.5));h=max(2,math.floor(mask['h']*scale+.5))
        x=_value_expression(mask,'x',scale);y=_value_expression(mask,'y',scale)
        base=f'base{index}';sample=f'sample{index}';patch=f'patch{index}';output=f'picture{index}'
        enabled=f'gte(t\\,{mask["start"]:.6f})*lt(t\\,{mask["end"]:.6f})'
        advanced=mask.get('feather',0)>0 or any('w' in point or 'h' in point for point in mask.get('keyframes',[])) or any(
            point['x']<0 or point['y']<0 or point['x']+point['w']>1080 or point['y']+point['h']>1920 for point in points)
        if mask.get('mode','blur')=='solid':
            parts.append(f'[{incoming}]format=rgb24[{base}]')
            if not advanced:
                parts.append(f"color=c=white:s={w}x{h}:r={project['fps']}:d={duration:.6f},format=rgb24[{patch}]")
                parts.append(f"[{base}][{patch}]overlay=x='{x}':y='{y}':eval=frame:format=rgb:enable='{enabled}':eof_action=pass[{output}]")
            else:
                matte=f'matte{index}';width_expression=_value_expression(mask,'w',scale);height_expression=_value_expression(mask,'h',scale)
                parts.append(f"color=c=white:s={output_width}x{output_height}:r={project['fps']}:d={duration:.6f},format=rgb24[{patch}]")
                matte_filter=(f"color=c=black:s={output_width}x{output_height}:r={project['fps']}:d={duration:.6f},format=gray,"
                    f"drawbox=x='{x}':y='{y}':w='{width_expression}':h='{height_expression}':color=white:t=fill:enable='{enabled}'")
                if mask.get('feather',0)>0:
                    minimum=min(min(point['w'],point['h']) for point in points)*scale
                    matte_filter+=f',gblur=sigma={max(.1,mask["feather"]*minimum/6):.5f}'
                parts.append(f'{matte_filter}[{matte}]')
                parts.append(f'[{base}][{patch}][{matte}]maskedmerge=planes=7[{output}]')
        else:
            radius=max(1,min(math.floor(mask['blur']*scale+.5),output_width//2,output_height//2))
            lift=mask['white']*255
            effect=(f'boxblur=luma_radius={radius}:luma_power=2:chroma_radius={radius}:chroma_power=2,'
                    f"lutrgb=r='clip(val+{lift:.4f},0,255)':g='clip(val+{lift:.4f},0,255)':b='clip(val+{lift:.4f},0,255)'")
            parts.append(f'[{incoming}]format=gbrp,split=2[{base}][{sample}]')
            if not advanced:
                parts.append(f"[{sample}]crop={w}:{h}:x='{x}':y='{y}':exact=1,{effect}[{patch}]")
                parts.append(f"[{base}][{patch}]overlay=x='{x}':y='{y}':eval=frame:format=rgb:enable='{enabled}':eof_action=pass[{output}]")
            else:
                matte=f'matte{index}'
                width_expression=_value_expression(mask,'w',scale);height_expression=_value_expression(mask,'h',scale)
                parts.append(f'[{sample}]{effect}[{patch}]')
                matte_filter=(f"color=c=black:s={output_width}x{output_height}:r={project['fps']}:d={duration:.6f},format=gray,"
                    f"drawbox=x='{x}':y='{y}':w='{width_expression}':h='{height_expression}':color=white:t=fill:enable='{enabled}'")
                if mask.get('feather',0)>0:
                    minimum=min(min(point['w'],point['h']) for point in points)*scale
                    sigma=max(.1,mask['feather']*minimum/6)
                    matte_filter+=f',gblur=sigma={sigma:.5f}'
                parts.append(f'{matte_filter}[{matte}]')
                parts.append(f'[{base}][{patch}][{matte}]maskedmerge=planes=7[{output}]')
        incoming=output
    if subtitles and not subtitles_applied:
        parts.append(f'[{incoming}]format=yuv420p,ass=captions.ass:fontsdir=fonts[visual]')
    elif parts:
        parts.append(f'[{incoming}]format=yuv420p[visual]')
    else:
        parts.append('[0:v]null[visual]')
    return ';\n'.join(parts)+'\n'
