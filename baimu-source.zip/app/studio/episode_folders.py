"""Pure, deterministic folder-drop planning. No filesystem or network access.

Input paths include the dragged root folder, use '/' separators, and describe
files only. Client IDs are ignored. The upload layer must independently reject
real reparse points and verify received byte counts; a manifest cannot prove
that a source on another machine was not a link.
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections import defaultdict

from .core import AUDIO_EXT, VIDEO_EXT

MAX_FILES = 10000
MAX_EPISODES = 30
MAX_MEDIA_PER_EPISODE = 300
MAX_SAFE_INTEGER = 2**53-1
IGNORED_FOLDERS = {
    'venv', 'models', 'data', 'bin', 'cache', '__pycache__', 'node_modules',
    'site-packages', 'jobs', 'renders', 'history', 'trash', 'recovery',
    'batches', 'test-output', '__macosx', '$recycle.bin', 'system volume information',
}
DEVICE_NAMES = {'con', 'prn', 'aux', 'nul', 'clock$', 'conin$', 'conout$'} | {
    prefix+number for prefix in ('com', 'lpt') for number in ('1','2','3','4','5','6','7','8','9','¹','²','³')
}
CN_DIGITS = dict(zip('零〇一二三四五六七八九两', (0,0,1,2,3,4,5,6,7,8,9,2)))
CN_UNITS = {'十':10, '百':100, '千':1000}
NUMBER = r'(?:[0-9]{1,4}|[零〇一二三四五六七八九十百千两]{1,12})'


def _canonical(value):
    return unicodedata.normalize('NFC', value).casefold()


def _stable_id(kind, value):
    return hashlib.sha256((kind+'\0'+_canonical(value)).encode('utf-8')).hexdigest()[:32]


def _natural(value):
    return [int(part) if part.isdigit() else part for part in re.split(r'([0-9]+)', _canonical(value))]


def _component(value):
    if not value or value in ('.','..') or value[-1] in (' ','.') or len(value)>255:
        raise ValueError('文件夹或文件名无效：不允许空名称、..、末尾空格/点或超过255字')
    if any(ch in '<>:"/\\|?*' or unicodedata.category(ch) in ('Cc','Cs') for ch in value):
        raise ValueError('相对路径包含Windows非法字符、控制字符、盘符或路径分隔符')
    if _canonical(value.split('.',1)[0]) in DEVICE_NAMES:
        raise ValueError('相对路径使用Windows保留名称：'+value)


def validate_relative_path(value):
    """Reject ambiguity instead of normalizing away traversal/drive syntax."""
    if not isinstance(value,str) or len(value)>2048 or '\\' in value or value.startswith('/'):
        raise ValueError('请提供使用正斜杠的相对文件路径，不能包含绝对路径、反斜杠或UNC路径')
    parts=value.split('/')
    if len(parts)<2 or len(parts)>40:
        raise ValueError('文件必须位于拖入的根文件夹内，路径层级不能超过40层')
    for part in parts:_component(part)
    return parts


def _integer(value, label):
    if isinstance(value,bool) or not isinstance(value,int) or not 0<=value<=MAX_SAFE_INTEGER:
        raise ValueError(label+'必须是非负安全整数')
    return value


def _chinese_number(value):
    if value.isascii() and value.isdigit():return int(value)
    if not any(ch in CN_UNITS for ch in value):
        return int(''.join(str(CN_DIGITS[ch]) for ch in value))
    total,digit,last_unit=0,None,10000
    for ch in value:
        if ch in CN_DIGITS:
            # Zero is a separator, not a multiplier; consecutive nonzero
            # digits in a unit-based numeral would be ambiguous.
            number=CN_DIGITS[ch]
            if digit not in (None,0) and number!=0:raise ValueError('中文集数格式不明确')
            digit=number
        else:
            unit=CN_UNITS[ch]
            if unit>=last_unit or digit==0:raise ValueError('中文集数单位顺序无效')
            total+=(1 if digit is None else digit)*unit
            digit=None;last_unit=unit
    return total+(digit or 0)


def episode_name(name):
    """Return (number, optional series prefix), using directory names only."""
    value=name.strip()
    if re.fullmatch(r'[0-9]{1,4}', value):return int(value),''
    match=re.fullmatch(r'(.*?)第\s*('+NUMBER+r')\s*[集话話回](?:\s+.+)?',value)
    if match:
        try:number=_chinese_number(match.group(2))
        except (ValueError,KeyError):return None
        if number<=9999:return number,match.group(1).strip(' _-.·')
    match=re.fullmatch(r'(?:([^\r\n]+?)\s+)?(?:episode|ep)[ _.-]*([0-9]{1,4})(?:\s+.+)?',value,re.I)
    if match:return int(match.group(2)),(match.group(1) or '').strip(' _-.·')
    return None


def _series(folder_parts, parsed):
    if parsed and parsed[1]:return parsed[1]
    for parent in reversed(folder_parts[:-1]):
        if episode_name(parent) is None:return parent
    return ''


def preview_episode_folders(files, root_names=None, allow_audio_only=False):
    """Plan episodes without scanning/probing/importing any local path.

    files: [{relative_path, size, last_modified?}], roots: optional root-name list.
    normalized_files includes only media assigned to an importable episode.
    Unknown directory names remain separate manual-selection candidates; they
    are never guessed from clip filenames or automatically merged by number.
    """
    if not isinstance(files,list) or len(files)>MAX_FILES:
        raise ValueError('一次最多提供10000个文件，请选择更具体的剧集目录')
    explicit_roots=root_names is not None
    if explicit_roots and (not isinstance(root_names,list) or len(root_names)>MAX_FILES):
        raise ValueError('根文件夹列表无效')
    roots={}
    if explicit_roots:
        for name in root_names:
            if not isinstance(name,str):raise ValueError('根文件夹名称必须是文本')
            _component(name)
            canonical=_canonical(name)
            if canonical in roots:raise ValueError('拖入的根文件夹重名或大小写冲突，请分别导入或选择它们的上级剧名目录')
            roots[canonical]=name
    prefixes={}
    paths=set()
    directory_paths=set()
    groups=defaultdict(list)
    parsed_folders={}
    skipped=[]
    for record in files:
        if not isinstance(record,dict):raise ValueError('文件清单项目必须是对象')
        path=record.get('relative_path')
        parts=validate_relative_path(path)
        size=_integer(record.get('size'),'文件大小')
        modified=_integer(record.get('last_modified',0),'文件修改时间')
        if any(record.get(flag) for flag in ('is_symlink','is_junction','is_reparse_point','reparse_point','symlink','junction')):
            raise ValueError('文件清单包含符号链接或目录联接，不能作为素材来源')
        if record.get('is_directory'):
            raise ValueError('清单只能包含文件，不能将文件夹当成文件上传')
        root_key=_canonical(parts[0])
        if explicit_roots:
            if root_key not in roots or roots[root_key]!=parts[0]:
                raise ValueError('文件不属于声明的根文件夹，或根文件夹大小写不一致')
        elif root_key in roots and roots[root_key]!=parts[0]:
            raise ValueError('根文件夹大小写或Unicode名称冲突')
        else:roots[root_key]=parts[0]
        canonical=_canonical(path)
        if canonical in paths:raise ValueError('文件路径重复或大小写/Unicode冲突：'+path)
        if canonical in directory_paths:raise ValueError('同一路径同时被声明为文件和文件夹：'+path)
        paths.add(canonical)
        for depth in range(1,len(parts)+1):
            prefix='/'.join(parts[:depth]);key=_canonical(prefix)
            if key in prefixes and prefixes[key]!=prefix:
                raise ValueError('目录路径大小写或Unicode名称冲突：'+prefix)
            prefixes[key]=prefix
            if depth<len(parts):
                if key in paths:raise ValueError('文件路径被用作另一个文件的父文件夹：'+prefix)
                directory_paths.add(key)
        if any(part.startswith('.') or _canonical(part) in IGNORED_FOLDERS for part in parts):
            skipped.append(dict(relative_path=path,reason='隐藏、软件或缓存文件已跳过'));continue
        extension='.'+parts[-1].rsplit('.',1)[-1].lower() if '.' in parts[-1] else ''
        if extension not in VIDEO_EXT|AUDIO_EXT:
            skipped.append(dict(relative_path=path,reason='不是支持的视频或音频素材'));continue
        if size==0:
            skipped.append(dict(relative_path=path,reason='文件为空，不能作为视频或音频素材'));continue
        parents=parts[:-1]
        recognized=[(i,episode_name(part)) for i,part in enumerate(parents)]
        recognized=[pair for pair in recognized if pair[1] is not None]
        depth,parsed=recognized[-1] if recognized else (len(parents)-1,None)
        folder_parts=parents[:depth+1]
        folder='/'.join(folder_parts)
        parsed_folders[folder]=(folder_parts,parsed)
        groups[folder].append(dict(id=_stable_id('file',path),relative_path=path,size=size,last_modified=modified,
                                  kind='video' if extension in VIDEO_EXT else 'audio'))
    episodes=[];normalized=[];warnings=[]
    for folder,entries in groups.items():
        videos=sum(item['kind']=='video' for item in entries)
        if not videos and not allow_audio_only:
            skipped.extend(dict(relative_path=item['relative_path'],reason='该目录分组没有视频；音频可稍后手动添加到剧集') for item in entries)
            continue
        if len(entries)>MAX_MEDIA_PER_EPISODE:raise ValueError(folder+'超过每集300个媒体文件的上限')
        folder_parts,parsed=parsed_folders[folder]
        number=parsed[0] if parsed else None
        eid=_stable_id('episode',folder)
        ordered=sorted(entries,key=lambda item:_natural(item['relative_path']))
        episodes.append(dict(id=eid,source_folder=folder,name=f'第{number:02d}集' if number is not None else folder_parts[-1],
                             episode_number=number,series=_series(folder_parts,parsed),
                             file_ids=[item['id'] for item in ordered],video_count=videos,audio_count=len(entries)-videos,
                             needs_selection=parsed is None))
        normalized.extend(dict(id=item['id'],relative_path=item['relative_path'],size=item['size'],
                               last_modified=item['last_modified'],episode_id=eid) for item in ordered)
        if parsed is None:
            warnings.append(folder+' 未识别到集数，保留原目录名称，请明确勾选；不会根据视频文件名猜集数')
    if len(episodes)>MAX_EPISODES and not allow_audio_only:raise ValueError('一次最多30集，请缩小拖入的目录范围')
    folders={episode['source_folder'] for episode in episodes}
    for episode in episodes:
        folder=episode['source_folder']
        children=[other for other in folders if other.startswith(folder+'/')]
        if children:
            warnings.append(folder+' 同时有本层视频和子集目录，已分开保留，不会把本层视频静默遗漏或重复分配')
    same_numbers=defaultdict(list)
    for episode in episodes:
        if episode['episode_number'] is not None:
            same_numbers[(_canonical(episode['series']),episode['episode_number'])].append(episode['source_folder'])
    for paths_for_number in same_numbers.values():
        if len(paths_for_number)>1:
            warnings.append('多个物理目录使用相同集数，仍保持独立，请确认：'+'、'.join(sorted(paths_for_number,key=_natural)))
    episodes.sort(key=lambda item:(_natural(item['series']),item['episode_number'] is None,
                                   item['episode_number'] if item['episode_number'] is not None else 0,
                                   _natural(item['source_folder'])))
    rank={episode['id']:index for index,episode in enumerate(episodes)}
    normalized.sort(key=lambda item:(rank[item['episode_id']],_natural(item['relative_path'])))
    normalized_roots=sorted(roots.values(),key=_natural)
    total=sum(item['size'] for item in normalized)
    if total>MAX_SAFE_INTEGER:raise ValueError('文件总大小超过安全整数范围')
    fingerprint=hashlib.sha256(json.dumps(dict(version=1,roots=normalized_roots,files=normalized),
                                         sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf-8')).hexdigest()
    return dict(episodes=episodes,normalized_files=normalized,roots=normalized_roots,
                fingerprint=fingerprint,total_size=total,warnings=list(dict.fromkeys(warnings)),skipped=skipped)
