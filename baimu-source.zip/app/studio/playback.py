"""Find a playable output without enqueueing new rendering work."""
from .core import digest,sound_digest

def select_playback(store,jobs,pid,mix_only=False,export_only=False):
    project=store.get(pid);full=digest(project);sound=sound_digest(project);candidates=[]
    for job in list(jobs.items.values()):
        if job['project_id']!=pid or job['state']!='complete' or job['kind'] not in ('draft','final','preview'):continue
        result=job.get('result',{});filename=result.get('file')
        if filename not in ('film.mp4','preview.mp4'):continue
        if not (store.root/'renders'/job['id']/filename).is_file():continue
        burned=result.get('captions_burned') is True
        if export_only and job['kind'] not in ('draft','final'):continue
        current=result.get('project_hash')==full if burned else result.get('sound_digest')==sound
        if mix_only and (burned or not current):continue
        # Current audio with live captions is preferable to an outdated burned film.
        priority=0 if burned and current else 1 if current else 2 if burned else 3
        candidates.append((priority,-job['created'],job,current))
    if not candidates:return dict(job=None,current=False)
    _,_,job,current=min(candidates,key=lambda c:(c[0],c[1]))
    return dict(job=jobs.public(job,detail=True),current=current)
