"""Font-face calibration for Baimu's 1080-reference em pixels.

No global numeric factor is called calibrated without a saved native comparison.
Profiles live outside source projects and are copied into each migration map.
"""
import hashlib,json,math
from pathlib import Path
from functools import lru_cache


FONT_IDENTITY='sfnt_tables_ignore_volatile_head_v1'
JY_OUTLINE_PER_1080PX=5
JY_STROKE_WIDTH_PER_PANEL_UNIT=.002
LAYOUT_METHOD='explicit_lines_text_v1'


def layout(text,font_path,style):
    """Resolve wrapping once; Jianying receives ordinary text with hard breaks.

    Keep fitting lines byte-for-byte, including deliberate spaces and blank
    lines. Only overlong lines use the same font measurement as local export.
    The source is recorded separately so a round trip never edits the script.
    """
    from PIL import ImageFont
    from .core import wrap_text
    font=ImageFont.truetype(str(font_path),round(style['font_size']))
    limit=1080*style.get('max_width',84)/100;spacing=style.get('spacing',0)
    def fits(line):return font.getlength(line)+max(0,len(line)-1)*spacing<=limit
    resolved='\n'.join(line if fits(line) else wrap_text(line,font_path,style['font_size'],limit,spacing)
                       for line in text.split('\n'))
    return dict(schema=1,method=LAYOUT_METHOD,source_text=text,native_text=resolved)


def source_text(text,record):
    """Recover source only while the generated native text is still intact."""
    saved=record.get('native_layout_mapping',{})
    if saved.get('schema')==1 and saved.get('method')==LAYOUT_METHOD and saved.get('native_text')==text:
        return saved.get('source_text',text)
    return text


def legacy_layout(material,segment,record):
    """Upgrade only provable old Baimu auto-layout, never arbitrary native text."""
    if record.get('native_layout_mapping') or not record.get('native_font_mapping'):return False
    if material.get('type')!='subtitle' or material.get('typesetting',0)!=0 or material.get('alignment',1)!=1:return False
    if segment.get('common_keyframes') or (segment.get('clip') or {}).get('rotation',0):return False
    if any(not math.isclose(((segment.get('clip') or {}).get('scale') or {}).get(a,1),1) for a in ('x','y')):return False
    rich=json.loads(material['content']);styles=rich.get('styles',[])
    if len(styles)!=1 or styles[0].get('effectStyle'):return False
    style=record.get('source_style',{})
    pairs=((styles[0].get('size'),record['native_font_mapping'].get('native_font_size')),
           (material.get('line_max_width',.84),style.get('max_width',84)/100),
           (material.get('letter_spacing',0),style.get('spacing',0)*.05),
           (material.get('line_spacing',.02),.02+style.get('line_spacing',0)*.05))
    return all(isinstance(a,(int,float)) and isinstance(b,(int,float)) and math.isclose(a,b,rel_tol=1e-7,abs_tol=1e-9) for a,b in pairs)


def jianying_outline(canvas_pixels):
    """Convert Baimu's 1080-canvas outline radius to Jianying's panel value."""
    return canvas_pixels*JY_OUTLINE_PER_1080PX


def canvas_outline(panel_value):
    """Convert Jianying's panel value back to Baimu's 1080-canvas pixels."""
    return panel_value/JY_OUTLINE_PER_1080PX


def outline_conversion(canvas_pixels):
    panel=jianying_outline(canvas_pixels)
    return dict(schema=1,method='jianying_panel_visual_calibration',source_outline_1080px=canvas_pixels,
                native_panel_value=panel,native_stroke_width=panel*JY_STROKE_WIDTH_PER_PANEL_UNIT)


def font_hash(path):
    path=Path(path).resolve();stat=path.stat()
    return _font_hash(str(path),stat.st_size,stat.st_mtime_ns)


@lru_cache(maxsize=128)
def _font_hash(path,size,modified):
    """Keep glyphs/metrics/styles exact while ignoring font-save timestamps.

    Store.import_font reserializes the renamed application copy on startup.
    Its head.modified and checkSumAdjustment change even for the same face.
    Every other byte of every SFNT table remains part of this identity.
    """
    from fontTools.ttLib import TTFont
    face=TTFont(str(path),lazy=True,recalcTimestamp=False)
    digest=hashlib.sha256(FONT_IDENTITY.encode())
    try:
        for tag in sorted(face.reader.keys()):
            raw=face.reader[tag]
            if tag=='head':raw=raw[:8]+b'\0'*4+raw[12:20]+b'\0'*16+raw[36:]
            digest.update(tag.encode('ascii'));digest.update(len(raw).to_bytes(8,'big'));digest.update(raw)
    finally:face.close()
    return digest.hexdigest()


def calibration(store,font_path):
    """Return the same font profile used by native export for UI unit conversion."""
    digest=font_hash(font_path);candidate=None
    # A clean installation must retain the validated default; local profiles
    # can override it without modifying a source project or bundled asset.
    for path in (Path(__file__).resolve().parents[1]/'assets/jianying/font_calibrations.json',
                 store.root/'jianying/font_calibrations.json'):
        if not path.is_file():continue
        data=json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(data,dict) or data.get('schema')!=1 or not isinstance(data.get('fonts'),dict):
            raise ValueError('字幕字号标定记录无效，请重新标定')
        if digest in data['fonts']:candidate=data['fonts'][digest]
    if candidate:
        ratio=candidate.get('native_units_per_1080px')
        width=candidate.get('canvas_width',0);height=candidate.get('canvas_height',0)
        if candidate.get('verified') is not True or not isinstance(ratio,(int,float)) or not math.isfinite(ratio) or not 0<ratio<1 or any(not isinstance(v,(int,float)) or not math.isfinite(v) or v<=0 for v in (width,height)):
            raise ValueError('字幕字号标定记录尚未验证或参数无效')
    return digest,candidate


def public_calibration(store,font_path):
    """Expose native-size units without exposing a font fingerprint or local path."""
    _,profile=calibration(store,font_path)
    if profile:
        return dict(verified=True,native_units_per_1080px=profile['native_units_per_1080px'],
                    canvas_width=profile['canvas_width'],canvas_height=profile['canvas_height'])
    return dict(verified=False,native_units_per_1080px=1/8,canvas_width=1080,canvas_height=1920)


def conversion(store,project,style,font_path):
    digest,candidate=calibration(store,font_path);profile=None
    if candidate:
        width=candidate['canvas_width'];height=candidate['canvas_height']
        if math.isclose(width/height,project['width']/project['height'],abs_tol=1e-9):profile=candidate
    ratio=profile['native_units_per_1080px'] if profile else 1/8
    return dict(schema=1,source_font_sha256=digest,font_identity_algorithm=FONT_IDENTITY,source_font_size_px=style['font_size'],
        native_font_size=style['font_size']*ratio,
        method='native_font_face_calibration' if profile else 'legacy_unverified',calibration=profile)


def verify(style,material,segment,record):
    mapping=record.get('native_font_mapping')
    if not mapping:return
    algorithm=mapping.get('font_identity_algorithm')
    if algorithm is None:identity=hashlib.sha256(Path(material['font_path']).read_bytes()).hexdigest()
    elif algorithm==FONT_IDENTITY:identity=font_hash(material['font_path'])
    else:raise ValueError('字幕字号核对失败：未知字体指纹格式')
    if identity!=mapping['source_font_sha256']:
        raise ValueError('字幕字号核对失败：字体文件改变')
    if mapping['source_font_size_px']!=style['font_size']:
        raise ValueError('字幕字号核对失败：源字号改变')
    profile=mapping.get('calibration')
    ratio=profile['native_units_per_1080px'] if profile else 1/8
    expected=style['font_size']*ratio
    if not math.isclose(mapping['native_font_size'],expected,abs_tol=1e-12):
        raise ValueError('字幕字号核对失败：换算记录不一致')
    rich=json.loads(material['content'])
    if not rich.get('styles') or any(not math.isclose(s['size'],expected,rel_tol=1e-12,abs_tol=1e-12) for s in rich['styles']):
        raise ValueError('字幕字号核对失败：原生字号改变')
    scale=segment.get('clip',{}).get('scale',{})
    if any(not math.isclose(scale.get(axis,1),1,abs_tol=1e-12) for axis in ('x','y')):
        raise ValueError('字幕字号核对失败：字幕片段额外缩放')
    outline=record.get('native_outline_mapping')
    if outline:
        expected=outline_conversion(style.get('outline',0))
        for key in ('source_outline_1080px','native_panel_value','native_stroke_width'):
            if not math.isclose(outline.get(key,-1),expected[key],rel_tol=1e-12,abs_tol=1e-12):
                raise ValueError('字幕描边核对失败：换算记录不一致')
        strokes=rich['styles'][0].get('strokes',[])
        if (style.get('outline',0)>0)!=(len(strokes)==1):
            raise ValueError('字幕描边核对失败：原生描边缺失或多余')
        if strokes and not math.isclose(strokes[0].get('width',-1),expected['native_stroke_width'],rel_tol=1e-12,abs_tol=1e-12):
            raise ValueError('字幕描边核对失败：原生描边宽度改变')
