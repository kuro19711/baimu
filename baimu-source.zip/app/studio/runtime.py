"""Paths shared by the source checkout and the per-Windows-user distribution."""
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]


def is_bundle(root=ROOT):
    root = Path(root)
    return (root.parent/'bundle.json').is_file() and (root.parent/'runtime/python.exe').is_file()


def data_directory(root=ROOT):
    root = Path(root)
    override = os.environ.get('MUXU_DATA_DIR')
    if override:
        return Path(override).expanduser().resolve()
    if is_bundle(root):
        local = os.environ.get('LOCALAPPDATA')
        if not local:
            raise RuntimeError('无法找到当前 Windows 用户目录，请使用正常登录的 Windows 账号启动。')
        return Path(local)/'MuXuStudio'/'data'
    return root/'data'


def python_executable(root=ROOT, windowed=False):
    root = Path(root)
    name = 'pythonw.exe' if windowed else 'python.exe'
    return root.parent/'runtime'/name if is_bundle(root) else root/'.venv'/'Scripts'/name


def default_model(root=ROOT):
    root = Path(root)
    return (root.parent if is_bundle(root) else root)/'models'/'faster-whisper-tiny'
