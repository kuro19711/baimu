"""Paths shared by the source checkout and the per-Windows-user distribution."""
from pathlib import Path
import os
import json

ROOT = Path(__file__).resolve().parents[1]


def is_bundle(root=ROOT):
    root = Path(root)
    return (root.parent/'bundle.json').is_file() and (root.parent/'runtime/python.exe').is_file()


def data_directory(root=ROOT):
    root = Path(root)
    override = os.environ.get('BAIMU_DATA_DIR') or os.environ.get('MUXU_DATA_DIR')
    if override:
        return Path(override).expanduser().resolve()
    if is_bundle(root):
        local = os.environ.get('LOCALAPPDATA')
        if not local:
            raise RuntimeError('无法找到当前 Windows 用户目录，请使用正常登录的 Windows 账号启动。')
        for name in ('Baimu', 'MuXuStudio'):
            record = Path(local)/name/'installation.json'
            if record.is_file():
                value = json.loads(record.read_text(encoding='utf-8-sig'))
                if value.get('data'):
                    return Path(value['data']).expanduser().resolve()
        for name in ('Baimu', 'MuXuStudio'):
            candidate = Path(local)/name/'data'
            if candidate.is_dir():
                return candidate.resolve()
        return Path(local)/'Baimu'/'data'
    return root/'data'


def python_executable(root=ROOT, windowed=False):
    root = Path(root)
    name = 'pythonw.exe' if windowed else 'python.exe'
    return root.parent/'runtime'/name if is_bundle(root) else root/'.venv'/'Scripts'/name


def default_model(root=ROOT):
    root = Path(root)
    return (root.parent if is_bundle(root) else root)/'models'/'faster-whisper-tiny'
