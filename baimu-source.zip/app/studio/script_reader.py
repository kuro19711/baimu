"""Bounded, read-only script extraction and conservative episode segmentation.

All inputs/outputs stay in memory. A heading boundary is not evidence that an
episode is complete. The caller should run extraction in a time-limited worker
(PDF parsers cannot impose a reliable wall-clock budget in this function).
"""
from __future__ import annotations

import hashlib
import io
import re
import stat
import unicodedata
import zipfile
from collections import Counter
from pathlib import PurePosixPath
from xml.etree import ElementTree as ET

MAX_INPUT_BYTES = 16 * 1024 * 1024
MAX_TEXT_CHARS = 1_000_000
MAX_PDF_PAGES = 500
MAX_SECTIONS = 1000
MAX_ZIP_MEMBERS = 2000
MAX_ZIP_EXPANDED_BYTES = 64 * 1024 * 1024
MAX_ZIP_MEMBER_BYTES = 16 * 1024 * 1024
WORD_NAMESPACES = {
    'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'http://purl.oclc.org/ooxml/wordprocessingml/main',
}
CN_DIGITS = dict(zip('零〇一二三四五六七八九两', (0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 2)))
CN_UNITS = {'十': 10, '百': 100, '千': 1000}
CN_NUMBER = r'(?:[0-9]{1,4}|[零〇一二三四五六七八九十百千两]{1,12})'
EOF_WARNING = '此片段到达文件结尾；文件结束不证明本集完整，请核对末尾台词与剧本范围。'


def _source_name(name):
    if not isinstance(name, str) or not name.strip() or len(name) > 2048 or '\x00' in name:
        raise ValueError('请提供有效的剧本文件名')
    return name.replace('\\', '/').rsplit('/', 1)[-1]


def _text(value, *, empty_message='剧本没有可读取的正文文字'):
    if not isinstance(value, str):
        raise ValueError('剧本文本格式无效')
    if len(value) > MAX_TEXT_CHARS:
        raise ValueError('剧本文字超过100万字符，请按剧名或集数拆分后导入')
    if any((unicodedata.category(ch) in ('Cc', 'Cs') and ch not in '\r\n\t\f')
           or ch == '\ufffd' for ch in value):
        raise ValueError('剧本文字包含乱码替代符或不支持的控制字符，请重新保存为UTF-8文字版')
    value = value.replace('\r\n', '\n').replace('\r', '\n')
    if not value.strip():
        raise ValueError(empty_message)
    return value


def _decode_text(data):
    warnings = []
    if data.startswith((b'\xff\xfe\x00\x00', b'\x00\x00\xfe\xff')):
        raise ValueError('不支持UTF-32，请另存为UTF-8或带BOM的UTF-16文本')
    if data.startswith(b'\xef\xbb\xbf'):
        encoding = 'utf-8-sig'
    elif data.startswith((b'\xff\xfe', b'\xfe\xff')):
        encoding = 'utf-16'
    elif b'\x00' in data:
        # BOM-less ASCII-containing UTF-16 has a strong alternating-zero signal.
        # Other binary/NUL-containing inputs must not be guessed as plain text.
        sample = data[:4096]
        even, odd = sample[::2], sample[1::2]
        rates = (even.count(0) / max(1, len(even)), odd.count(0) / max(1, len(odd)))
        if len(data) % 2 or max(rates) < .25 or min(rates) > .1:
            raise ValueError('无法可靠识别文字编码，请另存为UTF-8或带BOM的UTF-16文本')
        encoding = 'utf-16-le' if rates[1] > rates[0] else 'utf-16-be'
        warnings.append('文本未带编码标记，依据字节结构按UTF-16读取；请核对文字，推荐另存为UTF-8。')
    else:
        try:
            return _text(data.decode('utf-8', errors='strict')), warnings
        except UnicodeDecodeError:
            encoding = 'gb18030'
            warnings.append('文本不是UTF-8，已严格按GB18030解码；编码推定不能证明文字正确，请核对人名和重音字符。')
    try:
        return _text(data.decode(encoding, errors='strict')), warnings
    except UnicodeDecodeError as exc:
        raise ValueError('剧本编码无效；未用替代字符修补，请另存为UTF-8文本后重试') from exc


def _pdf(data):
    from pypdf import PdfReader
    try:
        reader = PdfReader(io.BytesIO(data), strict=True)
        if reader.is_encrypted:
            raise ValueError('PDF已加密，请提供已解密且可复制文字的版本')
        count = len(reader.pages)
        if not 1 <= count <= MAX_PDF_PAGES:
            raise ValueError('PDF页数必须为1至500页，请分卷后导入')
        pages, blank, size = [], [], 0
        for index, page in enumerate(reader.pages, 1):
            value = page.extract_text() or ''
            if not isinstance(value, str):
                raise ValueError('PDF文字提取返回无效数据')
            size += len(value) + (3 if pages else 0)
            if size > MAX_TEXT_CHARS:
                raise ValueError('剧本文字超过100万字符，请按集数拆分PDF')
            if not value.strip():
                blank.append(index)
            pages.append(value)
        text = _text('\n\f\n'.join(pages), empty_message='PDF未提取到文字，可能是扫描版；请先OCR或提供可复制文字的剧本。')
        warnings = ['PDF文字提取不等同于版面校对；请核对阅读顺序、缺字和每集首尾，不会自动认定剧本完整。']
        if blank:
            warnings.append('PDF共%d页，第%s页没有提取到文字（可能为空白页或扫描页）；这些页需要人工核对/OCR，未静默视为完整。'
                            % (count, '、'.join(map(str, blank))))
        return dict(text=text, warnings=warnings, pages=count)
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError('PDF无法安全读取，请重新导出可复制文字的PDF或UTF-8文本：' + str(exc)) from exc


def _local(tag):
    return tag.rsplit('}', 1)[-1]


def _xml(data, name):
    # Also catches UTF-16/32 declarations without relying on an XML decoder.
    simplified = data.replace(b'\x00', b'')
    if re.search(br'<!\s*(?:DOCTYPE|ENTITY)\b', simplified, re.I):
        raise ValueError('DOCX包含DTD或实体声明，已拒绝解析：' + name)
    try:
        return ET.fromstring(data)
    except (ET.ParseError, ValueError) as exc:
        raise ValueError('DOCX内部XML损坏：' + name) from exc


def _paragraph(element):
    values = []

    def visit(node):
        kind = _local(node.tag)
        if kind in ('del', 'moveFrom'):
            return
        if kind == 't':
            values.append(node.text or '')
        elif kind == 'tab':
            values.append('\t')
        elif kind in ('br', 'cr', 'lastRenderedPageBreak'):
            page = kind == 'lastRenderedPageBreak' or any(_local(k) == 'type' and v == 'page' for k, v in node.attrib.items())
            values.append('\f' if page else '\n')
        else:
            for child in node:
                visit(child)

    visit(element)
    return ''.join(values)


def _blocks(element):
    """Traverse body wrappers and tables in document order without double reading."""
    for child in element:
        kind = _local(child.tag)
        if kind in ('del', 'moveFrom', 'sectPr'):
            continue
        if kind == 'p':
            yield _paragraph(child)
        elif kind == 'tbl':
            for row in _table_parts(child, 'tr'):
                yield '\t'.join('\n'.join(_blocks(cell)) for cell in _table_parts(row, 'tc'))
        else:
            yield from _blocks(child)


def _table_parts(element, wanted):
    for child in element:
        kind = _local(child.tag)
        if kind == wanted:
            yield child
        elif kind not in ('del', 'moveFrom', 'tbl', 'tc', 'tr', 'p'):
            # Structured document tags can wrap rows/cells. Do not accidentally
            # recurse into nested tables, which are read separately in the cell.
            yield from _table_parts(child, wanted)


def _docx(data):
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            members = archive.infolist()
            if len(members) > MAX_ZIP_MEMBERS:
                raise ValueError('DOCX内部文件超过2000项，已拒绝展开')
            seen, total = set(), 0
            for member in members:
                name = member.filename
                parts = name.rstrip('/').split('/')
                canonical = unicodedata.normalize('NFC', name.rstrip('/')).casefold()
                if (not name or name != member.orig_filename or name.startswith('/') or '\\' in name or ':' in name
                        or any(part in ('', '.', '..') for part in parts)
                        or canonical in seen or len(parts) > 40):
                    raise ValueError('DOCX内部路径无效或重复，已拒绝解析')
                seen.add(canonical)
                if member.flag_bits & 1 or stat.S_ISLNK(member.external_attr >> 16):
                    raise ValueError('DOCX包含加密条目或符号链接，已拒绝解析')
                if member.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                    raise ValueError('DOCX使用不支持的压缩方式')
                total += member.file_size
                if member.file_size > MAX_ZIP_MEMBER_BYTES or total > MAX_ZIP_EXPANDED_BYTES:
                    raise ValueError('DOCX展开大小超过安全限额（单项16MiB、合计64MiB）')
            if 'word/document.xml' not in archive.namelist() or '[Content_Types].xml' not in archive.namelist():
                raise ValueError('DOCX缺少正文或内容类型文件，请重新保存为标准DOCX')
            document = None
            for member in members:
                name = member.filename
                if not (name.lower().endswith(('.xml', '.rels'))):
                    continue
                with archive.open(member) as handle:
                    raw = handle.read(MAX_ZIP_MEMBER_BYTES + 1)
                if len(raw) != member.file_size or len(raw) > MAX_ZIP_MEMBER_BYTES:
                    raise ValueError('DOCX展开字节数与声明不一致')
                root = _xml(raw, name)
                if name.lower().endswith('.rels'):
                    for relationship in root.iter():
                        target = relationship.attrib.get('Target', '').strip()
                        if (relationship.attrib.get('TargetMode', '').casefold() == 'external'
                                or target.startswith(('//', '\\', '/'))
                                or re.match(r'^[a-z][a-z0-9+.-]*:', target, re.I)):
                            raise ValueError('DOCX包含外部链接，已拒绝访问或解析，请提供无外链文字版')
                if name == 'word/document.xml':
                    document = root
            if document is None or not any(document.tag == '{' + ns + '}document' for ns in WORD_NAMESPACES):
                raise ValueError('DOCX正文命名空间无效')
            for node in document.iter():
                kind = _local(node.tag)
                if kind in ('altChunk', 'object', 'OLEObject'):
                    raise ValueError('DOCX包含嵌入式文档/对象，无法保证正文完整；请另存为普通文字版')
                instruction = (node.text or '') if kind == 'instrText' else ' '.join(node.attrib.values()) if kind == 'fldSimple' else ''
                if re.search(r'\b(?:HYPERLINK|INCLUDETEXT|INCLUDEPICTURE|DDEAUTO|DDE|LINK)\b', instruction, re.I):
                    raise ValueError('DOCX包含外部字段或动态链接，请转换为普通文字后导入')
            body = next((node for node in document if _local(node.tag) == 'body'), None)
            if body is None:
                raise ValueError('DOCX没有正文内容')
            pieces, size = [], 0
            for value in _blocks(body):
                size += len(value) + (1 if pieces else 0)
                if size > MAX_TEXT_CHARS:
                    raise ValueError('剧本文字超过100万字符，请分集保存DOCX')
                pieces.append(value)
            text = _text('\n'.join(pieces))
            warnings = []
            omitted = [member.filename for member in members
                       if re.fullmatch(r'word/(?:header\d*|footer\d*|footnotes|endnotes|comments)\.xml', member.filename, re.I)]
            if omitted:
                warnings.append('已按正文与表格顺序读取；页眉、页脚、脚注、尾注、批注没有混入台词，请核对其中是否有必要正文。')
            if any(_local(node.tag) in ('ins', 'del', 'moveFrom', 'moveTo', 'txbxContent') for node in document.iter()):
                warnings.append('DOCX含修订或文本框；已保留插入文字、忽略删除修订，阅读顺序与最终可见内容仍需人工核对。')
            return dict(text=text, warnings=warnings)
    except ValueError:
        raise
    except (zipfile.BadZipFile, RuntimeError, OSError, NotImplementedError) as exc:
        raise ValueError('DOCX压缩包无法安全读取，请重新保存为标准DOCX：' + str(exc)) from exc


def extract_script(name: str, data: bytes) -> dict:
    name = _source_name(name)
    if not isinstance(data, bytes) or not data:
        raise ValueError('剧本文件为空或内容不是字节数据')
    if len(data) > MAX_INPUT_BYTES:
        raise ValueError('剧本文件超过16MiB，请拆分后导入')
    extension = PurePosixPath(name).suffix.casefold()
    if extension in ('.txt', '.md'):
        text, warnings = _decode_text(data)
        return dict(text=text, warnings=warnings)
    if extension == '.pdf':
        return _pdf(data)
    if extension == '.docx':
        return _docx(data)
    raise ValueError('仅支持TXT、MD、可复制文字的PDF和DOCX剧本')


def _number(value):
    if value.isascii() and value.isdigit():
        return int(value)
    if not any(ch in CN_UNITS for ch in value):
        return int(''.join(str(CN_DIGITS[ch]) for ch in value))
    total, digit, last = 0, None, 10000
    for ch in value:
        if ch in CN_DIGITS:
            current = CN_DIGITS[ch]
            if digit not in (None, 0) and current:
                raise ValueError('中文集数格式不明确')
            digit = current
        else:
            unit = CN_UNITS[ch]
            if unit >= last or digit == 0:
                raise ValueError('中文集数单位顺序无效')
            total += (1 if digit is None else digit) * unit
            digit, last = None, unit
    return total + (digit or 0)


def _latin(value):
    return ''.join(ch for ch in unicodedata.normalize('NFKD', value) if not unicodedata.combining(ch)).casefold()


def _heading(line):
    value = line.strip()
    value = re.sub(r'^#{1,6}\s+', '', value)
    if value.startswith('**') and value.endswith('**'):
        value = value[2:-2].strip()
    if len(value) > 120:
        return None
    match = re.match(r'^第\s*(' + CN_NUMBER + r')\s*[集话話](.*)$', value)
    if match:
        try:
            number = _number(match[1])
        except (KeyError, ValueError):
            return None
        suffix = match[2]
    else:
        match = re.match(r'^(?:episode|episodio|capitulo|ep\.?)\s*([0-9]{1,4})(?![0-9])(.*)$', _latin(value))
        if not match:
            return None
        number, suffix = int(match[1]), match[2]
    if not 0 <= number <= 9999:
        return None
    explicit_separator = bool(re.match(r'^[:：\-–—|]', suffix.strip()))
    if suffix:
        if not re.match(r'^(?:\s|[:：\-–—|（(])', suffix) or len(suffix.strip()) > 80:
            return None
        # An explicit title separator permits real question/sentence titles.
        # Quoted dialogue and ordinary sentence tails remain body text.
        if re.search(r'["“”「」]', suffix):
            return None
        if not explicit_separator and (re.search(r'[!?。！？]', suffix)
                                       or (suffix.rstrip().endswith('.') and not re.search(r'\.{2,}', suffix))):
            return None
    toc = bool(re.search(r'\.{2,}|…{2,}|[·•]{2,}', suffix))
    weak_suffix = bool(suffix.strip()) and not explicit_separator and not toc
    return dict(number=number, title=line.strip(), toc=toc, weak_suffix=weak_suffix)


def _filename_number(name):
    stem = PurePosixPath(name).stem
    parsed = _heading(stem)
    if parsed:
        return parsed['number']
    # Only an explicit episode marker, not arbitrary digits in a video/name.
    match = re.search(r'(第\s*' + CN_NUMBER + r'\s*[集话話])\s*$', stem)
    if not match:
        match = re.search(r'(?<![a-z])((?:episode|epis[oó]dio|cap[ií]tulo|ep)\s*[0-9]{1,4})\s*$', stem, re.I)
    parsed = _heading(match[1]) if match else None
    return parsed['number'] if parsed else None


def _anchors(body):
    lines = [line.strip() for line in body.splitlines() if line.strip() and not re.fullmatch(r'\s*[0-9]{1,4}\s*', line)]
    if not lines:
        return '', ''
    return lines[0][:160], lines[-1][-160:]


def _section(text, source, offset, number, title, body, warnings=None, ambiguous=False):
    start, end = _anchors(body)
    identity = source + '\0' + str(offset) + '\0' + text
    return dict(id=hashlib.sha256(identity.encode('utf-8')).hexdigest()[:32], number=number,
                title=title, text=text, start_anchor='全文起点（待人工核实）',
                end_anchor='文档结尾（待核实）', body_start_excerpt=start, body_end_excerpt=end,
                warnings=list(warnings or []), ambiguous=ambiguous)


def split_script(text: str, source_name: str) -> dict:
    text = _text(text)
    source_name = _source_name(source_name)
    headings, offset = [], 0
    for line in text.splitlines(keepends=True):
        parsed = _heading(line)
        if parsed:
            headings.append(dict(parsed, offset=offset, body_offset=offset + len(line)))
            if len(headings) > MAX_SECTIONS:
                raise ValueError('剧本分段超过1000个，请拆分文件并核对是否误将目录当正文')
        offset += len(line)
    warnings = ['分集仅依据独立标题，不代表台词齐全；导入后须人工核对每集首尾，完整性不会自动通过。']
    if not headings:
        number = _filename_number(source_name)
        local = ['未找到明确的独立分集标题，全文保留为一个待手动分配片段。', EOF_WARNING]
        if number is not None:
            local.insert(1, '集数仅由文件名推定，不能证明正文属于该集，请人工确认。')
        section = _section(text, source_name, 0, number, PurePosixPath(source_name).stem,
                           text, local, True)
        return dict(sections=[section], warnings=warnings)
    sections = []
    prefix = text[:headings[0]['offset']]
    if len(headings) + bool(prefix.strip()) > MAX_SECTIONS:
        raise ValueError('剧本分段超过1000个，请拆分文件后导入')
    if prefix.strip():
        sections.append(_section(prefix, source_name, 0, None, '标题前内容（待手动分配）', prefix,
                                 ['首个分集标题前仍有内容，可能是目录、前言或续接台词；已保留，不能自动舍弃。'], True))
        sections[-1]['end_anchor'] = headings[0]['title']
    bodies = []
    for index, heading in enumerate(headings):
        end = headings[index + 1]['offset'] if index + 1 < len(headings) else len(text)
        body = text[heading['body_offset']:end]
        bodies.append(body)
        section = _section(text[heading['offset']:end], source_name, heading['offset'],
                           heading['number'], heading['title'], body)
        section['start_anchor'] = heading['title']
        section['end_anchor'] = headings[index + 1]['title'] if index + 1 < len(headings) else '文档结尾（待核实）'
        if not body.strip():
            section['warnings'].append('该标题下没有正文，可能是目录项或缺页，不能认定为完整剧集。')
            section['ambiguous'] = True
        if heading['toc']:
            section['warnings'].append('标题含目录式点线，可能是目录项而非正文分集。')
            section['ambiguous'] = True
        if heading['weak_suffix']:
            section['warnings'].append('集数后的文字没有冒号或破折号等明确分隔，可能是台词而非标题；仅保留候选片段，请人工核对，不可自动归集。')
            section['ambiguous'] = True
        sections.append(section)
    counts = Counter(heading['number'] for heading in headings)
    duplicates = sorted(number for number, count in counts.items() if count > 1)
    if duplicates:
        warnings.append('同一集数出现多次：%s；已按出现位置分别保留，未合并或删除，请确认目录与正文。' % '、'.join(map(str, duplicates)))
        for section in sections:
            if section['number'] in duplicates:
                section['warnings'].append('此集数重复出现，需人工选择正确片段；不能自动合并。')
                section['ambiguous'] = True
    toc_prefix = any(re.fullmatch(r'(?:目录|目錄|contents|table of contents|sumario|indice)\s*[:：]?', _latin(line.strip()))
                     for line in prefix.splitlines())
    thin = [index for index, body in enumerate(bodies) if len(re.sub(r'\s+', '', body)) < 50]
    dense = len(headings) >= 3 and len(thin) >= max(3, len(headings) * .7)
    if toc_prefix or dense:
        warning = '检测到目录标记或过密的分集标题，可能将目录误当正文；所有原文仍保留，请逐项核实。'
        warnings.append(warning)
        for section in sections:
            section['warnings'].append(warning)
            section['ambiguous'] = True
    sections[-1]['warnings'].append(EOF_WARNING)
    sections[-1]['ambiguous'] = True
    return dict(sections=sections, warnings=warnings)
