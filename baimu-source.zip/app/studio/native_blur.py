"""Native blur + rectangular mask, explicitly a compatibility conversion.

The structure and KFTypeCommonMask fields come from locally saved Jianying
drafts. The built-in effect is Gaussian, whereas Baimu uses two box passes and
an additive white lift. These differences must remain visible in the report.
No installed effect resources or original drafts are changed by this module.
"""
import math,os,uuid
from pathlib import Path
from .native_defaults import timerange as native_range,keyframe as native_keyframe

EFFECT_ID='7399495140399746304'
MASK_ID='7356934318301647410'
POSITION_PROPERTIES=('KFTypeCommonMaskPositionX','KFTypeCommonMaskPositionY')
SIZE_PROPERTIES=('KFTypeCommonMaskSizeWidth','KFTypeCommonMaskSizeHeight')
INERT_PROPERTIES=('KFTypeCommonMaskRotation','KFTypeCommonMaskRoundCorner')
FEATHER_PROPERTY='KFTypeCommonMaskFeather'
SUPPORTED_PROPERTIES=set(POSITION_PROPERTIES+SIZE_PROPERTIES+INERT_PROPERTIES+(FEATHER_PROPERTY,))


def uid():return str(uuid.uuid4()).upper()
def us(value):return round(value*1_000_000)


def resources():
    cache=Path(os.environ['LOCALAPPDATA'])/'JianyingPro/User Data/Cache/effect'
    found=[]
    for key in (EFFECT_ID,'77064322'):
        candidates=sorted(p.parent for p in (cache/key).glob('*/config.json'))
        if not candidates:raise ValueError('本机剪映缺少模糊/矩形蒙版资源；请先在剪映使用一次该效果')
        found.append(candidates[0].as_posix())
    return tuple(found)


def geometry(project,mask,x=None,y=None,w=None,h=None):
    # Native mask dimensions are fractions of the canvas, its centre is in
    # [-1,1]. Baimu stores top-left pixels on a width-1080 reference canvas.
    ref_height=project['height']*1080/project['width']
    x=mask['x'] if x is None else x;y=mask['y'] if y is None else y
    w=mask['w'] if w is None else w;h=mask['h'] if h is None else h
    return dict(width=w/1080,height=h/ref_height,
        centerX=2*(x+w/2)/1080-1,
        centerY=1-2*(y+h/2)/ref_height,feather=mask.get('feather',0))


def strength(mask):
    # Initial Gaussian sigma match at the effect's 720-pixel reference scale.
    # This is not an exact boxblur conversion; native downsampling and gamma
    # make visual calibration necessary. Preserve the source radius separately.
    sigma=math.sqrt(2*mask['blur']*(mask['blur']+1)/3)
    return min(1,max(0,sigma/(27+.75*sigma)))


def points(mask):
    result=[dict(time=mask['start'],x=mask['x'],y=mask['y'],w=mask['w'],h=mask['h'])]
    previous=result[0]
    for raw in mask.get('keyframes',[]):
        point=dict(previous,**raw);result.append(point);previous=point
    if mask.get('keyframes') and result[-1]['time']<mask['end']:
        result.append(dict(result[-1],time=mask['end']))
    return result


def keyframes(project,mask,material_id):
    if not mask.get('keyframes'):return []
    result=[]
    for axis,field in [('X','centerX'),('Y','centerY')]:
        result.append(dict(id=uid(),material_id=material_id,property_type='KFTypeCommonMaskPosition'+axis,
            keyframe_list=[dict(id=uid(),time_offset=us(p['time'])-us(mask['start']),
                curveType='Line',graphID='',left_control=dict(x=0.,y=0.),right_control=dict(x=0.,y=0.),
                values=[geometry(project,mask,p['x'],p['y'],p['w'],p['h'])[field]]) for p in points(mask)]))
    if any('w' in p or 'h' in p for p in mask.get('keyframes',[])):
        for axis,field in [('Width','width'),('Height','height')]:
            result.append(dict(id=uid(),material_id=material_id,property_type='KFTypeCommonMaskSize'+axis,
                keyframe_list=[dict(id=uid(),time_offset=us(p['time'])-us(mask['start']),
                    curveType='Line',graphID='',left_control=dict(x=0.,y=0.),right_control=dict(x=0.,y=0.),
                    values=[geometry(project,mask,p['x'],p['y'],p['w'],p['h'])[field]]) for p in points(mask)]))
    return result


def compatible_native_effect(segment,material):
    """Return whether a native effect can be represented by Baimu's mask model.

    This is intentionally strict. Unknown effect kinds, animation curves, effect
    parameters, rotations and rounded corners remain fail-closed instead of being
    mislabeled as an ordinary blur mask.
    """
    if not isinstance(segment,dict) or not isinstance(material,dict) or material.get('type')!='video_effect':return False
    if str(material.get('effect_id'))!=EFFECT_ID or str(material.get('resource_id'))!=EFFECT_ID:return False
    material_value=material.get('value',1)
    if material.get('apply_target_type')!=2 or isinstance(material_value,bool) or not isinstance(material_value,(int,float)) or not math.isfinite(material_value) or not math.isclose(material_value,1,abs_tol=1e-9):return False
    params=material.get('adjust_params',[])
    if not isinstance(params,list) or len(params)!=1 or not isinstance(params[0],dict) or params[0].get('name')!='effects_adjust_blur':return False
    value=params[0].get('value')
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not 0<=value<=1:return False
    masks=material.get('effect_mask',[])
    if not isinstance(masks,list) or len(masks)!=1:return False
    native=masks[0]
    if not isinstance(native,dict):return False
    config=native.get('config',{})
    if str(native.get('resource_id'))!=MASK_ID or native.get('resource_type')!='rectangle' or not isinstance(config,dict):return False
    for key in ('width','height','centerX','centerY','feather','rotation','roundCorner'):
        number=config.get(key,0)
        if isinstance(number,bool) or not isinstance(number,(int,float)) or not math.isfinite(number):return False
    if config.get('width',0)<=0 or config.get('height',0)<=0 or not 0<=config.get('feather',0)<=1:return False
    if not math.isclose(config.get('rotation',0),0,abs_tol=1e-9) or not math.isclose(config.get('roundCorner',0),0,abs_tol=1e-9):return False
    feather_values=[config.get('feather',0)]
    entries=segment.get('common_keyframes',[])
    if not isinstance(entries,list):return False
    for entry in entries:
        if not isinstance(entry,dict):return False
        prop=entry.get('property_type')
        if prop not in SUPPORTED_PROPERTIES:return False
        frames=entry.get('keyframe_list',[])
        if not isinstance(frames,list):return False
        last=-1
        for frame in frames:
            if not isinstance(frame,dict):return False
            offset=frame.get('time_offset',0);values=frame.get('values',[])
            if isinstance(offset,bool) or not isinstance(offset,(int,float)) or not math.isfinite(offset) or offset<0 or offset<last:return False
            if not isinstance(values,list):return False
            if len(values)!=1 or isinstance(values[0],bool) or not isinstance(values[0],(int,float)) or not math.isfinite(values[0]):return False
            if frame.get('curveType','Line')!='Line':return False
            controls=[frame.get(side) or {} for side in ('left_control','right_control')]
            if any(not isinstance(control,dict) for control in controls):return False
            control_values=[control.get(axis,0) for control in controls for axis in ('x','y')]
            if any(isinstance(number,bool) or not isinstance(number,(int,float)) or not math.isfinite(number) or not math.isclose(number,0,abs_tol=1e-9) for number in control_values):return False
            if prop in INERT_PROPERTIES and not math.isclose(values[0],0,abs_tol=1e-9):return False
            if prop==FEATHER_PROPERTY:feather_values.append(values[0])
            last=offset
    return all(0<=value<=1 and math.isclose(value,feather_values[0],abs_tol=1e-7) for value in feather_values)


def native_mask(project,segment,material,source=None):
    """Convert a verified native blur rectangle into the editable/local model."""
    if not compatible_native_effect(segment,material):raise ValueError('原生模糊效果超出当前兼容范围')
    native=material['effect_mask'][0];config=native['config'];duration=native_range(segment.get('target_timerange',{}))['duration']
    entries={entry['property_type']:entry.get('keyframe_list',[]) for entry in segment.get('common_keyframes',[])}
    def series(prop,default):
        rows=[]
        for frame in entries.get(prop,[]):rows.append((frame.get('time_offset',0),frame['values'][0]))
        return rows or [(0,default)]
    def value(rows,offset):
        if offset<=rows[0][0]:return rows[0][1]
        for (left_time,left),(right_time,right) in zip(rows,rows[1:]):
            if offset<=right_time:
                ratio=(offset-left_time)/(right_time-left_time) if right_time>left_time else 1
                return left+(right-left)*ratio
        return rows[-1][1]
    native_values={
        # Jianying omits zero-valued optional centre fields in some drafts.
        'centerX':series(POSITION_PROPERTIES[0],config.get('centerX',0)),
        'centerY':series(POSITION_PROPERTIES[1],config.get('centerY',0)),
        'width':series(SIZE_PROPERTIES[0],config['width']),
        'height':series(SIZE_PROPERTIES[1],config['height']),
    }
    offsets=sorted({offset for rows in native_values.values() for offset,_ in rows if 0<=offset<duration})
    if 0 not in offsets:offsets.insert(0,0)
    ref_height=project['height']*1080/project['width']
    def geometry_at(offset):
        width=value(native_values['width'],offset)*1080;height=value(native_values['height'],offset)*ref_height
        center_x=value(native_values['centerX'],offset);center_y=value(native_values['centerY'],offset)
        return dict(x=(center_x+1)*540-width/2,y=(1-center_y)*ref_height/2-height/2,w=width,h=height)
    start=native_range(segment.get('target_timerange',{}))['start']/1_000_000
    states=[dict(time=start+offset/1_000_000,**geometry_at(offset)) for offset in offsets]
    first=states[0];mask=dict(source or {})
    parameter=material['adjust_params'][0]['value'];sigma=27*parameter/(1-.75*parameter) if parameter<1/.75 else 108
    blur=max(1,min(40,(-1+math.sqrt(1+6*sigma*sigma))/2))
    mask.update(start=start,end=start+duration/1_000_000,x=first['x'],y=first['y'],w=first['w'],h=first['h'],
        mode='blur',blur=blur,white=0,feather=config.get('feather',0),keyframes=states[1:])
    return mask


def append_blur_layers(content,project,mapping):
    masks=[m for m in project.get('masks',[]) if m.get('mode','blur')=='blur']
    if not masks:return []
    effect_path,mask_path=resources();lanes=[];track_ids=[]
    for i,mask in enumerate(masks):
        lane=next((lane for lane in lanes if lane['end']<=us(mask['start'])),None)
        if lane is None:
            track=dict(id=uid(),type='effect',name='模糊打码（待校准）'+('' if not lanes else f' · 重叠 {len(lanes)+1}'),
                is_default_name=False,attribute=0,flag=0,segments=[])
            content['tracks'].append(track);track_ids.append(track['id'])
            lane=dict(track=track,end=0);lanes.append(lane)
        lane['end']=us(mask['end']);track=lane['track'];mid=uid();mask_mid=uid()
        material=dict(id=mid,effect_id=EFFECT_ID,resource_id=EFFECT_ID,name='模糊',type='video_effect',
            path=effect_path,value=1.,category_id='100000',category_name='画面特效',apply_target_type=2,source_platform=1,
            adjust_params=[dict(name='effects_adjust_blur',value=strength(mask),default_value=.5)],
            effect_mask=[dict(id=uid(),type='video_effect',category='effect',category_name='蒙版',category_id='effect_mask',
                resource_id=MASK_ID,constant_material_id=mask_mid,name='矩形',resource_type='rectangle',path=mask_path,
                config=geometry(project,mask),text_config=dict(align_type=15))])
        content['materials'].setdefault('video_effects',[]).append(material)
        track['segments'].append(dict(id=mask['id'],target_timerange=dict(start=us(mask['start']),duration=us(mask['end'])-us(mask['start'])),
            render_timerange={},material_id=mid,render_index=11000+i,track_render_index=content['tracks'].index(track),
            enable_lut=False,enable_adjust=False,enable_hsl=False,enable_adjust_mask=False,
            responsive_layout={},source='segmentsourcenormal',common_keyframes=keyframes(project,mask,mask_mid)))
        mapping.append(dict(source_kind='mask',source_id=mask['id'],track_id=track['id'],segments=[mask['id']],
            representation='editable_native_gaussian_blur_rectangle',source_mask=mask,
            exact_visual_match=False,unmapped=['boxblur_kernel','additive_white_lift'],
            native_blur_strength=strength(mask)))
    return track_ids


def verify_blur_layers(project,content,mapping):
    masks={m['id']:m for m in project.get('masks',[]) if m.get('mode','blur')=='blur'}
    records={r['source_id']:r for r in mapping if r['source_kind']=='mask' and r.get('representation')=='editable_native_gaussian_blur_rectangle'}
    def check(test,label):
        if not test:raise ValueError('模糊打码核对失败：'+label)
    check(set(records)==set(masks),'图层丢失')
    segments={s['id']:(t,s) for t in content['tracks'] for s in t['segments']}
    materials={m['id']:m for m in content['materials'].get('video_effects',[])}
    for mid,mask in masks.items():
        r=records[mid];check(r['source_mask']==mask,'源参数丢失')
        check(r['segments']==[mid] and mid in segments,'片段丢失')
        track,seg=segments[mid];check(track['id']==r['track_id'] and track['type']=='effect','轨道错误')
        check(native_range(seg['target_timerange'])==dict(start=us(mask['start']),duration=us(mask['end'])-us(mask['start'])),'时间范围改变')
        effect=materials[seg['material_id']]
        check(effect['resource_id']==EFFECT_ID and effect['apply_target_type']==2,'模糊效果错误')
        check(effect['adjust_params']==[dict(name='effects_adjust_blur',value=strength(mask),default_value=.5)],'强度改变')
        check(len(effect.get('effect_mask',[]))==1,'矩形蒙版丢失')
        native=effect['effect_mask'][0]
        check(native['resource_id']==MASK_ID and native['resource_type']=='rectangle','蒙版类型改变')
        check(all(native['config'].get(k,0)==v for k,v in geometry(project,mask).items()),'矩形位置或尺寸改变')
        check(native['config'].get('rotation',0)==0 and native['config'].get('roundCorner',0)==0,'矩形旋转或圆角改变')
        frames={k['property_type']:k for k in seg.get('common_keyframes',[])}
        expected=keyframes(project,mask,native['constant_material_id'])
        check(set(frames)=={k['property_type'] for k in expected},'关键帧丢失')
        for entry in expected:
            actual=frames[entry['property_type']]
            check(actual['material_id']==native['constant_material_id'],'关键帧绑定错误')
            check(len(actual['keyframe_list'])==len(entry['keyframe_list']),'关键帧数量改变')
            for a,b in zip(actual['keyframe_list'],entry['keyframe_list']):
                check(native_keyframe(a)==native_keyframe(b),'关键帧时间/位置/插值改变')
        check(not r.get('exact_visual_match') and 'additive_white_lift' in r.get('unmapped',[]),'效果差异未披露')
    return len(records)
