﻿param([Parameter(Mandatory=$true)][string]$InstallRoot, [Parameter(Mandatory=$true)][string]$VersionRoot, [string]$ShortcutDirectory)
$ErrorActionPreference = 'Stop'
$studioRoot = [IO.Path]::GetFullPath($InstallRoot)
$studioVersion = [IO.Path]::GetFullPath($VersionRoot)
$studioVersions = (Join-Path $studioRoot 'versions') + [IO.Path]::DirectorySeparatorChar
$studioOwnedPrefixes = @($studioVersions)
foreach ($studioName in @('Baimu','MuXuStudio')) {
    $studioRecordPath = Join-Path (Join-Path $env:LOCALAPPDATA $studioName) 'installation.json'
    if (Test-Path -LiteralPath $studioRecordPath -PathType Leaf) {
        $studioRecord = Get-Content -LiteralPath $studioRecordPath -Raw | ConvertFrom-Json
        if ($studioRecord.app_id -in @('baimu-studio-local','muxu-studio-local')) {
            $studioPriorVersions = Split-Path -Parent ([IO.Path]::GetFullPath($studioRecord.program))
            if ((Split-Path -Leaf $studioPriorVersions) -eq 'versions') { $studioOwnedPrefixes += $studioPriorVersions + [IO.Path]::DirectorySeparatorChar }
        }
    }
}
$studioLegacyRoot = Join-Path (Split-Path -Parent $studioRoot) 'MuXuStudio'
if (Test-Path -LiteralPath $studioLegacyRoot) {
    $studioLegacyItem = Get-Item -LiteralPath $studioLegacyRoot
    if ($studioLegacyItem.LinkType -eq 'Junction' -and [IO.Path]::GetFullPath([string]$studioLegacyItem.Target) -eq $studioRoot) {
        $studioOwnedPrefixes += (Join-Path $studioLegacyRoot 'versions') + [IO.Path]::DirectorySeparatorChar
    }
}
function Test-StudioOwnedShortcut([string]$TargetPath) {
    foreach ($studioPrefix in $studioOwnedPrefixes) {
        if ($TargetPath.StartsWith($studioPrefix,[StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
}
if (-not $studioVersion.StartsWith($studioVersions,[StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid installation directory.' }
$studioApp = Join-Path $studioVersion 'app'
$studioNative = Join-Path $studioApp 'desktop\九州百慕.exe'
$studioIcon = Join-Path $studioApp 'assets\studio.ico'
foreach ($studioFile in @($studioNative,$studioIcon,(Join-Path $studioVersion 'bundle.json'))) {
    if (-not (Test-Path -LiteralPath $studioFile -PathType Leaf)) { throw ('Missing installation file: ' + $studioFile) }
}
$studioLocations = @([Environment]::GetFolderPath('DesktopDirectory'),[Environment]::GetFolderPath('Programs'))
if ($ShortcutDirectory) { $studioLocations = @([IO.Path]::GetFullPath($ShortcutDirectory)) }
$studioShell = New-Object -ComObject WScript.Shell
$studioOldNames = @('九州百慕（独立版）.lnk','九州百慕 · 剪映工程.lnk','幕序短剧工坊（独立版）.lnk')
# Only replace or remove shortcuts owned by this installation.
foreach ($studioLocation in $studioLocations) {
    $studioShortcut = Join-Path $studioLocation '九州百慕.lnk'
    if (Test-Path -LiteralPath $studioShortcut) {
        if (-not (Test-StudioOwnedShortcut $studioShell.CreateShortcut($studioShortcut).TargetPath)) { throw 'An unrelated shortcut uses the same name.' }
    }
}
foreach ($studioLocation in $studioLocations) {
    $studioShortcut = Join-Path $studioLocation '九州百慕.lnk'
    $studioLink = $studioShell.CreateShortcut($studioShortcut)
    $studioLink.TargetPath = $studioNative
    $studioLink.Arguments = ''
    $studioLink.WorkingDirectory = $studioApp
    $studioLink.IconLocation = $studioIcon+',0'
    $studioLink.Description = '九州百慕 · 剪辑、实时预览、自动保存'
    $studioLink.Save()
    foreach ($studioOldName in $studioOldNames) {
        $studioOldShortcut = Join-Path $studioLocation $studioOldName
        if (Test-Path -LiteralPath $studioOldShortcut) {
            $studioOldTarget = $studioShell.CreateShortcut($studioOldShortcut).TargetPath
            if (Test-StudioOwnedShortcut $studioOldTarget) { Remove-Item -LiteralPath $studioOldShortcut }
        }
    }
}
