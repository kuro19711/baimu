﻿param([Parameter(Mandatory=$true)][string]$InstallRoot, [Parameter(Mandatory=$true)][string]$VersionRoot, [string]$ShortcutDirectory)
$ErrorActionPreference = 'Stop'
$studioRoot = [IO.Path]::GetFullPath($InstallRoot)
$studioVersion = [IO.Path]::GetFullPath($VersionRoot)
$studioVersions = (Join-Path $studioRoot 'versions') + [IO.Path]::DirectorySeparatorChar
if (-not $studioVersion.StartsWith($studioVersions,[StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid installation directory.' }
$studioApp = Join-Path $studioVersion 'app'
$studioNative = Join-Path $studioApp 'desktop\九州百慕.exe'
$studioIcon = Join-Path $studioApp 'assets\studio.ico'
foreach ($studioFile in @($studioNative,$studioIcon,(Join-Path $studioVersion 'bundle.json'))) {
    if (-not (Test-Path -LiteralPath $studioFile -PathType Leaf)) { throw ('Missing installation file: ' + $studioFile) }
}
$studioLocations = @([Environment]::GetFolderPath('DesktopDirectory'),[Environment]::GetFolderPath('Programs'))
if ($ShortcutDirectory) { $studioLocations = @([IO.Path]::GetFullPath($ShortcutDirectory)) }
$studioShell = New-Object -ComObject WScript.Shell
$studioOldNames = @('九州百慕（独立版）.lnk','九州百慕 · 剪映工程.lnk','幕序短剧工坊（独立版）.lnk')
# Only replace or remove shortcuts owned by this installation.
foreach ($studioLocation in $studioLocations) {
    $studioShortcut = Join-Path $studioLocation '九州百慕.lnk'
    if (Test-Path -LiteralPath $studioShortcut) {
        if (-not $studioShell.CreateShortcut($studioShortcut).TargetPath.StartsWith($studioVersions,[StringComparison]::OrdinalIgnoreCase)) { throw 'An unrelated shortcut uses the same name.' }
    }
}
foreach ($studioLocation in $studioLocations) {
    $studioShortcut = Join-Path $studioLocation '九州百慕.lnk'
    $studioLink = $studioShell.CreateShortcut($studioShortcut)
    $studioLink.TargetPath = $studioNative
    $studioLink.Arguments = ''
    $studioLink.WorkingDirectory = $studioApp
    $studioLink.IconLocation = $studioIcon+',0'
    $studioLink.Description = '九州百慕 · 剪辑、实时预览、自动保存'
    $studioLink.Save()
    foreach ($studioOldName in $studioOldNames) {
        $studioOldShortcut = Join-Path $studioLocation $studioOldName
        if (Test-Path -LiteralPath $studioOldShortcut) {
            $studioOldTarget = $studioShell.CreateShortcut($studioOldShortcut).TargetPath
            if ($studioOldTarget.StartsWith($studioVersions,[StringComparison]::OrdinalIgnoreCase)) { Remove-Item -LiteralPath $studioOldShortcut }
        }
    }
}
