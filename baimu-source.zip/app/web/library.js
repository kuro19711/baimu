'use strict';
function installStudioLibrary(){
  const original={api,refreshBoot,renderProjects,openProject,modal,pollJobs};
  let folders=[],folder=null,started=false,openSequence=0;
  const sortKey='studio-library-sort',sortModes=['name-asc','name-desc','modified-desc','modified-asc'];
  const nameOrder=new Intl.Collator('zh-CN-u-co-pinyin',{numeric:true,sensitivity:'base'});
  let sortMode='name-asc';
  try{const saved=localStorage.getItem(sortKey);if(sortModes.includes(saved))sortMode=saved}catch(_){}
  const params=new URLSearchParams(location.search),workspaceId=params.get('workspace'),projectId=params.get('project');
  const home=document.createElement('section');home.id='library-home';
  home.innerHTML='<div class="library-heading"><div><h1>剧目</h1><p>一部剧一个剧目，打开后按分集剪辑。</p></div><div class="library-actions"><button id="library-manage">管理</button><button id="library-import">导入文件夹</button><button id="library-new" class="primary">＋ 新建剧目</button></div></div><div class="library-summary" id="library-summary"></div><input id="library-search" type="search" placeholder="搜索剧名" aria-label="搜索剧名"><div id="library-cards"></div>';
  const toolbar=document.createElement('div');toolbar.className='library-toolbar';
  const search=home.querySelector('#library-search');search.before(toolbar);toolbar.append(search);
  const sortLabel=document.createElement('label');sortLabel.className='library-sort';
  sortLabel.innerHTML='<span>排序</span><select id="library-sort" aria-label="剧目文件夹排序"><option value="name-asc">首字母 A–Z</option><option value="name-desc">首字母 Z–A</option><option value="modified-desc">修改时间：最新优先</option><option value="modified-asc">修改时间：最早优先</option></select>';
  toolbar.append(sortLabel);sortLabel.querySelector('select').value=sortMode;
  document.querySelector('.app-layout').before(home);
  const button=document.createElement('button');button.id='library-home-button';button.textContent='⌂ 首页';
  document.querySelector('.top-actions').prepend(button);
  const title=document.createElement('span');title.id='library-workspace-title';document.querySelector('.brand').append(title);
  function workspaceUrl(id){return location.origin+location.pathname+'?workspace='+encodeURIComponent(id)+'#token='+encodeURIComponent(token)}
  function showHome(){
    if(window.chrome?.webview){window.chrome.webview.postMessage({type:'open-home'});return}
    location.href=location.origin+location.pathname+'#token='+encodeURIComponent(token);
  }
  button.onclick=handle(async()=>{await save();if(folder)showHome();else await updateLibrary()});
  function openFolder(id){
    if(window.chrome?.webview)window.chrome.webview.postMessage({type:'open-workspace',folder_id:id});
    else window.open(workspaceUrl(id),'baimu-workspace-'+id);
  }
  function drawHome(){
    const query=document.querySelector('#library-search').value.trim().toLocaleLowerCase();
    document.querySelector('#library-summary').textContent=`${folders.length} 部剧 · ${folders.reduce((n,f)=>n+f.episode_count,0)} 个分集工程`;
    const byName=(a,b)=>nameOrder.compare(a.name,b.name)||String(a.id).localeCompare(String(b.id));
    const modified=f=>{const value=Number(f.modified??f.created??0);return Number.isFinite(value)?value:0};
    const rows=folders.filter(f=>f.name.toLocaleLowerCase().includes(query)).sort((a,b)=>{
      if(sortMode==='name-desc')return -byName(a,b);
      if(sortMode==='modified-desc')return modified(b)-modified(a)||byName(a,b);
      if(sortMode==='modified-asc')return modified(a)-modified(b)||byName(a,b);
      return byName(a,b);
    });
    document.querySelector('#library-cards').innerHTML=rows.map(f=>{
      const numbers=(f.episodes||[]).map(row=>row.episode_number).filter(Number.isFinite),range=numbers.length?` · EP${String(Math.min(...numbers)).padStart(2,'0')}–EP${String(Math.max(...numbers)).padStart(2,'0')}`:'';
      return `<button class="library-card" data-folder="${f.id}"><span class="library-folder-icon" aria-hidden="true">▱</span><strong>${esc(f.name)}</strong><span>${f.episode_count} 集${range}</span><b>打开</b></button>`;
    }).join('')||'<div class="empty"><h3>还没有剧目</h3><p>新建剧目，或导入含分集的文件夹。</p></div>';
    document.querySelectorAll('[data-folder]').forEach(el=>el.onclick=()=>openFolder(el.dataset.folder));
  }
  async function updateLibrary(){
    folders=await original.api('/api/library');
    if(folder){
      const next=folders.find(f=>f.id===folder.id);if(!next)throw Error('剧文件夹不存在，请返回首页');folder=next;
      boot.projects=(boot.projects||[]).filter(p=>p.series===folder.series);
    }
    drawHome();
  }
  window.addEventListener('focus',()=>{if(started&&!folder)updateLibrary().catch(error=>toast(error.message,true))});
  function scopeFields(){
    if(!folder)return;
    for(const id of ['create-series','batch-series','folder-drop-series']){
      const input=document.getElementById(id);if(input){input.value=folder.series;input.readOnly=true;input.title='当前工作页只处理这部剧';}
    }
    const series=document.querySelector('#project-series');series.value=folder.name;series.readOnly=true;
  }
  new MutationObserver(scopeFields).observe(document.querySelector('#modal-body'),{childList:true,subtree:true});
  const oldRender=render;
  render=function(...args){oldRender(...args);scopeFields()};
  modal=function(...args){const result=original.modal(...args);scopeFields();return result};
  api=function(path,body){
    if(folder&&path==='/api/jobs'&&body===undefined)path+='?folder_id='+encodeURIComponent(folder.id);
    return original.api(path,body);
  };
  refreshBoot=async function(){await original.refreshBoot();if(started){await updateLibrary();renderProjects()}};
  renderProjects=function(){
    if(!folder){original.renderProjects();return}
    const query=document.querySelector('#project-search').value.trim().toLocaleLowerCase();
    const ranks=new Map(folder.episodes.map((p,i)=>[p.id,i])),episodes=new Map(folder.episodes.map(row=>[row.id,row]));
    const rows=(boot.projects||[]).filter(p=>p.series===folder.series&&(!query||p.name.toLocaleLowerCase().includes(query)))
      .sort((a,b)=>(ranks.get(a.id)??1e9)-(ranks.get(b.id)??1e9)||a.name.localeCompare(b.name,'zh',{numeric:true}));
    document.querySelector('#projects').innerHTML=rows.map(row=>`<button class="project-row ${p?.id===row.id?'active':''}" data-project="${row.id}" title="${esc(row.name)}"><span class="episode-number">${esc(row.name)}</span></button>`).join('')||'<p class="helper">还没有分集</p>';
    document.querySelectorAll('[data-project]').forEach(el=>el.onclick=handle(()=>openProject(el.dataset.project)));
    document.querySelector('#project-list-count').textContent=rows.length;
  };
  document.querySelector('#project-search').oninput=renderProjects;
  openProject=async function(pid,...args){
    // Reserve the selection before any membership request can finish out of order.
    const request=++openSequence;
    if(started&&!folder){
      await updateLibrary();if(request!==openSequence)return;
      const target=folders.find(f=>f.episodes.some(episode=>episode.id===pid));
      if(!target)throw Error('分集工程不存在，请刷新首页');
      openFolder(target.id);return;
    }
    if(folder){const candidate=await original.api('/api/projects/'+pid);if(request!==openSequence)return;if(candidate.series!==folder.series)throw Error('该集属于另一部剧，请从首页打开它的工作页');}
    await original.openProject(pid,...args);
    if(request!==openSequence)return;
    if(folder&&p?.id===pid){try{localStorage.setItem('studio-last-episode:'+folder.id,pid)}catch(_){}document.title=folder.name+' / '+p.name+' · 九州百慕';}
    scopeFields();
  };
  pollJobs=async function(){await original.pollJobs();if(folder)document.querySelector('#job-count').textContent=jobs.filter(j=>['queued','running'].includes(j.state)).length};
  document.querySelector('#library-search').oninput=drawHome;
  document.querySelector('#library-sort').onchange=event=>{
    sortMode=sortModes.includes(event.target.value)?event.target.value:'name-asc';
    try{localStorage.setItem(sortKey,sortMode)}catch(_){}
    drawHome();
  };
  document.querySelector('#library-manage').onclick=()=>document.querySelector('#manage-button').click();
  document.querySelector('#library-import').onclick=()=>window.studioMaterialImport?.openFolder();
  document.querySelector('#library-new').onclick=()=>{
    modal('<h2>新建剧目</h2><p>一部剧一个剧目，进入后再添加分集。不会移动磁盘上的原素材。</p><label>剧名</label><input id="library-folder-name" maxlength="150" placeholder="填写这部剧的名称"><div class="modal-actions"><button id="library-create" class="primary">创建并打开</button></div>');
    document.querySelector('#library-create').onclick=handle(async()=>{
      const el=document.querySelector('#library-create');el.disabled=true;
      try{const created=await original.api('/api/library',{name:document.querySelector('#library-folder-name').value});document.querySelector('#modal').close();await updateLibrary();openFolder(created.id)}finally{el.disabled=false}
    });
  };
  window.studioLibrary={current:()=>folder?{id:folder.id,name:folder.name,series:folder.series}:null,openFolder,refresh:updateLibrary,
    async start(){
      folders=await original.api('/api/library');
      folder=workspaceId?folders.find(f=>f.id===workspaceId||(f.aliases||[]).includes(workspaceId)):projectId?folders.find(f=>f.episodes.some(p=>p.id===projectId)):null;
      if((workspaceId||projectId)&&!folder)throw Error('工作页不存在，请点击首页重新选择');
      started=true;document.body.classList.remove('library-loading');document.body.classList.toggle('library-home-mode',!folder);document.body.classList.toggle('library-workspace-mode',!!folder);
      if(!folder){document.title='剧本总览 · 九州百慕';drawHome();document.querySelector('#save-status').textContent='全部工程保存在本机';return}
      document.querySelector('#library-workspace-title').textContent=folder.name;
      document.querySelector('.sidebar .section-title').firstChild.textContent='分集 ';
      document.querySelector('#new-button').textContent='＋ 新建分集';document.querySelector('#global-new-button').textContent='＋ 新建分集';
      document.querySelector('#project-search').placeholder='搜索本剧集数';
      boot.projects=(boot.projects||[]).filter(p=>p.series===folder.series);
      // Preserve the existing new-project/import handlers' default series.
      const filter=document.querySelector('#series-filter');filter.value='s:'+encodeURIComponent(folder.series);if(filter.value)filter.onchange();
      let last=projectId;try{last=last||localStorage.getItem('studio-last-episode:'+folder.id)}catch(_){}
      const chosen=folder.episodes.find(p=>p.id===last)||folder.episodes[0];
      if(chosen)await openProject(chosen.id);else{render();renderProjects();document.querySelector('#save-status').textContent='新剧已建立，请添加分集';}
      if(window.chrome?.webview)window.chrome.webview.postMessage({type:'workspace-title',title:folder.name});
    }};
}
