/* Pure timeline model. Video is magnetic; independent tracks keep absolute time. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.StudioTimeline=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';
  const AUDIO=new Set(['dialogue','narration','bgm','sfx']),EPS=1e-7,MAX_TIME=86400;
  const fail=message=>{throw Error(message)};
  const clone=value=>{
    if(Array.isArray(value))return value.map(clone);
    if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([key,item])=>[key,clone(item)]));
    return value;
  };
  function number(value,min,max,label){
    if(typeof value!=='number'||!Number.isFinite(value)||value<min||value>max)fail(`${label}必须为 ${min} 至 ${max} 的有效数字`);
    return value;
  }
  function fpsValue(value){
    if(typeof value!=='number'&&typeof value!=='string')fail('帧率格式无效');
    const parts=String(value).split('/');
    const syntax=parts.length===2?/^[+-]?\d+$/:/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i;
    if(parts.length>2||parts.some(part=>!syntax.test(part.trim())||!Number.isFinite(Number(part))))fail('帧率格式无效');
    return number(parts.length===2?Number(parts[0])/Number(parts[1]):Number(parts[0]),1,120,'帧率');
  }
  function frame(time,fps,label='时间'){
    number(time,0,MAX_TIME,label);
    return Math.round(time*fps)/fps;
  }
  function sourceEndLimit(asset,fps,isVideo){
    let end=asset.duration;
    if(isVideo&&typeof asset.native_duration==='number'&&Number.isFinite(asset.native_duration)){
      const rate=typeof asset.fps==='number'&&Number.isFinite(asset.fps)&&asset.fps>0?asset.fps:fps;
      // Jianying may retain a frame-aligned/material endpoint while the media
      // stream reports a slightly shorter container timestamp. Trust only a
      // nearby native endpoint; a corrupt or unrelated duration still fails.
      const drift=Math.max(.05,1/rate+EPS);
      if(asset.native_duration>=asset.duration-EPS&&asset.native_duration<=asset.duration+drift+EPS)
        end=Math.max(end,asset.native_duration);
    }
    return Math.round((end+.00001)*1e6)/1e6;
  }
  const frameCount=(clip,fps)=>Math.max(1,Math.floor((clip.out-clip.in)*fps+EPS));
  function validate(project,overlapAllowed=false){
    if(!project||typeof project!=='object')fail('工程数据无效');
    const fps=fpsValue(project.fps),assets=new Map();
    for(const key of ['assets','clips','audios','captions']){
      if(!Array.isArray(project[key])||project[key].length>10000)fail(`${key}轨道数据无效`);
      const ids=new Set();
      for(const item of project[key]){
        if(!item||typeof item.id!=='string'||!item.id||ids.has(item.id))fail(`${key}包含无效或重复ID`);
        ids.add(item.id);
      }
    }
    for(const asset of project.assets){number(asset.duration,0,Number.MAX_SAFE_INTEGER,'素材时长');assets.set(asset.id,asset)}
    for(const [list,isVideo] of [[project.clips,true],[project.audios,false]])for(const item of list){
      const asset=assets.get(item.asset_id);
      if(!asset)fail('片段引用的素材不存在');
      if(isVideo&&typeof (item.audio_detached??false)!=='boolean')fail('原声分离标记无效');
      if(isVideo&&asset.kind!=='video')fail('画面轨必须引用视频素材');
      if(isVideo&&item.start!==undefined)number(item.start,0,MAX_TIME,'画面开始时间');
      number(item.in,0,asset.duration,'源入点');number(item.out,0,sourceEndLimit(asset,fps,isVideo),'源出点');
      if(item.out<=item.in||(isVideo&&item.out-item.in<1/fps-EPS))fail(isVideo?'视频片段不能短于一帧':'音频源出点必须晚于入点');
      number(item.gain===undefined?0:item.gain,-60,12,'音量');
      if(item.audio_stream!==undefined&&item.audio_stream!==null){
        if(!Number.isInteger(item.audio_stream)||!(asset.audio_streams||[]).some(stream=>stream.index===item.audio_stream))fail('所选原声音轨不存在');
      }
      if(!isVideo){
        number(item.start,0,MAX_TIME,'音频开始时间');
        if(!AUDIO.has(item.role))fail('音频类型必须为人物原声、旁白、BGM或音效');
        if(item.loop!==undefined&&typeof item.loop!=='boolean')fail('循环设置必须为布尔值');
        if(item.loop_duration!==undefined)number(item.loop_duration,1/fps,MAX_TIME,'循环片段时长');
        if(item.loop_offset!==undefined)number(item.loop_offset,0,item.out-item.in,'循环偏移');
        const streams=asset.audio_streams||[],stream=item.audio_stream==null?(streams.length===1?streams[0]:null):streams.find(s=>s.index===item.audio_stream);
        if(stream&&stream.duration_verified&&Number.isFinite(stream.start)&&Number.isFinite(stream.end)
          &&(item.in<stream.start-.002||item.out>stream.end+.002))fail('音频源入出点超出所选音轨的有效范围');
      }
    }
    for(const cue of project.captions){
      number(cue.start,0,MAX_TIME,'字幕开始时间');number(cue.end,0,MAX_TIME,'字幕结束时间');
      if(cue.end<=cue.start)fail('字幕结束必须晚于开始');
      if(typeof cue.text!=='string'||cue.text.length>3000)fail('字幕文字必须为不超过3000字符的文本');
    }
    const masks=project.masks||[];
    if(!Array.isArray(masks)||masks.length>200)fail('打码轨道数据无效');
    const maskIds=new Set();
    for(const mask of masks){
      if(!mask||typeof mask.id!=='string'||!mask.id||maskIds.has(mask.id))fail('打码包含无效或重复ID');
      maskIds.add(mask.id);
      number(mask.start,0,MAX_TIME,'打码开始');number(mask.end,0,MAX_TIME,'打码结束');
      if(mask.end-mask.start<1/fps-EPS)fail('打码时长不能短于一帧');
      number(mask.w,16,4320,'打码宽度');number(mask.h,16,7680,'打码高度');
      number(mask.x,-mask.w,1080,'打码横坐标');number(mask.y,-mask.h,1920,'打码纵坐标');
      if(mask.x>=1080||mask.y>=1920||mask.x+mask.w<=0||mask.y+mask.h<=0)fail('打码区域必须与画面相交');
      number(mask.blur,1,40,'模糊强度');number(mask.white,0,.6,'白色强度');
      number(mask.feather??0,0,1,'羽化强度');
      if(!['blur','solid'].includes(mask.mode||'blur'))fail('打码类型无效');
      if(!['below_captions','above_captions'].includes(mask.layer||'below_captions'))fail('打码层级无效');
      if(!Array.isArray(mask.keyframes)||mask.keyframes.length>100)fail('打码关键帧无效');
      let last=mask.start;
      for(const point of mask.keyframes){
        number(point.time,mask.start,mask.end,'关键帧时间');
        if(point.time<=last+EPS)fail('打码关键帧必须按时间递增，且晚于打码开始');
        if(point.time>=mask.end-EPS)fail('打码关键帧必须早于打码结束');
        const width=point.w??mask.w,height=point.h??mask.h;
        number(width,16,4320,'关键帧宽度');number(height,16,7680,'关键帧高度');
        number(point.x,-width,1080,'关键帧横坐标');number(point.y,-height,1920,'关键帧纵坐标');
        if(point.x>=1080||point.y>=1920||point.x+width<=0||point.y+height<=0)fail('关键帧打码区域必须与画面相交');
        last=point.time;
      }
    }
    if(!overlapAllowed){
      const sorted=[...project.captions].sort((a,b)=>a.start-b.start||a.end-b.end);
      for(let index=1;index<sorted.length;index++)if(sorted[index].start<sorted[index-1].end-EPS)fail('字幕时间重叠，请先调整边界；不能让两条字幕同时出现');
    }
    return {fps,assets};
  }
  function layout(project){
    const {fps,assets}=validate(project,true),items=[],warnings=[];
    let cursor=0;
    for(const clip of project.clips){
      const count=frameCount(clip,fps),asset=assets.get(clip.asset_id),start=clip.start===undefined?cursor/fps:frame(clip.start,fps),end=start+count/fps;
      const common={id:clip.id,start,end,sourceIn:clip.in,sourceOut:clip.out,asset_id:clip.asset_id,linked:true,linkedId:clip.id,
        gain:clip.gain===undefined?0:clip.gain,audio_stream:clip.audio_stream??null,loop:false,label:asset.name||'视频素材',frames:count};
      items.push({...common,kind:'video'});
      if(!clip.audio_detached)items.push({...common,kind:'original',hasAudio:!!asset.has_audio,label:asset.has_audio?'人物原声':'无原声（静音）'});
      cursor=Math.max(cursor,Math.round(end*fps));
    }
    const duration=Math.max(cursor/fps,project.native?.shared?Math.ceil((project.native.duration_us||0)/1e6*fps-1e-7)/fps:0);
    for(const cue of project.captions)items.push({kind:'caption',id:cue.id,start:cue.start,end:cue.end,sourceIn:null,sourceOut:null,linked:false,text:cue.text,label:cue.text,loop:false});
    for(const mask of project.masks||[])items.push({kind:'mask',id:mask.id,start:mask.start,end:mask.end,sourceIn:null,sourceOut:null,linked:false,label:'打码遮挡',loop:false});
    for(const audio of project.audios){
      const looping=audio.role==='bgm'&&audio.loop===true,asset=assets.get(audio.asset_id);
      items.push({kind:audio.role,id:audio.id,start:audio.start,end:looping?(audio.loop_duration===undefined?Math.max(audio.start,duration):audio.start+audio.loop_duration):audio.start+audio.out-audio.in,
        sourceIn:audio.in,sourceOut:audio.out,asset_id:audio.asset_id,linked:false,gain:audio.gain===undefined?0:audio.gain,
        audio_stream:audio.audio_stream??null,loop:!!audio.loop,effectiveLoop:looping,label:asset.name||'音频素材'});
      if(audio.loop&&audio.role!=='bgm')warnings.push('循环仅对BGM生效；当前非BGM音频的循环标记不改变渲染长度。');
    }
    const captions=[...project.captions].sort((a,b)=>a.start-b.start);
    if(captions.some((cue,index)=>index&&cue.start<captions[index-1].end-EPS))warnings.push('已有字幕时间重叠，可逐条修复；正式交付前必须消除重叠。');
    if(items.some(item=>!item.linked&&item.end>duration+EPS))warnings.push('部分字幕、打码或独立音频超出画面范围，导出时不能完整出现，请调整。');
    return {fps,duration,items,warnings:[...new Set(warnings)]};
  }
  function get(project,kind,id){
    const item=layout(project).items.find(item=>item.kind===kind&&item.id===id);
    if(!item)fail('所选时间线片段已不存在，请刷新后重试');
    return item;
  }
  function newIdentifier(project,newId){
    const id=typeof newId==='function'?newId():newId;
    if(typeof id!=='string'||!id||[...project.clips,...project.audios,...project.captions,...(project.masks||[])].some(item=>item.id===id))fail('切分需要一个新的、不重复的片段ID');
    return id;
  }
  function preserveOrReduceOverlaps(before,after){
    const previous=new Map(before.captions.map(cue=>[cue.id,cue]));
    const overlap=(left,right)=>left&&right?Math.max(0,Math.min(left.end,right.end)-Math.max(left.start,right.start)):0;
    // Only time-changed/new cues can add or worsen a pair. This permits repairing
    // one fault at a time and avoids quadratic work for unrelated audio edits.
    const changed=after.captions.filter(cue=>{
      const old=previous.get(cue.id);
      return !old||old.start!==cue.start||old.end!==cue.end;
    });
    for(const cue of changed)for(const other of after.captions){
      if(cue.id===other.id)continue;
      const currentOverlap=overlap(cue,other);
      if(currentOverlap>overlap(previous.get(cue.id),previous.get(other.id))+EPS)
        fail('字幕时间重叠新增或加重，请调整边界；已有重叠可以逐条修复');
    }
  }
  function patchItem(item,patch,allowed,fps){
    if(!patch||typeof patch!=='object'||Array.isArray(patch))fail('请提供需要修改的字段');
    if(Object.keys(patch).some(key=>!allowed.includes(key)))fail('此轨道不允许修改所提供的字段');
    for(const [key,value] of Object.entries(patch)){
      // The property form submits unchanged timing fields together with gain.
      // Preserve legacy source offsets exactly unless that field was changed.
      if(value===item[key])continue;
      item[key]=['start','end','in','out'].includes(key)?frame(value,fps,key):clone(value);
    }
  }
  function maskPosition(mask,t){
    const points=[{time:mask.start,x:mask.x,y:mask.y,w:mask.w,h:mask.h}];
    for(const raw of mask.keyframes)points.push({...points.at(-1),...raw});
    for(let index=1;index<points.length;index++){
      const left=points[index-1],right=points[index];
      if(t<=right.time){const ratio=Math.max(0,Math.min(1,(t-left.time)/(right.time-left.time)));
        return {x:left.x+(right.x-left.x)*ratio,y:left.y+(right.y-left.y)*ratio,w:left.w+(right.w-left.w)*ratio,h:left.h+(right.h-left.h)*ratio}}
    }
    return {x:points.at(-1).x,y:points.at(-1).y,w:points.at(-1).w,h:points.at(-1).h};
  }
  function apply(project,operation,newId){
    const beforeLayout=layout(project),fps=beforeLayout.fps;
    if(!operation||typeof operation!=='object')fail('时间线操作无效');
    const {type,kind,id}=operation;
    if(type==='reorder_selection'){
      if(!Array.isArray(operation.items)||!operation.items.length||operation.items.length>10000)fail('请选择要排序的片段');
      const chosen=new Map();for(const entry of operation.items){const view=get(project,entry.kind,entry.id);chosen.set(view.kind+':'+view.id,view)}
      const videoIds=new Set([...chosen.values()].filter(v=>v.kind==='video').map(v=>v.id));
      for(const entry of chosen.values()){const linked=project.native_links?.[entry.id]?.linked_video_id;if(linked)videoIds.add(linked)}
      if(!videoIds.has(id))fail('请从选中的画面拖动整组选区');
      if((project.track_locks||[]).includes('video'))fail('画面轨道已锁定');
      const indices=project.clips.map((c,i)=>videoIds.has(c.id)?i:-1).filter(i=>i>=0);
      if(indices.at(-1)-indices[0]+1!==indices.length)fail('主轨整组排序需选择连续镜头；非连续选区请关闭主轨磁吸后整体移动');
      const next=clone(project),block=next.clips.filter(c=>videoIds.has(c.id)),rest=next.clips.filter(c=>!videoIds.has(c.id));
      if(!Number.isInteger(operation.targetIndex)||operation.targetIndex<0||operation.targetIndex>rest.length)fail('目标排序位置无效');
      rest.splice(operation.targetIndex,0,...block);next.clips=rest;for(const clip of next.clips)delete clip.start;
      const delta=get(next,'video',id).start-get(project,'video',id).start;
      for(const view of chosen.values()){
        if(view.kind==='video'||videoIds.has(project.native_links?.[view.id]?.linked_video_id))continue;
        if(view.kind==='original')fail('内嵌原声请随对应画面移动');
        if((project.track_locks||[]).includes(view.kind))fail('所选跟随轨道已锁定');
        if(view.start+delta<-EPS)fail('排序后选中片段会产生负时间');
        const list=view.kind==='caption'?next.captions:view.kind==='mask'?next.masks:next.audios,row=list.find(row=>row.id===view.id);
        row.start=view.start+delta;if(['caption','mask'].includes(view.kind))row.end=view.end+delta;
        if(view.kind==='mask')row.keyframes=row.keyframes.map(point=>({...point,time:point.time+delta}));
      }
      validate(next,true);preserveOrReduceOverlaps(project,next);
      next.reviews={};for(const cue of next.captions)delete cue.speech;
      return {project:next,warnings:['连续镜头整组插入排序；所选独立轨道跟随拖动镜头的时间差，未选独立轨道不动。']};
    }
    if(type==='replace_video'){
      const view=get(project,'video',id),asset=project.assets.find(a=>a.id===operation.asset_id);
      if(!asset||asset.kind!=='video')fail('请选择已导入的视频素材');
      if(!['fit','gap','ripple'].includes(operation.strategy))fail('请选择保长裁切、保留空位或推动后续');
      const sourceIn=frame(operation.in??0,fps,'新素材入点'),available=frame(operation.out??Math.floor(asset.duration*fps)/fps,fps,'新素材出点')-sourceIn;
      if(available<1/fps-EPS||sourceIn+available>sourceEndLimit(asset,fps,true)+EPS)fail('新素材选段无效');
      const length=view.end-view.start;
      if(operation.strategy==='fit'&&available<length-EPS)fail('新素材不足原片段长度，请改选保留空位或推动后续，不会自动补帧');
      const used=operation.strategy==='ripple'?available:Math.min(length,available),delta=used-length;
      const next=clone(project),clip=next.clips.find(c=>c.id===id);
      for(const row of next.clips)row.start=get(project,'video',row.id).start;
      if((project.track_locks||[]).includes('video'))fail('画面轨道已锁定');
      clip.asset_id=asset.id;clip.in=sourceIn;clip.out=sourceIn+used;
      if(operation.audio_stream===undefined)delete clip.audio_stream;else clip.audio_stream=operation.audio_stream;
      if(operation.strategy==='ripple'){
        const follow=operation.follow??[];
        if(!Array.isArray(follow)||follow.some(kind=>!['caption','mask',...AUDIO].includes(kind)))fail('跟随轨道设置无效');
        for(const row of next.clips)if(row.id!==id&&row.start>=view.end-EPS)row.start+=delta;
        for(const entry of beforeLayout.items)if(follow.includes(entry.kind)&&entry.start>=view.end-EPS){
          if((project.track_locks||[]).includes(entry.kind)&&Math.abs(delta)>EPS)fail('需要跟随移动的轨道已锁定');
          const list=entry.kind==='caption'?next.captions:entry.kind==='mask'?next.masks:next.audios;
          const row=list.find(row=>row.id===entry.id);row.start+=delta;
          if(['caption','mask'].includes(entry.kind))row.end+=delta;
          if(entry.kind==='mask')row.keyframes=row.keyframes.map(point=>({...point,time:point.time+delta}));
        }
      }
      validate(next,true);preserveOrReduceOverlaps(project,next);
      const videos=layout(next).items.filter(row=>row.kind==='video').sort((a,b)=>a.start-b.start);
      for(let i=1;i<videos.length;i++)if(videos[i].start<videos[i-1].end-EPS)fail('替换后画面重叠，工程未修改');
      next.reviews={};for(const cue of next.captions)delete cue.speech;
      return {project:next,warnings:['仅替换所选画面及其已联动的原声；独立声音保持不变，请试听确认。']};
    }
    if(type==='move_selection'){
      if(!Array.isArray(operation.items)||!operation.items.length||operation.items.length>10000)fail('请选择需要一起移动的片段');
      number(operation.delta,-MAX_TIME,MAX_TIME,'移动时间差');
      const delta=Math.round(operation.delta*fps)/fps,next=clone(project),chosen=new Map();
      for(const entry of operation.items){
        if(!entry||entry.kind==='original')fail('内嵌原声请先分离，或选择对应画面');
        const view=get(project,entry.kind,entry.id);chosen.set(view.kind+':'+view.id,view);
      }
      // Include an existing native pair once. Never infer caption/music links.
      for(const view of [...chosen.values()]){
        const link=project.native_links?.[view.id];
        const peer=link?.linked_audio_id?get(project,'dialogue',link.linked_audio_id):link?.linked_video_id?get(project,'video',link.linked_video_id):null;
        if(peer)chosen.set(peer.kind+':'+peer.id,peer);
      }
      for(const clip of next.clips)clip.start=get(project,'video',clip.id).start;
      for(const view of chosen.values()){
        if((project.track_locks||[]).includes(view.kind))fail('所选片段或关联原声的轨道已锁定');
        if(view.start+delta<-EPS)fail('移动后不能产生负时间');
        const list=view.kind==='video'?next.clips:view.kind==='caption'?next.captions:view.kind==='mask'?next.masks:next.audios;
        const record=list.find(row=>row.id===view.id);
        record.start=Math.max(0,view.start+delta);
        if(['caption','mask'].includes(view.kind))record.end=view.end+delta;
        if(view.kind==='mask')record.keyframes=record.keyframes.map(point=>({...point,time:point.time+delta}));
        if(view.kind==='caption')delete record.speech;
      }
      next.clips.sort((a,b)=>a.start-b.start);
      validate(next,true);
      const videos=layout(next).items.filter(row=>row.kind==='video').sort((a,b)=>a.start-b.start);
      for(let i=1;i<videos.length;i++)if(videos[i].start<videos[i-1].end-EPS)fail('画面片段重叠：请把整组选区放到空白区');
      preserveOrReduceOverlaps(project,next);
      if([...chosen.values()].some(view=>!['caption','mask'].includes(view.kind)))for(const cue of next.captions)delete cue.speech;
      next.reviews={};
      return {project:next,warnings:['只移动所选片段与其已联动原声；未选字幕、旁白、音乐保持原位置。',...layout(next).warnings]};
    }
    const linkedVideo=project.native_links?.[id]?.linked_video_id;
    if(type==='unlink'){
      if(!project.native?.shared||!['video','dialogue'].includes(kind))fail('请选择已联动的画面或人物原声');
      get(project,kind,id);
      const videoId=kind==='video'?id:linkedVideo,audioId=kind==='dialogue'?id:project.native_links?.[id]?.linked_audio_id;
      if(!videoId||!audioId||project.native_links?.[audioId]?.linked_video_id!==videoId)fail('这段原声已经独立，无须解除联动');
      if((project.track_locks||[]).some(k=>['video','dialogue'].includes(k)))fail('画面或原声轨道已锁定，请先解锁');
      const next=clone(project),audio=next.audios.find(a=>a.id===audioId);
      if(!audio)fail('关联原声已不存在');
      audio.linked_video_id=null;
      delete next.native_links[videoId].linked_audio_id;delete next.native_links[audioId].linked_video_id;
      next.reviews={};return {project:next,selection:{kind:'dialogue',id:audioId},warnings:['已解除联动，原声可单独移动。']};
    }
    if(linkedVideo&&type==='split')return apply(project,{...operation,kind:'video',id:linkedVideo},newId);
    if(type==='style'){
      if(kind!=='caption'||!operation.patch||typeof operation.patch!=='object'||Array.isArray(operation.patch))fail('字幕样式操作无效');
      if(Object.keys(operation.patch).some(k=>!Object.hasOwn(project.style,k)))fail('不支持的字幕样式字段');
      if((project.track_locks||[]).includes('caption'))fail('字幕轨道已锁定');
      const next=clone(project),patch=clone(operation.patch);
      if(operation.scope==='all'){
        Object.assign(next.style,patch);for(const cue of next.captions)for(const field of Object.keys(patch))if(cue.style)delete cue.style[field];
      }else if(operation.scope==='one'){
        const cue=next.captions.find(c=>c.id===id);if(!cue)fail('字幕已不存在');cue.style={...cue.style,...patch};
      }else fail('请明确选择整集或单条字幕');
      next.reviews={};return {project:next,warnings:[]};
    }
    if(type==='lock'){
      if(!['video','original','caption','mask',...AUDIO].includes(kind)||typeof operation.locked!=='boolean')fail('轨道锁定参数无效');
      const next=clone(project);next.track_locks=[...new Set(project.track_locks||[])].filter(k=>k!==kind);
      if(operation.locked)next.track_locks.push(kind);
      return {project:next,warnings:[]};
    }
    if(!['move','trim','split','remove','update','reorder'].includes(type))fail('不支持的时间线操作');
    if(!['video','original','caption','mask',...AUDIO].includes(kind))fail('不支持的轨道类型');
    const view=get(project,kind,id),next=clone(project),warnings=[];
    const videoViews=project.clips.map(clip=>beforeLayout.items.find(row=>row.kind==='video'&&row.id===clip.id));
    const magneticVideo=operation.magnetic!==false&&videoViews.every((row,index)=>row&&(index===0?Math.abs(row.start)<EPS:Math.abs(row.start-videoViews[index-1].end)<EPS));
    if((project.track_locks||[]).includes(kind))fail('这条轨道已锁定，请先解锁');
    const list=kind==='video'||kind==='original'?next.clips:kind==='caption'?next.captions:kind==='mask'?next.masks:next.audios;
    const index=list.findIndex(item=>item.id===id),item=list[index];
    if(kind==='video'&&type!=='reorder'&&(type==='move'||!magneticVideo))for(const video of next.clips){video.start=beforeLayout.items.find(v=>v.kind==='video'&&v.id===video.id).start}
    if(kind==='original'&&type!=='update'){
      if((project.track_locks||[]).includes('dialogue'))fail('人物原声轨已锁定，请先解锁');
      const a=project.assets.find(a=>a.id===item.asset_id),streams=a.audio_streams||[];
      const stream=item.audio_stream==null?(streams.length===1?streams[0]:null):streams.find(s=>s.index===item.audio_stream);
      if(!stream||!stream.duration_verified)fail('请先明确选择已确认时长的原声音轨');
      const sourceIn=Math.max(item.in,stream.start||0),sourceOut=Math.min(item.in+view.end-view.start,stream.end);
      if(sourceOut<=sourceIn)fail('此画面选段内没有有效原声');
      const audio={id:newIdentifier(next,newId),asset_id:item.asset_id,role:'dialogue',start:view.start+sourceIn-item.in,in:sourceIn,out:sourceOut,
        gain:item.gain||0,audio_stream:stream.index,detached_from:item.id,loop:false};
      item.audio_detached=true;next.audios.push(audio);
      const result=apply(next,{...operation,kind:'dialogue',id:audio.id},newId);
      return {...result,selection:{kind:'dialogue',id:audio.id},warnings:['原声已分离，画面保持位置。',...result.warnings]};
    }
    if(kind==='caption'&&type==='split')fail('字幕不能自动复制切分；请先按语义人工分句，再分别设置起止时间');
    if(kind==='mask'&&type==='split')fail('打码暂不支持切分；请添加第二个打码区间');
    if(type==='update'){
      const patch=operation.patch;
      if(kind==='original')patchItem(item,patch,['gain','audio_stream'],fps);
      else if(kind==='video'){patchItem(item,patch,['start','in','out','gain','audio_stream'],fps);if(magneticVideo&&('in' in patch||'out' in patch))for(const clip of next.clips)delete clip.start}
      else if(kind==='caption')patchItem(item,patch,['text','start','end','style'],fps);
      else if(kind==='mask')patchItem(item,patch,['start','end','x','y','w','h','blur','white','feather','mode','layer','keyframes'],fps);
      else{
        if(patch&&patch.role!==undefined&&patch.role!==item.role&&item.loop&&patch.loop===undefined)fail('改变带循环标记的音频类型前，请明确关闭循环，避免渲染语义变化');
        patchItem(item,patch,['start','in','out','gain','audio_stream','loop','role','loop_duration','loop_offset'],fps);
        if(patch&&patch.loop===true&&item.role!=='bgm')fail('只有BGM支持循环，请先选择BGM类型');
        if(item.loop&&item.role==='bgm'&&(patch.loop===true||patch.role==='bgm'))warnings.push('循环BGM会从开始位置持续到画面结尾，不以单次素材长度结束。');
      }
    }else if(type==='remove'){list.splice(index,1);if(kind==='video'&&magneticVideo)for(const clip of next.clips)delete clip.start}
    else if(type==='reorder'){
      if(kind!=='video')fail('只有磁吸视频轨支持插入排序；其他轨道请移动绝对时间');
      let target;
      if(type==='reorder'){
        if(!Number.isInteger(operation.targetIndex)||operation.targetIndex<0||operation.targetIndex>=list.length)fail('视频目标排序位置无效');
        target=operation.targetIndex;
      }else{
        const targetTime=frame(operation.targetTime,fps,'目标时间');
        target=beforeLayout.items.filter(v=>v.kind==='video'&&v.id!==id&&targetTime>=(v.start+v.end)/2).length;
      }
      list.splice(index,1);list.splice(target,0,item);
      for(const clip of list)delete clip.start;
    }else if(type==='move'){
      const start=frame(operation.targetTime,fps,'目标时间');
      if(kind==='video')for(const video of next.clips){const previous=beforeLayout.items.find(v=>v.kind==='video'&&v.id===video.id);video.start=previous.start}
      if(kind==='caption'||kind==='mask'){
        const length=item.end-item.start;
        if(kind==='mask'){const delta=start-item.start;item.keyframes=item.keyframes.map(point=>({...point,time:point.time+delta}))}
        item.start=start;item.end=start+length;
      }else item.start=start;
    }else if(type==='trim'){
      if(operation.start===undefined&&operation.end===undefined)fail('请指定裁剪开始或结束时间');
      const start=operation.start===undefined?view.start:frame(operation.start,fps,'裁剪开始');
      const end=operation.end===undefined?view.end:frame(operation.end,fps,'裁剪结束');
      if(end<=start)fail('裁剪结束必须晚于开始');
      if(kind==='video'){
        if(!magneticVideo)for(const video of next.clips){const previous=beforeLayout.items.find(v=>v.kind==='video'&&v.id===video.id);video.start=previous.start}
        const oldIn=item.in;
        if(operation.start!==undefined)item.in=oldIn+(start-view.start);
        if(operation.end!==undefined&&Math.abs(end-view.end)>EPS)item.out=oldIn+(end-view.start);
        if(magneticVideo)for(const video of next.clips)delete video.start;else item.start=start;
      }else if(kind==='caption'){item.start=start;item.end=end}
      else if(kind==='mask'){
        if(start>view.start+EPS){const at=maskPosition(item,start);item.x=at.x;item.y=at.y;item.w=at.w;item.h=at.h}
        item.start=start;item.end=end;
        item.keyframes=item.keyframes.filter(point=>point.time>start+EPS&&point.time<end-EPS);
      }
      else if(kind==='bgm'&&item.loop){
        const period=item.out-item.in;
        item.loop_offset=(((item.loop_offset||0)+start-view.start)%period+period)%period;
        item.start=start;item.loop_duration=end-start;
      }else{
        const oldIn=item.in;
        item.in=oldIn+(start-view.start);item.out=oldIn+(end-view.start);item.start=start;
      }
    }else if(type==='split'){
      const time=frame(operation.time,fps,'切分时间');
      const offsetFrames=Math.round((time-view.start)*fps);
      const totalFrames=kind==='video'?frameCount(item,fps):null;
      if(kind==='video'?(offsetFrames<=0||offsetFrames>=totalFrames):(time-view.start<1/fps-EPS||view.end-time<1/fps-EPS))fail('请在片段内部按帧切分，两侧至少各保留一帧');
      if(kind==='bgm'&&item.loop){
        const right=clone(item),period=item.out-item.in;right.id=newIdentifier(next,newId);
        right.start=time;right.loop_duration=view.end-time;right.loop_offset=((item.loop_offset||0)+time-view.start)%period;
        item.loop_duration=time-view.start;list.splice(index+1,0,right);
        validate(next,true);return {project:next,warnings:[]};
      }
      const right=clone(item),boundary=item.in+(kind==='video'?offsetFrames/fps:time-view.start);
      right.id=newIdentifier(next,newId);right.in=boundary;item.out=boundary;
      if(kind==='video'){if(magneticVideo){for(const video of next.clips)delete video.start;delete right.start}else{for(const video of next.clips){const previous=beforeLayout.items.find(v=>v.kind==='video'&&v.id===video.id);video.start=previous.start}right.start=time}}
      if(AUDIO.has(kind)){
        right.start=time;
        // Preserve optional legacy fades at the outside edges only. This does
        // not claim custom fades are currently supported by the renderer.
        if(Object.hasOwn(item,'fade_out'))item.fade_out=0;
        if(Object.hasOwn(right,'fade_in'))right.fade_in=0;
      }
      list.splice(index+1,0,right);
    }
    validate(next,true);
    const videos=layout(next).items.filter(v=>v.kind==='video').sort((a,b)=>a.start-b.start);
    for(let i=1;i<videos.length;i++)if(videos[i].start<videos[i-1].end-EPS)fail('画面片段重叠：请放到空白区，或先移开相邻镜头');
    preserveOrReduceOverlaps(project,next);
    const changed=JSON.stringify(next)!==JSON.stringify(project);
    if(changed){
      next.reviews={};
      if(kind==='video'||kind==='original'||AUDIO.has(kind)){
        for(const cue of next.captions)delete cue.speech;
        warnings.push('声音版本已变化，已清除字幕发声验证；请重新试听并确认字幕同步。');
      }else if(kind==='caption'){
        for(const cue of next.captions)if(cue.id===id)delete cue.speech;
        warnings.push('字幕内容或时间已修改，请重新核对实际发声与字幕边界。');
      }else if(kind==='mask'){
        warnings.push('打码已修改；旧预览不会自动更新，请重新生成并检查遮挡范围。');
      }
      if(kind==='video')warnings.push(project.native_links?.[id]?.linked_audio_id?'画面与关联原声同步修改；主轨保持吸附。':'主轨保持吸附；字幕和独立声音保留原时间。');
    }
    return {project:next,warnings:[...new Set([...warnings,...layout(next).warnings])]};
  }
  return {layout,get,apply,fpsValue};
});
