'use strict';

function installMediaRelink(){
  let status=null,serial=0;
  const oldOpen=openProject;
  async function refreshStatus(){
    if(!p)return;
    const pid=p.id,result=await api(`/api/projects/${pid}/media-status`,{});
    if(p?.id!==pid)return;
    status=result;
    let notice=$('#missing-media-notice');
    if(!notice){notice=document.createElement('div');notice.id='missing-media-notice';notice.className='parallel-editor-notice';$('.project-heading').after(notice)}
    const missing=result.assets.filter(a=>a.missing);notice.hidden=!missing.length;
    notice.innerHTML=missing.length?`<span>素材已经丢失：${missing.length} 项。工程和原裁剪仍然保留，请重连素材；不会自动删除片段。</span><button id="missing-media-relink">重连素材</button>`:'';
    if(missing.length)$('#missing-media-relink').onclick=handle(()=>openRelink(missing[0].id));
  }
  openProject=async function(...args){await oldOpen(...args);await refreshStatus()};
  async function openRelink(assetId){
    if(!p)throw Error('请先打开工程');
    await save();
    const pid=p.id,revision=p.revision,assets=p.assets.map(a=>({...a}));
    let preview=null;
    modal(`<h2>重连素材</h2><p>选择原文件的新位置。按 SHA-256 核对内容，不按同名猜测；保留原入出点、时间位置、音量与联动。不同内容请使用替换，不会悄悄当成原素材。</p><label>丢失或移动的素材</label><select id="relink-source">${assets.map(a=>`<option value="${a.id}" ${a.id===assetId?'selected':''}>${esc(a.name)}${status?.assets.find(row=>row.id===a.id)?.missing?' · 已丢失':''}</option>`).join('')}</select><p id="relink-old-path" class="helper"></p><label>新文件路径</label><div class="row"><input id="relink-path" placeholder="选择原媒体文件，或粘贴完整路径"><button id="relink-pick">选择文件</button></div><p id="relink-result" role="status"></p><div class="modal-actions"><button id="relink-check">检查素材</button><button id="relink-confirm" class="primary" disabled>确认重连并保留原裁剪</button></div>`);
    const invalidate=()=>{preview=null;$('#relink-confirm').disabled=true;$('#relink-result').textContent='';$('#relink-old-path').textContent=assets.find(a=>a.id===$('#relink-source').value)?.path||''};
    $('#relink-source').onchange=invalidate;$('#relink-path').oninput=invalidate;invalidate();
    $('#relink-pick').onclick=()=>{
      if(!window.chrome?.webview){$('#relink-result').textContent='浏览器无法读取文件的原始完整路径，请从资源管理器复制路径粘贴到上方。桌面版可直接选择文件。';$('#relink-path').focus();return}
      const request_id='relink-'+(++serial);
      const listener=event=>{
        const data=event.data;if(data?.type!=='media-file-picked'||data.request_id!==request_id)return;
        window.chrome.webview.removeEventListener('message',listener);
        if(p?.id!==pid||!$('#relink-path'))return;
        if(data.path){$('#relink-path').value=data.path;invalidate();$('#relink-check').click()}
      };
      window.chrome.webview.addEventListener('message',listener);
      window.chrome.webview.postMessage({type:'pick-media-file',request_id});
      $('#relink-result').textContent='请选择原文件；若旧桌面程序未响应，可直接粘贴完整路径。';
    };
    $('#relink-check').onclick=handle(async()=>{
      invalidate();const source=$('#relink-source').value,path=$('#relink-path').value;
      const result=await api(`/api/projects/${pid}/relink-preview`,{revision,asset_id:source,path});
      if(p?.id!==pid||!$('#relink-path')||$('#relink-path').value!==path||$('#relink-source').value!==source)return;
      preview=result;$('#relink-result').textContent=`${result.notice}。时长 ${time(result.asset.duration)}，${result.asset.width||0} × ${result.asset.height||0}。`;
      $('#relink-confirm').disabled=!result.identical;
    });
    $('#relink-confirm').onclick=handle(async()=>{
      if(!preview?.identical)throw Error('请先检查并确认原素材');
      if(p?.id!==pid||p.revision!==revision)throw Error('工程已变化，请重新打开重连');
      $('#relink-confirm').disabled=true;
      try{
        const result=await api(`/api/projects/${pid}/relink-asset`,{revision,asset_id:preview.asset.id,path:preview.asset.path,expected_sha256:preview.asset.sha256,confirmed:true});
        if(p?.id===pid){remember();studioProjectHooks.adopt(result);render();window.StudioRealtime?.refresh();await refreshQA();await refreshStatus()}
        $('#modal').close();toast('素材已重连，保留原裁剪和时间位置；请播放核对。');
      }catch(error){$('#relink-confirm').disabled=false;throw error}
    });
  }
  window.studioMediaRelink={open:openRelink,refresh:refreshStatus};
}
