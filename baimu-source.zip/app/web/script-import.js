'use strict';

const StudioScripts={
  maxBytes:16*1024*1024,
  accepts(name){return /\.(pdf|txt|md|docx)$/i.test(String(name||''))},
  number(name){
    const match=String(name||'').trim().match(/^(?:第\s*([0-9零〇一二三四五六七八九十百千两]+)\s*[集章]|(?:EP(?:ISODE|IS[OÓ]DIO)?\.?|CAP[IÍ]TULO)\s*(\d+)\b|(\d+)$)/i);
    if(!match)return null;const raw=match[1]||match[2]||match[3];if(/^\d+$/.test(raw))return Number(raw);
    const digits={'零':0,'〇':0,'一':1,'二':2,'两':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9};let total=0,n=0;
    if(!/[十百千]/.test(raw)){if([...raw].some(char=>!Object.hasOwn(digits,char)))return null;return Number([...raw].map(char=>digits[char]).join(''))}
    for(const char of raw){if(char==='十'||char==='百'||char==='千'){total+=(n||1)*({'十':10,'百':100,'千':1000}[char]);n=0}else if(Object.hasOwn(digits,char))n=digits[char];else return null}return total+n;
  },
  projects(rows,series){return rows.filter(row=>!row.archived&&(row.series||'')===series)},
  suggested(section,rows,currentId){
    if(section.number===null||section.number===undefined||section.ambiguous)return '';
    const matches=rows.filter(row=>this.number(row.name)===Number(section.number));
    if(currentId&&matches.some(row=>row.id===currentId))return currentId;
    return matches.length===1?matches[0].id:'';
  },
  mapping(sections,choices,rows,series){
    const items=[],used=new Set();
    sections.forEach((section,index)=>{
      const choice=choices[index];if(!choice?.selected)return;
      if(!choice.target)throw Error('请为“'+section.title+'”选择目标工程，未知集数不能自动猜测');
      if(choice.target==='new'){
        const name=String(choice.name||'').trim();if(!name||name.length>150)throw Error('新建集名需为 1–150 个字符');
        items.push({section_id:section.id,create_new:true,name,series});
      }else{
        const row=rows.find(row=>row.id===choice.target&&(row.series||'')===series&&!row.archived);
        if(!row)throw Error('目标工程不在所选剧名中，请重新选择；不会跨剧匹配同集号');
        if(used.has(row.id))throw Error('不能把两个章节同时写到同一个工程，请重新分配');
        used.add(row.id);items.push({section_id:section.id,project_id:row.id,revision:row.revision,replace_confirmed:false});
      }
    });
    if(!items.length)throw Error('请先逐项勾选确实要使用的剧本章节');
    if(series.length>150)throw Error('剧名最多150个字符');return items;
  },
  projectId(row){return row.project_id||row.id},
  resultLabel(row){if(row.archived)return '工程已在回收站，未自动恢复';if(row.unavailable)return '工程暂不可用，请检查工程管理';return row.created||row.state==='created'?'已创建独立工程':row.state==='reused'?'复用本预览已写入的工程，未重复覆盖':'已更新剧本'},
  async filePayload(file){
    if(!this.accepts(file.name))throw Error('仅支持 PDF、TXT、MD、DOCX 剧本文件');
    if(!Number.isSafeInteger(file.size)||file.size<1||file.size>this.maxBytes)throw Error('每份剧本必须非空且不超过 16 MiB');
    const data=new Uint8Array(await file.arrayBuffer());if(data.length!==file.size||data.length>this.maxBytes)throw Error('剧本文件在读取时发生变化，请重新选择');
    let binary='';for(let start=0;start<data.length;start+=32768)binary+=String.fromCharCode(...data.subarray(start,start+32768));
    return {name:file.name,content_base64:btoa(binary)};
  }
};
if(typeof module!=='undefined'&&module.exports)module.exports=StudioScripts;

function installScriptImport(){
  const originalRenderScript=renderScript,confirmAction=window.studioProjectConfirm,hooks=window.studioProjectHooks;
  let flow=null;
  const pendingDiscards=new Set(),discarding=new Map();
  const input=$('#script-file-input'),dialog=$('#modal');
  const live=state=>flow===state;
  const controls=['#global-new-button','#global-manage-button','#new-button','#manage-button','#batch-button','#batch-queue-button','#material-picker-button','#folder-picker-button','#folder-drop-path','#script-picker-button','#import-button','#close-modal'];
  const disabled=new Map();
  function lock(value){controls.forEach(selector=>{const el=$(selector);if(!el)return;if(value){disabled.set(selector,!!el.disabled);el.disabled=true}else el.disabled=disabled.get(selector)||false});if(!value)disabled.clear()}
  function paint(state,html){if(live(state)){modal(html);$('#close-modal').disabled=true}}
  async function discard(id){
    if(!id)return true;if(discarding.has(id))return discarding.get(id);
    const work=(async()=>{try{await api(`/api/script-import/${encodeURIComponent(id)}/discard`,{});pendingDiscards.delete(id);return true}catch(error){pendingDiscards.add(id);toast('未能释放这份剧本的预览内存；没有删除文件或工程。下次读取时会重试，也可等待预览30分钟过期：'+error.message,true);return false}})();
    discarding.set(id,work);try{return await work}finally{discarding.delete(id)}
  }
  async function releasePreview(state){const id=state.preview?.id;state.preview=null;return discard(id)}
  async function retryDiscards(){for(const id of [...pendingDiscards])await discard(id)}
  function close(state=flow){if(!live(state))return;flow=null;state.closed=true;lock(false);input.value='';dialog.close();void releasePreview(state)}
  function canBegin(){
    if(flow||window.studioFolderDrop?.busy?.()||dialog.open||$('#project-confirm').open){toast('请先完成或关闭当前操作，再读取剧本。',true);return false}return true;
  }
  function createState(options={}){
    if(!canBegin())return null;
    flow={phase:'entry',documents:[],index:0,contextId:options.currentId||null,series:options.currentId===p?.id?(p.series||''):'',closed:false,preview:null,choices:[],results:[]};lock(true);return flow;
  }
  function cancel(state){if(!live(state))return;if(state.phase==='applying'){toast('正在写入已确认的工程，请等待结果，不能把已提交的写入当成撤销。',true);return}close(state)}
  dialog.addEventListener('cancel',event=>{if(flow){event.preventDefault();cancel(flow)}});
  document.addEventListener('click',event=>{if(!flow)return;if(event.target===input||dialog.contains(event.target)||$('#project-confirm').contains(event.target))return;if(event.target.closest?.('button,a,input,select,[data-project]')){event.preventDefault();event.stopImmediatePropagation();toast('请先完成剧本预览或取消此次操作。')}},true);
  window.addEventListener('beforeunload',event=>{if(flow?.phase==='applying'){event.preventDefault();event.returnValue='已确认的剧本写入仍在处理，请等待结果。'}});
  function entry(options={}){
    const state=createState(options);if(!state)return;
    paint(state,`<h2>读取剧本 / 预览分集</h2><p>PDF、TXT、MD、DOCX，每份最多 16 MiB；只在本机读取。预览不会改动任何工程，也不会变成字幕或修改声音。${state.contextId?'本次从当前集进入，匹配建议仍需你逐项勾选确认。':''}</p><button id="script-choose-file" class="accent">选择剧本文件（可多份）</button><hr class="section-break"><label>本机剧本文件完整路径</label><input id="script-source-path" placeholder="C:\\剧本\\全剧.txt"><button id="script-read-path">读取路径并预览</button><hr class="section-break"><label>或粘贴整部剧本文字（保留各集标题）</label><input id="script-source-name" value="粘贴剧本.txt" placeholder="剧本名称"><textarea id="script-source-text" rows="7" placeholder="第1集\n本集内容……\n第2集\n下一集内容……"></textarea><div class="modal-actions"><button id="script-entry-cancel">取消</button><button id="script-read-text" class="primary">预览粘贴的剧本</button></div>`);
    $('#script-entry-cancel').onclick=()=>close(state);
    $('#script-choose-file').onclick=()=>{input.click()};
    $('#script-read-path').onclick=handle(async()=>{const path=$('#script-source-path').value.trim();if(!path)throw Error('请填写一份剧本文件的完整路径');await read(state,{path})});
    $('#script-read-text').onclick=handle(async()=>{const text=$('#script-source-text').value,name=$('#script-source-name').value.trim()||'粘贴剧本.txt';if(!text.trim())throw Error('请先粘贴剧本文字');if(new Blob([text]).size>StudioScripts.maxBytes)throw Error('剧本文字超过 16 MiB，请分文件导入');await read(state,{name,text})});
  }
  async function startFiles(files,options={}){
    let state=options.state;
    if(!state){state=createState(options);if(!state)return}
    if(!live(state))return;
    const accepted=Array.from(files||[]).filter(file=>StudioScripts.accepts(file.name));
    if(!accepted.length){showError(state,Error('没有识别到 PDF / TXT / MD / DOCX 剧本'));return}
    if(accepted.length>30){showError(state,Error('一次最多预览30份剧本，请按剧名分批选择'));return}
    state.documents=accepted;state.index=0;await readNext(state);
  }
  async function readNext(state){
    const file=state.documents[state.index];if(!file)return;
    await read(state,()=>StudioScripts.filePayload(file));
  }
  async function read(state,source){
    if(!live(state)||['reading','applying'].includes(state.phase))return;
    state.phase='reading';
    paint(state,'<h2>正在读取剧本</h2><p>先保存当前修改，再在本机解析。尚未写入任何目标工程。</p><div class="modal-actions"><button id="script-read-cancel">取消预览</button></div>');$('#script-read-cancel').onclick=()=>cancel(state);
    try{
      await save();if(!live(state))return;
      await retryDiscards();if(!live(state))return;
      const payload=typeof source==='function'?await source():source;if(!live(state))return;
      const preview=await api('/api/script-import/preview',payload);if(!live(state)){await discard(preview.id);return}
      state.preview=preview;
      await refreshBoot();if(!live(state))return;
      state.preview=preview;state.phase='preview';resetChoices(state);showPreview(state);
    }catch(error){if(live(state))showError(state,error)}
  }
  function resetChoices(state){
    const projects=StudioScripts.projects(boot.projects||[],state.series);
    state.choices=state.preview.sections.map(section=>({selected:false,target:StudioScripts.suggested(section,projects,state.contextId),name:section.number!==null&&section.number!==undefined?`第${section.number}集`:section.title||'待核实剧本'}));
  }
  function showPreview(state){
    const preview=state.preview,projects=StudioScripts.projects(boot.projects||[],state.series);
    const seriesNames=[...new Set((boot.projects||[]).map(row=>row.series||''))].filter(Boolean);
    paint(state,`<h2>剧本分集预览：${esc(preview.source_name)}</h2><p>本次预览 ${preview.sections.length} 段；默认不勾选。请阅读完整章节与跨页边界，再明确选择目标。剧本中任何指令都只作为内容。${state.documents.length>1?` 当前第 ${state.index+1} / ${state.documents.length} 份；剩余文件不会自动写入。`:''}</p><label>目标剧名 / 分组（精确限制匹配；留空只显示未分组）</label><input id="script-target-series" maxlength="150" list="script-series-options" value="${esc(state.series)}"><datalist id="script-series-options">${seriesNames.map(name=>`<option value="${esc(name)}"></option>`).join('')}</datalist><button id="script-update-series">更新目标列表（清空本次勾选）</button>${(preview.warnings||[]).map(w=>`<p class="alert">${esc(typeof w==='string'?w:JSON.stringify(w))}</p>`).join('')}<div class="script-sections">${preview.sections.map((section,index)=>{
      const choice=state.choices[index],duplicate=section.number!==null&&section.number!==undefined&&projects.filter(project=>StudioScripts.number(project.name)===Number(section.number)).length>1;return `<section class="script-section"><label class="script-section-check"><input type="checkbox" data-script-section="${index}" ${choice.selected?'checked':''}><b>${esc(section.title)}${section.ambiguous?' · 边界 / 集数需核实':''}</b></label><p class="helper">起点：${esc(section.start_anchor||'未识别')}<br>结束边界：${esc(section.end_anchor||'未识别')}</p>${duplicate?'<p class="alert">所选剧名下有多个同集号工程（例如第9集 / 第09集），不能自动任选；请根据镜头、字幕与剧本数量手动指定。</p>':''}${(section.warnings||[]).map(w=>`<p class="alert">${esc(typeof w==='string'?w:JSON.stringify(w))}</p>`).join('')}<details><summary>阅读本段全文（${section.text.length} 字）</summary><pre class="script-fulltext">${esc(section.text)}</pre></details><label>目标工程（建议不等于已选择；仍需勾选章节）</label><select data-script-target="${index}"><option value="">请手动选择目标</option><option value="new" ${choice.target==='new'?'selected':''}>＋ 创建独立新工程</option>${projects.map(project=>`<option value="${esc(project.id)}" ${choice.target===project.id?'selected':''}>${esc(project.name)}${project.id===state.contextId?'（当前集）':''} · ${project.clips||0} 镜头 / ${project.captions||0} 字幕 / 剧本 ${project.script_chars||0} 字</option>`).join('')}</select><input data-script-name="${index}" value="${esc(choice.name)}" maxlength="150" aria-label="新工程集名" placeholder="选择新建时使用此集名" ${choice.target==='new'?'':'hidden'}></section>`;
    }).join('')}</div><p id="script-selection-count" class="manager-count"></p><div class="modal-actions"><button id="script-preview-cancel">取消，不写入</button>${state.index+1<state.documents.length?'<button id="script-next-skip">跳过这份，预览下一份</button>':''}<button id="script-apply" class="primary" disabled>核对所选章节与目标</button></div>`);
    function count(){const n=state.choices.filter(choice=>choice.selected).length;$('#script-selection-count').textContent=`已勾选 ${n} 段，写入前还需确认目标与替换清单`;$('#script-apply').disabled=!n}
    $$('[data-script-section]').forEach(box=>box.onchange=()=>{state.choices[Number(box.dataset.scriptSection)].selected=box.checked;count()});
    $$('[data-script-target]').forEach(select=>select.onchange=()=>{const index=Number(select.dataset.scriptTarget);state.choices[index].target=select.value;$(`[data-script-name="${index}"]`).hidden=select.value!=='new'});
    $$('[data-script-name]').forEach(field=>field.oninput=()=>state.choices[Number(field.dataset.scriptName)].name=field.value);
    $('#script-update-series').onclick=()=>{const next=$('#script-target-series').value.trim();if(next.length>150)return toast('剧名最多150个字符',true);state.series=next;resetChoices(state);showPreview(state)};
    $('#script-preview-cancel').onclick=()=>close(state);
    if(state.index+1<state.documents.length)$('#script-next-skip').onclick=handle(()=>nextDocument(state));
    $('#script-apply').onclick=handle(()=>apply(state));count();
  }
  async function nextDocument(state){
    if(!live(state)||state.phase==='applying'||state.phase==='reading'||state.phase==='releasing')return;
    state.phase='releasing';await releasePreview(state);if(!live(state))return;state.index++;await readNext(state);
  }
  async function apply(state){
    if(!live(state)||state.phase!=='preview')return;
    if($('#script-target-series').value.trim()!==state.series)throw Error('剧名输入已改变，请先点“更新目标列表”，防止写入上一部剧');
    const items=StudioScripts.mapping(state.preview.sections,state.choices,boot.projects||[],state.series);
    state.phase='checking';$('#script-apply').disabled=true;
    try{
      await save();if(!live(state))return;
      const currentBefore=p?copy(p):null,countBefore=dirty,undoBefore=copy(undo),targets=new Map();
      // Fetch current revisions and replacement presence instead of trusting a stale sidebar count.
      for(const item of items){if(item.project_id){const project=await api('/api/projects/'+item.project_id);if(project.archived||(project.series||'')!==state.series)throw Error('目标工程分组或回收站状态已改变，请重新预览');targets.set(project.id,project);item.revision=project.revision;item.replace_confirmed=!!(project.script?.text||project.script?.source)}}
      if(!live(state))return;
      const lines=items.map(item=>{const section=state.preview.sections.find(s=>s.id===item.section_id),project=targets.get(item.project_id);return `• ${section.title} → ${item.create_new?'新建 '+item.name:project.name}${item.replace_confirmed?'【替换已有剧本】':''}`});
      const message=`确认写入以下 ${items.length} 段？\n目标剧名：${state.series||'未分组'}\n\n${lines.join('\n')}\n\n只更新所选工程的剧本内容与边界锚点。已有字幕、必保台词、原声音轨、镜头均保留；不会自动勾选“已完整读取”。标记替换的旧剧本会留在工程历史中，需要重新复核。`;
      if(!await confirmAction(message,'确认这些目标与剧本替换')){if(live(state)){state.phase='preview';$('#script-apply').disabled=false}return}
      if(!live(state))return;state.phase='applying';
      paint(state,'<h2>正在写入已确认的剧本</h2><p>请等待具体结果。不会自动添加字幕、修改原声或删除对白保护清单。</p>');
      let outcome,problem=null;
      try{outcome=await hooks.transaction(()=>api(`/api/script-import/${state.preview.id}/apply`,{confirmed:true,items}))}
      catch(error){problem=error;outcome=error.data||{results:[]}}
      if(!live(state))return;
      const results=outcome.results||[];state.results=results;
      try{await refreshBoot()}catch(error){toast('写入结果已经收到，但工程列表刷新失败：'+error.message,true)}
      const changedCurrent=results.some(row=>StudioScripts.projectId(row)===currentBefore?.id);
      if(changedCurrent&&p?.id===currentBefore.id&&dirty===countBefore&&dirty<=saved){
        try{await openProject(currentBefore.id,{skipSave:true});if(p?.id===currentBefore.id){undo=[...undoBefore,currentBefore].slice(-40);tab='script';render()}}catch(error){toast('剧本已保存，但当前工程重载失败，请稍后手动打开：'+error.message,true)}
      }else if(changedCurrent&&p?.id===currentBefore.id)toast('当前存在更新的本地编辑，已保留，没有用导入结果覆盖；请先保存草稿再手动重载。',true);
      if(live(state))showResults(state,results,problem);
    }catch(error){if(live(state)){state.phase='preview';showPreview(state);toast(error.message,true)}}
  }
  function showResults(state,results,error){
    state.phase='results';
    paint(state,`<h2>${error?'剧本写入未全部确认':'剧本写入结果'}</h2>${error?`<div class="alert">${esc(error.message)}。${error.data?'以下返回的成功项已经保存，不能从头盲目重做。':'请求结果未确认，可能已发生写入，不能声称没有改动。'}失败 / 未确认项请检查工程状态后重新预览。</div>`:''}<p>已确认 ${results.length} 项。字幕、镜头与声音未改动；章节“完整读取”仍需人工复核。</p><div class="manager-list">${results.map(row=>`<div class="batch-result"><b>${esc(row.name||StudioScripts.projectId(row)||'工程')}</b><p>${StudioScripts.resultLabel(row)}${row.error?' · '+esc(row.error):''}</p></div>`).join('')||'<p>没有收到已成功项的记录；这不等于确认没有写入。请先检查工程，不自动重试。</p>'}</div><div class="modal-actions">${state.index+1<state.documents.length?'<button id="script-next-file" class="accent">只预览下一份剧本</button>':''}<button id="script-results-done">完成，回到编辑区</button></div>`);
    $('#script-results-done').onclick=()=>close(state);
    if(state.index+1<state.documents.length)$('#script-next-file').onclick=handle(()=>nextDocument(state));
  }
  function showError(state,error){
    state.phase='error';paint(state,`<h2>剧本尚未写入</h2><div class="alert">${esc(error.message)}</div><p>没有据此改动工程。请核对文件、文字与分集标题后重新读取。扫描型 PDF 若不能提取文字，需要提供可复制文本。</p><div class="modal-actions">${state.index+1<state.documents.length?'<button id="script-error-next">跳过这份，预览下一份</button>':''}<button id="script-error-close">关闭</button></div>`);$('#script-error-close').onclick=()=>close(state);
    if(state.index+1<state.documents.length)$('#script-error-next').onclick=handle(()=>nextDocument(state));
  }
  input.onchange=()=>{const files=Array.from(input.files||[]);input.value='';if(files.length)void startFiles(files,flow?{state:flow}:{})};
  $('#script-picker-button').onclick=()=>entry();
  renderScript=function(){
    originalRenderScript();if(!p)return;
    $('#script-import').textContent='读取 / 替换剧本并预览分集';$('#script-import').onclick=()=>entry({currentId:p.id});
    $('#script-text').placeholder='可直接拖入 PDF / TXT / MD / DOCX 剧本，先预览本集匹配再确认；也可在此手动编辑';
    $('#script-text').classList.add('script-drop-zone');
    const tip=document.createElement('p');tip.className='helper script-drop-note';tip.textContent='将剧本文件直接拖进上方大文本框，可预览并匹配当前集；原有剧本不会直接覆盖。';$('#script-text').after(tip);
  };
  window.addEventListener('drop',event=>{
    if(!StudioFolderDrop.hasFiles(event.dataTransfer))return;
    const inPanel=!!event.target.closest?.('#script-text,.script-drop-note');
    const snapshots=StudioFolderDrop.capture(event.dataTransfer);
    const directScripts=snapshots.length&&snapshots.every(item=>!item.entry?.isDirectory&&StudioScripts.accepts(item.file?.name||item.entry?.name));
    if(!inPanel&&!directScripts)return;
    event.preventDefault();event.stopImmediatePropagation();document.body.classList.remove('folder-drag-active');
    const state=createState({currentId:p?.id||null});if(!state)return;
    state.phase='scanning';paint(state,'<h2>读取拖入的剧本清单</h2><p>只在本机解析，之后逐份预览，不会直接覆盖已有剧本。</p>');
    void (async()=>{try{const scan=await StudioFolderDrop.scan(snapshots,{allowScriptRoots:true,cancelled:()=>!live(state)});if(live(state))await startFiles(scan.records.map(row=>row.file),{state})}catch(error){if(live(state))showError(state,error)}})();
  },true);
  window.studioScriptImport={busy:()=>!!flow,open:entry,startFiles};
}
