'use strict';
const StudioWorkflow={
  toPercent(value,dimension,axis){return 50+(axis==='y'?-1:1)*Number(value)/dimension*50},
  fromPercent(value,dimension,axis){return (Number(value)-50)*dimension/50*(axis==='y'?-1:1)}
};
if(typeof module!=='undefined')module.exports=StudioWorkflow;
function installStudioWorkflow(){
  const previous={openProject,renderInspector,mark};let opening=0,packageBusy=false;
  async function restoreOutput(pid,ticket){
    const result=await api('/api/projects/'+pid+'/playback');
    if(ticket!==opening||p?.id!==pid||dirty>saved||$('#video').getAttribute('src'))return false;
    if(result.job){await viewRender(result.job);return true}
    $('#preview-label').textContent='尚无可播放视频';
    $('#preview-note').textContent='本集还没有可用导出或混音预览。点击“生成混音预览”，或导出审阅版。';return false;
  }
  window.studioPreviewSubtitleStyle=async()=>{
    if(!p)return 'none';
    const pid=p.id;
    if(previewJob?.kind==='preview'&&previewJob.result?.sound_digest===qa?.sound_hash&&$('#video').getAttribute('src')){
      updateOverlay();return 'live';
    }
    const result=await api('/api/projects/'+pid+'/playback?mode=mix');
    if(p?.id!==pid)return 'switched';
    if(result.job){
      const position=$('#video').currentTime;
      await viewRender(result.job);
      if(p?.id!==pid)return 'switched';
      if(Number.isFinite(position)&&position>0)$('#video').currentTime=position;
      return 'live';
    }
    return previewJob?.result?.captions_burned?'burned':'none';
  };
  openProject=async function(pid,...args){
    const ticket=++opening;await previous.openProject(pid,...args);
    if(p?.id!==pid||ticket!==opening)return;
    if(window.StudioRealtime)return;
    try{await restoreOutput(pid,ticket)}catch(error){if(p?.id===pid)toast('工程已打开，历史视频暂未加载：'+error.message,true)}
  };
  $('#play-button').onclick=handle(async()=>{
    if(!p)throw Error('请先打开分集');
    const pid=p.id;
    if(!$('#video').getAttribute('src')){
      await save();await restoreOutput(p.id,opening);
      if(p?.id!==pid)return;
      if(!$('#video').getAttribute('src'))throw Error('本集尚无可播放结果，请生成混音预览或导出审阅版');
    }
    if($('#video').paused)await $('#video').play();else $('#video').pause();
  });
  renderInspector=function(){
    previous.renderInspector();if(!p)return;
    let note;
    for(const axis of ['x','y']){
      const percent=document.querySelector(`[data-style="${axis}"]`);if(!percent)continue;
      const dimension=axis==='y'?p.height:p.width,container=percent.parentElement,label=container.querySelector('label');
      label.textContent='剪映位置 '+axis.toUpperCase();percent.hidden=true;
      const input=document.createElement('input');input.type='number';input.id='jianying-'+axis;input.min=-dimension;input.max=dimension;input.step='.01';
      input.value=Number(StudioWorkflow.fromPercent(percent.value,dimension,axis).toFixed(4));
      input.setAttribute('aria-label',label.textContent);
      const hint=document.createElement('small');hint.style.cssText='display:block;color:var(--muted);font-size:10px';
      const sync=()=>{hint.textContent='画布 '+dimension+' px · '+Number(percent.value).toFixed(2)+'%'};sync();
      input.onchange=()=>{
        const value=Number(input.value);
        if(input.value===''||!Number.isFinite(value)||Math.abs(value)>dimension){toast('位置值应在 '+(-dimension)+' 至 '+dimension+' 之间',true);return}
        const converted=StudioWorkflow.toPercent(value,dimension,axis);
        if(Math.abs(Number(percent.value)-converted)<1e-10){sync();return}
        percent.value=converted;percent.onchange();sync();
      };
      container.append(input,hint);note=percent.closest('.row');
    }
    if(note){
      const help=document.createElement('div');help.className='subtitle-preset';help.innerHTML='<p class="helper">整个字幕框居中定位；X 正数向右，Y 正数向上。按当前画布尺寸作 2 倍换算。单行、双行围绕同一中心。此为兼容换算，尚未经本机剪映实测。</p><button id="calibrate-caption-y">校准当前样式：Y = −800</button>';
      note.after(help);help.querySelector('button').onclick=()=>{const input=$('#jianying-y');input.value=-800;input.onchange();toast('已更新当前字幕样式位置；可撤销。请导出样张校准，不会批量修改其他集。')};
    }
  };
  window.addEventListener('beforeunload',event=>{if(packageBusy){event.preventDefault();event.returnValue='工程包正在处理，请等待完成'}});
  async function packageOperation(work){
    if(packageBusy)throw Error('工程包正在处理，请勿重复提交');
    packageBusy=true;try{return await work()}finally{packageBusy=false}
  }
  const share=document.createElement('button');share.id='share-project-button';share.textContent='工程分享';
  document.querySelector('.heading-actions').prepend(share);
  share.onclick=handle(async()=>{
    if(!p)throw Error('请先打开分集');await save();const pid=p.id;
    modal('<h2>单集工程分享包</h2><p>包含当前工程、素材库和所需字体，接收方无需原目录。导入时建立新副本，不覆盖已有工程。</p><p class="helper">不含历史版本、旧成片和外部 PDF/DOCX 原文件；已读入的剧本文字会保留。素材较多时，打包耗时且占用额外磁盘空间。请确认素材与字体允许分享。</p><div id="package-progress"></div><div class="modal-actions"><button id="package-export" class="primary">打包当前已保存版本</button><button id="package-open-import">导入工程包副本</button></div>');
    $('#package-open-import').onclick=()=>showImport();
    $('#package-export').onclick=handle(()=>packageOperation(async()=>{
      await save();if(p?.id!==pid)throw Error('分集已切换，请重新打开工程分享');
      const button=$('#package-export'),progress=$('#package-progress');button.disabled=true;progress.textContent='正在复制并校验素材，请勿关闭窗口…';
      try{
        const result=await api('/api/projects/'+pid+'/package',{revision:p.revision});
        progress.innerHTML=`<p>工程包已生成，${(result.size/1024/1024).toFixed(1)} MB</p><a class="accent" href="${url((result.kind==='native'?'/api/native/packages/':'/api/packages/')+result.id)}" download>保存工程ZIP包</a><p class="helper">${esc(result.note)}</p>`;
      }finally{button.disabled=false}
    }));
  });
  function showImport(){
    const folder=window.studioLibrary?.current();
    modal(`<h2>导入工程包副本</h2><p>填写本机收到的工程ZIP路径。逐个校验素材和字体后创建新工程。</p><input id="package-import-path" placeholder="D:\\收到的工程.zip" style="width:100%"><p class="helper">${folder?'副本将加入当前剧：'+esc(folder.name):'副本将按包内剧名出现在首页'}。验收记录需要重新确认；旧工程、旧导出和历史不覆盖。</p><div id="package-import-status"></div><div class="modal-actions"><button id="package-import-confirm" class="primary">导入为新副本</button></div>`);
    $('#package-import-confirm').onclick=handle(()=>packageOperation(async()=>{
      const path=$('#package-import-path').value.trim();if(!path)throw Error('请填写工程ZIP完整路径');
      const button=$('#package-import-confirm');button.disabled=true;$('#package-import-status').textContent='正在校验并导入…';
      try{
        await save();const created=await api('/api/packages/import',{path,...(folder?{series:folder.series}:{})});
        $('#modal').close();await refreshBoot();
        if(created.kind==='native'){await window.studioNativeDrafts.show(created.key);toast(created.message)}
        else{await openProject(created.id);toast('工程已导入为新副本，旧工程未覆盖')}
      }finally{button.disabled=false}
    }));
  }
  const homeImport=document.createElement('button');homeImport.id='library-import-package';homeImport.textContent='导入工程包';homeImport.onclick=()=>showImport();
  document.querySelector('.library-actions').prepend(homeImport);
}
