'use strict';
function installStudioEditActions(){
  let busy=false,redo=[],polling=false;
  const notice=document.createElement('div');notice.id='parallel-editor-notice';notice.className='parallel-editor-notice';notice.hidden=true;notice.setAttribute('role','status');
  $('.project-heading').after(notice);
  let noticeProject=null,editorRunning=false,syncError='',handoffResult=null,noticeMarkup='';
  function showNotice(){
    if(noticeProject!==p?.id){noticeProject=p?.id;editorRunning=false;syncError='';handoffResult=null;noticeMarkup=''}
    const messages=[];
    if(p?.native?.shared)messages.push(editorRunning?'当前是一份共同草稿。剪映保存后百慕会读取磁盘新版本；百慕保存后，请先在剪映保存当前页面、返回首页，再重开这一集，避免旧页面覆盖新版本。':'当前是一份共同草稿。剪映保存后百慕会自动读取磁盘新版本；百慕修改也直接保存在这份草稿中。');
    if(handoffResult)messages.push(`共同草稿「${handoffResult.name||p.name}」已登记。${handoffResult.refresh_required?'剪映已经运行：保存当前页面并返回首页后打开这一集；不必再次点刷新。若首页仍缓存旧列表，再重启剪映。':'剪映已启动，在本地草稿顶部打开即可。'}`);
    if(syncError)messages.push('暂未同步剪映的新版本：'+syncError+'。当前编辑已保留。');
    notice.hidden=!messages.length;
    const actions=[];
    if(p?.native?.shared)actions.push('<button id="reload-jianying-save">读取剪映已保存</button>');
    if(handoffResult)actions.push('<button id="handoff-reveal">定位工程</button><button id="handoff-launch">打开剪映</button>');
    const markup=messages.map(text=>`<span>${esc(text)}</span>`).join('')+(actions.length?'<div>'+actions.join('')+'</div>':'');
    if(markup===noticeMarkup)return;
    noticeMarkup=markup;notice.innerHTML=markup;
    if(p?.native?.shared)$('#reload-jianying-save').onclick=handle(()=>readSharedSaved(true));
    if(handoffResult){
      const key=handoffResult.key;
      $('#handoff-reveal').onclick=handle(()=>api('/api/native/reveal',{key}));
      $('#handoff-launch').onclick=handle(()=>api('/api/native/launch',{}));
    }
  }
  const oldRemember=remember;
  remember=function(){redo=[];oldRemember()};
  async function transaction(work,saveFirst=true){
    if(busy)throw Error('上一项编辑正在保存');
    busy=true;
    const main=$('main'),previous=main.inert;
    try{
      if(saveFirst)await save();else{clearTimeout(timer);if(saving)await saving}main.inert=true;
      return await studioProjectHooks.transaction(work,{skipSave:!saveFirst});
    }finally{busy=false;main.inert=previous;}
  }
  async function execute(operation){
    return transaction(async()=>{
      const pid=p.id;
      const result=await api(`/api/projects/${pid}/edits`,{revision:p.revision,operations:Array.isArray(operation)?operation:[operation]});
      if(p?.id!==pid)throw Error('工程已切换，请重新打开查看已保存结果');
      if(result.changed){remember();studioProjectHooks.adopt(result.project)}
      render();
      if(result.selection)StudioTimelineUI.select(result.selection.kind,result.selection.id,false);
      return result;
    });
  }
  async function history(direction){
    const stack=direction==='undo'?undo:redo;if(!stack.length)return toast(direction==='undo'?'暂无可撤销的编辑':'暂无可重做的编辑');
    return transaction(async()=>{
      const target=copy(stack.at(-1)),current=copy(p);target.revision=p.revision;
      const savedProject=await api(`/api/projects/${p.id}`,target);
      stack.pop();(direction==='undo'?redo:undo).push(current);
      studioProjectHooks.adopt(savedProject);render();
    },false);
  }
  $('#undo-button').onclick=handle(()=>history('undo'));
  const redoButton=document.createElement('button');redoButton.id='redo-button';redoButton.textContent='↷ 重做';redoButton.title='Ctrl+Shift+Z / Ctrl+Y';$('#undo-button').after(redoButton);
  redoButton.onclick=handle(()=>history('redo'));
  document.addEventListener('keydown',event=>{
    if(event.defaultPrevented||event.isComposing||event.keyCode===229||!p||!(event.ctrlKey||event.metaKey)||event.altKey)return;
    const key=event.key.toLowerCase();if(!['z','y'].includes(key))return;
    if(event.target.closest('input,textarea,select,[contenteditable="true"]')||document.querySelector('dialog[open]'))return;
    event.preventDefault();(event.shiftKey||key==='y'?redoButton:$('#undo-button')).click();
  });
  const oldOpen=openProject;openProject=async function(...args){redo=[];const result=await oldOpen(...args);showNotice();return result};
  window.StudioEditActions={execute,undo:()=>history('undo'),redo:()=>history('redo'),busy:()=>busy};
  const handoff=document.createElement('button');handoff.id='handoff-button';handoff.textContent='导入剪映';$('#export-button').before(handoff);
  handoff.onclick=handle(async()=>{
    if(!p)throw Error('请先打开工程');
    await transaction(async()=>{
      if(p.native?.shared){
        const state=await api(`/api/projects/${p.id}/editor-state`);
        editorRunning=state.editor_running;syncError='';showNotice();
        if(state.revision!==p.revision)throw Error('剪映已有新的保存版本，请先点“读取剪映已保存”再继续');
        if(state.editor_running){
          handoffResult=null;showNotice();
          toast('百慕修改已直接保存；请在剪映返回首页后重开这一集，无需退出或再次刷新');
          return;
        }
      }
      const result=await api(`/api/projects/${p.id}/handoff`,{revision:p.revision});
      studioProjectHooks.adopt(await api(`/api/projects/${p.id}`));render();
      showNotice();handoffResult=result;showNotice();
      if(!result.editor_running)await api('/api/native/launch',{});
      toast(result.refresh_required?'已写入共同草稿；请在剪映保存并返回首页后打开这一集':'已登记共同草稿并启动剪映');
    });
  });
  installBatchJianyingHandoff(transaction,async(result,pid)=>{
    if(p?.id!==pid)return;
    studioProjectHooks.adopt(await api(`/api/projects/${pid}`));render();
    showNotice();handoffResult=result;showNotice();
  });
  async function readSharedSaved(manual=false){
    if(polling||busy||!p?.native?.shared)return;
    if(dirty>saved||saving||StudioTimelineUI.dragging?.()||window.StudioRealtime?.gestureActive()||window.StudioMasks?.dragging()){
      if(manual)throw Error('百慕还有未保存或正在拖动的修改，请保存完成后再读取剪映版本');
      return;
    }
    const pid=p.id,revision=p.revision;polling=true;
    try{
      const state=await api(`/api/projects/${pid}/editor-state`);
      if(p?.id!==pid)return;
      showNotice();editorRunning=state.editor_running;syncError='';showNotice();
      if(state.revision===revision||dirty>saved){if(manual)toast('没有检测到剪映新的已保存版本');return}
      const remote=await api(`/api/projects/${pid}`);
      if(p?.id!==pid||p.revision!==revision||dirty>saved||StudioTimelineUI.dragging?.()||window.StudioRealtime?.gestureActive()||window.StudioMasks?.dragging())return;
      remember();studioProjectHooks.adopt(remote);render();
      toast(manual?'已读取剪映保存的最新版本，可撤销这次更新':'已自动读取剪映保存的新版本，可撤销这次更新');
    }catch(error){if(p?.id===pid){showNotice();syncError=error.message;showNotice()}if(manual)throw error}
    finally{polling=false}
  }
  // Jianying disk saves become visible only when there is no local gesture, draft, or text edit.
  setInterval(async()=>{
    if(document.hidden||document.activeElement?.matches('input,textarea,select'))return;
    await readSharedSaved(false);
  },1500);
}

function installBatchJianyingHandoff(transaction,onImported){
  let running=false,opening=false,stopping=false,rows=[],selected=new Set(),results=new Map();
  const button=document.createElement('button');button.id='batch-handoff-button';button.textContent='批量导入剪映';
  $('#handoff-button').after(button);
  const homeButton=document.createElement('button');homeButton.id='library-batch-handoff';homeButton.textContent='批量导入剪映';
  document.querySelector('.library-actions')?.prepend(homeButton);
  const dialog=document.createElement('dialog');dialog.id='batch-handoff-dialog';dialog.setAttribute('aria-label','批量导入剪映');document.body.append(dialog);
  const el=selector=>dialog.querySelector(selector);
  const visible=()=>rows.filter(row=>(!el('#batch-handoff-series').value||row.series===el('#batch-handoff-series').value)&&(`${row.series||''} ${row.name}`).toLocaleLowerCase().includes(el('#batch-handoff-search').value.trim().toLocaleLowerCase()));
  function draw(){
    el('#batch-handoff-list').innerHTML=visible().map(row=>{
      const result=results.get(row.id);
      return `<label class="manager-row"><input type="checkbox" data-handoff-id="${esc(row.id)}" ${selected.has(row.id)?'checked':''} ${running?'disabled':''}><span><b>${esc(row.name)}</b><small>${esc(row.series||'未分组')}</small><small data-handoff-status="${esc(row.id)}">${esc(result?.message||'待导入')}</small></span></label>`;
    }).join('')||'<p class="helper">没有匹配的分集工程。</p>';
    dialog.querySelectorAll('[data-handoff-id]').forEach(box=>box.onchange=()=>{if(box.checked)selected.add(box.dataset.handoffId);else selected.delete(box.dataset.handoffId);draw()});
    const chosen=rows.filter(row=>selected.has(row.id)),success=chosen.filter(row=>results.get(row.id)?.state==='success').length,failed=chosen.filter(row=>results.get(row.id)?.state==='failed').length;
    el('#batch-handoff-count').textContent=`已选 ${chosen.length} 集 · 成功 ${success} 集 · 失败 ${failed} 集 · 待处理 ${chosen.length-success-failed} 集`;
    el('#batch-handoff-progress').max=Math.max(1,chosen.length);el('#batch-handoff-progress').value=success+failed;
    el('#batch-handoff-start').disabled=running||!chosen.some(row=>results.get(row.id)?.state!=='success');
    el('#batch-handoff-start').textContent=success||failed?'继续导入未成功的集数':'导入所选分集';
    el('#batch-handoff-retry').disabled=running||!failed;
    el('#batch-handoff-stop').hidden=!running;el('#batch-handoff-stop').disabled=stopping;
    for(const selector of ['#batch-handoff-all','#batch-handoff-clear','#batch-handoff-close','#batch-handoff-series','#batch-handoff-search'])el(selector).disabled=running;
    el('#batch-handoff-launch').disabled=running||![...results.values()].some(result=>result.state==='success');
  }
  async function run(failedOnly=false){
    if(running)return;
    const queue=rows.filter(row=>selected.has(row.id)&&(failedOnly?results.get(row.id)?.state==='failed':results.get(row.id)?.state!=='success'));
    if(!queue.length)return;
    running=true;stopping=false;draw();el('#batch-handoff-message').textContent='正在保存当前编辑…';
    try{
      await transaction(async()=>{
        for(const [index,row] of queue.entries()){
          if(stopping)break;
          results.set(row.id,{state:'running',message:'正在导入…'});draw();
          el('#batch-handoff-message').textContent=`正在导入 ${index+1}/${queue.length}：${row.name}`;
          try{
            const project=await api(`/api/projects/${row.id}`);
            const result=await api(`/api/projects/${row.id}/handoff`,{revision:project.revision});
            results.set(row.id,{state:'success',message:`已导入：${result.name||row.name}`});
            try{await onImported(result,row.id)}catch(error){results.get(row.id).message+='；当前视图刷新失败：'+error.message}
          }catch(error){results.set(row.id,{state:'failed',message:'失败：'+error.message})}
          draw();
        }
      });
      el('#batch-handoff-message').textContent=stopping?'已停止后续导入，已成功的工程保留。可继续导入剩余集数。':'批量导入结束。剪映已经运行时请先返回首页查看；若首页仍缓存旧列表，再重启剪映。';
    }catch(error){el('#batch-handoff-message').textContent='未开始导入：'+error.message}
    finally{running=false;stopping=false;draw()}
  }
  async function show(){
    if(running||opening)return;
    opening=true;
    try{
    await refreshBoot();
    rows=[...(boot.projects||[])].filter(row=>!row.archived).sort((a,b)=>(a.series||'').localeCompare(b.series||'','zh')||a.name.localeCompare(b.name,'zh',{numeric:true}));
    selected=new Set();results=new Map();
    const series=[...new Set(rows.map(row=>row.series).filter(Boolean))];
    dialog.innerHTML=`<h2>批量导入剪映</h2><p>勾选需要导入的分集，或全选当前列表。开始前自动保存当前编辑；重复导入会登记同一份工程。</p><div class="toolbar"><select id="batch-handoff-series" aria-label="筛选剧名"><option value="">全部剧名</option>${series.map(name=>`<option value="${esc(name)}">${esc(name)}</option>`).join('')}</select><input id="batch-handoff-search" type="search" placeholder="搜索集名" aria-label="搜索集名"></div><div class="toolbar"><button id="batch-handoff-all">全选当前列表</button><button id="batch-handoff-clear">清空选择</button></div><div class="manager-list" id="batch-handoff-list"></div><div id="batch-handoff-count" class="manager-count" role="status"></div><progress id="batch-handoff-progress" style="width:100%" aria-label="导入进度"></progress><p id="batch-handoff-message" role="status">尚未开始导入。</p><div class="modal-actions"><button id="batch-handoff-start" class="primary">导入所选分集</button><button id="batch-handoff-retry">仅重试失败集数</button><button id="batch-handoff-stop" hidden>完成当前集后停止</button><button id="batch-handoff-launch">打开剪映</button><button id="batch-handoff-close">关闭</button></div>`;
    el('#batch-handoff-series').value=window.studioLibrary?.current()?.series||p?.series||'';
    el('#batch-handoff-series').onchange=draw;el('#batch-handoff-search').oninput=draw;
    el('#batch-handoff-all').onclick=()=>{visible().forEach(row=>selected.add(row.id));draw()};
    el('#batch-handoff-clear').onclick=()=>{selected.clear();draw()};
    el('#batch-handoff-start').onclick=()=>run();el('#batch-handoff-retry').onclick=()=>run(true);
    el('#batch-handoff-stop').onclick=()=>{stopping=true;draw();el('#batch-handoff-message').textContent='正在完成当前集，之后停止。'};
    el('#batch-handoff-launch').onclick=handle(()=>api('/api/native/launch',{}));
    el('#batch-handoff-close').onclick=()=>{if(!running)dialog.close()};
    draw();dialog.showModal();
    }finally{opening=false}
  }
  button.onclick=homeButton.onclick=handle(show);
  dialog.addEventListener('cancel',event=>{if(running)event.preventDefault()});
  window.addEventListener('beforeunload',event=>{if(running){event.preventDefault();event.returnValue='正在批量导入剪映'}});
}
