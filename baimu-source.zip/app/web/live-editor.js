'use strict';
const StudioLiveLayers={
  reference(p){
    const pick=(o,keys)=>Object.fromEntries(keys.map(k=>[k,o[k]??null]));
    const assets=ids=>p.assets.filter(a=>ids.has(a.id)).map(a=>pick(a,['id','sha256'])).sort((a,b)=>a.id.localeCompare(b.id));
    const clips=p.clips.map(c=>pick(c,['asset_id','in','out']));
    return {
      picture:{clips,assets:assets(new Set(clips.map(c=>c.asset_id))),fps:p.fps,width:p.width,height:p.height},
      sound:{clips:p.clips.map(c=>pick(c,['asset_id','in','out','gain','audio_stream','audio_detached'])),audios:p.audios.map(a=>pick(a,['asset_id','in','out','start','gain','role','loop','audio_stream','fade_in','fade_out'])),assets:assets(new Set([...p.clips,...p.audios].map(a=>a.asset_id))),fps:p.fps},
      subtitles:{style:p.style,captions:p.captions.map(c=>pick(c,['text','start','end','style']))},masks:p.masks||[]
    };
  },
  diff(base,current){
    if(!base)return ['picture','sound','subtitles','masks'];
    const a=this.reference(base),b=this.reference(current);
    return Object.keys(a).filter(k=>JSON.stringify(a[k])!==JSON.stringify(b[k]));
  },
  blur(data,w,h,r,lift){
    // Separable, twice-per-axis box filter with symmetric edge extension.
    const mirror=(i,n)=>i<0?-i-1:i>=n?2*n-i-1:i;
    let a=new Uint8ClampedArray(data),b=new Uint8ClampedArray(a.length);const n=2*r+1;
    for(const horizontal of [true,false])for(let pass=0;pass<2;pass++){
      const lines=horizontal?h:w,length=horizontal?w:h;
      for(let line=0;line<lines;line++)for(let c=0;c<3;c++){
        const index=i=>horizontal?(line*w+i)*4+c:(i*w+line)*4+c;
        let sum=0;for(let i=-r;i<=r;i++)sum+=a[index(mirror(i,length))];
        for(let i=0;i<length;i++){
          b[index(i)]=Math.floor(sum/n+.5);
          sum+=a[index(mirror(i+r+1,length))]-a[index(mirror(i-r,length))];
        }
      }
      for(let i=3;i<b.length;i+=4)b[i]=255;[a,b]=[b,a];
    }
    for(let i=0;i<a.length;i+=4)for(let c=0;c<3;c++)a[i+c]=Math.min(255,Math.floor(a[i+c]+lift*255));
    return a;
  }
};
if(typeof module!=='undefined')module.exports=StudioLiveLayers;

function installStudioLiveEditor(){
  const old={openProject,viewRender,mark,updateOverlay,renderInspector,render};
  const video=$('#video'),overlay=$('#caption-overlay');
  let mode='edit',clean=false,opening=0,openEpoch=0,ticket=0,reference=null,drag=null,errorShown=false,lastStatus=0;
  const toolbar=document.createElement('div');toolbar.className='viewer-modes';
  toolbar.innerHTML='<button id="mode-edit" class="accent">编辑预览</button><button id="mode-export">导出结果</button><button id="refresh-edit-preview" title="更新底图／混音" aria-label="更新底图与混音">↻</button><select id="caption-drag-scope" aria-label="字幕拖动范围"><option value="all">整集拖动</option><option value="one">单条拖动</option></select>';
  document.querySelector('.viewer-top').before(toolbar);
  const canvas=document.createElement('canvas');canvas.id='mask-preview-canvas';$('#mask-layer').before(canvas);
  const scratch=document.createElement('canvas'),ctx=scratch.getContext('2d',{willReadFrequently:true}),out=canvas.getContext('2d');
  const editing=()=>mode==='edit'&&clean;
  function status(force=false){
    if(!force&&performance.now()-lastStatus<180)return;lastStatus=performance.now();
    $('#mode-edit').classList.toggle('accent',mode==='edit');$('#mode-export').classList.toggle('accent',mode==='export');
    $('#caption-drag-scope').hidden=mode!=='edit'||tab!=='captions';
    if(!p)return;
    const diff=reference?StudioLiveLayers.diff(reference,p):[],names={picture:'镜头画面',sound:'声音',subtitles:'字幕',masks:'打码'};
    if(mode==='edit'){
      if(!clean){$('#preview-label').textContent='编辑底图尚未准备';return}
      const stale=diff.filter(k=>k==='picture'||k==='sound');
      $('#preview-label').textContent=stale.length?stale.map(k=>names[k]).join('、')+'已改 · 请更新底图／混音':'编辑预览 · 字幕／打码实时';
      $('#preview-note').textContent=stale.length?'当前底图或声音来自旧版本；字幕和打码已即时更新。点击“更新底图／混音”后再核对音画。':'字幕可拖动定位、拖角改字号；打码选中后拖动与调大小。当前为编辑效果，导出结果可单独查看。';
    }else{
      $('#preview-label').textContent='导出结果'+(diff.length?' · '+diff.map(k=>names[k]).join('、')+'已修改':' · 与当前内容一致');
      $('#preview-note').textContent='正在播放真实导出MP4，字幕和打码固定在文件中。返回“编辑预览”可即时调整。';
    }
    overlay.style.display=editing()?'block':'none';
    canvas.style.display=editing()?'block':'none';
    $('#mask-layer').style.display=editing()?'block':'none';
  }
  function paintMasks(t){
    if(!editing()||!p||video.readyState<2){out.clearRect(0,0,canvas.width,canvas.height);return}
    const masks=(p.masks||[]).filter(m=>t>=m.start&&t<m.end);
    const w=Math.min(540,video.videoWidth||540),h=Math.round(w*16/9),scale=w/1080;
    if(canvas.width!==w||canvas.height!==h){canvas.width=scratch.width=w;canvas.height=scratch.height=h}
    out.clearRect(0,0,w,h);if(!masks.length)return;
    try{
      ctx.drawImage(video,0,0,w,h);
      for(const m of masks){
        const at=StudioMasks.position(m,t),left=Math.floor(at.x*scale),top=Math.floor(at.y*scale),right=Math.ceil((at.x+at.w)*scale),bottom=Math.ceil((at.y+at.h)*scale);
        const x=Math.max(0,left),y=Math.max(0,top),mw=Math.max(0,Math.min(w,right)-x),mh=Math.max(0,Math.min(h,bottom)-y);if(!mw||!mh)continue;
        if(m.mode==='solid'){ctx.fillStyle='white';ctx.fillRect(x,y,mw,mh)}
        else{
          const image=ctx.getImageData(x,y,mw,mh),radius=Math.max(1,Math.min(Math.round(m.blur*scale),Math.floor(mw/2),Math.floor(mh/2)));
          image.data.set(StudioLiveLayers.blur(image.data,mw,mh,radius,m.white));ctx.putImageData(image,x,y);
        }
        out.drawImage(scratch,x,y,mw,mh,x,y,mw,mh);
      }
    }catch(error){out.clearRect(0,0,w,h);if(!errorShown){errorShown=true;toast('打码实时预览失败：'+error.message,true)}}
  }
  function adorn(){
    const can=editing()&&tab==='captions'&&!!overlay.textContent;
    overlay.classList.toggle('caption-editable',can);overlay.style.pointerEvents=can?'auto':'none';
    overlay.title=can?'拖动字幕位置；右下角改字号。范围由“拖动”选项决定。':'';
    if(can&&!overlay.querySelector('.caption-resize')){const corner=document.createElement('span');corner.className='caption-resize';corner.dataset.captionResize='1';overlay.append(corner)}
  }
  async function loadEdit(){
    if(!p)return false;const pid=p.id,turn=++ticket;mode='edit';clean=false;status(true);
    $('#preview-label').textContent='正在准备编辑底图…';
    const result=await api('/api/projects/'+pid+'/editing-preview',{});
    if(p?.id!==pid||turn!==ticket)return false;
    await refreshQA();if(p?.id!==pid||turn!==ticket)return false;
    if(!result.job){
      video.pause();video.removeAttribute('src');video.load();reference=null;clean=false;
      status(true);$('#preview-label').textContent='首次编辑：请准备底图／混音';$('#preview-note').textContent='点击“更新底图／混音”。准备一次后，字幕和打码调整即时可见。';return false;
    }
    const job=result.job,position=video.currentTime||0;
    previewJob=job;reference=job.view_reference;clean=true;peaks=job.result.waveform;
    const stale=StudioLiveLayers.diff(reference,p).some(k=>k==='picture'||k==='sound');
    StudioTimelineUI.previewUpdated(stale);
    video.src=url(`/render/${job.id}/${job.result.file}`);video.load();
    if(position>0)video.currentTime=position;
    status(true);updateOverlay(position);drawWave();return true;
  }
  async function loadExport(job=null){
    if(!p)return;const pid=p.id,turn=++ticket;
    if(!job){const result=await api('/api/projects/'+pid+'/playback?mode=export');job=result.job}
    if(p?.id!==pid||turn!==ticket)return;
    if(!job){toast('本集还没有导出结果，可先导出审阅版');return}
    mode='export';clean=false;
    await old.viewRender(job);if(p?.id!==pid||turn!==ticket)return;
    reference=previewJob?.view_reference||null;status(true);updateOverlay();
  }
  $('#mode-edit').onclick=handle(async()=>{await save();await loadEdit()});
  $('#mode-export').onclick=handle(async()=>{await save();await loadExport()});
  $('#refresh-edit-preview').onclick=handle(async()=>{mode='edit';await submitJob('preview')});
  $('#preview-button').textContent='更新底图／混音';$('#preview-button').title='镜头或声音改变后更新；字幕和打码无需重复生成';
  $('#preview-button').onclick=handle(async()=>{mode='edit';await submitJob('preview')});
  openProject=async function(pid,...args){
    const epoch=++openEpoch;ticket++;mode='edit';clean=false;reference=null;opening++;canvas.width=canvas.width;
    try{await old.openProject(pid,...args)}finally{opening--}
    if(epoch!==openEpoch)return;
    if(p?.id===pid&&!window.StudioRealtime)try{await loadEdit()}catch(error){clean=false;status();toast('编辑底图未准备完成：'+error.message,true)}
  };
  viewRender=async function(job){
    if(opening)return;
    if(job.project_id!==p?.id){await openProject(job.project_id);if(p?.id!==job.project_id)return}
    if(job.kind==='preview')await loadEdit();else await loadExport(job);
  };
  mark=function(...args){old.mark(...args);status(true)};
  updateOverlay=function(t){
    old.updateOverlay(t);status();
    adorn();
  };
  renderInspector=function(...args){old.renderInspector(...args);adorn()};
  render=function(...args){old.render(...args);status(true);adorn();paintMasks(video.currentTime||0)};
  video.addEventListener('loadeddata',()=>{updateOverlay();status(true)});
  window.studioPreviewSubtitleStyle=async()=>{
    if(mode!=='edit'||!clean)await loadEdit();updateOverlay();return editing()?'live':'none';
  };
  function finish(e,cancel=false){
    if(!drag||e.pointerId!==drag.pointer)return;
    const d=drag;drag=null;if(overlay.hasPointerCapture(d.pointer))overlay.releasePointerCapture(d.pointer);
    if(p?.id!==d.pid)return;
    if(cancel){p.style=copy(d.before.style);p.captions.forEach(c=>{const original=d.before.captions.find(v=>v.id===c.id);if(original)c.style=copy(original.style||{})});updateOverlay();if(dirty>saved)timer=setTimeout(()=>save().catch(e=>toast(e.message,true)),600);return}
    if(!d.changed)return;
    undo.push(d.before);if(undo.length>40)undo.shift();mark(false);renderInspector();updateOverlay();
  }
  overlay.addEventListener('pointerdown',e=>{
    if(e.button!==0||!editing())return;
    const t=video.currentTime||0,cue=p.captions.find(c=>t>=c.start&&t<c.end);if(!cue)return;
    video.pause();clearTimeout(timer);selected=cue.id;tab='captions';
    const effective={...p.style,...cue.style},box=overlay.getBoundingClientRect();
    drag={pid:p.id,pointer:e.pointerId,cue:cue.id,before:copy(p),x:e.clientX,y:e.clientY,style:effective,height:box.height,
          scope:$('#caption-drag-scope').value,resize:!!e.target.closest('[data-caption-resize]'),changed:false};
    overlay.setPointerCapture(e.pointerId);e.preventDefault();
  });
  overlay.addEventListener('pointermove',e=>{
    if(!drag||e.pointerId!==drag.pointer||p?.id!==drag.pid)return;
    const d=drag,stage=$('#stage').getBoundingClientRect(),dx=e.clientX-d.x,dy=e.clientY-d.y;
    if(Math.abs(dx)+Math.abs(dy)<1&&!d.changed)return;
    const patch=d.resize?{font_size:Math.max(4,Math.min(800,Math.round(d.style.font_size*(1+dy/Math.max(12,d.height)))))}:
      {x:Math.max(0,Math.min(100,d.style.x+dx/stage.width*100)),y:Math.max(0,Math.min(100,d.style.y+dy/stage.height*100))};
    if(d.scope==='all'){
      Object.assign(p.style,patch);for(const c of p.captions)for(const k of Object.keys(patch))if(c.style)delete c.style[k];
    }else{const cue=p.captions.find(c=>c.id===d.cue);cue.style={...cue.style,...patch}}
    d.changed=true;updateOverlay();
  });
  overlay.addEventListener('pointerup',e=>finish(e));overlay.addEventListener('pointercancel',e=>finish(e,true));
  window.addEventListener('keydown',e=>{if(e.key==='Escape'&&drag){e.preventDefault();finish({pointerId:drag.pointer},true)}});
  window.addEventListener('beforeunload',e=>{if(drag?.changed){e.preventDefault();e.returnValue='字幕拖动尚未结束'}});
  window.StudioLiveEditor={editing,paintMasks,refresh:()=>{status(true);updateOverlay()},mode:()=>mode,loadEdit};
}
