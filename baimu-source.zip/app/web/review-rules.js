'use strict';
// Rules and scope live outside p: never mark/save a timeline when editing these.
(() => {
  const link=document.createElement('link');link.rel='stylesheet';link.href='/review-rules.css';document.head.append(link);
  const home=document.createElement('button');home.id='review-rules-home';home.textContent='审核与返工规则';
  $('.library-actions').prepend(home);
  const reviewTab=document.createElement('button');reviewTab.dataset.tab='review';reviewTab.textContent='审核';$('#tabs').append(reviewTab);
  const repairTab=document.createElement('button');repairTab.dataset.tab='repair';repairTab.textContent='修改';$('#tabs').append(repairTab);
  const reviewing=()=>p&&['review','repair'].includes(tab);
  const dialog=document.createElement('dialog');dialog.id='review-skills-dialog';dialog.setAttribute('aria-label','审核与返工规则');document.body.append(dialog);
  let docs=null, draft=null, editorKind='review', editorDirty=false, editorBusy=false, editorOpening=false, context=null, sequence=0, loading=null, scopeOpen=false;
  const editorStatus=message=>{const el=dialog.querySelector('[data-editor-status]');if(el)el.textContent=message};
  function drawEditor(){
    dialog.innerHTML=`<div class="review-dialog-head"><div><h2>审核与返工规则</h2><p>所有分集共用；保存后，Codex 下次审核会读取最新内容。</p></div><button data-editor-close aria-label="关闭规则编辑器">关闭</button></div>
      <div class="review-doc-tabs"><button data-doc="review" class="${editorKind==='review'?'primary':''}">审核要求</button><button data-doc="repair" class="${editorKind==='repair'?'primary':''}">返工方法</button></div>
      <p class="helper">审核要求中的每个 ## 小标题会成为勾选项，正文写细则。新增项默认勾选；改名视为新项。保存不会修改成片。</p>
      <label for="review-markdown">${editorKind==='review'?'审核要求':'返工方法'} · Markdown 原文</label><textarea id="review-markdown" spellcheck="false"></textarea>
      <div class="review-dialog-foot"><span data-editor-status role="status">${editorDirty?'有修改，尚未保存':'已读取当前规则'}</span><button data-editor-reload>重新读取</button><button data-editor-save class="primary">保存两份规则</button></div>`;
    const input=dialog.querySelector('textarea');input.value=draft[editorKind];
    input.oninput=()=>{draft[editorKind]=input.value;editorDirty=true;editorStatus('有修改，尚未保存')};
    dialog.querySelectorAll('[data-doc]').forEach(button=>button.onclick=()=>{editorKind=button.dataset.doc;drawEditor()});
    dialog.querySelector('[data-editor-close]').onclick=closeEditor;
    dialog.querySelector('[data-editor-reload]').onclick=handle(async()=>{
      if(editorDirty&&!confirm('重新读取会丢弃当前未保存的规则文字。继续吗？'))return;
      await loadEditor();
    });
    dialog.querySelector('[data-editor-save]').onclick=async()=>{
      if(editorBusy)return;editorBusy=true;setEditorBusy(true);editorStatus('正在保存…');
      try{
        docs=await api('/api/review-skills',{revision:docs.revision,...draft});
        draft={review:docs.review,repair:docs.repair};editorDirty=false;context=null;
        editorStatus('已保存；新增和修改的内容将在下次审核时核对理解');
        if(reviewing())await loadContext(true);
      }catch(error){editorStatus(error.message+'。当前输入已保留，可先复制再重新读取。')}
      finally{editorBusy=false;setEditorBusy(false)}
    };
  }
  function setEditorBusy(value){dialog.querySelectorAll('button,textarea').forEach(el=>el.disabled=value)}
  async function loadEditor(){
    if(editorBusy)return;editorBusy=true;setEditorBusy(true);
    try{docs=await api('/api/review-skills');draft={review:docs.review,repair:docs.repair};editorDirty=false;drawEditor()}
    finally{editorBusy=false;setEditorBusy(false)}
  }
  async function openEditor(){
    if(editorOpening||dialog.open)return;editorOpening=true;
    try{await loadEditor();dialog.showModal()}finally{editorOpening=false}
  }
  function closeEditor(){
    if(editorBusy)return;
    if(editorDirty&&!confirm('规则文字尚未保存，关闭并放弃这些修改吗？'))return;
    editorDirty=false;dialog.close();
  }
  home.onclick=handle(openEditor);
  dialog.addEventListener('cancel',event=>{event.preventDefault();closeEditor()});
  window.addEventListener('beforeunload',event=>{if(editorDirty){event.preventDefault();event.returnValue='规则文字尚未保存'}});

  function ruleMarkup(item,common=false){
    const status=item.needs_clarification?'新增或修改 · 待确认理解':item.interpretation_current?'已确认理解':'内置初始规则';
    return `<div class="review-rule ${item.needs_clarification?'review-pending':''}">
      ${common?`<b>${esc(item.title)}</b>`:`<label class="review-choice"><input type="checkbox" data-rule="${esc(item.id)}" ${item.selected?'checked':''}><b>${esc(item.title)}</b></label>`}
      <small>${status}</small><details><summary>查看细则与理解说明</summary><pre>${esc(item.body||'尚未填写细则，请补充或与 Codex 确认。')}</pre>
      ${item.interpretation?`<p>${item.interpretation_current?'已确认的理解':'上次理解（原文已变化）'}：</p><blockquote>${esc(item.interpretation)}</blockquote>`:''}
      <label>已确认的理解（各集共用）<textarea data-note="${esc(item.id)}" rows="3" placeholder="可填入与 Codex 讨论后确认的解释">${esc(item.interpretation)}</textarea></label>
      <button data-confirm-rule="${esc(item.id)}">保存为我确认的理解</button></details></div>`;
  }
  function drawContext(){
    if(!reviewing())return;
    if(!context||context.project_id!==p.id){$('#panel').innerHTML='<p class="helper">正在读取本集审核要求…</p>';return}
    $('#panel').innerHTML=`<section class="review-panel"><div class="panel-head"><h3>${tab==='repair'?'修改清单':'审核结果'}</h3><button id="review-edit-rules">编辑规则</button></div>
      <div id="review-findings"><p class="helper">正在读取问题清单…</p></div>
      <details id="review-scope-details" ${tab==='repair'?'hidden':''} ${scopeOpen?'open':''}><summary>自定义审核项目 · 默认全项${context.selected_ids.length!==context.sections.length?' · 已自定义':''}${context.needs_clarification.length?' · 有新规待确认':''}</summary>
      <p class="helper">默认检查全部项目；仅需排除某类时在此调整。这是检查类别，不是修改清单。正在返修时调整范围会使原任务过期。</p>
      <div class="review-toolbar"><button id="review-all">全选</button><button id="review-none">全不选</button><button id="review-refresh">刷新规则</button></div>
      <p id="review-status" role="status">已选 ${context.selected_ids.length} 项 · ${context.needs_clarification.length} 处待确认理解</p>
      ${context.sections.map(s=>ruleMarkup(s)).join('')}
      <details class="review-common"><summary>通用说明与返工方法${context.common.some(s=>s.needs_clarification)?' · 有变更':''}</summary>${context.common.map(s=>ruleMarkup(s,true)).join('')}</details>
      <p class="helper">新增或修改的规则会在下次审核时交给 Codex 核对。确认解释只记录规则含义，不代表成片通过。</p>
      <button id="review-copy-request" class="wide">复制给 Codex 的审片请求</button></details></section>`;
    $('#review-edit-rules').onclick=handle(openEditor);
    $('#review-scope-details').ontoggle=event=>{scopeOpen=event.target.open};
    $('#review-refresh').onclick=handle(()=>loadContext(true));
    const scopedContext=context;
    async function choose(ids){
      const pid=scopedContext.project_id;
      $('#panel').querySelectorAll('button,input,textarea').forEach(el=>el.disabled=true);
      try{
        const next=await api(`/api/projects/${pid}/review-scope`,{rules_revision:scopedContext.rules_revision,scope_revision:scopedContext.scope_revision,selected_ids:ids});
        if(p?.id===pid&&reviewing()){context=next;drawContext()}
      }catch(error){if(p?.id===pid&&reviewing()){drawContext();$('#review-status').textContent=error.message+'；请刷新规则后重试。'}throw error}
    }
    $('#panel').querySelectorAll('[data-rule]').forEach(box=>box.onchange=handle(()=>choose([...$('#panel').querySelectorAll('[data-rule]:checked')].map(el=>el.dataset.rule))));
    $('#review-all').onclick=handle(()=>choose(scopedContext.sections.map(s=>s.id)));
    $('#review-none').onclick=handle(()=>choose([]));
    $('#panel').querySelectorAll('[data-confirm-rule]').forEach(button=>button.onclick=handle(async()=>{
      const pid=scopedContext.project_id,key=button.dataset.confirmRule;
      const note=button.closest('details').querySelector('textarea').value;
      button.disabled=true;
      try{
        const next=await api(`/api/projects/${pid}/review-confirmation`,{rules_revision:scopedContext.rules_revision,scope_revision:scopedContext.scope_revision,id:key,interpretation:note,confirmed_by_user:true});
        if(p?.id===pid&&reviewing()){context=next;drawContext()}
      }finally{button.disabled=false}
    }));
    $('#review-copy-request').onclick=handle(async()=>{
      const sessionOption=boot.settings?.review_rules_preview?`--session-file "${boot.data_dir}/session.json" `:'';
      const message=`请通过 baimu 技能审核百慕${sessionOption?'独立试用版的':''}工程「${p.name}」（ID：${p.id}）。先运行 baimu_client.py ${sessionOption}review-context ${p.id}，从百慕读取最新的两份内置 skill 和本集勾选范围，按 selected_review_markdown 检查实际成片。先与我核对 needs_clarification 中的新规并保存我确认的解释，其它明确项目可继续。此次先审片并报告，不修改工程。`;
      await navigator.clipboard.writeText(message);toast('已复制审片请求，粘贴给 Codex 即可');
    });
    window.studioReviewFindings?.show(scopedContext.project_id);
  }
  async function loadContext(force=false){
    if(!reviewing())return;
    const pid=p.id;
    if(!force&&context?.project_id===pid){drawContext();return}
    if(!force&&loading===pid)return;
    const ticket=++sequence;loading=pid;context=null;drawContext();
    try{
      const value=await api(`/api/projects/${pid}/review-context`);
      if(ticket===sequence&&p?.id===pid&&reviewing()){context=value;drawContext()}
    }catch(error){if(ticket===sequence&&p?.id===pid&&reviewing()){
      $('#panel').innerHTML=`<p class="alert">${esc(error.message)}</p><button id="review-retry">重试读取审核规则</button>`;
      $('#review-retry').onclick=handle(()=>loadContext(true));
    }}finally{if(ticket===sequence)loading=null}
  }
  const oldRender=render;
  let openReviewOnStart=new URLSearchParams(location.search).get('modify')==='1'?'repair':new URLSearchParams(location.search).get('review')==='1'?'review':'';
  render=function(...args){
    if(p&&openReviewOnStart){tab=openReviewOnStart;openReviewOnStart=''}
    oldRender(...args);
    if(reviewing()){
      $('#inspector').innerHTML=tab==='repair'?'<h3>修改意见</h3><p class="helper">选择问题，编辑并保存最终修改意见；按清单修改后，Codex 只读取本轮固定意见。取消勾选表示保留原内容。</p>':'<h3>审核说明</h3><p class="helper">✓ 无问题表示已明确检查通过；未检查不等于无问题。有问题的项目排在前面，具体位置与修改意见在「修改」栏。</p>';
      loadContext();
    }else{sequence++;loading=null;context=null}
  };
  window.addEventListener('focus',()=>{if(reviewing()&&!dialog.open&&!document.activeElement?.matches('#finding-plan,#finding-human-note'))loadContext(true)});
})();
