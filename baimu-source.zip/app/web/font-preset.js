'use strict';
const StudioFontPreset={
  apply(project,style){
    const result=JSON.parse(JSON.stringify(project));
    result.style={...result.style,...style};
    // Explicit whole-episode apply wins over old per-cue style overrides only.
    for(const cue of result.captions){
      if(!cue.style)continue;
      for(const key of Object.keys(style))delete cue.style[key];
    }
    return result;
  }
};
if(typeof module!=='undefined')module.exports=StudioFontPreset;
function installFontPreset(){
  const old=renderInspector;
  renderInspector=function(){
    old();if(!p)return;
    const preset=boot.settings?.subtitle_reference_preset,style=preset?.style||boot.settings?.subtitle_default_style;
    if(!preset||!style)return;
    const box=document.createElement('section');box.className='subtitle-preset';
    box.innerHTML=`<h3>${esc(preset.name)}</h3><details><summary>参数说明与换算</summary><p class="helper">${esc(preset.note)}</p><p class="helper">此字体不含中文字形：中文界面由系统字体补足；中文字幕导出会提示缺字。你仍可导入其他字体、调整单句或整集字幕。</p></details><button id="apply-font-preset" class="wide accent">应用统一字幕预设（整集）</button><p class="helper">可撤销；不改文字、时间或音画。调整样式后请点“自动断行”，再重新导出烧录审阅版；旧视频不会自动改变。</p>`;
    $('#inspector').prepend(box);
    const status=document.createElement('div');status.id='subtitle-preset-status';status.setAttribute('role','status');box.append(status);
    $('#apply-font-preset').onclick=handle(async()=>{
      const pid=p.id,next=StudioFontPreset.apply(p,style);
      const changed=JSON.stringify(next.style)!==JSON.stringify(p.style)||next.captions.some((cue,i)=>JSON.stringify(cue.style)!==JSON.stringify(p.captions[i].style));
      if(changed){remember();p=next;mark();renderInspector();updateOverlay()}
      let status=$('#subtitle-preset-status');status.textContent=changed?'整集预设已应用，正在保存…':'本集样式已经与预设一致，正在检查预览…';
      $('#apply-font-preset').disabled=true;
      try{
        await save();if(p?.id!==pid)return;
        const mode=await window.studioPreviewSubtitleStyle?.();if(p?.id!==pid||mode==='switched')return;
        status=$('#subtitle-preset-status');
        const prefix=changed?'整集预设已保存。':'本集已与预设一致，无需重复修改。';
        status.innerHTML=`<p class="helper">${prefix}${mode==='live'?'播放器正在显示新样式的即时字幕；已导出的MP4仍需重新导出。':mode==='burned'?'当前是旧的烧录视频，画面内字幕不会随工程修改。请生成样式预览，或重新导出审阅版。':'本集还没有可用的当前混音，请生成样式预览。'}</p><div class="toolbar">${mode==='live'?'':'<button id="preset-style-preview">生成样式预览</button>'}<button id="preset-style-export">导出新样式审阅版</button></div>`;
        const preview=$('#preset-style-preview');if(preview)preview.onclick=handle(async()=>{preview.disabled=true;try{await submitJob('preview');status.querySelector('p').textContent='混音预览已加入队列，完成后会打开新字幕样式。'}catch(error){preview.disabled=false;throw error}});
        $('#preset-style-export').onclick=()=>$('#export-button').click();
        toast(changed?'整集字幕预设已保存；'+(mode==='live'?'已显示新样式预览':'旧视频需重新生成才能更新字幕'):'本集已经应用了这套字幕预设');
      }catch(error){if(p?.id===pid&&$('#subtitle-preset-status'))$('#subtitle-preset-status').textContent='参数已应用，但保存或预览未完成：'+error.message;throw error}
      finally{if(p?.id===pid&&$('#apply-font-preset'))$('#apply-font-preset').disabled=false}
    });
  };
  const settings=$('#settings-button').onclick;
  $('#settings-button').onclick=function(){
    settings();
    const preset=boot.settings?.subtitle_reference_preset;
    if(!preset)return;
    const note=document.createElement('section');note.className='subtitle-preset';
    note.innerHTML=`<h3>可用成片参考：${esc(preset.name)}</h3><p class="helper">${esc(preset.note)}</p><p class="helper">手动调整过的新工程默认值和界面字体会保留。中文界面使用系统字形补足。旧工程或自定义样式可在右侧点击“应用统一字幕预设（整集）”；原工程、旧导出和历史记录不会自动覆盖。</p>`;
    $('#modal-body').prepend(note);
  };
}
