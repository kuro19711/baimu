'use strict';

// This module never asks for absolute paths or sends file bytes off the local origin.
const StudioFolderDrop={
  limits:{files:10000,entries:30000,depth:32},
  video:/\.(mp4|mov|mkv|webm|avi|m4v)$/i,
  audio:/\.(mp3|wav|m4a|aac|flac|ogg)$/i,
  script:/\.(pdf|txt|md|docx)$/i,
  caption:/\.(srt|vtt)$/i,
  // Keep this conservative directory-only list aligned with episode_folders.IGNORED_FOLDERS.
  ignoredFolders:new Set(['venv','models','data','bin','cache','__pycache__','node_modules','site-packages','jobs','renders','history','trash','recovery','batches','test-output','__macosx','$recycle.bin','system volume information']),
  ignoredName(name){return name.startsWith('.')||this.ignoredFolders.has(name.normalize('NFC').toLocaleLowerCase())},
  hasFiles(transfer){return Array.from(transfer?.types||[]).includes('Files')||Array.from(transfer?.items||[]).some(item=>item.kind==='file')},
  capture(transfer){
    // These methods must run synchronously in the drop event, before any await.
    const snapshots=[];
    for(const item of Array.from(transfer?.items||[])){
      if(item.kind!=='file')continue;
      let entry=null,file=null,handlePromise=null;
      try{entry=(item.getAsEntry||item.webkitGetAsEntry)?.call(item)||null}catch(e){}
      if(!entry&&typeof item.getAsFileSystemHandle==='function'){
        try{handlePromise=Promise.resolve(item.getAsFileSystemHandle()).catch(()=>null)}catch(e){}
      }
      try{file=item.getAsFile?.()||null}catch(e){}
      snapshots.push({entry,handlePromise,file});
    }
    if(!snapshots.length)for(const file of Array.from(transfer?.files||[]))snapshots.push({file});
    return snapshots;
  },
  relative(value){
    const path=String(value||'').replaceAll('\\','/');
    if(!path||path.startsWith('/')||path.includes('\0')||path.split('/').some(part=>!part||part==='.'||part==='..'))throw Error('文件夹内出现无效的相对路径');
    return path;
  },
  kind(name){name=String(name||'');if(this.video.test(name))return 'video';if(this.audio.test(name))return 'audio';if(this.script.test(name))return 'script';if(this.caption.test(name))return 'caption';return 'other'},
  standalonePath(file,options={}){
    const name=String(file?.name||'').replaceAll('\\','/').split('/').pop();
    if(!name)throw Error('无法读取所选文件名，请重新选择');
    const kind=this.kind(name);
    if(kind==='script')return '添加的剧本/'+name;
    if(kind==='caption')return '添加的字幕/'+name;
    if(options.groupLooseMedia&&['video','audio'].includes(kind))return '添加的素材/'+name;
    let stem=name.replace(/\.[^.]+$/,'').trim();
    if(!stem||stem==='.'||stem==='..')stem='添加的素材';
    return stem+'/'+name;
  },
  manifest(records){return records.map(row=>({relative_path:row.relative_path,size:row.size,last_modified:row.last_modified}))},
  plan(records,roots,selected,series=''){
    const plan={files:this.manifest(records),roots:[...roots],selected:[...selected],confirmed:true};
    if(series.trim())plan.series=series.trim();
    return plan;
  },
  resultRows(result){return result.results||((result.episodes||[]).map(row=>({...row,id:row.project_id||null})))},
  canOpen(row){return !!row.id&&!row.archived&&!row.unavailable&&row.state!=='failed'},
  bytes(value){const n=Math.max(0,Number(value)||0);if(n>=1024**3)return (n/1024**3).toFixed(2)+' GB';if(n>=1024**2)return (n/1024**2).toFixed(1)+' MB';if(n>=1024)return (n/1024).toFixed(1)+' KB';return n+' B'},
  async scan(snapshots,options={}){
    const limits={...this.limits,...options.limits},records=[],roots=new Set(),seen=new Set(),skipped=new Set();let visited=0,totalBytes=0;
    const skipPath=path=>{const parts=path.split('/');for(let i=0;i<parts.length;i++)if(this.ignoredName(parts[i])){skipped.add(parts.slice(0,i+1).join('/'));return true}return false};
    const cancelled=()=>{if(options.cancelled?.()){const e=Error('已停止读取文件夹目录');e.name='ImportCancelled';throw e}};
    const visit=depth=>{cancelled();if(depth>limits.depth)throw Error(`目录层级超过 ${limits.depth} 层，请选择具体剧名目录`);if(++visited>limits.entries)throw Error(`目录条目超过 ${limits.entries} 个，请按剧名分批导入`)};
    const add=(file,path)=>{
      cancelled();path=this.relative(path);
      if(skipPath(path))return;
      if(!path.includes('/'))path=this.standalonePath(file,options);
      if(seen.has(path))throw Error('有两个根目录包含同名相对路径，请分开导入：'+path);
      if(records.length>=limits.files)throw Error(`文件超过 ${limits.files} 个，请按剧名分批选择`);
      if(!Number.isSafeInteger(file.size)||file.size<0)throw Error('无法读取文件大小：'+path);
      seen.add(path);roots.add(path.split('/')[0]);totalBytes+=file.size;
      records.push({relative_path:path,size:file.size,last_modified:Number(file.lastModified)||0,file});
      options.progress?.({count:records.length,bytes:totalBytes,path});
    };
    const entryFile=entry=>new Promise((resolve,reject)=>entry.file(resolve,reject));
    const readBatch=reader=>new Promise((resolve,reject)=>reader.readEntries(resolve,reject));
    const walkEntry=async(entry,prefix,depth)=>{
      cancelled();const path=prefix?prefix+'/'+entry.name:entry.name;if(skipPath(path))return;visit(depth);
      if(entry.isFile){add(await entryFile(entry),path);return}
      if(!entry.isDirectory)throw Error('这个拖入项不是可读取的文件夹');
      const reader=entry.createReader();
      for(;;){cancelled();const batch=await readBatch(reader);if(!batch.length)break;for(const child of batch)await walkEntry(child,path,depth+1)}
    };
    const walkHandle=async(handle,prefix,depth)=>{
      cancelled();const path=prefix?prefix+'/'+handle.name:handle.name;if(skipPath(path))return;visit(depth);
      if(handle.kind==='file'){add(await handle.getFile(),path);return}
      if(handle.kind!=='directory'||typeof handle.values!=='function')throw Error('当前浏览器不支持目录句柄，请使用“选择文件夹”');
      for await(const child of handle.values()){cancelled();await walkHandle(child,path,depth+1)}
    };
    for(const snapshot of snapshots){
      cancelled();
      if(snapshot.entry){await walkEntry(snapshot.entry,'',0);continue}
      const handle=snapshot.handlePromise?await snapshot.handlePromise:null;
      if(handle){await walkHandle(handle,'',0);continue}
      if(snapshot.file){const path=snapshot.file.webkitRelativePath||snapshot.relative_path||snapshot.file.name;if(skipPath(path))continue;visit(0);add(snapshot.file,path);continue}
      throw Error('无法取得文件夹结构，请改用“选择文件夹”');
    }
    if(!records.length)throw Error('文件夹中没有可读取文件'+(skipped.size?'；已跳过隐藏 / 缓存 / 软件目录：'+[...skipped].join('、'):''));
    records.sort((a,b)=>a.relative_path.localeCompare(b.relative_path,undefined,{numeric:true}));
    return {records,roots:[...roots],bytes:totalBytes,skipped:[...skipped]};
  },
  selectedBytes(preview,ids){
    const wanted=new Set((preview.episodes||[]).filter(row=>ids.includes(row.id)).flatMap(row=>row.file_ids||[]));
    return (preview.normalized_files||[]).filter(file=>wanted.has(file.id)).reduce((n,file)=>n+file.size,0);
  },
  async transfer(session,files,options){
    if(options.confirmed!==true)throw Error('必须先明确确认所选剧集，才允许读取媒体内容');
    const requested=Number(session.max_chunk_size)||8*1024*1024;
    const chunkSize=Math.max(1,Math.floor(Math.min(requested,8*1024*1024)));
    const total=session.files.reduce((n,row)=>n+row.size,0);
    const report=row=>options.progress?.({bytes:session.files.reduce((n,file)=>n+file.offset,0),total,file:row?.relative_path||''});
    report();
    for(const row of session.files){
      const file=files.get(row.relative_path);
      if(!file||file.size!==row.size)throw Error('原文件引用不可用或大小已变化，请重新选择同一文件夹：'+row.relative_path);
      if(!Number.isSafeInteger(row.offset)||row.offset<0||row.offset>row.size)throw Error('服务端返回了无效的续传位置');
      while(row.offset<row.size){
        await options.beforeChunk?.();
        if(options.cancelled?.()){const e=Error('已停止后续分块');e.name='ImportCancelled';throw e}
        const offset=row.offset,end=Math.min(row.size,offset+chunkSize);
        const body=file.slice(offset,end);
        const response=await options.put(session.id,row.id,offset,body);
        const accepted=response.file?.offset;
        if(!Number.isSafeInteger(accepted)||accepted!==end)throw Error('确认字节位置不一致，请按服务端记录重试续传');
        row.offset=accepted;row.state=response.file?.state||row.state;report(row);
      }
    }
    return session;
  }
};
if(typeof module!=='undefined'&&module.exports)module.exports=StudioFolderDrop;

function installFolderDrop(){
  let flow=null,flowNumber=0,dragDepth=0;
  const previousDisabled=new Map();
  const confirmAction=window.studioProjectConfirm;
  const modalElement=$('#modal'),input=$('#folder-drop-input'),materialInput=$('#material-file-input');
  const current=state=>flow===state;
  const busy=()=>!!flow;
  const controls=['#global-new-button','#global-manage-button','#new-button','#manage-button','#batch-button','#batch-queue-button','#material-picker-button','#folder-picker-button','#folder-drop-path','#script-picker-button','#import-button'];
  function lock(value){[...controls,'#close-modal'].forEach(selector=>{const el=$(selector);if(!el)return;if(value){previousDisabled.set(selector,!!el.disabled);el.disabled=true}else{el.disabled=previousDisabled.get(selector)||false}});if(!value)previousDisabled.clear();$('#folder-drop-target').classList.toggle('import-busy',value)}
  function paint(html,state=flow){if(!current(state))return;modal(html);$('#close-modal').disabled=true}
  function closeFlow(state=flow){
    if(!current(state))return;state.cancelled=true;flow=null;lock(false);input.value='';materialInput.value='';$('#modal').close();
    $('#folder-drop-hint').textContent=state.session?'素材已保存在本机；再次选择相同内容不会重复添加。':'自动识别类型，只在本机处理。';
  }
  function showFailure(error,state){
    if(!current(state))return;state.phase='failed';
    paint(`<h2>${state.session?'素材添加中断':'无法读取这次选择'}</h2><div class="alert">${esc(error.message)}</div><p>${state.session?'已经复制到本机的部分会保留；重试从确认位置继续，不会从头重复发送。':'没有添加或改动任何素材。可以直接重新选文件或文件夹。'}</p><div class="modal-actions">${state.session?'<button id="folder-drop-retry" class="primary">继续重试</button>':'<button id="folder-drop-reselect" class="primary">重新选择文件</button><button id="folder-drop-refolder">选择文件夹</button>'}<button id="folder-drop-stop">关闭</button></div>`,state);
    if(state.session)$('#folder-drop-retry').onclick=handle(()=>startTransfer(state,true));
    if(!state.session){$('#folder-drop-reselect').onclick=()=>{closeFlow(state);setTimeout(()=>materialInput.click())};$('#folder-drop-refolder').onclick=()=>{closeFlow(state);setTimeout(()=>input.click())}}
    $('#folder-drop-stop').onclick=handle(()=>cancelFlow(state));
  }
  async function cancelFlow(state=flow){
    if(!current(state))return;
    if(state.phase==='complete'){closeFlow(state);return}
    if(state.phase==='committing'){toast('正在建立独立工程，请等待结果；不能把已提交操作当作已撤销。',true);return}
    if(state.phase==='uploading'||state.phase==='starting'){
      if(state.pauseGate)return;
      state.pauseGate=confirmAction('停止本次导入？\n\n当前分块结束后暂停发送下一块，等待本次选择。确认停止后，已拷贝到本机的数据保留以便续传，不会删除原文件、现有工程或已导出视频。','停止后续分块');
      const accepted=await state.pauseGate;state.pauseGate=null;if(!accepted)return;
      if(!current(state))return;state.cancelled=true;$('#folder-drop-progress-message').textContent='停止请求已记录，等待当前分块结束…';return;
    }
    if(state.session){
      if(!await confirmAction('结束这次未完成导入？\n\n已拷贝缓存保留，可再次选择同一文件夹续传。不会删除缓存或原文件。','结束并保留暂存'))return;
      try{await api(`/api/folder-drop/${state.session.id}/cancel`,{})}catch(error){toast('未能确认服务端取消状态；本机暂存未删除。'+error.message,true)}
    }
    closeFlow(state);
  }
  modalElement.addEventListener('cancel',event=>{if(flow){event.preventDefault();void cancelFlow(flow)}});
  // Prevent other toolbar actions from replacing this flow's modal while work is pending.
  document.addEventListener('click',event=>{
    if(!flow)return;
    const target=event.target;
    if(modalElement.contains(target)||$('#project-confirm').contains(target))return;
    if(target.closest?.('button,a,input,select,[data-project]')){event.preventDefault();event.stopImmediatePropagation();toast('请先完成或结束当前文件夹导入，再进行其他操作。')}
  },true);
  function canBegin(){
    if(busy()||window.studioScriptImport?.busy?.()){toast('已有导入正在处理，请先完成或结束，不会重复创建。',true);return false}
    if($('#modal').open||$('#project-confirm').open){toast('请先完成或关闭当前对话框，再拖入文件夹。',true);return false}
    return true;
  }
  async function begin(snapshots,options={}){
    if(!canBegin())return;
    const state={id:++flowNumber,phase:'scanning',cancelled:false,session:null,records:[],roots:[],plan:null,inFlight:false,targetProjectId:options.targetProjectId||null,extraScripts:[],extraCaptions:[]};flow=state;lock(true);
    paint('<h2>正在识别素材</h2><p>读取文件名、大小和类型；还没有复制或改动工程。</p><p id="folder-scan-progress">正在读取选择…</p><div class="modal-actions"><button id="folder-scan-cancel">取消</button></div>',state);
    $('#folder-scan-cancel').onclick=()=>{state.cancelled=true;closeFlow(state)};
    try{
      await save();
      if(!current(state)||state.cancelled)return;
      const scanned=await StudioFolderDrop.scan(snapshots,{allowScriptRoots:true,groupLooseMedia:!!state.targetProjectId,cancelled:()=>state.cancelled||!current(state),progress:progress=>{if(current(state)&&$('#folder-scan-progress'))$('#folder-scan-progress').textContent=`已发现 ${progress.count} 个文件 · ${StudioFolderDrop.bytes(progress.bytes)}（尚未复制）`}});
      if(!current(state))return;
      const media=scanned.records.filter(row=>['video','audio'].includes(StudioFolderDrop.kind(row.relative_path)));
      state.extraScripts=scanned.records.filter(row=>StudioFolderDrop.kind(row.relative_path)==='script');
      state.extraCaptions=scanned.records.filter(row=>StudioFolderDrop.kind(row.relative_path)==='caption');
      const unsupported=scanned.records.filter(row=>StudioFolderDrop.kind(row.relative_path)==='other');
      if(!media.length&&state.extraScripts.length){const files=state.extraScripts.map(row=>row.file),currentId=state.targetProjectId;closeFlow(state);await window.studioScriptImport.startFiles(files,{currentId});return}
      if(!media.length&&state.extraCaptions.length){const files=state.extraCaptions.map(row=>row.file);if(!state.targetProjectId)throw Error('字幕需要添加到具体剧集，请先新建或打开一集');closeFlow(state);await window.studioImportSubtitleFiles(files);return}
      if(!media.length)throw Error(unsupported.length?'没有识别到可添加的视频、音频、字幕或剧本':'所选内容中没有可添加的素材');
      if(!state.targetProjectId&&!media.some(row=>StudioFolderDrop.kind(row.relative_path)==='video'))throw Error('音频需要添加到具体剧集，请先新建或打开一集');
      state.records=media;state.roots=[...new Set(media.map(row=>row.relative_path.split('/')[0]))];state.skipped=scanned.skipped;state.phase='previewing';
      const preview=await api('/api/folder-drop/preview',{files:StudioFolderDrop.manifest(state.records),roots:state.roots,include_audio_only:!!state.targetProjectId});
      if(!current(state)||state.cancelled)return;preview.warnings=[...(preview.warnings||[]),...(state.skipped.length?['浏览器已提前跳过以下隐藏 / 缓存 / 软件目录或文件，未读取其内容：'+state.skipped.join('、')]:[])];state.preview=preview;state.phase='preview';
      if(state.targetProjectId){
        if(!(preview.episodes||[]).length)throw Error('没有识别到可添加的视频或音频');
        if(preview.episodes.length===1){
          state.plan={...StudioFolderDrop.plan(state.records,state.roots,[preview.episodes[0].id]),target_project_id:state.targetProjectId,append:true};
          await startTransfer(state,false);
        }else showProjectPreview(state);
      }else showPreview(state);
    }catch(error){if(error.name==='ImportCancelled'){if(current(state))closeFlow(state)}else showFailure(error,state)}
  }
  function showProjectPreview(state){
    const preview=state.preview;
    paint(`<h2>选择要加入当前分集的素材</h2><p>识别到 ${preview.episodes.length} 个分集 / 素材分组。为避免串集，一次只能把其中一个分组加入当前工程；其他分组不会复制或改动。</p><div class="folder-drop-episodes">${preview.episodes.map(row=>`<label class="manager-row"><input type="radio" name="folder-project-episode" data-folder-episode="${esc(row.id)}"><span><b>${esc(row.name)}</b><small>剧名：${esc(row.series||'未识别')} · 来源：${esc(row.source_folder||'')}</small><small>${row.video_count||0} 个视频 / ${row.audio_count||0} 个音频</small></span></label>`).join('')}</div><details class="batch-skipped"><summary>识别提示与跳过项</summary>${(preview.warnings||[]).map(row=>`<p>${esc(typeof row==='string'?row:JSON.stringify(row))}</p>`).join('')}${(preview.skipped||[]).map(row=>`<p>${esc(typeof row==='string'?row:[row.name||row.relative_path||row.path||'',row.reason||''].join('：'))}</p>`).join('')}</details><p id="folder-drop-selection" class="manager-count">尚未选择 · 不会自动合并不同集素材</p><div class="modal-actions"><button id="folder-drop-use-path">改用路径导入（免复制）</button><button id="folder-drop-preview-cancel">取消</button><button id="folder-drop-confirm" class="primary" disabled>添加所选分组</button></div>`,state);
    $$('[data-folder-episode]').forEach(box=>box.onchange=()=>{const row=preview.episodes.find(item=>item.id===box.dataset.folderEpisode);$('#folder-drop-selection').textContent=`已选择 1 个分组 · 需要额外拷贝 ${StudioFolderDrop.bytes(StudioFolderDrop.selectedBytes(preview,[row.id]))}`;$('#folder-drop-confirm').disabled=false});
    $('#folder-drop-preview-cancel').onclick=()=>closeFlow(state);
    $('#folder-drop-use-path').onclick=()=>{closeFlow(state);$('#batch-button').click()};
    $('#folder-drop-confirm').onclick=handle(async()=>{
      const selected=$('[data-folder-episode]:checked');
      if(!selected)throw Error('请先选择一个要加入当前分集的素材分组');
      const row=preview.episodes.find(item=>item.id===selected.dataset.folderEpisode),bytes=StudioFolderDrop.selectedBytes(preview,[row.id]);
      if(!await confirmAction(`只把“${row.name}”加入当前分集？\n\n将向本机数据目录额外拷贝约 ${StudioFolderDrop.bytes(bytes)}。其他分组不会复制；原文件和当前工程已有编辑不删除。`,'确认添加这个分组'))return;
      if(!current(state))return;
      state.plan={...StudioFolderDrop.plan(state.records,state.roots,[row.id]),target_project_id:state.targetProjectId,append:true};
      await startTransfer(state,false);
    });
  }
  function showPreview(state){
    const preview=state.preview;
    paint(`<h2>预览识别到的剧集</h2><p>浏览器不能提供本地文件夹的绝对路径。此方式需要把所选素材<strong>分块拷贝到本机软件数据目录</strong>，占用额外磁盘空间；不会发往外部网站。大素材建议使用“路径导入”免复制。</p><label>统一剧名 / 分组（可选；填写后覆盖所选各集分组）</label><input id="folder-drop-series" maxlength="150" placeholder="留空时使用各集识别到的剧名"><div class="folder-drop-episodes">${(preview.episodes||[]).map(row=>`<label class="manager-row"><input type="checkbox" data-folder-episode="${esc(row.id)}"><span><b>${esc(row.name)}</b><small>剧名：${esc(row.series||'未识别，可自行填写')} · 来源：${esc(row.source_folder||'')}</small><small>${row.video_count||0} 个视频 / ${row.audio_count||0} 个音频${row.needs_selection?' · 命名需核实：不猜测未知集数，请确认后再选':''}</small></span></label>`).join('')||'<p>没有可导入的剧集，请检查文件夹结构或改用路径导入。</p>'}</div><details class="batch-skipped"><summary>识别提示与跳过项</summary>${(preview.warnings||[]).map(row=>`<p>${esc(typeof row==='string'?row:JSON.stringify(row))}</p>`).join('')}${(preview.skipped||[]).map(row=>`<p>${esc(typeof row==='string'?row:[row.name||row.relative_path||row.path||'',row.reason||''].join('：'))}</p>`).join('')}</details><p id="folder-drop-selection" class="manager-count">已选择 0 集 · 需要额外拷贝 0 B</p><div class="modal-actions"><button id="folder-drop-use-path">改用路径导入（免复制）</button><button id="folder-drop-preview-cancel">取消</button><button id="folder-drop-confirm" class="primary" disabled>确认所选剧集并拷贝</button></div>`,state);
    $$('[data-folder-episode]').forEach(box=>box.onchange=()=>{const selected=$$('[data-folder-episode]:checked').map(item=>item.dataset.folderEpisode);$('#folder-drop-selection').textContent=`已选择 ${selected.length} 集 · 需要额外拷贝 ${StudioFolderDrop.bytes(StudioFolderDrop.selectedBytes(preview,selected))}`;$('#folder-drop-confirm').disabled=!selected.length});
    $('#folder-drop-preview-cancel').onclick=()=>closeFlow(state);
    $('#folder-drop-use-path').onclick=()=>{closeFlow(state);$('#batch-button').click()};
    $('#folder-drop-confirm').onclick=handle(async()=>{
      const selected=$$('[data-folder-episode]:checked').map(item=>item.dataset.folderEpisode),series=$('#folder-drop-series').value.trim();
      if(!selected.length)throw Error('请先逐项勾选需要导入的剧集');
      if(series.length>150)throw Error('剧名最多150个字符');
      const names=preview.episodes.filter(row=>selected.includes(row.id)).map(row=>row.name);
      const bytes=StudioFolderDrop.selectedBytes(preview,selected);
      if(!await confirmAction(`确认导入以下 ${names.length} 集？\n\n${names.map(name=>'• '+name).join('\n')}\n\n将向本机数据目录额外拷贝约 ${StudioFolderDrop.bytes(bytes)}，需要相应磁盘空间。原文件和当前编辑工程不修改。未勾选项目不导入。`,'确认并开始本机拷贝'))return;
      if(!current(state))return;
      state.plan=StudioFolderDrop.plan(state.records,state.roots,selected,series);
      await startTransfer(state,false);
    });
  }
  function showProgress(state){
    paint(`<h2>${state.targetProjectId?'正在添加素材':'正在导入所选剧集'}</h2><p>复制到百慕的本机素材库，不会上传云端。显示的是本机已确认接收的字节。</p><progress id="folder-drop-progress" value="0" max="1"></progress><p id="folder-drop-bytes">正在核对已接收位置…</p><p id="folder-drop-progress-message"></p><p id="folder-drop-current-file" class="helper"></p><div class="modal-actions"><button id="folder-drop-upload-cancel">停止</button></div>`,state);
    $('#folder-drop-upload-cancel').onclick=handle(()=>cancelFlow(state));
  }
  function updateProgress(state,progress){
    if(!current(state))return;
    $('#folder-drop-progress').max=Math.max(1,progress.total);$('#folder-drop-progress').value=progress.bytes;
    $('#folder-drop-bytes').textContent=`已确认 ${StudioFolderDrop.bytes(progress.bytes)} / ${StudioFolderDrop.bytes(progress.total)}`;
    $('#folder-drop-current-file').textContent=progress.file||'';
    if(!state.cancelled)$('#folder-drop-progress-message').textContent='分块发送中；停止操作会保留已经拷贝的暂存。';
  }
  async function put(sessionId,fileId,offset,blob){
    const response=await fetch(`/api/folder-drop/${encodeURIComponent(sessionId)}/files/${encodeURIComponent(fileId)}?offset=${offset}`,{method:'PUT',headers:{'X-Studio-Token':token,'Content-Type':'application/octet-stream'},body:blob});
    let result;try{result=await response.json()}catch(e){throw Error('未收到可确认的分块响应；请按服务端记录重试，不盲目从零发送')}
    if(!response.ok)throw Error(result.error||'本机分块接收失败');return result;
  }
  async function startTransfer(state,retry){
    if(!current(state)||state.inFlight)return;
    state.inFlight=true;state.cancelled=false;state.phase='starting';showProgress(state);
    try{
      if(retry&&state.session)state.session=await api(`/api/folder-drop/${state.session.id}`);
      // start is idempotent and re-enables a cancelled session with its recorded offsets.
      state.session=await api('/api/folder-drop/start',state.plan);
      if(state.pauseGate)await state.pauseGate;
      if(!current(state))return;
      if(state.cancelled){if(state.session.requires_reuse_confirmation){closeFlow(state);return}const e=Error('停止请求已生效');e.name='ImportCancelled';throw e}
      try{localStorage.setItem('studio-folder-drop-last',JSON.stringify({id:state.session.id,roots:state.roots,time:Date.now()}))}catch(e){}
      if(state.session.requires_reuse_confirmation){
        state.phase='reuse';
        const accepted=await confirmAction('这份文件名、大小和修改时间清单对应已经完成的导入。\n\n本次没有重新读取新文件内容，也没有做新旧文件的 SHA 一致性验证。是否只打开已有工程并保留已有编辑？\n\n已归档的工程不会自动恢复；同路径素材实际改变请使用明确更新素材的入口。','只查看已有工程，不重新导入');
        if(!current(state))return;
        if(!accepted){closeFlow(state);return}
        showComplete(state,state.session,true);return;
      }
      if(state.session.resume_warning){
        state.phase='resume-check';
        const accepted=await confirmAction('检测到已有的未完成会话。\n\n续传位置只依据文件路径、大小与修改时间匹配，没有重新做文件内容 SHA 对比。必须继续使用上次相同、未被替换的原文件，避免前后分块混合。\n\n'+state.session.resume_warning,'确认原文件未改变，继续续传');
        if(!accepted){closeFlow(state);return}
      }
      state.phase='uploading';
      const files=new Map(state.records.map(row=>[row.relative_path,row.file]));
      await StudioFolderDrop.transfer(state.session,files,{confirmed:true,put,beforeChunk:()=>state.pauseGate,cancelled:()=>state.cancelled||!current(state),progress:progress=>updateProgress(state,progress)});
      if(state.pauseGate)await state.pauseGate;
      if(state.cancelled){const error=Error('停止请求已生效');error.name='ImportCancelled';throw error}
      state.phase='committing';$('#folder-drop-upload-cancel').disabled=true;$('#folder-drop-progress-message').textContent=state.targetProjectId?'素材已接收，正在检查并添加到当前工程。':'素材已接收，正在检查并建立独立工程；当前工程不被替换。';
      const result=await api(`/api/folder-drop/${state.session.id}/commit`,{});
      if(!current(state))return;state.session=result;await refreshBoot();
      if(state.targetProjectId&&p?.id===state.targetProjectId){await openProject(state.targetProjectId,{skipSave:true});tab='clips';render()}
      showComplete(state,result,false);
    }catch(error){
      if(!current(state))return;
      if(error.name==='ImportCancelled'||state.cancelled){
        let note='已停止发送后续分块，已拷贝的本机暂存保留，可再次选择同一文件夹续传。';
        try{if(state.session)await api(`/api/folder-drop/${state.session.id}/cancel`,{})}catch(e){note+=' 服务端取消状态未确认：'+e.message}
        state.phase='cancelled';paint(`<h2>本次导入已停止</h2><p>${esc(note)}</p><p>源文件与原有工程未删除；没有声称清理暂存。</p><div class="modal-actions"><button id="folder-drop-resume" class="primary">按现有位置继续</button><button id="folder-drop-close">关闭</button></div>`,state);
        $('#folder-drop-resume').onclick=handle(()=>startTransfer(state,true));$('#folder-drop-close').onclick=()=>closeFlow(state);
      }else{
        if(state.session){try{const latest=await api(`/api/folder-drop/${state.session.id}`);state.session=latest;if(latest.results?.length){showPartial(state,error,latest);return}}catch(e){}}
        showFailure(error,state);
      }
    }finally{state.inFlight=false}
  }
  function showComplete(state,result,reused){
    state.phase='complete';
    const rows=StudioFolderDrop.resultRows(result);
    const projectMode=!!state.targetProjectId;
    paint(`<h2>${projectMode?'素材已添加':reused?'已有工程，请按需打开':'导入完成'}</h2><p>${projectMode?'视频已经加入画面轨道；音频已进入当前工程素材库。原文件没有改动。':reused?'本次只复用已有工程记录，没有重读文件内容或验证新旧内容相同。':'所选素材已经复制到本机并建立独立工程，没有覆盖原工程。'}</p><div class="folder-drop-episodes">${rows.map(row=>`<div class="batch-result"><b>${esc(row.name||row.source_folder||'工程')}</b><p>${esc(row.state||'完成')}${row.archived?' · 已在回收站，请手动恢复':''}${row.unavailable?' · 工程暂不可用':''}${row.error?' · '+esc(row.error):''}</p>${!projectMode&&StudioFolderDrop.canOpen(row)?`<button data-folder-open="${esc(row.id)}">打开这个工程</button>`:''}</div>`).join('')}</div><div class="modal-actions"><button id="folder-drop-done" class="primary">完成</button></div>`,state);
    $$('[data-folder-open]').forEach(button=>button.onclick=handle(async()=>{const pid=button.dataset.folderOpen;closeFlow(state);await openProject(pid);tab='clips';render()}));
    $('#folder-drop-done').onclick=()=>closeFlow(state);
    const scripts=state.extraScripts||[];
    if(scripts.length&&window.studioScriptImport){const button=document.createElement('button');button.id='folder-attached-scripts';button.className='accent';button.textContent=`继续读取剧本（${scripts.length} 份）`;button.onclick=handle(async()=>{const files=scripts.map(row=>row.file),currentId=state.targetProjectId;closeFlow(state);await window.studioScriptImport.startFiles(files,{currentId})});$('#modal-body').append(button)}
    const captions=state.extraCaptions||[];
    if(captions.length&&window.studioImportSubtitleFiles){const button=document.createElement('button');button.id='folder-attached-captions';button.textContent=`继续添加字幕（${captions.length} 份）`;button.onclick=handle(async()=>{const files=captions.map(row=>row.file);closeFlow(state);await window.studioImportSubtitleFiles(files)});$('#modal-body').append(button)}
  }
  function showPartial(state,error,result){
    showComplete(state,result,false);state.phase='failed';
    const warning=document.createElement('div');warning.className='alert';warning.textContent='部分工程已经建立，不能当作全部成功或从头重复创建。'+error.message;$('#modal-body').prepend(warning);
    const retry=document.createElement('button');retry.textContent='重试同一会话的未完成部分';retry.onclick=handle(()=>startTransfer(state,true));$('#modal-body').append(retry);
  }
  const openFiles=()=>{if(canBegin())materialInput.click()};
  const openFolder=()=>{if(canBegin())input.click()};
  $('#material-picker-button').onclick=openFiles;
  $('#folder-picker-button').onclick=openFolder;
  $('#folder-drop-path').onclick=()=>{if(canBegin())$('#batch-button').click()};
  materialInput.onchange=()=>{const snapshots=Array.from(materialInput.files||[]).map(file=>({file}));materialInput.value='';if(snapshots.length)void begin(snapshots,{targetProjectId:p?.id||null})};
  input.onchange=()=>{const snapshots=Array.from(input.files||[]).map(file=>({file}));input.value='';if(snapshots.length)void begin(snapshots,{targetProjectId:p?.id||null})};
  window.addEventListener('dragenter',event=>{if(StudioFolderDrop.hasFiles(event.dataTransfer)){event.preventDefault();dragDepth++;document.body.classList.add('folder-drag-active')}});
  window.addEventListener('dragover',event=>{if(StudioFolderDrop.hasFiles(event.dataTransfer)){event.preventDefault();event.dataTransfer.dropEffect=busy()?'none':'copy'}});
  window.addEventListener('dragleave',event=>{if(StudioFolderDrop.hasFiles(event.dataTransfer)&&--dragDepth<=0){dragDepth=0;document.body.classList.remove('folder-drag-active')}});
  window.addEventListener('drop',event=>{
    if(!StudioFolderDrop.hasFiles(event.dataTransfer))return;
    event.preventDefault();dragDepth=0;document.body.classList.remove('folder-drag-active');
    const snapshots=StudioFolderDrop.capture(event.dataTransfer);
    void begin(snapshots,{targetProjectId:p?.id||null});
  });
  window.addEventListener('beforeunload',event=>{if(flow&&['starting','uploading','committing'].includes(flow.phase)){event.preventDefault();event.returnValue='素材仍在添加；关闭后可重新选择相同内容续传。'}});
  window.studioFolderDrop={busy,begin};
  window.studioMaterialImport={open:openFiles,openFolder};
}
