'use strict';
const StudioCaptionPreview={
  rgba(hex,alpha){const rgb=hex.replace('#','').match(/../g).map(x=>parseInt(x,16));return `rgba(${rgb.join(',')},${alpha})`},
  nativeRatio(font={},project={width:1080,height:1920}){
    const profile=font.jianying_font_size||{},ratio=Number(profile.native_units_per_1080px),
      width=Number(profile.canvas_width),height=Number(profile.canvas_height);
    if(Number.isFinite(ratio)&&ratio>0&&ratio<1&&width>0&&height>0&&
       Math.abs(width/height-Number(project.width||1080)/Number(project.height||1920))<1e-9)return ratio;
    return 1/8;
  },
  nativeSize(st,font={},project={width:1080,height:1920}){
    return Number(st.font_size)*this.nativeRatio(font,project);
  },
  canvasSize(value,font={},project={width:1080,height:1920}){
    return Number(value)/this.nativeRatio(font,project);
  },
  displayNativeSize(st,font={},project={width:1080,height:1920}){
    return Number(this.nativeSize(st,font,project).toFixed(4));
  },
  style(st,font={},scale=1){
    const opacity=st.opacity??1,angle=(st.shadow_angle??45)*Math.PI/180,distance=(st.shadow??0)*scale;
    return {position:'absolute',transform:'translate(-50%,-50%)',textAlign:'center',whiteSpace:'pre-wrap',paintOrder:'stroke fill',
      fontFamily:`"Studio${st.font_id}",sans-serif`,width:st.max_width+'%',fontSize:st.font_size*scale+'px',
      fontStyle:st.italic?'italic':'normal',textDecorationLine:st.underline?'underline':'none',
      lineHeight:(st.font_size*(font.line_height||1.2)+(st.line_spacing||0))*scale+'px',
      left:st.x+'%',top:st.y+'%',opacity:'1',color:this.rgba(st.color,opacity),fontWeight:st.bold?'700':String(font.weight||400),
      letterSpacing:(st.spacing||0)*scale+'px',webkitTextStroke:`${st.outline*2*scale}px ${this.rgba(st.outline_color,(st.outline_opacity??1)*opacity)}`,
      textShadow:`${distance*Math.cos(angle)}px ${distance*Math.sin(angle)}px ${(st.shadow_blur||0)*scale}px ${this.rgba('#000000',(st.shadow_opacity??.1)*opacity)}`};
  }
};
if(typeof module!=='undefined')module.exports=StudioCaptionPreview;
