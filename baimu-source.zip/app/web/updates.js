/* Shared daily GitHub check; loading the editor never waits for the network. */
(()=>{
  let latestResult=null;
  const label=r=>r.status!=='ok'?(r.message||'暂时无法检查更新'):r.message?r.message:r.update_available?`当前 ${r.current_version} · 发现新版 ${r.latest.tag}`:`当前 ${r.current_version} · 已检查 GitHub，无需更新`;
  function paint(){
    const output=document.getElementById('update-result');
    if(!output||!latestResult)return;
    output.textContent=label(latestResult)+(latestResult.checked_at?`（检查时间：${new Date(latestResult.checked_at).toLocaleString()}）`:'');
  }
  async function check(force=false){
    try{
      latestResult=await api('/api/updates/check',{force,claim_notice:true});
      paint();
      if(latestResult.notify)toast(`百慕有新版 ${latestResult.latest.tag}，可在设置中查看更新`);
    }catch(_){
      latestResult={status:'unavailable',message:'更新检查暂不可用，不影响使用'};paint();
    }
  }
  const settings=document.getElementById('settings-button');
  const previous=settings.onclick;
  settings.onclick=function(...args){
    previous?.apply(this,args);
    const section=document.createElement('section');
    section.innerHTML='<h3>关于与更新</h3><p id="update-result">正在检查 GitHub 最新正式发布…</p><p>每天首次使用检查一次，其他对话与窗口共用当天结果。</p><div class="modal-actions"><a href="https://github.com/kuro19711/baimu/releases/latest" target="_blank" rel="noopener noreferrer">查看发布说明与下载</a><button id="update-check-now" type="button">立即检查</button></div>';
    document.getElementById('modal-body').append(section);paint();
    document.getElementById('update-check-now').onclick=async function(){this.disabled=true;try{await check(true)}finally{this.disabled=false}};
  };
  check();
})();
