"use strict";
(() => {
  let state=null,loading=0,busy=false,selectedFinding=null;
  const drafts=new Map();
  const names={pending:'待修改',kept:'人工保留',working:'修改中',awaiting_verification:'待复审',resolved:'已解决',unresolved:'未解决',interrupted:'已中断，需复核'};
  const checkNames={pass:'✓ 无问题',issues:'● 有问题',needs_review:'? 待复核',not_checked:'— 未检查',not_selected:'未纳入本次',pending:'检查中',outdated:'需重新审核'};
  const clock=t=>`${Math.floor(t/60).toString().padStart(2,'0')}:${(t%60).toFixed(2).padStart(5,'0')}`;
  const current=pid=>p?.id===pid&&['review','repair'].includes(tab)&&!!$('#review-findings');
  const draftKey=f=>`${p.id}:${state.report.id}:${f.id}`;
  const hasDrafts=()=>state?.report&&(state.report.findings||[]).some(f=>drafts.has(draftKey(f)));
  const switchTab=value=>{tab=value;render()};
  function taskText(kind){
    const session=boot.settings?.review_rules_preview?`--session-file "${boot.data_dir}/session.json" `:'';
    const instruction=kind==='repair'?`执行百慕固定的返工清单 ${state.active_batch?.id||''}。以 active_batch.findings[].plan 中固定的最终修改意见为准，不重用早期 AI 建议；只修改本轮清单，保留人工取消项，逐项回写修改及实际新成片复审结果。`:
      `执行百慕初审请求 ${state.requests.filter(r=>r.status==='waiting').at(-1)?.id||''}。默认全项检查，尊重本集明确排除项；逐项提交 checks，status 使用 pass/issues/needs_review/not_checked 并提供 evidence。不能以无问题单代替已检查通过。具体问题通过 findings 提交，此次不修改工程。`;
    return `请使用 baimu 技能${instruction}\n工程：${p.name}（${p.id}）。\n先运行 baimu_client.py ${session}review-workflow ${p.id}，并读取 review-context ${p.id}。${session?'所有命令均使用上述独立试用会话。':''}`;
  }
  async function copyTask(kind){
    const value=taskText(kind);
    try{await navigator.clipboard.writeText(value);toast('任务已复制，粘贴给 Codex 执行')}
    catch(_){modal(`<h2>交给 Codex 执行</h2><textarea rows="9" readonly>${esc(value)}</textarea><p>复制以上内容到 Codex。任务已保存。</p>`)}
  }
  async function mutate(payload){
    if(busy)return;busy=true;
    const pid=p.id,revision=state.workflow_revision;
    $('#review-findings').querySelectorAll('button,input,textarea').forEach(el=>el.disabled=true);
    try{const result=await api(`/api/projects/${pid}/review-workflow`,{workflow_revision:revision,...payload});if(current(pid)){state=result;draw();return result}}
    catch(error){if(current(pid)){await show(pid,true);toast(error.message,true)}throw error}
    finally{busy=false;if(current(pid))draw()}
  }
  function inspect(finding,seek=true){
    selectedFinding=finding.id;
    if(seek&&!state.report.stale)seekPlayback(finding.start);
    const draft=drafts.get(draftKey(finding));
    $('#inspector').innerHTML=`<h3>${esc(finding.title)}</h3><p>${clock(finding.start)}–${clock(finding.end)} · ${esc(finding.category)}</p>
      <span class="finding-status">${names[finding.status]}</span>
      <label for="finding-plan">最终修改意见${finding.locked?'（本轮已固定）':'（可编辑）'}</label>
      <textarea id="finding-plan" rows="5" ${finding.locked||finding.status==='resolved'?'disabled':''}>${esc(draft??finding.plan)}</textarea>
      <p id="finding-plan-status" role="status">${draft!=null?'有未保存意见，请先保存再发起修改':finding.plan_source==='human'?'已保存你的最终意见':'当前为 AI 建议，可直接编辑'}</p>
      <button id="finding-save-plan" ${finding.locked||finding.status==='resolved'?'disabled':''}>保存修改意见</button>
      <label>保留理由（可不填）<textarea id="finding-human-note" rows="2" ${finding.locked?'disabled':''}>${esc(finding.human_note)}</textarea></label>
      <button id="finding-save-note" ${finding.locked?'disabled':''}>保存说明</button>
      <details class="finding-evidence"><summary>核对依据与确认程度</summary><h4>观测依据</h4><p class="finding-prose">${esc(finding.evidence)}</p><h4>确认程度</h4><p>${esc(finding.certainty)}</p></details>`;
    $('#finding-plan').oninput=()=>{drafts.set(draftKey(finding),$('#finding-plan').value);$('#finding-plan-status').textContent='有未保存意见，请先保存再发起修改';if($('#review-fix'))$('#review-fix').disabled=true};
    $('#finding-save-plan').onclick=handle(async()=>{
      const key=draftKey(finding),plan=$('#finding-plan').value;
      if(!plan.trim())throw Error('最终修改意见不能为空');
      const result=await mutate({action:'mark',report_id:state.report.id,finding_id:finding.id,selected:finding.selected,plan});
      if(result){drafts.delete(key);draw();toast('最终修改意见已保存')}
    });
    $('#finding-save-note').onclick=handle(()=>mutate({action:'mark',report_id:state.report.id,finding_id:finding.id,selected:finding.selected,human_note:$('#finding-human-note').value}));
  }
  function auditMarkup(){
    const report=state.report,active=state.active_batch,rows=state.review_results||[];
    const rank={issues:0,needs_review:1,outdated:2,pending:3,not_checked:4,pass:5,not_selected:6};
    const sorted=[...rows].sort((a,b)=>(rank[a.status]??4)-(rank[b.status]??4));
    const passed=rows.filter(r=>r.status==='pass').length,issues=rows.filter(r=>r.status==='issues').length;
    const remaining=['needs_review','not_checked','pending','outdated','not_selected'].map(status=>{
      const count=rows.filter(r=>r.status===status).length;
      return count?` · ${count} 项${({needs_review:'待复核',not_checked:'未检查',pending:'检查中',outdated:'需重审',not_selected:'未纳入'})[status]}`:'';
    }).join('');
    return `<div class="review-workflow-bar"><button id="review-start" ${active?'disabled':''}>${report?'重新初审':'开始初审'}</button><button id="review-go-repair">查看修改意见（${report?.findings.length||0}）</button><button id="findings-refresh">刷新</button></div>
      <p class="audit-summary">${rows.filter(r=>r.selected).length===rows.length?'全项已纳入':`已纳入 ${rows.filter(r=>r.selected).length}/${rows.length} 项`} · ${passed} 项无问题 · ${issues} 项有问题${remaining}</p>
      <p class="helper">无问题以明确检查结果为准；没返回结果的项目保持「未检查」。具体问题与可编辑的修改方法在「修改」栏。</p>
      ${state.requests.some(r=>r.status==='waiting')?'<div class="review-task-notice">初审任务已生成，等待 Codex 执行。<button id="review-copy-audit">复制初审任务</button></div>':''}
      ${active?.stale?'<p class="alert">旧返修任务的工程、规则或范围已变化，请到修改栏核对并取消旧任务后重新审核。</p>':''}
      <div class="audit-results">${sorted.map(r=>`<article class="audit-result audit-${esc(r.status)}" data-audit-rule="${esc(r.rule_id)}"><div class="audit-result-head"><b>${esc(r.title)}</b><span class="audit-status">${checkNames[r.status]||'未检查'}${r.finding_count?' · '+r.finding_count+' 处':''}</span></div><details><summary>查看细则与检查说明</summary>${r.evidence?`<p class="finding-prose">${esc(r.evidence)}</p>`:''}<pre>${esc(r.body)}</pre></details></article>`).join('')}</div>`;
  }
  function repairMarkup(){
    const report=state.report,active=state.active_batch,rows=report?.findings||[];
    const kept=rows.filter(f=>!f.selected).length,selected=rows.filter(f=>f.selected&&f.status!=='resolved').length;
    return `<div class="review-workflow-bar"><button id="review-go-audit">查看审核结果</button><button id="review-fix" class="primary" ${!report||report.stale||!selected||active||hasDrafts()?'disabled':''}>按清单修改（${selected}）</button><button id="findings-refresh">刷新</button></div>
      <p class="findings-summary" role="status">${report?`发现 ${rows.length} 处 · 待修改 ${selected} 处 · 人工保留 ${kept} 处`:'尚无初审问题单'}</p>
      <p class="helper">点击问题编辑最终修改意见；取消勾选表示保留。保存意见后发起任务，Codex 读取本轮固定的最终意见。</p>
      ${active?`<div class="review-task-notice">${active.stale?'本轮清单已过期，暂停执行':active.status==='queued'?'本轮清单与最终意见已固定，等待 Codex 修改':'本轮修改进行中'} · ${active.findings.length} 项<button id="review-copy-repair" ${active.stale?'disabled':''}>复制修改任务</button><button id="review-cancel-repair">取消本轮任务</button></div>`:''}
      ${report?.stale?'<p class="alert">原问题单对应的工程、规则或范围已变化。原审计记录保留；新任务须重新审核，本轮有效修改仍按固定批次复审。</p>':''}
      ${report?`<details class="review-coverage"><summary>检查覆盖说明</summary><p>${esc(report.coverage)}</p></details>`:''}
      <div class="finding-list">${rows.map(f=>`<article class="finding-row ${!f.selected?'finding-kept':''}" data-finding="${f.id}"><div class="finding-top"><input type="checkbox" data-mark-finding="${f.id}" aria-label="修改：${esc(f.title)}" ${f.selected?'checked':''} ${f.locked||f.status==='resolved'?'disabled':''}><button data-inspect-finding="${f.id}" class="finding-title">${esc(f.title)}</button></div><div class="finding-meta"><button data-inspect-finding="${f.id}" class="finding-time">${clock(f.start)}–${clock(f.end)}</button><span class="finding-status status-${f.status}">${names[f.status]}</span></div><p class="finding-plan">${f.selected?'最终意见：'+esc(f.plan):'保留原内容，不修改'}</p>${f.selected?`<button data-inspect-finding="${f.id}" class="edit-plan-button">${f.locked?'查看固定意见':'编辑修改意见'}</button>`:''}</article>`).join('')}${report&&!rows.length?'<p class="helper">没有具体修改项。各类别的检查情况请看审核栏。</p>':''}</div>
      ${state.batches.length?`<details class="review-batch-history"><summary>返工记录</summary>${state.batches.slice().reverse().map(b=>`<div class="review-batch"><b>${({queued:'等待执行',running:'执行中',complete:'本轮结束',cancelled:'已取消'})[b.status]} · ${b.findings.length} 项</b>${b.findings.map(f=>`<p>${esc(f.title)}：${names[b.outcomes[f.id].status]}<small>固定意见：${esc(f.plan)}</small><small>${esc(b.outcomes[f.id].note)}</small>${b.outcomes[f.id].verification?`<small>复审：${esc(b.outcomes[f.id].verification.note)}</small>`:''}</p>`).join('')}</div>`).join('')}</details>`:''}`;
  }
  function draw(){
    if(!state||!current(state.project_id))return;
    const root=$('#review-findings');root.innerHTML=tab==='review'?auditMarkup():repairMarkup();
    if($('#review-start'))$('#review-start').onclick=handle(async()=>{await save();const result=await mutate({action:'request_review',request_id:id()});if(result)await copyTask('audit')});
    if($('#review-fix'))$('#review-fix').onclick=handle(async()=>{if(hasDrafts())throw Error('请先保存修改意见');await save();const result=await mutate({action:'create_repair',report_id:state.report.id,request_id:id()});if(result)await copyTask('repair')});
    if($('#review-go-repair'))$('#review-go-repair').onclick=()=>switchTab('repair');
    if($('#review-go-audit'))$('#review-go-audit').onclick=()=>switchTab('review');
    $('#findings-refresh').onclick=handle(()=>show(p.id,true));
    if($('#review-copy-audit'))$('#review-copy-audit').onclick=handle(()=>copyTask('audit'));
    if($('#review-copy-repair'))$('#review-copy-repair').onclick=handle(()=>copyTask('repair'));
    if($('#review-cancel-repair'))$('#review-cancel-repair').onclick=handle(()=>mutate({action:'cancel_repair',batch_id:state.active_batch.id}));
    root.querySelectorAll('[data-mark-finding]').forEach(box=>box.onchange=handle(()=>mutate({action:'mark',report_id:state.report.id,finding_id:box.dataset.markFinding,selected:box.checked})));
    const rows=state.report?.findings||[];
    root.querySelectorAll('[data-inspect-finding]').forEach(button=>button.onclick=()=>inspect(rows.find(f=>f.id===button.dataset.inspectFinding)));
    if(tab==='repair'&&selectedFinding&&rows.some(f=>f.id===selectedFinding))inspect(rows.find(f=>f.id===selectedFinding),false);
  }
  async function show(pid,force=false){
    const ticket=++loading;if(!current(pid))return;
    if(state?.project_id!==pid)selectedFinding=null;
    if(!force&&state?.project_id===pid){draw();return}
    try{const result=await api(`/api/projects/${pid}/review-workflow`);if(ticket!==loading||!current(pid))return;const changed=result.workflow_revision!==state?.workflow_revision||result.report?.stale!==state?.report?.stale||result.active_batch?.stale!==state?.active_batch?.stale||!$('#findings-refresh');state=result;if(changed)draw()}
    catch(error){if(current(pid))$('#review-findings').innerHTML=`<p class="alert">${esc(error.message)}</p><button id="findings-retry">重试读取</button>`;if($('#findings-retry'))$('#findings-retry').onclick=handle(()=>show(pid,true))}
  }
  window.studioReviewFindings={show};
  setInterval(()=>{if(p&&['review','repair'].includes(tab)&&!busy&&!document.querySelector('dialog[open]')&&!document.activeElement?.matches('#finding-plan,#finding-human-note'))show(p.id,true)},4000);
})();
