'use strict';
function studioAudioRelation(project,item){
  if(!project||!item||!['video','original','dialogue'].includes(item.kind))return null;
  const link=project.native_links?.[item.id],videoId=link?.linked_video_id||(link?.linked_audio_id?item.id:null);
  const clip=project.clips.find(c=>c.id===(videoId||item.id));
  const number=String(project.clips.findIndex(c=>c.id===(videoId||item.id))+1).padStart(2,'0');
  if(videoId)return {state:'linked',pair:videoId,label:`联动 ${number}`,detail:`已分轨，仍与画面联动（${number}组）。移动、裁剪或删除任一条，会同时影响同组画面和原声；音量分别调整。`};
  if(item.kind==='dialogue')return {state:'independent',pair:null,label:'独立原声',detail:'已独立：移动、裁剪或删除这段原声，不会带动画面。'};
  const source=project.assets.find(a=>a.id===clip?.asset_id);
  if(!source?.has_audio)return {state:'silent',pair:null,label:'无原声',detail:'源视频没有原声音轨。'};
  if(clip?.audio_detached)return {state:'independent',pair:null,label:'画面独立',detail:'画面原声已关闭，与声音轨没有联动关系。移动、裁剪画面不会带动独立音频；声音请在对应音频轨调整。'};
  return {state:'embedded',pair:clip?.id,label:`未分离 ${number}`,detail:item.kind==='original'?'未分离：这是视频内的原声。拖动这条原声会先自动分离，再独立移动；也可点击“分离音频”。':'未分离：原声仍在视频内，移动、裁剪画面时原声一起变化。'};
}
/* A view/editor for the existing render model, not a second hidden timeline. */
function installStudioTimeline(){
  const root=$('#timeline');
  if(!root||typeof StudioTimeline==='undefined')return;
  const old={render,mark,renderInspector,updateOverlay,openProject,viewRender};
  const kinds=[['mask','打码','#f5f7ec'],['caption','字幕','#db987b'],['video','主轨','#5abdb3'],['original','内嵌原声','#5d9ed3'],['dialogue','人物原声','#70b7ed'],['narration','旁白 / 配音','#b198dc'],['bgm','背景音乐','#7db28c'],['sfx','音效','#d5b36c']];
  const kindName=kind=>kinds.find(row=>row[0]===kind)?.[1]||kind;
  const kindColor=kind=>kinds.find(row=>row[0]===kind)?.[2]||'#8fa0b5';
  function visibleTracks(layout){
    const has=kind=>layout.items.some(item=>item.kind===kind);
    return [
      {key:'mask',name:'效果',icon:'◆',kinds:['mask'],color:'#f5f7ec',show:has('mask')},
      {key:'caption',name:'字幕',icon:'T',kinds:['caption'],color:'#db987b',show:has('caption')},
      {key:'video',name:'主轨',icon:'▣',kinds:['video'],color:'#5abdb3',show:true},
      {key:'audio',name:'音频',icon:'♫',kinds:['dialogue','narration','bgm','sfx'],color:'#70b7ed',show:['dialogue','narration','bgm','sfx'].some(has)}
    ].filter(track=>track.show);
  }
  const state={pid:null,selection:null,selections:[],magnetic:true,follow:new Set(),cursor:0,scale:24,snap:true,collapsed:false,focus:false,drag:null,layout:null,frame:null,media:new Map(),pending:new Set(),loading:0,stale:false,locked:new Set(),mediaEpoch:0};
  const key=(kind,itemId)=>kind+':'+itemId;
  const sig=()=>JSON.stringify([p?.clips,p?.audios,p?.captions,p?.masks,p?.fps]);
  const viewSignature=()=>JSON.stringify([p?.id,p?.clips,p?.audios,p?.captions,p?.masks,p?.fps,p?.assets,p?.style,p?.track_locks,p?.native_links,p?.native]);
  const labelWidth=()=>Number.parseFloat(getComputedStyle(root).getPropertyValue('--track-label'))||114;
  const maxScale=()=>Math.max(600,rate()*20);
  function zoomTo(value,clientX){
    const scroll=root.querySelector('.tl-scroll');if(!scroll||state.drag)return;
    const x=clientX==null?scroll.clientWidth/2:Math.max(labelWidth(),clientX-scroll.getBoundingClientRect().left);
    const anchor=Math.max(0,(scroll.scrollLeft+x-labelWidth())/state.scale);
    const next=Math.max(5,Math.min(maxScale(),value));if(next===state.scale)return;
    state.scale=next;draw();
    root.querySelector('.tl-scroll').scrollLeft=Math.max(0,labelWidth()+anchor*next-x);
  }
  root.addEventListener('wheel',event=>{
    const scroll=event.target.closest('.tl-scroll');if(!scroll||!p)return;
    // Ordinary wheel keeps native vertical track scrolling. Ctrl zooms, Shift pans.
    if(!event.ctrlKey){
      if(event.shiftKey){event.preventDefault();const unit=event.deltaMode===1?16:event.deltaMode===2?scroll.clientWidth:1;scroll.scrollLeft+=(event.deltaY||event.deltaX)*unit}
      return;
    }
    event.preventDefault();
    if(!event.deltaY)return;
    if(state.drag)return;
    const delta=event.deltaY*(event.deltaMode===1?16:event.deltaMode===2?scroll.clientHeight:1);
    zoomTo(state.scale*Math.exp(-Math.max(-240,Math.min(240,delta))*.002),event.clientX);
  },{passive:false});
  const quant=t=>Math.max(0,Math.round(t*rate())/rate());
  const itemNow=layout=>{try{return state.selection&&p?(layout||StudioTimeline.layout(p)).items.find(item=>item.kind===state.selection.kind&&item.id===state.selection.id)||null:null}catch(e){return null}};
  const editing=()=>document.activeElement?.matches('input,textarea,select,[contenteditable=true]');
  const getRecord=item=>item.kind==='caption'?p.captions.find(c=>c.id===item.id):item.kind==='mask'?(p.masks||[]).find(c=>c.id===item.id):['video','original'].includes(item.kind)?p.clips.find(c=>c.id===item.id):p.audios.find(c=>c.id===item.id);
  const heading=item=>item.kind==='caption'?getRecord(item)?.text:item.kind==='mask'?'打码遮挡':asset(item.asset_id)?.name||'素材';
  const soundKind=kind=>!['caption','mask'].includes(kind);
  function reset(){state.pid=p?.id||null;state.selection=null;state.selections=[];state.cursor=0;state.drag=null;state.stale=false;state.mediaEpoch++;state.media.clear();state.locked.clear();state.drawnSignature=null;}
  function schedule(){if(state.frame)return;state.frame=requestAnimationFrame(()=>{
    state.frame=null;
    if(root.contains(document.activeElement)&&document.activeElement?.matches('input,textarea,select')){state.redrawPending=true;return}
    if(!state.drag){state.redrawPending=false;draw()}
  })}
  root.addEventListener('focusout',()=>{if(state.redrawPending)schedule()});
  function setCursor(value,seek=true){
    state.cursor=Math.max(0,Math.min(total(),Number(value)||0));
    const video=$('#video');
    if(seek){if(window.StudioRealtime?.editing())StudioRealtime.seek(state.cursor);else{video.pause();if(video.getAttribute('src')){try{video.currentTime=Math.min(state.cursor,Number.isFinite(video.duration)?video.duration:state.cursor)}catch(e){}}}}
    $('#seek').value=state.cursor;$('#timecode').textContent=time(state.cursor);
    updateOverlay(state.cursor);paintCursor();
  }
  function paintCursor(){
    const line=root.querySelector('.tl-playhead');if(line)line.style.left=(labelWidth()+state.cursor*state.scale)+'px';
    const field=$('#tl-position');if(field&&document.activeElement!==field)field.value=time(state.cursor);
  }
  function selectedItems(layout){
    if(!p||!state.selections.length)return [];
    try{
      const available=new Set((layout||StudioTimeline.layout(p)).items.map(item=>key(item.kind,item.id)));
      return state.selections.filter(entry=>available.has(key(entry.kind,entry.id)));
    }catch{return []}
  }
  function selectionHas(kind,itemId){return state.selections.some(entry=>entry.kind===kind&&entry.id===itemId)}
  function renderSelection(previousTab){
    // Selecting an existing clip changes highlights and properties, not track DOM,
    // thumbnails, the caption list, or the compiled playback timeline.
    if(previousTab!==tab||state.drawnSignature!==viewSignature()||!window.StudioRealtime?.editing()||!$('#tl-split')||
       (tab==='captions'&&state.locked.has('caption'))||(tab==='masks'&&state.locked.has('mask'))){render();return}
    const active=itemNow(state.layout),locked=active&&state.locked.has(active.kind),multiple=state.selections.length>1;
    const pairs=new Set(state.selections.map(entry=>studioAudioRelation(p,entry)?.pair).filter(Boolean));
    root.querySelectorAll('[data-tl-id]').forEach(node=>{
      const kind=node.dataset.tlKind,id=node.dataset.tlId,pair=studioAudioRelation(p,{kind,id})?.pair;
      node.classList.toggle('selected',selectionHas(kind,id)||!!pair&&pairs.has(pair));
    });
    $('#tl-split').disabled=multiple||!active||locked||['caption','mask'].includes(active.kind);
    $('#tl-delete').disabled=multiple||!active||locked;
    $('#tl-detach-audio').disabled=multiple||!active||!['video','original'].includes(active.kind)||locked||state.locked.has('video')||state.locked.has('original')||getRecord(active)?.audio_detached||!asset(active.asset_id)?.has_audio;
    $('#tl-unlink-audio')?.remove();
    if(studioAudioRelation(p,active)?.state==='linked'){
      const unlink=document.createElement('button');unlink.id='tl-unlink-audio';unlink.textContent='解除联动';unlink.disabled=!canUnlink();unlink.title='解除后声音可单独拖动';unlink.onclick=handle(unlinkSelected);$('#tl-detach-audio').after(unlink);
    }
    root.querySelector('.tl-edit-settings summary').textContent=`联动设置 · ${state.selections.length} 项`;
    $$('[data-cue]').forEach(node=>node.classList.toggle('selected',node.dataset.cue===selected));
    $$('[data-mask-card]').forEach(node=>node.classList.toggle('mask-card-active',node.dataset.maskCard===state.selection?.id));
    renderInspector();updateOverlay();
  }
  function selectItem(kind,itemId,seek=true,additive=false){
    const previousTab=tab;
    const entry={kind,id:itemId};
    state.selections=additive?(selectionHas(kind,itemId)?state.selections.filter(row=>key(row.kind,row.id)!==key(kind,itemId)):[...state.selections,entry]):[entry];
    state.selection=state.selections.at(-1)||null;const item=itemNow();if(!item){render();return}
    if(kind==='video'&&!additive){
      for(const candidate of StudioTimeline.layout(p).items)if(state.follow.has(candidate.kind)&&candidate.start<item.end&&candidate.end>item.start&&!selectionHas(candidate.kind,candidate.id))state.selections.push({kind:candidate.kind,id:candidate.id});
    }
    if(kind==='caption'){selected=itemId;tab='captions'}else if(kind==='mask')tab='masks';
    if(seek)setCursor(Math.min(item.start,total()));
    renderSelection(previousTab);
  }
  async function change(op){
    if(!p)throw Error('请先打开剧集');
    if(state.locked.has(op.kind))throw Error('这条轨道已锁定，请先点击轨道旁的锁解锁');
    const result=await StudioEditActions.execute(op);
    if(state.selection&&['dialogue','narration','bgm','sfx'].includes(state.selection.kind)){
      const audio=p.audios.find(row=>row.id===state.selection.id);
      state.selection=audio?{kind:audio.role,id:audio.id}:null;
    }
    window.StudioRealtime?.clearPreview();
    state.selections=selectedItems();if(!itemNow())state.selection=state.selections.at(-1)||null;
    state.cursor=Math.min(state.cursor,total());render();
    if(result.selection)state.selection=result.selection;
  }
  function boundarySnap(value,exclude){
    if(!state.snap)return quant(value);
    const points=[0,total(),state.cursor];
    for(const item of state.layout.items){if(!exclude.endsWith(':'+item.id)&&!(state.drag?.multi&&selectionHas(item.kind,item.id)))points.push(item.start,item.end)}
    let best=value,dist=7/state.scale;
    state.snapPoint=null;for(const point of points){const delta=Math.abs(point-value);if(delta<dist){best=point;dist=delta;state.snapPoint=point}}
    return quant(best);
  }
  function lanes(items){
    const ends=[];
    return [...items].sort((a,b)=>a.start-b.start||a.end-b.end).map(item=>{let lane=ends.findIndex(end=>end<=item.start+1e-7);if(lane<0)lane=ends.length;ends[lane]=item.end;return {...item,lane}});
  }
  function waveSvg(item,data){
    const wave=data?.waveform;if(!wave?.points?.length)return '';
    const source=getRecord(item),duration=Number(wave.duration)||0;if(!duration)return '';
    const sourceIn=source.in||0,sourceOut=source.out||duration,period=sourceOut-sourceIn;
    const peak=Math.max(.001,...wave.points.filter(value=>Number.isFinite(value)).map(value=>Math.abs(value)));
    const durationOnTrack=item.end-item.start,segments=[];
    const count=Math.max(12,Math.min(180,Math.ceil(durationOnTrack*state.scale/3)));
    for(let n=0;n<count;n++){
      let at=sourceIn+(n+.5)/count*durationOnTrack;
      if(source.loop&&item.kind==='bgm')at=sourceIn+((at-sourceIn)%period);
      const index=Math.min(wave.points.length-1,Math.max(0,Math.floor(at/duration*wave.points.length)));
      const value=wave.points[index];if(value===null||value===undefined)continue;
      const height=Math.max(.4,Math.min(1,Math.abs(value)/peak)*15),x=(n+.5)/count*1000;
      segments.push(`M${x.toFixed(2)},${(16-height).toFixed(2)}V${(16+height).toFixed(2)}`);
    }
    return `<svg class="tl-wave" viewBox="0 0 1000 32" preserveAspectRatio="none" aria-hidden="true"><path d="${segments.join('')}" stroke="currentColor" stroke-width="2" fill="none"/></svg>`;
  }
  function mediaKey(item){const a=asset(item.asset_id),record=getRecord(item);return `${p.id}:${item.asset_id}:${record?.audio_stream??''}:${a?.mtime_ns??a?.mtime??''}:${a?.size??''}`}
  function decorate(item){
    if(item.kind==='caption'||item.kind==='mask')return '';
    const data=state.media.get(mediaKey(item));
    if(item.kind==='video'){
      const thumbs=(data?.thumbnails||[]).filter(x=>typeof x.data_url==='string'&&x.data_url.startsWith('data:image/jpeg;base64,'));
      if(!thumbs.length)return '';
      const record=getRecord(item),usable=thumbs.filter(x=>x.time>=record.in&&x.time<=record.out);
      const list=usable.length?usable:[thumbs.reduce((a,b)=>Math.abs(a.time-record.in)<Math.abs(b.time-record.in)?a:b)];
      return `<div class="tl-thumbs">${list.slice(0,6).map(t=>`<img src="${t.data_url}" alt="" draggable="false">`).join('')}</div>`;
    }
    return waveSvg(item,data);
  }
  function queueMedia(){
    if(!p||state.collapsed)return;
    const pid=p.id,epoch=state.mediaEpoch;
    const items=state.layout.items.filter(item=>item.asset_id);
    for(const item of items){
      if(state.loading>=2)break;
      const cacheKey=mediaKey(item);if(state.media.has(cacheKey)||state.pending.has(cacheKey))continue;
      const record=getRecord(item),query=record.audio_stream==null?'':`?stream=${encodeURIComponent(record.audio_stream)}`;
      state.pending.add(cacheKey);state.loading++;
      api(`/api/projects/${pid}/timeline-media/${item.asset_id}${query}`).then(data=>{
        if(p?.id===pid&&state.mediaEpoch===epoch)state.media.set(cacheKey,data);
      }).catch(e=>{if(p?.id===pid&&state.mediaEpoch===epoch){state.media.set(cacheKey,{error:e.message});if(/缺失|丢失|已移动/.test(e.message))window.studioMediaRelink?.refresh().catch(()=>{})}}).finally(()=>{
        state.loading--;state.pending.delete(cacheKey);schedule();
      });
    }
  }
  function draw(){
    if(state.drag)return;
    if(state.pid!==p?.id)reset();
    document.body.classList.toggle('timeline-ready',!!p);
    document.body.classList.toggle('timeline-focus',!!p&&state.focus);
    if(!p){root.innerHTML='<div class="tl-empty-project">打开剧集后，这里显示打码、画面、人物原声、字幕、旁白、音乐与音效轨道。</div>';return}
    state.locked=new Set(p.track_locks||[]);
    try{state.layout=StudioTimeline.layout(p)}catch(error){root.innerHTML=`<div class="tl-empty-project">时间线暂不可用：${esc(error.message)}。请修正左侧片段的时间 / 音量输入，或点击上方“撤销”；原文件不会改动。</div>`;return}
    state.selections=selectedItems(state.layout);if(state.selection&&!itemNow(state.layout))state.selection=state.selections.at(-1)||null;
    const oldScroll=root.querySelector('.tl-scroll'),scrollLeft=oldScroll?.scrollLeft||0,scrollTop=oldScroll?.scrollTop||0;
    // Reuse the validated layout for every clip; total() rebuilds the entire model.
    const duration=state.layout.duration;
    const label=labelWidth(),length=Math.max(duration,...state.layout.items.map(x=>Math.min(x.end,duration+30)),1),tail=Math.max(50,root.clientWidth-label),width=Math.max(root.clientWidth-2,label+length*state.scale+tail);
    const tickStep=state.scale>=rate()*8?1/rate():state.scale>=300?.2:state.scale>=90?1:state.scale>=40?2:state.scale>=16?5:10;
    const labelEvery=Math.max(1,Math.ceil(70/(tickStep*state.scale)));
    const tickMarkup=i=>{const t=i*tickStep,major=i%labelEvery===0;return `<span class="tl-tick${major?'':' minor'}" style="left:${label+t*state.scale}px">${major?(tickStep<1?time(t):time(t).slice(0,5)):''}</span>`};
    const ticks=[],tickStart=Math.max(0,Math.floor((scrollLeft-label)/state.scale/tickStep)-1),tickEnd=Math.min(Math.ceil(length/tickStep),Math.ceil((scrollLeft+root.clientWidth)/state.scale/tickStep)+1);
    for(let i=tickStart;i<=tickEnd;i++)ticks.push(tickMarkup(i));
    const active=itemNow(state.layout),locked=active&&state.locked.has(active.kind),activeRelation=studioAudioRelation(p,active),displayTracks=visibleTracks(state.layout);
    root.classList.toggle('tl-collapsed',state.collapsed);
    root.innerHTML=`<div class="tl-toolbar"><button id="tl-undo" title="撤销 · Ctrl+Z" aria-keyshortcuts="Control+Z Meta+Z">↶ 撤销</button><button id="tl-add-material" class="accent">＋ 添加素材</button><button id="tl-split" ${!active||locked||['caption','mask'].includes(active.kind)?'disabled':''} title="在播放头处分割，快捷键 S">分割</button><button id="tl-delete" class="danger" ${!active||locked?'disabled':''}>删除</button><button id="tl-detach-audio" ${!active||!['video','original'].includes(active.kind)||locked||state.locked.has('video')||state.locked.has('original')||getRecord(active)?.audio_detached||!asset(active.asset_id)?.has_audio?'disabled':''}>分离音频</button><details class="tl-add-menu"><summary>＋ 添加</summary><div><button id="tl-add-caption">字幕</button><button id="tl-add-audio">音频</button><button id="tl-add-mask">打码</button><label><input id="tl-snap" type="checkbox" ${state.snap?'checked':''}> 磁吸</label><button id="tl-focus">${state.focus?'恢复布局':'扩大轨道'}</button><button id="tl-collapse">${state.collapsed?'展开轨道':'收起轨道'}</button></div></details><span class="tl-spacer"></span><input id="tl-position" class="tl-time" value="${time(state.cursor)}" aria-label="播放头时间" title="输入秒，或 分:秒.毫秒 后按回车"><span class="tl-duration">/ ${time(duration)}</span><button id="tl-zoom-out" aria-label="缩小时间线">−</button><input id="tl-zoom" aria-label="时间线缩放" type="range" min="5" max="160" value="${state.scale}"><button id="tl-zoom-in" aria-label="放大时间线">＋</button><button id="tl-fit">适应</button><span class="tl-zoom-label">${Math.round(state.scale)} px/s</span></div><div class="tl-scroll"><div class="tl-content" style="width:${width}px;--grid-width:${tickStep*state.scale}px"><div class="tl-ruler">${ticks.join('')}<div class="tl-ruler-label">时间</div></div>${displayTracks.map(track=>{
      const items=lanes(state.layout.items.filter(x=>track.kinds.includes(x.kind))),laneHeight=track.key==='video'?68:43,height=Math.max(1,...items.map(x=>x.lane+1))*laneHeight+4,lockKind=track.kinds.length===1?track.kinds[0]:null;
      return `<div class="tl-row" data-track="${track.key}" style="height:${height}px;--track-color:${track.color}"><div class="tl-grid"></div>${!items.length?`<span class="tl-empty">把视频拖到这里，主轨会自动吸附</span>`:''}${items.map(item=>{
        const relation=studioAudioRelation(p,item);
        const title=heading(item),selectedItem=selectionHas(item.kind,item.id)||(relation?.pair&&state.selections.some(entry=>studioAudioRelation(p,entry)?.pair===relation.pair)),rec=getRecord(item),badge=item.kind==='video'&&relation?.state==='embedded'?'🔊 原声':relation?.state==='linked'?(item.kind==='video'?'🔗 原声':'🔗 跟随画面'):track.key==='audio'?kindName(item.kind):'';
        return `<div class="tl-clip ${relation?.pair?'linked ':''}${selectedItem?'selected ':''}${rec.gain<=-59?'tl-muted':''}" tabindex="0" role="button" aria-label="${esc(track.name+'：'+String(title).replaceAll('\n',' ')+'，'+time(item.start)+'至'+time(item.end)+(relation?'，'+relation.detail:''))}" data-tl-kind="${item.kind}" data-tl-id="${item.id}" data-audio-state="${relation?.state||''}" style="--clip-color:${kindColor(item.kind)};left:${label+item.start*state.scale}px;top:${2+item.lane*laneHeight}px;width:${Math.max(3,(item.end-item.start)*state.scale)}px;height:${laneHeight-4}px" title="${esc(title)}\n${time(item.start)} → ${time(item.end)}\n拖中间移动，拖两端裁剪">${decorate(item)}<span class="tl-clip-title">${badge?`<span class="tl-relation ${relation?.state||'type'}">${esc(badge)}</span>`:''}<span class="tl-clip-name">${esc(title)}</span></span>${item.kind==='bgm'&&rec.loop?'<span class="tl-clip-sub">↻ 循环</span>':''}${!state.locked.has(item.kind)?'<span class="tl-handle left" data-trim="start" title="拖动裁剪左边" aria-label="裁剪左边"></span><span class="tl-handle right" data-trim="end" title="拖动裁剪右边" aria-label="裁剪右边"></span>':''}</div>`;
      }).join('')}<div class="tl-label"><b><span class="tl-track-icon">${track.icon}</span>${track.name}</b>${lockKind?`<button class="tl-lock" data-lock="${lockKind}" title="${state.locked.has(lockKind)?'解锁':'锁定'}${track.name}">${state.locked.has(lockKind)?'🔒':'🔓'}</button>`:''}</div></div>`;
    }).join('')}<div class="tl-end" style="left:${label+duration*state.scale}px"></div><div class="tl-playhead"></div><div class="tl-drop-line"></div></div></div><div class="tl-note"><span id="tl-hint">${state.stale?'<span class="warn">预览已更新。</span>':'拖动主轨镜头可排序 · 拖动两端可裁剪 · 点击空白移动播放头'}</span><span>主轨自动吸附，音频和字幕可以自由摆放</span></div>`;
    const scroll=root.querySelector('.tl-scroll');scroll.scrollLeft=scrollLeft;scroll.scrollTop=scrollTop;
    const settings=document.createElement('span');settings.className='tl-edit-settings';
    settings.innerHTML=`<label title="关闭后，移动、缩短或删除画面会保留空位；不会自动合拢主轨"><input id="tl-magnetic" type="checkbox" ${state.magnetic?'checked':''}>主轨磁吸</label><details class="tl-add-menu"><summary>联动设置 · ${state.selections.length} 项</summary><div><p>默认仅移动选中项及已联动原声。Ctrl 点击增减选区；拖动轨道空白框选，Ctrl 框选可追加。</p><p>可选：选画面时连选时间重叠的：</p>${['caption','narration','bgm','sfx','mask'].map(kind=>`<label><input data-tl-follow="${kind}" type="checkbox" ${state.follow.has(kind)?'checked':''}>${kindName(kind)}</label>`).join('')}<p>只影响后续选择；裁剪不自动裁切独立字幕或声音。原声要独立编辑请点“解除联动”。</p><button id="tl-clear-selection">清除选区</button></div></details><label title="拖动时吸附到其他片段边界和播放头，不等于主轨合拢"><input id="tl-auto-snap" type="checkbox" ${state.snap?'checked':''}>自动吸附</label></span>`;
    $('#tl-add-material').after(settings);
    $('#tl-magnetic').onchange=e=>{state.magnetic=e.target.checked};
    $('#tl-auto-snap').onchange=e=>{state.snap=e.target.checked;$('#tl-snap').checked=state.snap};
    root.querySelectorAll('[data-tl-follow]').forEach(field=>field.onchange=()=>{if(field.checked)state.follow.add(field.dataset.tlFollow);else state.follow.delete(field.dataset.tlFollow)});
    $('#tl-clear-selection').onclick=()=>{state.selection=null;state.selections=[];render()};
    const multiple=state.selections.length>1;
    for(const selector of ['#tl-split','#tl-delete','#tl-detach-audio'])if(multiple)$(selector).disabled=true;
    $('#tl-hint').textContent='Ctrl 点击多选 · 拖动空白框选 · 主轨磁吸：连续镜头整组排序；关闭：整组平移 · 点击标尺定位';
    let rulerFrame=null;
    scroll.addEventListener('scroll',()=>{
      if(rulerFrame)return;
      rulerFrame=requestAnimationFrame(()=>{
        rulerFrame=null;if(!scroll.isConnected)return;
        const start=Math.max(0,Math.floor((scroll.scrollLeft-label)/state.scale/tickStep)-1);
        const end=Math.min(Math.ceil(length/tickStep),Math.ceil((scroll.scrollLeft+scroll.clientWidth)/state.scale/tickStep)+1);
        const ruler=scroll.querySelector('.tl-ruler'),labels=[];
        for(let i=start;i<=end;i++)labels.push(tickMarkup(i));
        ruler.querySelectorAll('.tl-tick').forEach(t=>t.remove());ruler.insertAdjacentHTML('afterbegin',labels.join(''));
      });
    });
    const unavailable=[...state.media.values()].filter(data=>data.error||data.status==='busy'||data.status==='partial').length;
    if(unavailable){const retry=document.createElement('button');retry.id='tl-reload-media';retry.textContent='刷新素材预览';retry.title='重新读取缩略图与波形，不改变工程';retry.onclick=()=>{state.media.clear();state.mediaEpoch++;draw()};$('#tl-fit').before(retry);const warning=document.createElement('span');warning.className='warn';warning.textContent=`${unavailable} 项缩略图或波形未加载。`;root.querySelector('.tl-note').append(warning)}
    if(state.layout.warnings.length){const warning=document.createElement('span');warning.className='warn';warning.textContent=state.layout.warnings.join(' ');root.querySelector('.tl-note').append(warning)}
    if(state.stale&&!previewJob)$('#tl-hint').textContent='实时预览已更新。';
    const redo=document.createElement('button');redo.id='tl-redo';redo.textContent='↷ 重做';redo.title='重做 · Ctrl+Shift+Z / Ctrl+Y';redo.setAttribute('aria-keyshortcuts','Control+Shift+Z Control+Y Meta+Shift+Z');$('#tl-undo').after(redo);redo.onclick=()=>$('#redo-button').click();
    $('#tl-undo').onclick=()=>$('#undo-button').click();
    $('#tl-add-material').onclick=()=>window.studioMaterialImport?.open();
    $('#tl-split').onclick=handle(()=>{const item=itemNow();change({type:'split',kind:item.kind,id:item.id,time:state.cursor})});
    $('#tl-delete').onclick=handle(removeSelected);
    $('#tl-detach-audio').onclick=handle(()=>window.studioDetachAudio(itemNow().id));
    if(activeRelation?.state==='linked'){const unlink=document.createElement('button');unlink.id='tl-unlink-audio';unlink.textContent='解除联动';unlink.disabled=!canUnlink();unlink.title='解除后声音可单独拖动';unlink.onclick=handle(unlinkSelected);$('#tl-detach-audio').after(unlink)}
    $('#tl-add-mask').onclick=handle(addMask);
    $('#tl-add-caption').onclick=handle(addCaption);
    $('#tl-add-audio').onclick=()=>{const previous=tab;state.selection=null;state.selections=[];tab='audio';render();$('#add-audio').click();tab=previous;render()};
    $('#tl-snap').onchange=e=>{state.snap=e.target.checked;$('#tl-auto-snap').checked=state.snap};
    $('#tl-position').onchange=handle(e=>{const parts=e.target.value.trim().split(':').map(Number);if(parts.length>3||parts.some(n=>!Number.isFinite(n)||n<0))throw Error('请输入秒或 分:秒.毫秒');setCursor(parts.reduce((a,n)=>a*60+n,0))});
    $('#tl-position').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();e.currentTarget.onchange(e)}};
    $('#tl-position').oninput=e=>{if(/^\d+(?::\d+){0,2}(?:\.\d+)?$/.test(e.target.value.trim())){const value=e.target.value.trim().split(':').map(Number).reduce((a,n)=>a*60+n,0);setCursor(value)}};
    $('#tl-zoom').oninput=e=>{root.querySelector('.tl-zoom-label').textContent=Math.round(Number(e.target.value))+' px/s'};
    $('#tl-zoom').max=maxScale();$('#tl-zoom').step='any';$('#tl-zoom').value=state.scale;
    $('#tl-zoom').onchange=e=>zoomTo(Number(e.target.value));
    $('#tl-zoom-out').onclick=()=>zoomTo(state.scale/1.35);
    $('#tl-zoom-in').onclick=()=>zoomTo(state.scale*1.35);
    $('#tl-fit').onclick=()=>{state.scale=Math.max(5,Math.min(160,(root.clientWidth-label-30)/Math.max(1,total())));draw();root.querySelector('.tl-scroll').scrollLeft=0};
    $('#tl-focus').onclick=()=>{state.focus=!state.focus;draw()};
    $('#tl-collapse').onclick=()=>{state.collapsed=!state.collapsed;draw()};
    root.querySelectorAll('[data-lock]').forEach(button=>button.onclick=handle(()=>StudioEditActions.execute({type:'lock',kind:button.dataset.lock,locked:!state.locked.has(button.dataset.lock)})));
    state.drawnSignature=viewSignature();
    paintCursor();queueMedia();
  }
  function addCaption(){
    if(state.locked.has('caption'))throw Error('字幕轨已锁定');
    const start=quant(state.cursor),next=p.captions.filter(c=>c.start>=start).sort((a,b)=>a.start-b.start)[0],end=Math.min(total(),start+2,next?.start??Infinity);
    if(p.captions.some(c=>start>=c.start&&start<c.end)||end-start<1/rate())throw Error('这里已有字幕或空间不足，请选择没有字幕的时间段');
    remember();const cue={id:id(),start,end,text:'请输入字幕',style:{}};p.captions.push(cue);p.captions.sort((a,b)=>a.start-b.start);mark();selectItem('caption',cue.id);
  }
  function addMask(){
    if(state.locked.has('mask'))throw Error('打码轨已锁定');
    const start=quant(state.cursor),end=Math.min(total(),start+2);
    if(end-start<1/rate())throw Error('播放头后至少需要一帧画面才能添加打码');
    remember();p.masks=p.masks||[];
    const mask={id:id(),start,end,x:350,y:710,w:380,h:300,blur:18,white:.2,mode:'solid',keyframes:[]};
    p.masks.push(mask);mark(false);selectItem('mask',mask.id);
  }
  async function removeSelected(){
    if(state.selections.length>1)throw Error('多选当前支持整体移动；请单选后删除，避免误删关联原声');
    const item=itemNow();if(!item)return;
    await change({type:'remove',kind:item.kind,id:item.id,magnetic:state.magnetic});
  }
  function canUnlink(){return studioAudioRelation(p,itemNow())?.state==='linked'&&!state.locked.has('video')&&!state.locked.has('dialogue')}
  async function unlinkSelected(){
    const item=itemNow();if(!item||!canUnlink())return;
    await change({type:'unlink',kind:item.kind,id:item.id});
    toast('已解除联动，原声可单独拖动；可点撤销恢复联动。');
  }
  function renderProperties(){
    if(state.selections.length>1){$('#inspector').innerHTML=`<section class="tl-properties"><h3>已选择 ${state.selections.length} 项</h3><p>未选字幕、旁白和音乐不移动。主轨磁吸开启时，从画面拖动连续选中镜头可整组排序；关闭时，整组保持相对时间平移。</p><p>Ctrl 点击增减选区；点击单个未选片段恢复单选。不自动裁切独立声音。</p></section>`;return true}
    const item=itemNow();if(!item||item.kind==='caption'||item.kind==='mask')return false;
    const relation=studioAudioRelation(p,item),record=getRecord(item),isOriginal=item.kind==='original',isVideo=item.kind==='video',a=asset(item.asset_id),locked=state.locked.has(item.kind);
    const number=(key,label,value,min)=>`<div><label>${label}</label><input data-tl-prop="${key}" inputmode="decimal" type="text" value="${Number(value)}" ${min!==undefined?`data-min="${min}"`:''}></div>`;
    const relationText=relation?.state==='embedded'?'原声跟随画面。需要单独移动时，点击“分离音频”。':relation?.state==='linked'?'画面和原声仍然联动，移动、裁剪或删除会一起生效。':relation?.state==='independent'?'这段声音和画面已经独立，可以单独移动。':relation?.detail||'';
    const timing=!isOriginal?`<details class="tl-advanced"><summary>精确时间</summary>${!isVideo?number('start','成片开始 / 秒',record.start??item.start,0):''}<div class="row">${number('in','素材入点 / 秒',record.in,0)}${number('out','素材出点 / 秒',record.out,0)}</div>${(a?.audio_streams||[]).length?`<label>源音轨</label><select data-tl-prop="audio_stream"><option value="">${a.audio_streams.length===1?'默认音轨':'请选择音轨'}</option>${a.audio_streams.map(s=>`<option value="${s.index}" ${record.audio_stream===s.index?'selected':''}>音轨 ${s.index} · ${esc(s.language||'未知语言')} ${esc(s.title||'')}</option>`).join('')}</select>`:''}</details>`:'';
    $('#inspector').innerHTML=`<section class="tl-properties"><h3>${isVideo?'视频片段':'音频片段'}</h3><span class="tl-badge">${esc(kindName(item.kind))}${locked?' · 已锁定':''}</span><div class="tl-name">${esc(a?.name)}</div><div class="helper">${time(item.start)} → ${time(item.end)} · 时长 ${time(item.end-item.start)}</div>${relationText?`<p class="tl-relation-detail ${relation?.state||''}">${esc(relationText)}</p>`:''}<fieldset ${locked?'disabled':''} style="border:0;padding:0;margin:0">${number('gain',isVideo||isOriginal?'原声音量 / dB':'音量 / dB',record.gain??0)}${!isOriginal&&!isVideo?`<label>类型</label><select data-tl-prop="role">${kinds.filter(t=>['dialogue','narration','bgm','sfx'].includes(t[0])).map(t=>`<option value="${t[0]}" ${item.kind===t[0]?'selected':''}>${t[1]}</option>`).join('')}</select><label class="tl-check"><input data-tl-prop="loop" type="checkbox" ${record.loop?'checked':''}> 背景音乐循环到片尾</label>`:''}${timing}<button id="tl-apply-props" class="accent tl-submit">应用</button></fieldset><p class="tl-warning">${isVideo?'主轨会自动吸附。拖动片段是在镜头之间插入排序；拖两端裁剪。':'拖动片段改变位置，拖两端裁剪。'}</p><button id="tl-to-start">把播放头移到片段开始</button></section>`;
    if(isVideo&&record.audio_detached){
      for(const field of document.querySelectorAll('[data-tl-prop="gain"],[data-tl-prop="audio_stream"]'))field.disabled=true;
      const note=document.createElement('p');note.className='helper';note.textContent=relation?.state==='linked'?`原声音量请选中“人物原声”轨的「${relation.label}」调整。`:'画面原声已关闭；请在对应声音轨调整音量。';$('#inspector').prepend(note);
    }
    $('#tl-apply-props').onclick=handle(()=>{
      const patch={};$$('[data-tl-prop]').forEach(el=>{const k=el.dataset.tlProp;patch[k]=el.type==='checkbox'?el.checked:k==='role'?el.value:k==='audio_stream'&&el.value===''?null:Number(el.value);if(el.type==='text'&&!el.value.trim())throw Error('时间与音量不能为空')});
      for(const k of Object.keys(patch)){if(patch[k]===record[k]||(k==='audio_stream'&&patch[k]==null&&record[k]==null))delete patch[k]}
      if(!Object.keys(patch).length)return;
      change({type:'update',kind:item.kind,id:item.id,patch,magnetic:state.magnetic});
    });
    $('#tl-to-start').onclick=()=>setCursor(item.start);
    if(isVideo){const replace=document.createElement('button');replace.id='tl-replace-video';replace.textContent='替换视频…';replace.disabled=locked;replace.onclick=handle(()=>replaceVideo(item.id));$('#tl-to-start').after(replace)}
    if(relation?.state==='linked'){
      const unlink=document.createElement('button');unlink.id='tl-properties-unlink';unlink.textContent='解除联动';unlink.disabled=!canUnlink();
      unlink.onclick=handle(unlinkSelected);$('#inspector .tl-relation-detail').after(unlink);
    }
    return true;
  }
  async function replaceVideo(clipId){
    await save();const pid=p.id;
    modal(`<h2>替换当前视频片段</h2><p>只替换这一段，不覆盖同素材的其他镜头。已有联动原声随新画面换源，独立原声不变；音量和原生未知字段保留。新素材请先从“添加素材”导入。</p><label>新视频素材</label><select id="replace-video-source">${p.assets.filter(a=>a.kind==='video').map(a=>`<option value="${a.id}">${esc(a.name)} · ${time(a.duration)}</option>`).join('')}</select><div class="row"><div><label>新素材入点 / 秒</label><input id="replace-video-in" type="number" min="0" step="any" value="0"></div><div><label>新素材出点 / 秒</label><input id="replace-video-out" type="number" min="0" step="any"></div></div><label>长度处理</label><select id="replace-video-strategy"><option value="fit">保长裁切：保持原片段长度（新素材不足则拒绝）</option><option value="gap">保留后续位置：长则裁切，短则留空，不自动冻结补帧</option><option value="ripple">使用新选段长度：推动后续画面</option></select><p>“推动后续”中，默认只有画面和已联动原声移动。可勾选跟随的新片段起点在旧画面结束之后；跨越替换边界的长音乐/旁白保持原样，不自动切断。</p>${['caption','narration','bgm','sfx','mask'].map(kind=>`<label><input data-replace-follow="${kind}" type="checkbox"> 同时推动后续${kindName(kind)}</label>`).join('')}<div id="replace-video-stream"></div><div class="modal-actions"><button id="replace-video-confirm" class="primary">确认替换</button></div>`);
    const sourceChange=()=>{const source=asset($('#replace-video-source').value);$('#replace-video-out').value=Math.floor(source.duration*rate())/rate();$('#replace-video-stream').innerHTML=(source.audio_streams||[]).length>1?`<label>原声音轨（不可猜测）</label><select id="replace-video-audio-stream"><option value="">请选择</option>${source.audio_streams.map(s=>`<option value="${s.index}">${s.index} · ${esc(s.title||s.language||'未知音轨')}</option>`).join('')}</select>`:''};
    $('#replace-video-source').onchange=sourceChange;sourceChange();
    $('#replace-video-confirm').onclick=handle(async()=>{
      if(p?.id!==pid)throw Error('工程已切换，请重新选择片段');
      const stream=$('#replace-video-audio-stream');if(stream&&stream.value==='')throw Error('请选择新视频的原声音轨');
      const op={type:'replace_video',id:clipId,asset_id:$('#replace-video-source').value,in:Number($('#replace-video-in').value),out:Number($('#replace-video-out').value),strategy:$('#replace-video-strategy').value,follow:$$('[data-replace-follow]:checked').map(el=>el.dataset.replaceFollow)};
      if(stream)op.audio_stream=Number(stream.value);
      $('#replace-video-confirm').disabled=true;
      try{await change(op);$('#modal').close();toast('已替换这一段，原工程历史可撤销；请核对切点和原声。')}catch(error){$('#replace-video-confirm').disabled=false;throw error}
    });
  }
  root.addEventListener('pointerdown',e=>{
    if(e.button!==0||!p||e.target.closest('button,input,select,.tl-label'))return;
    const clip=e.target.closest('[data-tl-id]'),scroll=root.querySelector('.tl-scroll');if(!scroll||!scroll.contains(e.target))return;
    if(!clip){
      const rect=scroll.getBoundingClientRect(),x=e.clientX-rect.left+scroll.scrollLeft-labelWidth();
      if(x<0)return;
      if(e.target.closest('.tl-ruler')){setCursor(quant(x/state.scale));state.drag={scrub:true,pointer:e.pointerId}}
      else{
        const content=root.querySelector('.tl-content').getBoundingClientRect();
        state.drag={box:true,pointer:e.pointerId,startX:e.clientX,startY:e.clientY,contentX:e.clientX-content.left,contentY:e.clientY-content.top,base:e.ctrlKey||e.metaKey?selectedItems():[],pid:p.id,signature:sig(),moved:false};
        const box=document.createElement('div');box.className='tl-selection-box';root.querySelector('.tl-content').append(box);
      }
      root.setPointerCapture(e.pointerId);e.preventDefault();return;
    }
    const kind=clip.dataset.tlKind,itemId=clip.dataset.tlId,edge=e.target.dataset.trim;
    if(e.ctrlKey||e.metaKey){selectItem(kind,itemId,false,true);root.focus({preventScroll:true});e.preventDefault();return}
    if(!selectionHas(kind,itemId)||edge)selectItem(kind,itemId,false);else state.selection={kind,id:itemId};root.focus({preventScroll:true});
    const item=itemNow();if(!item)return;
    if(state.locked.has(kind)){setCursor(item.start);toast('此轨道已锁定');return}
    window.StudioRealtime?.pause();
    const sc=root.querySelector('.tl-scroll');
    state.drag={kind,id:itemId,item:{...item},multi:state.selections.length>1,edge,startX:e.clientX,scrollLeft:sc.scrollLeft,pid:p.id,signature:sig(),moved:false,op:null,pointer:e.pointerId};
    root.setPointerCapture(e.pointerId);e.preventDefault();
  });
  root.addEventListener('pointermove',e=>{
    const drag=state.drag;if(!drag||e.pointerId!==drag.pointer)return;
    if(drag.scrub){const scroll=root.querySelector('.tl-scroll'),rect=scroll.getBoundingClientRect();setCursor(quant((e.clientX-rect.left+scroll.scrollLeft-labelWidth())/state.scale));return}
    if(p?.id!==drag.pid||sig()!==drag.signature){cancelDrag();return}
    if(drag.box){
      const content=root.querySelector('.tl-content').getBoundingClientRect(),x=e.clientX-content.left,y=e.clientY-content.top;
      drag.moved ||= Math.abs(e.clientX-drag.startX)+Math.abs(e.clientY-drag.startY)>3;
      const left=Math.max(labelWidth(),Math.min(x,drag.contentX)),right=Math.max(x,drag.contentX),top=Math.min(y,drag.contentY),bottom=Math.max(y,drag.contentY);
      const box=root.querySelector('.tl-selection-box');Object.assign(box.style,{left:left+'px',top:top+'px',width:Math.max(0,right-left)+'px',height:(bottom-top)+'px'});
      const entries=new Map(drag.base.map(entry=>[key(entry.kind,entry.id),entry]));
      root.querySelectorAll('[data-tl-id]').forEach(node=>{const r=node.getBoundingClientRect();if(r.right>content.left+left&&r.left<content.left+right&&r.bottom>content.top+top&&r.top<content.top+bottom)entries.set(key(node.dataset.tlKind,node.dataset.tlId),{kind:node.dataset.tlKind,id:node.dataset.tlId})});
      drag.entries=[...entries.values()];
      root.querySelectorAll('[data-tl-id]').forEach(node=>node.classList.toggle('selected',entries.has(key(node.dataset.tlKind,node.dataset.tlId))));return;
    }
    const scroll=root.querySelector('.tl-scroll'),rect=scroll.getBoundingClientRect();
    if(e.clientX>rect.right-30)scroll.scrollLeft+=12;else if(e.clientX<rect.left+labelWidth()+24)scroll.scrollLeft-=12;
    const dx=e.clientX-drag.startX+scroll.scrollLeft-drag.scrollLeft;
    if(Math.abs(dx)<3&&!drag.moved)return;drag.moved=true;
    const node=root.querySelector(`[data-tl-kind="${drag.kind}"][data-tl-id="${drag.id}"]`),exclude=key(drag.kind,drag.id);
    let start=drag.item.start,end=drag.item.end,reorderIndex=null;
    if(drag.edge){
      if(drag.edge==='start')start=boundarySnap(start+dx/state.scale,exclude);else end=boundarySnap(end+dx/state.scale,exclude);
      drag.op={type:'trim',kind:drag.kind,id:drag.id,[drag.edge]:drag.edge==='start'?start:end,magnetic:state.magnetic};
    }else if(drag.kind==='video'&&state.magnetic){
      const pointerTime=Math.max(0,(e.clientX-rect.left+scroll.scrollLeft-labelWidth())/state.scale);
      const selectedVideos=new Set(selectedItems().flatMap(entry=>entry.kind==='video'?[entry.id]:p.native_links?.[entry.id]?.linked_video_id?[p.native_links[entry.id].linked_video_id]:[]));
      const others=state.layout.items.filter(item=>item.kind==='video'&&!selectedVideos.has(item.id)).sort((a,b)=>a.start-b.start);
      reorderIndex=others.filter(item=>pointerTime>(item.start+item.end)/2).length;
      drag.op=drag.multi?{type:'reorder_selection',id:drag.id,items:selectedItems(),targetIndex:reorderIndex}:{type:'reorder',kind:'video',id:drag.id,targetIndex:reorderIndex};
    }else{
      start=boundarySnap(drag.item.start+dx/state.scale,exclude);end=start+drag.item.end-drag.item.start;
      drag.op=drag.multi?{type:'move_selection',items:selectedItems(),delta:start-drag.item.start}:{type:'move',kind:drag.kind,id:drag.id,targetTime:start};
    }
    let error='';try{const candidate=StudioTimeline.apply(p,drag.op,()=> 'timeline-preview-'+drag.id),view=StudioTimeline.get(candidate.project,drag.kind,drag.id);start=view.start;end=view.end;if(reorderIndex!==null){state.snapPoint=start}if(drag.multi)for(const entry of selectedItems()){const row=StudioTimeline.get(candidate.project,entry.kind,entry.id),element=root.querySelector(`[data-tl-kind="${entry.kind}"][data-tl-id="${entry.id}"]`);if(element)element.style.left=(labelWidth()+row.start*state.scale)+'px'}window.StudioRealtime?.preview(candidate.project)}catch(err){error=err.message;window.StudioRealtime?.clearPreview()}
    drag.error=error;
    if(node){node.classList.add('dragging');node.style.left=(labelWidth()+start*state.scale)+'px';node.style.width=Math.max(3,(end-start)*state.scale)+'px';node.style.borderColor=error?'#ff9696':'#e3f6bc'}
    const line=root.querySelector('.tl-drop-line');if(line){line.style.display=state.snapPoint==null?'none':'block';line.style.left=(labelWidth()+state.snapPoint*state.scale)+'px'}
    const hint=$('#tl-hint');hint.textContent=error||(reorderIndex!==null?`放到第 ${reorderIndex+1} 个镜头 · 松开完成排序`:`${drag.edge?(drag.edge==='start'?'裁剪左边':'裁剪右边'):'移动片段'}：${time(start)} → ${time(end)}${state.snapPoint==null?'':' · 已吸附'}`);hint.className=error?'warn':'';
  });
  root.addEventListener('pointerup',async e=>{
    const drag=state.drag;if(!drag||e.pointerId!==drag.pointer)return;
    state.drag=null;if(root.hasPointerCapture(e.pointerId))root.releasePointerCapture(e.pointerId);
    if(drag.scrub){draw();return}
    if(drag.box){if(p?.id===drag.pid&&sig()===drag.signature){state.selections=drag.moved?(drag.entries||drag.base):drag.base;state.selection=state.selections.at(-1)||null}render();return}
    if(p?.id!==drag.pid||sig()!==drag.signature){draw();toast('工程在拖动期间已改变，本次拖动未应用。',true);return}
    try{if(drag.moved&&drag.op){if(drag.error)throw Error(drag.error);await change(drag.op)}else setCursor(drag.item.start)}catch(err){toast(err.message,true)}finally{window.StudioRealtime?.clearPreview();draw()}
  });
  function cancelDrag(){const drag=state.drag;state.drag=null;if(drag&&root.hasPointerCapture(drag.pointer))root.releasePointerCapture(drag.pointer);window.StudioRealtime?.clearPreview();draw()}
  root.addEventListener('pointercancel',cancelDrag);
  root.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&state.drag){e.preventDefault();cancelDrag();return}
    if(editing()||!p)return;
    if((e.ctrlKey||e.metaKey)&&['z','y'].includes(e.key.toLowerCase())){e.preventDefault();if(e.shiftKey||e.key.toLowerCase()==='y')$('#redo-button').click();else $('#undo-button').click();return}
    if(e.key==='Delete'||e.key==='Backspace'){e.preventDefault();handle(removeSelected)();return}
    if(e.key.toLowerCase()==='s'&&!e.ctrlKey&&!e.metaKey){e.preventDefault();$('#tl-split')?.click();return}
    if(e.key==='Enter'){const target=e.target.closest('[data-tl-id]');if(target){e.preventDefault();selectItem(target.dataset.tlKind,target.dataset.tlId)}}
  });
  render=function(...args){
    if(state.pid!==p?.id)reset();
    if(state.selection?.kind==='caption'&&tab==='captions'&&selected!==state.selection.id){state.selection=p.captions.some(c=>c.id===selected)?{kind:'caption',id:selected}:null;state.selections=state.selection?[state.selection]:[]}
    old.render(...args);draw();
  };
  renderInspector=function(...args){if(!renderProperties())old.renderInspector(...args)};
  mark=function(sound=false,...args){old.mark(sound,...args);if(sound&&!window.StudioRealtime?.editing()){state.stale=true;$('#video').pause()}schedule()};
  updateOverlay=function(frameTime){
    const effective=Number.isFinite(frameTime)?frameTime:(window.StudioRealtime?.editing()?StudioRealtime.time():$('#video').getAttribute('src')?$('#video').currentTime:state.cursor);
    old.updateOverlay(effective);state.cursor=Math.max(0,Math.min(total(),effective||0));paintCursor();
  };
  openProject=async function(pid,...args){await old.openProject(pid,...args);if(p?.id===pid)draw()};
  viewRender=async function(...args){await old.viewRender(...args);state.stale=!!previewJob&&!!qa&&(previewJob.result?.sound_digest!==qa.sound_hash);schedule()};
  const oldTabs=$('#tabs').onclick;
  $('#tabs').onclick=function(e){state.selection=null;state.selections=[];return oldTabs(e)};
  window.addEventListener('resize',schedule);
  window.StudioTimelineUI={canDetach:()=>!state.locked.has('video')&&!state.locked.has('original'),refresh:draw,previewUpdated:stale=>{state.stale=!!stale;schedule()},selection:()=>state.selection?{...state.selection}:null,selections:()=>selectedItems().map(entry=>({...entry})),select:selectItem,seek:setCursor,addMask,dragging:()=>!!state.drag};
}
