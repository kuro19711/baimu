'use strict';
/* One local visual effect: a white, softly blurred rectangular privacy mask. */
function installStudioMasking(){
  const layer=$('#mask-layer');
  if(!layer||!window.StudioTimelineUI)return;
  const old={render,renderInspector,updateOverlay,openProject,viewRender};
  let visualDirty=false,drag=null,lastInspectorFrame=null;
  const current=()=>StudioTimelineUI.selection()?.kind==='mask'?(p?.masks||[]).find(m=>m.id===StudioTimelineUI.selection().id):null;
  const now=()=>{
    if(window.StudioRealtime?.editing())return StudioRealtime.time();
    if($('#video').getAttribute('src'))return $('#video').currentTime||0;
    return ($('#tl-position')?.value||'0').split(':').map(Number).reduce((a,n)=>a*60+n,0);
  };
  // A pointer gesture can report a playhead exactly half a frame away from
  // the rounded keyframe time. Treat that boundary as the same frame so one
  // drag updates one keyframe instead of appending a duplicate per move event.
  const almost=(a,b)=>Math.abs(a-b)<=.500001/rate();
  function position(mask,t){
    const points=[{time:mask.start,x:mask.x,y:mask.y,w:mask.w,h:mask.h}];
    for(const raw of mask.keyframes)points.push({...points.at(-1),...raw});
    for(let i=1;i<points.length;i++){
      const right=points[i],left=points[i-1];
      if(t<=right.time){const f=Math.max(0,Math.min(1,(t-left.time)/(right.time-left.time)));return {x:left.x+(right.x-left.x)*f,y:left.y+(right.y-left.y)*f,w:left.w+(right.w-left.w)*f,h:left.h+(right.h-left.h)*f}}
    }
    return {x:points.at(-1).x,y:points.at(-1).y,w:points.at(-1).w,h:points.at(-1).h};
  }
  function activePoint(mask,t,create){
    if(t<=mask.start+.5/rate())return mask;
    let point=mask.keyframes.find(k=>almost(k.time,t));
    if(!point&&create&&t<mask.end-.5/rate()){
      point={time:Math.round(t*rate())/rate(),...position(mask,t)};
      mask.keyframes.push(point);mask.keyframes.sort((a,b)=>a.time-b.time);
    }
    return point;
  }
  const staleBurned=()=>!!(previewJob?.result?.masks_burned&&(visualDirty||previewJob.result.project_hash!==qa?.hash));
  const shouldSimulate=()=>false; // Live canvas owns pixels; this layer only holds editing handles.
  function paint(t=now()){
    if(!p){layer.replaceChildren();return}
    const selectedId=current()?.id;
    const active=window.StudioLiveEditor?.editing()?(p.masks||[]).filter(m=>t>=m.start&&t<m.end):[];
    const ids=active.map(m=>m.id).join('|');
    if(layer.dataset.ids!==ids&&!drag){
      layer.innerHTML=active.map(m=>`<div class="white-mask" data-mask-id="${m.id}" title="打码：拖动定位；拖右下角调整大小"><span class="mask-resize" data-mask-resize="1"></span></div>`).join('');
      layer.dataset.ids=ids;
    }
    for(const mask of active){
      const el=layer.querySelector(`[data-mask-id="${mask.id}"]`);if(!el)continue;
      const at=position(mask,t),selected=selectedId===mask.id;
      Object.assign(el.style,{left:(at.x/1080*100)+'%',top:(at.y/1920*100)+'%',width:(at.w/1080*100)+'%',height:(at.h/1920*100)+'%',backdropFilter:shouldSimulate()?`blur(${mask.blur*$('#stage').clientWidth/1080}px)`:'none',background:shouldSimulate()?`rgba(255,255,255,${mask.white})`:'transparent'});
      el.classList.toggle('selected',selected);
      el.classList.toggle('stale',false);
      el.style.pointerEvents=selected?'auto':'none';
    }
    window.StudioLiveEditor?.paintMasks(t);
  }
  function changed(){visualDirty=true;mark(false);paint();window.StudioLiveEditor?.refresh();}
  function validateMask(candidate){
    if(candidate.end>total()+1e-7)throw Error('打码不能超出本集画面结尾');
    StudioTimeline.layout({...p,masks:(p.masks||[]).map(m=>m.id===candidate.id?candidate:m)});
  }
  async function commit(candidate){
    try{validateMask(candidate);const {id,...patch}=candidate;const result=StudioTimeline.apply(p,{type:'update',kind:'mask',id,patch});remember();p=result.project;mark(false);render()}
    catch(error){toast(error.message,true)}
  }
  function renderPanel(){
    if(!p)return;
    const masks=p.masks||[];
    $('#panel').innerHTML=`<div class="panel-head"><h3>打码</h3><small>${masks.length} 段</small></div><p class="helper">在编辑预览中拖动方框即时遮挡，支持实心白块或模糊＋提亮。移动目标可添加位置关键帧；可在属性中选择打码位于字幕上方或下方。</p><div class="toolbar"><button id="mask-add" class="accent">＋ 在播放头添加</button></div>${masks.length?masks.map((m,i)=>`<div class="card mask-card ${current()?.id===m.id?'mask-card-active':''}" data-mask-card="${m.id}"><div class="card-title">${i+1}. ${m.mode==='solid'?'实心白块':'模糊＋提亮'}</div><small>${time(m.start)} → ${time(m.end)} · ${m.keyframes.length} 个位置/尺寸关键帧</small></div>`).join(''):empty('还没有打码','将播放头移动到需要遮挡的画面，点击添加。')}`;
    $('#mask-add').onclick=handle(()=>StudioTimelineUI.addMask());
    $$('[data-mask-card]').forEach(el=>el.onclick=()=>StudioTimelineUI.select('mask',el.dataset.maskCard));
  }
  function renderMaskInspector(atTime=now()){
    const m=current();if(!m)return false;
    const t=atTime,pos=position(m,t),point=activePoint(m,t,false);
    lastInspectorFrame=`${m.id}:${Math.round(t*rate())}`;
    const field=(k,label,v,step='1')=>`<div><label>${label}</label><input data-mask-field="${k}" type="text" inputmode="decimal" value="${Number(v.toFixed(3))}" data-step="${step}"></div>`;
    $('#inspector').innerHTML=`<h3>打码属性</h3><span class="tl-badge">实时打码 · 不影响声音</span><div class="row">${field('start','开始 / 秒',m.start,'.001')}${field('end','结束 / 秒',m.end,'.001')}</div><hr class="section-break"><p class="helper">暂停画面后拖动白框定位，拖右下角调整宽高。中途调整会自动建立关键帧，位置与尺寸在关键帧之间平滑变化。</p><div class="row">${field('x','当前 X / 1080',pos.x)}${field('y','当前 Y / 1920',pos.y)}</div><div class="row">${field('w','宽度 / 1080',pos.w)}${field('h','高度 / 1920',pos.h)}</div><div class="row">${field('blur','模糊强度 1–40',m.blur)}${field('white','白色柔化 0–0.6',m.white,'.01')}</div><div class="row">${field('feather','边缘羽化 0–1',m.feather||0,'.01')}</div><button id="mask-apply" class="wide accent">应用打码参数</button><div class="toolbar"><button id="mask-key-add" ${point||t<=m.start||t>=m.end?'disabled':''}>＋ 当前位置关键帧</button><button id="mask-key-delete" class="danger" ${!point||point===m?'disabled':''}>删除此关键帧</button></div><div class="helper">${m.keyframes.length?m.keyframes.map(k=>`<button class="mask-key-jump" data-mask-jump="${k.time}">${time(k.time)}</button>`).join(' '):'暂无关键帧，遮挡框在整段内保持不动。'}</div><p class="helper">编辑预览即时显示打码；X/Y 按左上角起算。剪映原生矩形模糊的羽化在本地导出中使用兼容近似，原生草稿参数保持不变。最终效果请分别核对本地导出和剪映画面。</p>`;
    const mode=document.createElement('label');mode.innerHTML=`打码效果<select id="mask-effect-mode"><option value="solid" ${m.mode==='solid'?'selected':''}>实心白块</option><option value="blur" ${(m.mode||'blur')==='blur'?'selected':''}>模糊＋提亮</option></select>`;
    const order=document.createElement('label');order.innerHTML=`与字幕的上下关系<select id="mask-layer-order"><option value="below_captions" ${m.layer!=='above_captions'?'selected':''}>字幕在上，打码在下</option><option value="above_captions" ${m.layer==='above_captions'?'selected':''}>打码在上，遮住字幕</option></select>`;
    $('#inspector').append(order);
    $('#mask-layer-order').onchange=()=>commit({...copy(m),layer:$('#mask-layer-order').value});
    $('#inspector h3').after(mode);
    $('#mask-effect-mode').onchange=()=>{const next=copy(m);next.mode=$('#mask-effect-mode').value;if(next.mode==='solid')next.feather=0;if(p.native?.shared&&next.mode==='blur')next.white=0;commit(next)};
    for(const key of ['blur','white','feather'])$(`[data-mask-field="${key}"]`).disabled=m.mode==='solid';
    $('#mask-apply').onclick=handle(()=>{
      const values={};
      $$('[data-mask-field]').forEach(el=>{if(!el.value.trim()||!Number.isFinite(Number(el.value)))throw Error('请输入有效数字');values[el.dataset.maskField]=Number(el.value)});
      const next=copy(m);
      if(values.start>=values.end)throw Error('开始必须早于结束');
      if(values.start>next.start){const at=position(next,values.start);next.x=at.x;next.y=at.y;next.w=at.w;next.h=at.h;next.keyframes=next.keyframes.filter(k=>k.time>values.start)}
      next.start=values.start;next.end=values.end;next.keyframes=next.keyframes.filter(k=>k.time<next.end);
      for(const key of ['blur','white','feather'])next[key]=values[key];
      const animatedSize=next.keyframes.some(k=>'w' in k||'h' in k),geometryChanged=['x','y','w','h'].some(key=>Math.abs(values[key]-pos[key])>1e-4);
      if(geometryChanged&&(animatedSize||t>next.start+.5/rate())){
        const at=activePoint(next,t,true);if(!at)throw Error('播放头必须位于这段打码内部');for(const key of ['x','y','w','h'])at[key]=values[key];
      }else{
        for(const key of ['x','y','w','h'])next[key]=values[key];
      }
      if(JSON.stringify(next)!==JSON.stringify(m))commit(next);
    });
    $('#mask-key-add').onclick=handle(()=>{const next=copy(m);activePoint(next,t,true);commit(next)});
    $('#mask-key-delete').onclick=handle(()=>{const next=copy(m);next.keyframes=next.keyframes.filter(k=>!almost(k.time,t));commit(next)});
    $$('[data-mask-jump]').forEach(el=>el.onclick=()=>{StudioTimelineUI.seek(Number(el.dataset.maskJump));renderInspector()});
    if((p.track_locks||[]).includes('mask'))for(const control of $$('#inspector input,#inspector select,#inspector button'))control.disabled=true;
    return true;
  }
  layer.addEventListener('pointerdown',e=>{
    const box=e.target.closest('[data-mask-id]'),m=current();
    if(e.button!==0||!box||!m||box.dataset.maskId!==m.id||(p.track_locks||[]).includes('mask'))return;
    const t=now();if(t<m.start||t>=m.end)return;
    window.StudioRealtime?.pause();$('#video').pause();clearTimeout(timer);
    drag={id:m.id,t,startX:e.clientX,startY:e.clientY,original:copy(m),resize:!!e.target.closest('[data-mask-resize]'),pointer:e.pointerId,changed:false};
    layer.setPointerCapture(e.pointerId);e.preventDefault();
  });
  layer.addEventListener('pointermove',e=>{
    if(!drag||e.pointerId!==drag.pointer)return;
    const m=(p.masks||[]).find(v=>v.id===drag.id);if(!m)return;
    const dx=(e.clientX-drag.startX)*1080/$('#stage').clientWidth,dy=(e.clientY-drag.startY)*1920/$('#stage').clientHeight;
    if(Math.abs(dx)+Math.abs(dy)<1&&!drag.changed)return;
    const snapshot=drag.original;
    if(drag.resize){
      const base=position(snapshot,drag.t),width=Math.max(16,Math.min(4320,Math.round(base.w+dx))),height=Math.max(16,Math.min(7680,Math.round(base.h+dy)));
      if(snapshot.keyframes.some(k=>'w' in k||'h' in k)||drag.t>snapshot.start+.5/rate()){
        const point=activePoint(m,drag.t,true);point.w=width;point.h=height;
      }else{m.w=width;m.h=height}
    }else{
      const point=activePoint(m,drag.t,true),base=activePoint(snapshot,drag.t,false)||position(snapshot,drag.t);
      const size=position(m,drag.t);
      if(point){point.x=Math.max(16-size.w,Math.min(1064,Math.round(base.x+dx)));point.y=Math.max(16-size.h,Math.min(1904,Math.round(base.y+dy)))}
    }
    drag.changed=true;paint(drag.t);window.StudioRealtime?.refresh();
  });
  async function finishDrag(e,cancel=false){
    if(!drag||e.pointerId!==drag.pointer)return;
    const entry=drag;drag=null;if(layer.hasPointerCapture(e.pointerId))layer.releasePointerCapture(e.pointerId);
    if(cancel){const i=p.masks.findIndex(m=>m.id===entry.id);if(i>=0)p.masks[i]=entry.original;paint();window.StudioRealtime?.refresh();if(dirty>saved)timer=setTimeout(()=>save().catch(e=>toast(e.message,true)),600);return}
    if(!entry.changed)return;
    const changedMask=p.masks.find(m=>m.id===entry.id);
    try{validateMask(changedMask)}catch(err){const i=p.masks.findIndex(m=>m.id===entry.id);p.masks[i]=entry.original;paint();toast(err.message,true);return}
    const candidate=copy(changedMask);p.masks=p.masks.map(m=>m.id===entry.id?entry.original:m);
    await commit(candidate);if(tab==='masks')renderPanel();renderInspector();StudioTimelineUI.refresh();window.StudioRealtime?.refresh();
  }
  layer.addEventListener('pointerup',e=>finishDrag(e));
  layer.addEventListener('pointercancel',e=>finishDrag(e,true));
  render=function(...args){old.render(...args);if(tab==='masks')renderPanel();paint()};
  renderInspector=function(...args){if(!renderMaskInspector())old.renderInspector(...args)};
  updateOverlay=function(frameTime){
    old.updateOverlay(frameTime);
    const t=Number.isFinite(frameTime)?frameTime:now();paint(t);
    const m=current(),frame=m?`${m.id}:${Math.round(t*rate())}`:null;
    if(frame&&frame!==lastInspectorFrame&&!$('#inspector').contains(document.activeElement))renderMaskInspector(t);
  };
  openProject=async function(...args){visualDirty=false;await old.openProject(...args);paint()};
  viewRender=async function(...args){await old.viewRender(...args);visualDirty=false;paint()};
  window.StudioMasks={position,paint,dragging:()=>!!drag};
}
