'use strict';
// One editing surface. Keep the original action handlers when relocating controls.
(() => {
  document.body.classList.add('simple-shell');
  const actions=$('.top-actions');
  const more=document.createElement('details');more.id='more-actions';
  more.innerHTML='<summary aria-label="更多操作">更多 ⋯</summary><div class="more-menu" aria-label="更多操作"></div>';
  const menu=more.querySelector('.more-menu');
  actions.append(more);
  const move=(id,label,projectOnly=false)=>{
    const button=$('#'+id);if(!button)return;
    if(label)button.textContent=label;
    if(projectOnly)button.dataset.projectAction='true';
    menu.append(button);
  };
  const handoffButton=$('#handoff-button');handoffButton.textContent='写入剪映';
  handoffButton.title='把当前工程写入同一份剪映草稿';
  move('mode-export','查看最近导出',true);
  move('batch-queue-button','批量导出 / 处理',true);
  move('share-project-button','打包工程与素材',true);
  move('history-button','恢复历史版本',true);
  move('library-import-package','导入工程包');
  move('global-new-button','新建分集',true);
  move('global-manage-button','管理 / 回收站');
  move('settings-button','设置');
  move('layout-reset','重置布局',true);
  move('batch-handoff-button','批量写入剪映',true);
  $('#batch-queue-button').hidden=true;
  const storage=document.createElement('button');storage.id='storage-button';storage.textContent='存储位置';
  storage.onclick=()=>$('.local').click();menu.append(storage);
  for(const id of ['save-button','preview-button','native-drafts-button'])$('#'+id).hidden=true;
  $('#global-new-button').hidden=true;
  // The native data inspector remains available for diagnostics, without a second user entry.
  const home=$('#library-home-button');home.textContent='首页';
  const importButton=document.createElement('button');importButton.id='import-button';importButton.textContent='导入素材';
  importButton.onclick=()=>{
    if(!p)return toast('先新建或打开一集，再导入素材',true);
    window.studioMaterialImport?.open();
  };
  const saveButton=$('#save-button');
  const saveStatus=$('#save-status');saveStatus.setAttribute('role','status');saveStatus.setAttribute('aria-live','polite');
  const retry=document.createElement('button');retry.id='retry-save-button';retry.textContent='重试保存';retry.hidden=true;
  retry.onclick=handle(async()=>{await save();toast('修改已保存')});
  const undoButton=$('#undo-button'),redoButton=$('#redo-button');undoButton.hidden=redoButton.hidden=true;menu.append(undoButton,redoButton);
  const batchHandoffButton=$('#batch-handoff-button');
  actions.replaceChildren(home,importButton,saveStatus,retry,handoffButton,$('#export-button'),more);
  // Lock/conflict handlers still reference the hidden save button.
  menu.append(saveButton);
  $('#export-button').textContent='导出视频';
  $('.viewer-top>span').textContent='实时预览';
  $('#stage-placeholder h3').textContent='导入素材，开始剪辑';
  $('#stage-placeholder p').textContent='修改即时预览，工程自动保存';
  const oldRender=render;
  function sync(){
    const hasProject=!!p,locked=!hasProject||saveButton.disabled||$('main').inert;
    for(const node of [importButton,$('#undo-button'),$('#redo-button'),handoffButton,$('#export-button')])node.disabled=locked;
    batchHandoffButton.disabled=saveButton.disabled||$('main').inert;
    for(const node of menu.querySelectorAll('[data-project-action]'))node.disabled=locked;
    retry.hidden=!hasProject||dirty<=saved||!/尚未保存|冲突|核对后保存/.test(saveStatus.textContent);
    saveStatus.title=dirty>saved?'修改尚未保存；保存成功后会显示“已保存到本机”':'修改会自动保存到本机';
    handoffButton.textContent=p?.native?.shared?'打开剪映':'写入剪映';
    handoffButton.title=p?.native?.shared?'百慕修改已直接保存到共同草稿；打开剪映或提示如何安全重开':'保存当前工程并写入剪映草稿列表';
  }
  render=function(...args){const value=oldRender(...args);sync();return value};
  new MutationObserver(sync).observe(saveStatus,{childList:true,subtree:true,characterData:true});
  new MutationObserver(sync).observe(saveButton,{attributes:true,attributeFilter:['disabled']});
  new MutationObserver(sync).observe($('main'),{attributes:true,attributeFilter:['inert']});
  more.addEventListener('toggle',()=>{if(more.open)sync()});
  menu.addEventListener('click',event=>{if(event.target.closest('button'))more.open=false});
  document.addEventListener('pointerdown',event=>{if(more.open&&!more.contains(event.target))more.open=false});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&more.open){more.open=false;more.querySelector('summary').focus()}});
  sync();
})();
