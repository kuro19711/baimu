// Source: hardening.js
'use strict';

// Pure helpers are also exercised in Node without opening a browser or project.
const StudioSafety = {
  updateInPlace(target, source) {
    const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
    if(Array.isArray(target)&&Array.isArray(source)){
      const keyed=new Map(target.filter(object).filter(item=>item.id!=null).map(item=>[String(item.id),item]));
      const next=source.map(item=>{
        if(object(item)&&item.id!=null&&keyed.has(String(item.id)))return StudioSafety.updateInPlace(keyed.get(String(item.id)),item);
        return JSON.parse(JSON.stringify(item));
      });
      target.splice(0,target.length,...next);return target;
    }
    if(object(target)&&object(source)){
      for(const key of Object.keys(target))if(!(key in source))delete target[key];
      for(const [key,value] of Object.entries(source)){
        if(Array.isArray(target[key])&&Array.isArray(value))StudioSafety.updateInPlace(target[key],value);
        else if(object(target[key])&&object(value))StudioSafety.updateInPlace(target[key],value);
        else target[key]=JSON.parse(JSON.stringify(value));
      }
      return target;
    }
    return JSON.parse(JSON.stringify(source));
  },
  mergeResult(base, current, result) {
    const next = JSON.parse(JSON.stringify(result));
    const editable = ['name','series','width','height','fps','clips','audios','captions','style','script','protected_lines','masks','language','track_locks'];
    const preserved = [];
    for (const key of editable) {
      if (JSON.stringify(base[key]) !== JSON.stringify(current[key])) {
        next[key] = JSON.parse(JSON.stringify(current[key]));
        preserved.push(key);
      }
    }
    if (preserved.length) next.reviews = {};
    return {project: next, preserved};
  },
  reconcile(base, local, remote) {
    if (!base || base.id!==local.id || remote.id!==local.id) return {conflicts:['工程']};
    const next=JSON.parse(JSON.stringify(remote)), conflicts=[];
    for (const key of ['name','series','width','height','fps','clips','audios','captions','masks','style','script','protected_lines','language','track_locks']) {
      const old=JSON.stringify(base[key]), mine=JSON.stringify(local[key]), theirs=JSON.stringify(remote[key]);
      if(mine===old)continue;
      if(theirs!==old && mine!==theirs){conflicts.push(key);continue;}
      if(local[key]===undefined)delete next[key];else next[key]=JSON.parse(mine);
    }
    if(!conflicts.length)next.reviews={};
    return {project:next,conflicts};
  },
  srt(cues) {
    const format = seconds => {
      const n = Math.round(seconds * 1000);
      return `${String(Math.floor(n/3600000)).padStart(2,'0')}:${String(Math.floor(n/60000)%60).padStart(2,'0')}:${String(Math.floor(n/1000)%60).padStart(2,'0')},${String(n%1000).padStart(3,'0')}`;
    };
    return [...cues].sort((a,b)=>a.start-b.start).map((c,i)=>`${i+1}\n${format(c.start)} --> ${format(c.end)}\n${c.text}`).join('\n\n')+'\n';
  },
  effectiveStyle(project, cue, activeTab) {
    return activeTab==='captions' && cue ? {...project.style,...cue.style} : {...project.style};
  },
  draftKey(projectId, windowId) { return `studio-draft:${projectId}:${windowId}`; },
  requestGate() {
    let sequence=0;
    return {begin:()=>++sequence, current:ticket=>ticket===sequence};
  },
  voiceRange(start, end) {
    if (String(start).trim()==='' || String(end).trim()==='') throw Error('请填写实际发声起止时间，不会用字幕时间自动代替');
    start=Number(start); end=Number(end);
    if (!Number.isFinite(start)||!Number.isFinite(end)||start<0||end<=start) throw Error('实际发声终点必须晚于起点');
    return {start,end};
  },
  healthMessages(data) {
    const messages=[];
    if(data.connection_error)messages.push('本地服务连接异常，未保存编辑仍保留在本窗口草稿中');
    if(data.jobs?.storage_error)messages.push('任务记录写入失败：请检查磁盘空间或文件夹权限，不要将此次输出直接交付');
    if(data.jobs?.worker_alive===false)messages.push('后台处理线程已停止：请保存工程并检查记录后重启软件');
    if(data.recovery_issues?.length)messages.push(`有 ${data.recovery_issues.length} 条文件读取或恢复告警，请查看详情；其他正常工程仍可使用`);
    return messages;
  }
};
if (typeof module!=='undefined' && module.exports) module.exports=StudioSafety;

function installStudioHardening() {
  const original={mark,renderCaptions,renderInspector,renderClips,renderAudio,renderScript,renderQA,updateOverlay,viewRender,pollJobs,refreshBoot};
  const gate=StudioSafety.requestGate();
  let operation=null, loading=false, frameHandle=null, frameKind='', textSession=null;
  let acknowledged=null, saveBlocked=false;
  const conflictNotice=document.createElement('div');conflictNotice.className='parallel-editor-notice';conflictNotice.hidden=true;conflictNotice.setAttribute('role','status');$('.project-heading').after(conflictNotice);
  // A duplicated browser tab can inherit sessionStorage: give every live page its own key.
  const windowId=id();
  sessionStorage.setItem('studio-window-id',windowId);
  let draftWarning=false, adoptedDraftKey=null,lastHealthAt=0,lastHealth={jobs:null,recovery_issues:[]};
  const serviceBanner=document.createElement('div');serviceBanner.className='service-health';serviceBanner.id='service-health';serviceBanner.style.display='none';serviceBanner.setAttribute('role','status');$('header').after(serviceBanner);
  function showHealth(update){
    lastHealth={...lastHealth,...update};
    const messages=StudioSafety.healthMessages(lastHealth);
    serviceBanner.style.display=messages.length?'block':'none';
    serviceBanner.innerHTML=messages.map(message=>`<div>${esc(message)}</div>`).join('')+(messages.length?'<button id="health-details">查看服务 / 恢复记录</button>':'');
    if(messages.length)$('#health-details').onclick=()=>modal(`<h2>服务与恢复记录</h2><p>异常记录不会被隐藏为正常完成。请先保留草稿和工程；不要手动删除恢复目录。</p><pre class="health-detail">${esc(JSON.stringify(lastHealth,null,2))}</pre>`);
  }
  refreshBoot=async function(){await original.refreshBoot();showHealth({recovery_issues:boot.recovery_issues||[]})};

  function draftKey(pid) { return StudioSafety.draftKey(pid,windowId); }
  function persistDraft() {
    if(!p || dirty<=saved)return true;
    try {
      localStorage.setItem(draftKey(p.id),JSON.stringify({project:copy(p),saved_at:Date.now(),window_id:windowId}));
      return true;
    } catch(e) {
      if(!draftWarning)toast('浏览器草稿空间不足，尚未保存的修改请先下载备份；不要关闭窗口。',true);
      draftWarning=true;return false;
    }
  }
  function removeOwnDraft(pid) {try{localStorage.removeItem(draftKey(pid))}catch(e){}}
  function findDraft(pid) {
    const rows=[];
    try {
      for(let n=0;n<localStorage.length;n++){
        const key=localStorage.key(n);
        if(key?.startsWith(`studio-draft:${pid}:`)){
          try{const row=JSON.parse(localStorage.getItem(key));if(row.project?.id===pid)rows.push({...row,key})}catch(e){}
        }
      }
    }catch(e){}
    return rows.sort((a,b)=>b.saved_at-a.saved_at)[0];
  }
  function exportDraft(project=p) {download(new Blob([JSON.stringify(project,null,2)],{type:'application/json'}),(project?.name||'工程')+'-未保存草稿.json')}
  function conflictDialog(message) {
    const pid=p?.id;
    conflictNotice.hidden=false;
    conflictNotice.innerHTML=`<span>${esc(message)}。可继续编辑，修改已保留为本地草稿；处理冲突后再写入共同工程。</span><div><button id="draft-download">下载草稿备份</button><button id="conflict-reload">读取本机保存版并比较</button></div>`;
    $('#draft-download').onclick=()=>exportDraft();
    $('#conflict-reload').onclick=handle(async()=>{await openProject(pid,{skipSave:true})});
  }
  function offerDraft(row) {
    if(!row||!p)return;
    const pid=p.id, snapshot=copy(row.project);
    modal(`<h2>发现本集的未保存草稿</h2><p>草稿基于修订 ${snapshot.revision}，本机保存版为修订 ${p.revision}。当前暂时显示本机保存版。草稿不会自动覆盖新版本。</p><div class="modal-actions"><button id="recover-download">下载草稿</button><button id="recover-server">保留本机保存版</button><button id="recover-local" class="primary">恢复草稿为待保存修改</button></div>`);
    $('#recover-download').onclick=()=>exportDraft(snapshot);
    $('#recover-server').onclick=()=>$('#modal').close();
    $('#recover-local').onclick=handle(()=>{
      if(p?.id!==pid)throw Error('当前工程已切换，请重新打开草稿');
      if(!confirm('恢复后会替换当前编辑区内容。保存时将建立历史版本，但其他窗口的新增修改需要你先核对。继续恢复？'))return;
      remember();
      const next={...copy(snapshot),assets:copy(p.assets),revision:p.revision,reviews:{}};
      const available=new Set(next.assets.map(a=>a.id));
      if([...next.clips,...next.audios,...next.protected_lines].some(c=>!available.has(c.asset_id)))throw Error('草稿引用的素材不在当前工程中，请先下载备份，不自动覆盖');
      p=next;adoptedDraftKey=row.key;dirty++;persistDraft();$('#save-status').textContent='已恢复草稿 · 请核对后保存';
      $('#modal').close();render();
    });
  }
  function lockEditing(value) {
    loading=value;
    $('main').inert=value;
    $('#save-button').disabled=value;$('#export-button').disabled=value;
  }
  function refreshMeta() {
    if(!p)return;
    $('#project-meta').textContent=`${p.width} × ${p.height} · ${p.fps} fps · ${time(total())} · ${p.captions.length} 条字幕`;
    $('#duration').textContent=time(total()).slice(0,5);$('#seek').max=total()||1;
    $('#footer-left').textContent=`${p.clips.length} 个画面片段 · ${p.audios.length} 条附加音频 · 修订 ${p.revision}`;
  }
  mark=function(sound=false,metadataOnly=false){
    original.mark(sound);if(!metadataOnly)p.reviews={};persistDraft();refreshMeta();
    if(!metadataOnly&&previewJob?.result?.captions_burned)$('#preview-label').textContent='旧版烧录结果 · 修改后需重新导出';
    if(sound){$('#preview-note').textContent='当前声音/镜头已改变，旧字幕同步依据失效。请重生成最终混音并逐条复核。'}
  };
  save=async function(){
    clearTimeout(timer);
    if(operation){await operation;return save()}
    if(saving){await saving;if(dirty>saved)return save();return}
    if(!p||dirty<=saved)return;
    if(saveBlocked)throw Error('请先处理本机版本冲突；你的修改已保留在草稿中');
    persistDraft();
    const pid=p.id;
    // Hold the lock through acknowledgement, including a single safe reconciliation.
    saving=(async()=>{
      let count=dirty,body=copy(p),result;
      try{
        try{result=await api('/api/projects/'+pid,body)}
        catch(error){
          if(!/另一窗口|版本|工程已/.test(error.message))throw error;
          const remote=await api('/api/projects/'+pid);
          if(p?.id!==pid)throw error;
          const merged=StudioSafety.reconcile(acknowledged,p,remote);
          if(merged.conflicts.length)throw error;
          // Never bypass the backend's revision check; retry against the fetched revision.
          p=merged.project;count=dirty;body=copy(p);
          result=await api('/api/projects/'+pid,body);
        }
        if(p?.id===pid){
          acknowledged=copy(result);p.revision=result.revision;
          // A native save returns a normalized project. Update the live object graph
          // without replacing it so focused controls keep editing the current cue,
          // rather than a detached pre-save object captured by their handlers.
          if(dirty===count&&result.native?.shared)StudioSafety.updateInPlace(p,result);
          if(dirty===count)p.reviews=result.reviews;
          saved=count;
          if(dirty<=saved){removeOwnDraft(pid);if(adoptedDraftKey){try{localStorage.removeItem(adoptedDraftKey)}catch(_){}adoptedDraftKey=null}}else persistDraft();
          $('#save-status').textContent=dirty>saved?'仍有修改 · 正在保存':'已保存到本机';refreshMeta();
          const summary=boot.projects?.find(row=>row.id===pid);
          if(summary)Object.assign(summary,{name:p.name,series:p.series,clips:p.clips.length,captions:p.captions.length});
          renderProjects();
        }
      }catch(error){
        persistDraft();$('#save-status').textContent='尚未保存 · 本机草稿已保留';
        if(/另一窗口|版本|工程已/.test(error.message)&&!saveBlocked){saveBlocked=true;conflictDialog(error.message)}
        throw error;
      }
    })();
    try{await saving}finally{saving=null}
    if(dirty>saved)return save();
  };
  openProject=async function(pid,options={}){
    const ticket=gate.begin();lockEditing(true);
    try{
      if(!options.skipSave){try{await save()}catch(e){if(!persistDraft())throw e;toast('未保存修改已保留在本地草稿；可稍后回本集恢复。',true)}}
      if(!gate.current(ticket))return;
      const next=await api('/api/projects/'+pid);
      if(!gate.current(ticket))return;
      if(next.archived)throw Error('这个工程已在回收站，请先恢复后再打开');
      p=next;acknowledged=copy(next);saveBlocked=false;conflictNotice.hidden=true;dirty=saved=0;selected=p.captions[0]?.id;undo=[];textSession=null;adoptedDraftKey=null;
      previewJob=null;peaks=null;qa=null;
      $('#video').pause();$('#video').removeAttribute('src');$('#video').load();
      $('#caption-overlay').style.display='block';$('#caption-overlay').textContent='';
      $('#stage-placeholder').style.display='flex';$('#preview-label').textContent='尚未生成';
      $('#project-name').value=p.name;$('#save-status').textContent='已保存到本机';
      await refreshQA();if(!gate.current(ticket))return;
      renderProjects();render();drawWave();offerDraft(findDraft(pid));
    }finally{if(gate.current(ticket))lockEditing(false)}
  };
  refreshQA=async function(){
    if(!p)return;const pid=p.id,result=await api(`/api/projects/${pid}/quality`);
    if(p?.id===pid){qa=result;$('#qa-count').textContent=qa.issues.length}
  };
  async function mutate(action,body={},rememberBefore=true){
    await save();
    if(operation){await operation;return mutate(action,body,rememberBefore)}
    if(!p)throw Error('请先打开工程');
    const base=copy(p),pid=p.id,count=dirty;
    if(rememberBefore)remember();
    const pending=api(`/api/projects/${pid}/${action}`,{...body,revision:p.revision});
    operation=pending;
    try{
      const result=await pending;
      if(p?.id!==pid)throw Error('工程已经切换，处理结果已保存在原工程，没有覆盖当前工程');
      const merged=StudioSafety.mergeResult(base,p,result);p=merged.project;acknowledged=copy(result);
      if(dirty!==count||merged.preserved.length){
        if(dirty<=saved)dirty++;persistDraft();
        toast('处理期间的新输入已保留；同时修改的字段以你的新输入为准。');
      }else{removeOwnDraft(pid);$('#save-status').textContent='已保存到本机'}
      render();return result;
    }catch(e){persistDraft();throw e}
    finally{if(operation===pending)operation=null;if(dirty>saved)timer=setTimeout(()=>save().catch(e=>toast(e.message,true)),600)}
  }
  function startTextSession(cueId){
    const key=`${p?.id}:${cueId}`;
    if(textSession!==key){remember();textSession=key}
  }
  renderCaptions=function(){
    if(p)p.captions.sort((a,b)=>a.start-b.start);
    original.renderCaptions();
    $('#wrap-all').onclick=handle(async()=>{await mutate('wrap');toast('已断行；可撤销，字号保持不变')});
  };
  renderInspector=function(){
    original.renderInspector();if(!p)return;
    const cue=currentCue();
    const st=StudioSafety.effectiveStyle(p,cue,tab);
    const extra=document.createElement('div');extra.className='extra-style-controls';
    extra.innerHTML=`<div class="row"><div><label>阴影角度 °</label><input data-extra-style="shadow_angle" type="number" min="-180" max="180" step="1" value="${st.shadow_angle??45}"></div><div><label>阴影模糊 / 1080画布像素</label><input data-extra-style="shadow_blur" type="number" min="0" max="30" step=".5" value="${st.shadow_blur??0}"></div></div><label>额外行间距 / 1080画布像素</label><input data-extra-style="line_spacing" type="number" min="0" max="100" step="1" value="${st.line_spacing??0}"><div class="row"><div><label>整体不透明度 0–1</label><input data-extra-style="opacity" type="number" min="0" max="1" step=".05" value="${st.opacity??1}"></div><div><label>描边不透明度 0–1</label><input data-extra-style="outline_opacity" type="number" min="0" max="1" step=".05" value="${st.outline_opacity??1}"></div></div>`;
    $('#inspector').append(extra);
    extra.querySelectorAll('[data-extra-style]').forEach(el=>el.onchange=()=>{remember();const target=tab==='captions'&&cue&&Object.keys(cue.style||{}).length?cue.style:p.style;target[el.dataset.extraStyle]=Number(el.value);mark();updateOverlay()});
    $('#export-srt').onclick=()=>download(new Blob(['\ufeff'+StudioSafety.srt(p.captions)],{type:'text/plain;charset=utf-8'}),p.name+'.srt');
    if(cue&&tab==='captions'){
      const textInput=$('#cue-text'),oldText=textInput.oninput;
      textInput.onfocus=()=>{textSession=null};textInput.onblur=()=>{textSession=null};
      textInput.oninput=e=>{startTextSession(cue.id);delete cue.speech;oldText(e);persistDraft()};
      for(const key of ['cue-start','cue-end','in-now','out-now']){
        const el=$('#'+key),event=key.includes('now')?'onclick':'onchange',old=el[event];
        el[event]=e=>{delete cue.speech;old(e);persistDraft()};
      }
      const section=document.createElement('div');section.className='speech-confirm';
      section.innerHTML='<hr class="section-break"><h3>按实际声音确认本句</h3><p class="helper">先播放当前最终混音，再填写真实发声范围。这里不把字幕时间当成声音检测结果。</p><div class="row"><div><label>实际发声起点 / 秒</label><input id="voice-start" type="number" min="0" step=".001" placeholder="请试听后填写"></div><div><label>实际发声终点 / 秒</label><input id="voice-end" type="number" min="0" step=".001" placeholder="请试听后填写"></div></div><div class="toolbar"><button id="voice-in-now">发声起点=播放头</button><button id="voice-out-now">发声终点=播放头</button></div><label><input id="voice-listened" type="checkbox"> 我已实际试听当前版本并核对本句</label><button id="confirm-cue" class="wide accent">确认这条字幕的声音依据</button><p id="voice-evidence" class="helper"></p>';
      $('#inspector').append(section);
      $('#voice-evidence').textContent=cue.speech?.method==='manual_verified'?'存在人工时间依据；修改声音或本句文字/时间后需重新确认。':'尚未人工确认；ASR只是识别草稿。';
      $('#voice-in-now').onclick=()=>{$('#voice-start').value=playbackTime().toFixed(3)};
      $('#voice-out-now').onclick=()=>{$('#voice-end').value=playbackTime().toFixed(3)};
      $('#confirm-cue').onclick=handle(async()=>{
        const range=StudioSafety.voiceRange($('#voice-start').value,$('#voice-end').value);
        if(!$('#voice-listened').checked)throw Error('请先实际试听并勾选本句确认');
        if(!previewJob?.id)throw Error('请先生成并打开当前最终混音预览');
        const renderId=previewJob.id,cueId=cue.id,pid=p.id,signature=JSON.stringify(cue);
        await save();await refreshQA();
        const detail=await api('/api/jobs/'+renderId);
        if(p?.id!==pid||detail.project_id!==pid||detail.state!=='complete'||!detail.result?.file||detail.result.sound_digest!==qa?.sound_hash)throw Error('当前播放器不是这一版最终混音，请重新生成并试听');
        if(JSON.stringify(p.captions.find(c=>c.id===cueId))!==signature)throw Error('确认期间本句已经改变，请重新试听核对后确认');
        await mutate('confirm-cue',{cue_id:cueId,render_id:renderId,...range,confirmed:true});
        await refreshQA();toast('已保存这句的人工发声依据；不代表全片自动验收');
      });
    }
  };
  function streamControl(assetId,value,onChange){
    const source=asset(assetId),streams=source?.audio_streams||[];
    if(streams.length<2)return null;
    const wrap=document.createElement('div');wrap.className='audio-stream-select';
    const choice=Number.isInteger(value)?String(value):'';
    wrap.innerHTML=`<label>音轨选择（多音轨素材必须明确选择）</label><select><option value="">请选择，不自动猜测</option>${streams.map(s=>`<option value="${s.index}" ${choice===String(s.index)?'selected':''}>音轨 ${s.index} · ${esc(s.language||'未知语言')} ${esc(s.title||'')} · ${s.channels||'?'}声道</option>`).join('')}</select>`;
    wrap.querySelector('select').onchange=e=>onChange(e.target.value===''?null:Number(e.target.value));return wrap;
  }
  renderClips=function(){original.renderClips();if(!p)return;
    p.clips.forEach(c=>{const anchor=$(`[data-remove-clip="${c.id}"]`)?.closest('.card');
      const control=c.audio_detached?null:streamControl(c.asset_id,c.audio_stream,value=>{remember();if(value===null)delete c.audio_stream;else c.audio_stream=value;mark(true)});
      if(anchor&&control)anchor.append(control);
      if(anchor){
        const relation=studioAudioRelation(p,{kind:'video',id:c.id});
        const gain=anchor.querySelector('[data-key="gain"]');
        if(c.audio_detached){if(gain)gain.disabled=true;const note=document.createElement('p');note.className='helper';note.textContent=relation.detail+' 请在对应声音轨调整音量。';anchor.append(note)}
        const button=document.createElement('button');button.textContent=c.audio_detached?(relation.state==='linked'?'已分轨 · 仍联动':'画面已独立'):'分离音频';button.dataset.detachClip=c.id;button.disabled=!!c.audio_detached||!asset(c.asset_id)?.has_audio;
        button.onclick=handle(()=>window.studioDetachAudio(c.id));anchor.querySelector('.card-actions').append(button);
      }

    });
    $$('[data-clip]').forEach(input=>{const old=input.onchange;input.onchange=e=>{old(e);const clip=p.clips.find(c=>c.id===input.dataset.clip),small=input.closest('.card')?.querySelector('small');if(small&&clip)small.textContent=`${(clip.out-clip.in).toFixed(2)}s · ${asset(clip.asset_id)?.fps.toFixed(2)} fps`;refreshMeta()}});
    const refresh=document.createElement('button');refresh.textContent='素材已替换？更新登记';refresh.className='wide ghost';
    $('#panel').append(refresh);
    const relink=document.createElement('button');relink.id='panel-relink-media';relink.textContent='素材丢失 / 换路径？重连素材';relink.className='wide ghost';
    relink.onclick=handle(()=>window.studioMediaRelink.open());$('#panel').append(relink);
    refresh.onclick=()=>{
      modal(`<h2>更新已替换的源文件</h2><p>仅选择你已在磁盘上替换的文件。会更新素材校验值并使旧混音/字幕依据失效；不自动缩短时间线。新时长不足时会拒绝，保留原工程。</p><div class="asset-refresh-list">${p.assets.map(a=>`<label class="review-line"><input type="checkbox" data-refresh-asset="${a.id}">${esc(a.name)}<small>${esc(a.path)}</small></label>`).join('')}</div><div class="modal-actions"><button id="refresh-assets-ok" class="primary">重新读取选中的文件</button></div>`);
      $('#refresh-assets-ok').onclick=handle(async()=>{const asset_ids=$$('[data-refresh-asset]:checked').map(b=>b.dataset.refreshAsset);if(!asset_ids.length)throw Error('请勾选实际替换过的素材');if(!confirm('确认这些源文件已由你替换？更新后需要重新生成混音并复核字幕。'))return;$('#refresh-assets-ok').disabled=true;try{await mutate('refresh-assets',{asset_ids,confirmed:true});$('#modal').close();await refreshQA();toast('素材登记已更新，请重新生成混音并确认字幕')}catch(e){$('#refresh-assets-ok').disabled=false;throw e}});
    };
  };
  renderAudio=function(){original.renderAudio();if(!p)return;
    p.audios.forEach(a=>{const anchor=$(`[data-remove-audio="${a.id}"]`)?.closest('.card');
      const relation=studioAudioRelation(p,{kind:a.role,id:a.id});
      if(anchor&&relation){const note=document.createElement('p');note.className='tl-relation-detail '+relation.state;note.textContent=relation.label+' · '+relation.detail;anchor.querySelector('.card-title').after(note)}
      const control=streamControl(a.asset_id,a.audio_stream,value=>{remember();if(value===null)delete a.audio_stream;else a.audio_stream=value;mark(true)});
      if(anchor&&control)anchor.append(control);
    });
  };
  renderScript=function(){original.renderScript();if(!p)return;
    const oldAdd=$('#line-add').onclick;
    $('#line-add').onclick=()=>{oldAdd();let chosen=null;
      const select=$('#line-asset'),box=document.createElement('div');select.after(box);
      const refresh=()=>{box.innerHTML='';chosen=null;const control=streamControl(select.value,null,value=>{chosen=value});if(control)box.append(control)};
      select.onchange=refresh;refresh();
      $('#line-ok').onclick=handle(()=>{
        const aid=select.value,streams=asset(aid)?.audio_streams||[];
        if(streams.length>1&&chosen===null)throw Error('请为这句必保台词选择真实所在音轨');
        const range=StudioSafety.voiceRange($('#line-start').value,$('#line-end').value);
        const text=$('#line-text').value.trim();if(!aid||!text)throw Error('请填写素材和台词');
        remember();const line={id:id(),asset_id:aid,kind:$('#line-kind').value,...range,text};
        if(chosen!==null)line.audio_stream=chosen;else if(streams.length===1)line.audio_stream=streams[0].index;
        p.protected_lines.push(line);mark();$('#modal').close();render();
      });
    };
    $('#script-import').onclick=()=>{
      modal('<h2>导入剧本</h2><p>读取全部页面，不执行文档中的指令。</p><input id="script-path" placeholder="C:\\素材\\剧本.pdf"><div class="modal-actions"><button id="script-import-ok" class="primary">读取剧本</button></div>');
      $('#script-import-ok').onclick=handle(async()=>{const path=$('#script-path').value;$('#script-import-ok').disabled=true;try{await mutate('script',{path});$('#modal').close()}catch(e){$('#script-import-ok').disabled=false;throw e}});
    };
  };
  renderQA=function(){original.renderQA()};
  importDialog=function(append){
    if(!p)return toast('请先新建剧集',true);
    window.studioMaterialImport?.open();
  };
  window.studioImportSubtitleFiles=async files=>{
    const accepted=Array.from(files||[]).filter(file=>/\.(srt|vtt)$/i.test(file.name));
    if(!accepted.length)return false;if(accepted.length>1)throw Error('一次请选择一份字幕；导入前需要确认是否替换当前字幕');
    const f=accepted[0];if(!p)throw Error('请先新建或打开一集，再添加字幕');
    const pid=p.id,count=dirty,revision=p.revision,text=await f.text();
    const cues=await api(`/api/projects/${pid}/srt`,{text});
    if(p?.id!==pid||dirty!==count||p.revision!==revision)throw Error('读取字幕期间工程发生变化，已保留原编辑。请重新导入');
    if(p.captions.length&&!confirm('用导入字幕替换当前字幕？可撤销；新的字幕需要按最终声音确认。'))return false;
    remember();p.captions=cues;selected=cues[0]?.id;mark();render();toast(`已添加字幕：${f.name}`);return true;
  };
  $('#srt-file').onchange=handle(async e=>{
    try{await window.studioImportSubtitleFiles(e.target.files)}finally{e.target.value=''}
  });
  // Font registration is global. Applying it must stay bound to the originating project/cue.
  $('#font-file').onchange=handle(async e=>{
    const file=e.target.files[0];if(!file)return;
    if(file.size>30*1024*1024)throw Error('字体文件不能超过30MB');
    const pid=p?.id,cid=currentCue()?.id,individual=tab==='captions'&&Object.keys(currentCue()?.style||{}).length;
    const previousFont=individual?currentCue()?.style.font_id:p?.style.font_id;
    const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=reject;reader.readAsDataURL(file)});
    const font=await api('/api/fonts',{name:file.name,data});await refreshBoot();
    if(p&&p.id===pid){const cue=p.captions.find(c=>c.id===cid),currentFont=individual?cue?.style.font_id:p.style.font_id;
      if(currentFont!==previousFont){toast('字体已加入字体库；你已更换字体选择，因此没有覆盖当前样式。');e.target.value='';return}
      remember();if(individual&&cue)cue.style.font_id=font.id;else p.style.font_id=font.id;mark();renderInspector();updateOverlay()}
    toast('字体已加入字体库'+(p?.id!==pid?'；工程已切换，没有更改当前字幕':'：'+font.name));e.target.value='';
  });
  viewRender=async function(job){
    const origin=p?.id;
    const detail=await api('/api/jobs/'+job.id);
    if(p?.id!==origin)return;
    if(detail.state!=='complete'||!detail.result?.file)throw Error('渲染尚未完成');
    await original.viewRender(detail);
  };
  pollJobs=async function(){
    try{await original.pollJobs();showHealth({connection_error:null})}
    catch(e){showHealth({connection_error:e.message});throw e}
    const cards=$$('#jobs .job');
    jobs.slice(0,30).forEach((job,index)=>{
      if(!cards[index]||!['failed','cancelled','interrupted'].includes(job.state))return;
      const retry=document.createElement('button');retry.textContent='重试原版本';retry.title='重试这次任务的原始快照；如需使用当前编辑，请重新提交';
      retry.onclick=handle(async()=>{retry.disabled=true;try{await api(`/api/jobs/${job.id}/retry`,{});toast('已用原始版本重新排队；没有替换为当前编辑');await pollJobs()}catch(e){retry.disabled=false;throw e}});cards[index].append(retry);
    });
    if(Date.now()-lastHealthAt>=20000){lastHealthAt=Date.now();try{const health=await api('/api/health');showHealth({...health,connection_error:null});if(Number.isFinite(health.jobs?.pending))$('#job-count').textContent=health.jobs.pending}catch(e){showHealth({connection_error:e.message})}}
  };
  updateOverlay=function(frameTime){original.updateOverlay(frameTime)};
  function tick(now,metadata){
    if($('#video').paused||$('#video').ended){frameHandle=null;return}
    const displayedTime=Number.isFinite(metadata?.mediaTime)?metadata.mediaTime:$('#video').currentTime;
    updateOverlay(displayedTime);$('#timecode').textContent=time(displayedTime);$('#seek').value=displayedTime;
    if(typeof $('#video').requestVideoFrameCallback==='function'){frameKind='video';frameHandle=$('#video').requestVideoFrameCallback(tick)}
    else{frameKind='animation';frameHandle=requestAnimationFrame(tick)}
  }
  function stopTick(){if(frameHandle!==null){if(frameKind==='video')$('#video').cancelVideoFrameCallback(frameHandle);else cancelAnimationFrame(frameHandle)}frameHandle=null;updateOverlay()}
  $('#video').addEventListener('play',()=>{stopTick();tick()});$('#video').addEventListener('pause',stopTick);$('#video').addEventListener('ended',stopTick);$('#video').addEventListener('seeked',()=>updateOverlay());
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')persistDraft()});
  window.addEventListener('pagehide',persistDraft);
  // Make per-cue buttons work with the compact job summaries returned by the server.
  window.studioApplyASR=async function(jobId){
    const j=await api('/api/jobs/'+jobId);
    if(!p||p.id!==j.project_id)throw Error('请先打开对应剧集');
    await save();await refreshQA();
    if(j.result?.sound_digest!==qa.sound_hash)throw Error('声音或镜头已变化，请按当前混音重新识别');
    if(!j.result?.captions?.length)throw Error('未识别到有效字幕；不覆盖现有字幕');
    if(!confirm('用识别草稿替换现有字幕？识别不是翻译，也不能代替实际试听逐条确认。'))return;
    remember();p.captions=copy(j.result.captions);selected=p.captions[0]?.id;mark();render();
  };
  window.studioDetachAudio=async clipId=>{
    if(!p)throw Error('请先打开工程');
    if(window.StudioTimelineUI?.canDetach&&!StudioTimelineUI.canDetach())throw Error('画面或联动原声轨已锁定，请先解锁');
    const pid=p.id,known=new Set(p.audios.map(a=>a.id)),sidebar=document.querySelector('.sidebar'),wasInert=sidebar.inert;
    // Detach atomically changes both the clip and independent audio list.
    lockEditing(true);sidebar.inert=true;
    try{
      await mutate('detach-audio',{clip_id:clipId});
      if(p?.id!==pid)return;
      const audio=p.audios.find(a=>a.role==='dialogue'&&a.detached_from===clipId&&!known.has(a.id));
      if(audio){window.StudioTimelineUI?.select('dialogue',audio.id,false);document.querySelector(`[data-tl-kind="dialogue"][data-tl-id="${audio.id}"]`)?.scrollIntoView({block:'nearest',inline:'nearest'})}
      await refreshQA();toast('原声已分离，可独立移动、裁剪和调音量；画面不会重复播放原声，可撤销恢复');
    }finally{sidebar.inert=wasInert;lockEditing(false)}
  };
  // Exposed only as read-only testable helpers; no local file/network operation here.
  window.studioDraftBackup=()=>exportDraft();
  window.studioProjectHooks={
    adopt(project){
      p=project;acknowledged=copy(project);saveBlocked=false;conflictNotice.hidden=true;dirty=saved=0;
      const summary=boot.projects?.find(row=>row.id===project.id);if(summary)Object.assign(summary,{name:project.name,series:project.series,clips:project.clips.length,audios:project.audios.length,captions:project.captions.length});
      removeOwnDraft(project.id);$('#save-status').textContent='已保存到本机';refreshMeta();
    },
    mutate,
    persistDraft,
    async transaction(work,options={}){
      if(!options.skipSave)await save();else if(saving)await saving;
      if(operation){await operation;return this.transaction(work,options)}
      // Reserve the mutation slot before invoking asynchronous work.
      const pending=Promise.resolve().then(work);operation=pending;
      try{return await pending}finally{if(operation===pending)operation=null}
    },
    detach(pid){
      if(p?.id!==pid)return;
      persistDraft();gate.begin();clearTimeout(timer);lockEditing(false);
      p=null;acknowledged=null;saveBlocked=false;conflictNotice.hidden=true;dirty=saved=0;selected=null;undo=[];previewJob=null;waitingPreview=null;peaks=null;qa=null;adoptedDraftKey=null;textSession=null;
      $('#video').pause();$('#video').removeAttribute('src');$('#video').load();
      $('#stage-placeholder').style.display='flex';$('#caption-overlay').textContent='';$('#caption-overlay').style.display='block';
      $('#preview-label').textContent='尚未生成';$('#project-name').value='';$('#project-meta').textContent='创建或打开一个剧本 / 剧集';
      $('#timecode').textContent='00:00.000';$('#duration').textContent='00:00';$('#seek').value=0;$('#seek').max=1;$('#qa-count').textContent='';
      $('#inspector').innerHTML='<p class="helper">请先新建或打开剧本 / 剧集。</p>';$('#save-status').textContent='工程已移至回收站';$('#footer-left').textContent='原素材未删除，可从回收站恢复';
      renderProjects();render();drawWave();
    }
  };
}

;
// Source: project-management.js
'use strict';

const StudioProjects={
  filter(rows,series=null,query=''){
    const needle=query.trim().toLocaleLowerCase();
    return rows.filter(row=>(series===null||(row.series||'')===series)&&(!needle||`${row.series||''} ${row.name}`.toLocaleLowerCase().includes(needle)));
  },
  selection(preview,names){
    const allowed=new Set((preview.folders||[]).map(row=>row.name));
    if(!names.length)throw Error('请逐项勾选需要导入的剧集文件夹');
    if(new Set(names).size!==names.length||names.some(name=>!allowed.has(name)))throw Error('所选文件夹不在刚才的预览中，请重新扫描');
    return [...names];
  },
  confirmation(rows,restore=false){
    if(!rows.length)throw Error('请先勾选具体工程');
    return `${restore?'恢复':'移入回收站'}以下 ${rows.length} 个工程？\n\n${rows.map(row=>`• ${row.series?row.series+' / ':''}${row.name}`).join('\n')}\n\n${restore?'恢复后重新出现在工程列表。':'只移动软件内的工程记录，原视频、源剧本PDF、音乐和已导出视频都不删除。可以恢复。'}`;
  },
  clearScript(project){
    const next=JSON.parse(JSON.stringify(project));
    next.script={text:'',source:'',start_anchor:'',end_anchor:'',complete:false};next.reviews={};return next;
  },
  summary(row){
    return `剧本 ${Number(row.script_chars)||0} 字 · ${Number(row.clips)||0} 镜头 · ${Number(row.audios)||0} 条附加音频 · ${Number(row.captions)||0} 条字幕 · ${Number(row.protected_lines)||0} 条必保台词`;
  }
};
if(typeof module!=='undefined'&&module.exports)module.exports=StudioProjects;

function installProjectManagement(){
  const hooks=window.studioProjectHooks;
  const original={render,renderScript,modal,refreshBoot};
  let seriesFilter=null,projectSearch='',modalVersion=0,managerMode='active',managerBusy=false,scriptTransaction=null;
  let confirmationResolve=null;
  function finishConfirmation(accepted){
    const resolve=confirmationResolve;confirmationResolve=null;
    if($('#project-confirm').open)$('#project-confirm').close();
    if(resolve)resolve(accepted);
  }
  function confirmProjectAction(message,label='确认执行'){
    if(confirmationResolve)throw Error('请先完成当前确认');
    $('#project-confirm-message').textContent=message;
    $('#project-confirm-ok').textContent=label;
    return new Promise(resolve=>{confirmationResolve=resolve;$('#project-confirm').showModal()});
  }
  window.studioProjectConfirm=confirmProjectAction;
  $('#project-confirm-ok').onclick=()=>finishConfirmation(true);
  $('#project-confirm-cancel').onclick=()=>finishConfirmation(false);
  $('#project-confirm').addEventListener('cancel',event=>{event.preventDefault();finishConfirmation(false)});
  $('#project-confirm').addEventListener('close',()=>{if(confirmationResolve&&!$('#project-confirm').open)finishConfirmation(false)});
  modal=function(html){modalVersion++;return original.modal(html)};
  const liveDialog=version=>version===modalVersion&&$('#modal').open;
  $('#modal').addEventListener('cancel',event=>{if(managerBusy)event.preventDefault()});
  function setDialogBusy(value){managerBusy=value;$('#close-modal').disabled=value}
  function updateFilters(){
    const names=[...new Set((boot.projects||[]).map(row=>row.series||''))].sort((a,b)=>a.localeCompare(b,'zh'));
    if(seriesFilter!==null&&!names.includes(seriesFilter))seriesFilter=null;
    $('#series-filter').innerHTML='<option value="all">全部剧名</option>'+names.map(name=>`<option value="s:${esc(encodeURIComponent(name))}">${esc(name||'未分组')}</option>`).join('');
    $('#series-filter').value=seriesFilter===null?'all':'s:'+encodeURIComponent(seriesFilter);
    $('#project-search').value=projectSearch;
  }
  renderProjects=function(){
    updateFilters();
    const rows=StudioProjects.filter(boot.projects||[],seriesFilter,projectSearch);
    $('#projects').innerHTML=rows.map(row=>`<button class="project-row ${row.id===p?.id?'active':''}" data-project="${row.id}"><div>${esc(row.name)}</div><small>${esc(row.series||'未分组')} · 剧本 ${Number(row.script_chars)||0} 字</small><small>${row.clips} 个镜头 · ${row.captions} 条字幕</small></button>`).join('')||'<p class="helper project-empty">没有符合条件的工程。可以清空筛选，或点击上方“新建剧本 / 剧集”。</p>';
    $$('[data-project]').forEach(button=>button.onclick=handle(()=>openProject(button.dataset.project)));
    $('#project-list-count').textContent=`${rows.length} / ${(boot.projects||[]).length}`;
  };
  $('#project-search').oninput=()=>{projectSearch=$('#project-search').value;renderProjects()};
  $('#series-filter').onchange=()=>{const value=$('#series-filter').value;seriesFilter=value==='all'?null:decodeURIComponent(value.slice(2));renderProjects()};
  refreshBoot=async function(){await original.refreshBoot();renderProjects()};
  render=function(){
    if(p&&typeof p.series!=='string')p.series='';
    original.render();
    $('#project-series').value=p?.series||'';$('#project-series').disabled=!p;
    $('#project-name').disabled=!p;
    if(!p){$('#project-meta').textContent='每个剧本 / 剧集都是独立工程，文字、素材与字幕互不覆盖';$('#project-series').value=''}
  };
  $('#project-series').onchange=()=>{
    if(!p)return;const value=$('#project-series').value.trim();if(value===(p.series||''))return;
    if(value.length>150)return toast('剧名不能超过150个字符',true);
    if(typeof p.series!=='string')p.series='';remember();p.series=value;mark(false,true);
    const row=boot.projects?.find(row=>row.id===p.id);if(row)row.series=value;renderProjects();
  };
  $('#project-name').onchange=()=>{
    if(!p)return;const value=$('#project-name').value.trim();if(!value)return toast('请填写集名 / 剧本名称',true);
    if(value===p.name)return;remember();p.name=value;mark();const row=boot.projects?.find(row=>row.id===p.id);if(row)row.name=value;renderProjects();
  };
  newProject=function(){
    modal(`<h2>新建分集</h2><p>每一集的剧本文字、素材、字幕和时间线独立。也可以先建空分集写剧本，不必立即导入视频。</p><label>剧名（可不填）</label><input id="create-series" maxlength="150" value="${esc(seriesFilter??p?.series??'')}" placeholder="例如：黑帮心声"><label>分集名 / 导出名</label><input id="create-name" maxlength="150" value="EP01" placeholder="例如：EP01"><label>从哪里开始</label><select id="create-mode"><option value="script">先编写 / 导入剧本</option><option value="clips">先导入视频素材</option></select><div class="modal-actions"><button id="create-project-ok" class="primary">创建分集</button></div>`);
    const version=modalVersion,origin=p?.id;
    $('#create-project-ok').onclick=handle(async()=>{
      const name=$('#create-name').value.trim(),series=$('#create-series').value.trim(),mode=$('#create-mode').value;
      if(!name)throw Error('请填写集名 / 剧本名称');if(name.length>150||series.length>150)throw Error('名称最多150个字符');
      const button=$('#create-project-ok');button.disabled=true;
      try{
        const created=await hooks.transaction(()=>api('/api/projects',{name,series}));
        await refreshBoot();
        if(liveDialog(version)&&p?.id===origin){$('#modal').close();seriesFilter=series;projectSearch='';await openProject(created.id);tab=mode;render();renderProjects()}
        else toast(`已建立“${name}”，请在左侧选择；没有切换你正在编辑的工程。`);
      }finally{button.disabled=false}
    });
  };
  $('#new-button').onclick=handle(newProject);$('#global-new-button').onclick=handle(newProject);

  async function manager(mode='active'){
    await save();managerMode=mode;
    const origin=p?.id;
    if(mode==='active')await refreshBoot();
    const rows=mode==='trash'?await api('/api/trash'):(boot.projects||[]);
    if(p?.id!==origin)return;
    modal(`<h2>管理工程 / 回收站</h2><div class="toolbar"><button id="manager-active" class="${mode==='active'?'accent':''}">当前工程</button><button id="manager-trash" class="${mode==='trash'?'accent':''}">回收站</button></div><p>${mode==='trash'?'勾选需要恢复的工程。恢复不会覆盖其他工程。':'导入错了可以逐项勾选并移入回收站。这里只管理工程记录，不会删除原视频、源剧本、音乐或导出文件。'}</p><input id="manager-search" placeholder="搜索剧名 / 集名"><div id="manager-list" class="manager-list"></div><div class="manager-count" id="manager-count">已选择 0 项</div><div class="modal-actions"><button id="manager-action" class="${mode==='trash'?'primary':'danger'}" disabled>${mode==='trash'?'恢复所选工程':'将所选工程移入回收站'}</button></div>`);
    const version=modalVersion,selectedIds=new Set();
    function drawManager(){
      const visible=StudioProjects.filter(rows,null,$('#manager-search').value);
      $('#manager-list').innerHTML=visible.map(row=>`<label class="manager-row"><input type="checkbox" data-manage-project="${row.id}" ${selectedIds.has(row.id)?'checked':''}><span><b>${esc(row.name)}</b><small>${esc(row.series||'未分组')}${p?.id===row.id?' · 当前打开':''}</small><small>${esc(StudioProjects.summary(row))}</small></span></label>`).join('')||'<p class="helper">没有工程。</p>';
      $$('[data-manage-project]').forEach(box=>box.onchange=()=>{if(box.checked)selectedIds.add(box.dataset.manageProject);else selectedIds.delete(box.dataset.manageProject);updateManagerCount()});
      updateManagerCount();
    }
    function updateManagerCount(){$('#manager-count').textContent=`已选择 ${selectedIds.size} 项（含筛选前已勾选项）`;$('#manager-action').disabled=!selectedIds.size}
    $('#manager-search').oninput=drawManager;drawManager();
    $('#manager-active').onclick=handle(()=>manager('active'));$('#manager-trash').onclick=handle(()=>manager('trash'));
    $('#manager-action').onclick=handle(async()=>{
      const selected=rows.filter(row=>selectedIds.has(row.id));
      if(!selected.length)throw Error('请先逐项勾选工程');
      if(!await confirmProjectAction(StudioProjects.confirmation(selected,mode==='trash'),mode==='trash'?'确认恢复所选工程':'确认移入回收站'))return;
      $('#manager-action').disabled=true;setDialogBusy(true);
      const succeeded=[],failed=[];
      try{
        await hooks.transaction(async()=>{
          for(const row of selected){
            try{await api(`/api/projects/${row.id}/${mode==='trash'?'unarchive':'archive'}`,{revision:row.revision,confirmed:true});succeeded.push(row);if(mode!=='trash')hooks.detach(row.id)}
            catch(error){failed.push({name:row.name,message:error.message})}
          }
        });
      }finally{setDialogBusy(false)}
      await refreshBoot();
      if(liveDialog(version)){
        await manager(mode);
        const result=document.createElement('div');result.className='alert '+(failed.length?'':'success');
        result.textContent=`${mode==='trash'?'已恢复':'已移入回收站'} ${succeeded.length} 项。${failed.length?'未处理：'+failed.map(item=>item.name+'（'+item.message+'）').join('；'):'原素材没有删除。'}`;
        $('#modal-body').prepend(result);
      }
    });
  }
  $('#manage-button').onclick=handle(()=>manager('active'));$('#global-manage-button').onclick=handle(()=>manager('active'));
  $('#batch-button').onclick=()=>{
    modal('<h2>预览分集文件夹</h2><p>先扫描下一层分集文件夹；不会立即建立工程。只有含视频的文件夹可以勾选，音乐库、缓存等跳过项会列出原因。</p><input id="batch-path" placeholder="F:\\剧名"><div class="modal-actions"><button id="batch-preview" class="primary">扫描并预览</button></div>');
    const version=modalVersion;
    $('#batch-preview').onclick=handle(async()=>{
      const path=$('#batch-path').value.trim(),button=$('#batch-preview');if(!path)throw Error('请填写具体剧名目录');button.disabled=true;
      try{await save();if(!liveDialog(version))return;const preview=await api('/api/batch/preview',{path});if(!liveDialog(version))return;showBatchPreview(preview)}finally{button.disabled=false}
    });
  };
  function showBatchPreview(preview){
    modal(`<h2>确认需要导入的分集</h2><p>目录：${esc(preview.path)}。请逐项勾选；未勾选的目录不会导入。</p><label>这些剧集的剧名 / 分组</label><input id="batch-series" maxlength="150" value="${esc(seriesFilter??p?.series??'')}" placeholder="例如：黑帮心声"><div class="manager-list">${(preview.folders||[]).map(folder=>`<label class="manager-row"><input type="checkbox" data-batch-folder="${esc(folder.name)}"><span><b>${esc(folder.name)}</b><small>${folder.video_count} 个视频 · ${folder.audio_count} 个音频</small></span></label>`).join('')||'<p>没有找到含视频的分集目录。</p>'}</div><details class="batch-skipped"><summary>跳过 ${preview.skipped?.length||0} 个目录</summary>${(preview.skipped||[]).map(row=>`<p><b>${esc(row.name)}</b>：${esc(row.reason)}</p>`).join('')}</details>${(preview.warnings||[]).map(warning=>`<p class="alert">${esc(typeof warning==='string'?warning:JSON.stringify(warning))}</p>`).join('')}<div id="batch-selection-count" class="manager-count">已选择 0 集</div><div class="modal-actions"><button id="batch-confirm" class="primary" disabled>仅导入所选剧集</button></div>`);
    const version=modalVersion;
    $$('[data-batch-folder]').forEach(box=>box.onchange=()=>{const count=$$('[data-batch-folder]:checked').length;$('#batch-selection-count').textContent=`已选择 ${count} 集`;$('#batch-confirm').disabled=!count});
    $('#batch-confirm').onclick=handle(async()=>{
      const selected=StudioProjects.selection(preview,$$('[data-batch-folder]:checked').map(box=>box.dataset.batchFolder)),series=$('#batch-series').value.trim();
      if(series.length>150)throw Error('剧名最多150个字符');
      if(!await confirmProjectAction(`仅为以下 ${selected.length} 个文件夹建立 / 复用工程？\n\n${selected.map(name=>'• '+name).join('\n')}\n\n未勾选目录不导入；源文件不移动、不删除。`,'确认仅导入这些剧集'))return;
      const button=$('#batch-confirm');button.disabled=true;setDialogBusy(true);
      try{
        const results=await hooks.transaction(()=>api('/api/batch',{path:preview.path,selected,series,confirmed:true}));
        await refreshBoot();
        if(!liveDialog(version)){toast('批次处理完成，请在工程管理中查看');return}
        modal(`<h2>本次批量导入结果</h2><p>仅处理了刚才明确勾选的 ${selected.length} 个目录。工程之间独立；原素材未删除。</p><div class="manager-list">${results.map(row=>`<div class="batch-result"><b>${esc(row.name)}</b><p>${esc(row.state||'已建立')}${row.reused?' · 复用已有工程':''}${row.archived?' · 仍在回收站，需手动恢复':''}</p>${row.id&&!row.archived?`<button data-open-import="${row.id}">打开这个工程</button>`:''}</div>`).join('')}</div>`);
        $$('[data-open-import]').forEach(open=>open.onclick=handle(async()=>{$('#modal').close();seriesFilter=series;projectSearch='';await openProject(open.dataset.openImport);tab='clips';render();renderProjects()}));
      }finally{button.disabled=false;setDialogBusy(false)}
    });
  }
  renderScript=function(){
    original.renderScript();if(!p)return;
    scriptTransaction=null;
    const startTransaction=key=>{const identity=`${p.id}:${key}`;if(scriptTransaction!==identity){remember();scriptTransaction=identity}};
    for(const [selector,key] of [['#script-text','text'],['#script-start','start_anchor'],['#script-end','end_anchor']]){
      const field=$(selector);field.onfocus=()=>{scriptTransaction=null};field.onblur=()=>{scriptTransaction=null};field.onchange=null;
      field.oninput=()=>{startTransaction(key);p.script[key]=field.value;p.script.complete=false;$('#script-complete').checked=false;mark()};
    }
    const existingImport=$('#script-import').onclick;
    $('#script-import').textContent=p.script.text||p.script.source?'替换本集剧本':'导入本集剧本';
    $('#script-import').onclick=handle(async()=>{
      const pid=p.id;
      if((p.script.text||p.script.source)&&!await confirmProjectAction(`替换“${p.name}”的剧本文字？\n\n只修改这一集；原PDF/文本文件不删除。现有必保台词、字幕与视频保留，但必须重新核对与新剧本是否一致。可撤销。`,'确认替换本集剧本'))return;
      if(p?.id!==pid)throw Error('当前工程已经变化，请重新选择需要替换剧本的工程');
      existingImport();
    });
    const clear=document.createElement('button');clear.id='clear-script';clear.className='danger wide';clear.textContent='清空本集剧本文字';
    clear.onclick=handle(async()=>{
      if(!p)return;
      const pid=p.id;
      if(!await confirmProjectAction(`清空“${p.name}”当前的剧本文字及章节确认？\n\n源PDF/文本文件不会删除；视频、字幕、必保台词清单全部保留。清空后需重新复核，可点击撤销恢复。`,'确认清空本集剧本文字'))return;
      if(p?.id!==pid)throw Error('当前工程已经变化，请重新选择需要清空剧本的工程');
      remember();p=StudioProjects.clearScript(p);mark();render();toast('本集剧本文字已清空，源文件、字幕与必保台词未删除；可撤销');
    });
    $('#panel').append(clear);
    const note=document.createElement('p');note.className='helper';note.textContent=`正在编辑：${p.series?p.series+' / ':''}${p.name}。本页修改只属于这一工程，不会替换其他剧集。`;$('#panel').prepend(note);
  };
}

;
// Source: script-import.js
'use strict';

const StudioScripts={
  maxBytes:16*1024*1024,
  accepts(name){return /\.(pdf|txt|md|docx)$/i.test(String(name||''))},
  number(name){
    const match=String(name||'').trim().match(/^(?:第\s*([0-9零〇一二三四五六七八九十百千两]+)\s*[集章]|(?:EP(?:ISODE|IS[OÓ]DIO)?\.?|CAP[IÍ]TULO)\s*(\d+)\b|(\d+)$)/i);
    if(!match)return null;const raw=match[1]||match[2]||match[3];if(/^\d+$/.test(raw))return Number(raw);
    const digits={'零':0,'〇':0,'一':1,'二':2,'两':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9};let total=0,n=0;
    if(!/[十百千]/.test(raw)){if([...raw].some(char=>!Object.hasOwn(digits,char)))return null;return Number([...raw].map(char=>digits[char]).join(''))}
    for(const char of raw){if(char==='十'||char==='百'||char==='千'){total+=(n||1)*({'十':10,'百':100,'千':1000}[char]);n=0}else if(Object.hasOwn(digits,char))n=digits[char];else return null}return total+n;
  },
  projects(rows,series){return rows.filter(row=>!row.archived&&(row.series||'')===series)},
  suggested(section,rows,currentId){
    if(section.number===null||section.number===undefined||section.ambiguous)return '';
    const matches=rows.filter(row=>this.number(row.name)===Number(section.number));
    if(currentId&&matches.some(row=>row.id===currentId))return currentId;
    return matches.length===1?matches[0].id:'';
  },
  mapping(sections,choices,rows,series){
    const items=[],used=new Set();
    sections.forEach((section,index)=>{
      const choice=choices[index];if(!choice?.selected)return;
      if(!choice.target)throw Error('请为“'+section.title+'”选择目标工程，未知集数不能自动猜测');
      if(choice.target==='new'){
        const name=String(choice.name||'').trim();if(!name||name.length>150)throw Error('新建集名需为 1–150 个字符');
        items.push({section_id:section.id,create_new:true,name,series});
      }else{
        const row=rows.find(row=>row.id===choice.target&&(row.series||'')===series&&!row.archived);
        if(!row)throw Error('目标工程不在所选剧名中，请重新选择；不会跨剧匹配同集号');
        if(used.has(row.id))throw Error('不能把两个章节同时写到同一个工程，请重新分配');
        used.add(row.id);items.push({section_id:section.id,project_id:row.id,revision:row.revision,replace_confirmed:false});
      }
    });
    if(!items.length)throw Error('请先逐项勾选确实要使用的剧本章节');
    if(series.length>150)throw Error('剧名最多150个字符');return items;
  },
  projectId(row){return row.project_id||row.id},
  resultLabel(row){if(row.archived)return '工程已在回收站，未自动恢复';if(row.unavailable)return '工程暂不可用，请检查工程管理';return row.created||row.state==='created'?'已创建独立工程':row.state==='reused'?'复用本预览已写入的工程，未重复覆盖':'已更新剧本'},
  async filePayload(file){
    if(!this.accepts(file.name))throw Error('仅支持 PDF、TXT、MD、DOCX 剧本文件');
    if(!Number.isSafeInteger(file.size)||file.size<1||file.size>this.maxBytes)throw Error('每份剧本必须非空且不超过 16 MiB');
    const data=new Uint8Array(await file.arrayBuffer());if(data.length!==file.size||data.length>this.maxBytes)throw Error('剧本文件在读取时发生变化，请重新选择');
    let binary='';for(let start=0;start<data.length;start+=32768)binary+=String.fromCharCode(...data.subarray(start,start+32768));
    return {name:file.name,content_base64:btoa(binary)};
  }
};
if(typeof module!=='undefined'&&module.exports)module.exports=StudioScripts;

function installScriptImport(){
  const originalRenderScript=renderScript,confirmAction=window.studioProjectConfirm,hooks=window.studioProjectHooks;
  let flow=null;
  const pendingDiscards=new Set(),discarding=new Map();
  const input=$('#script-file-input'),dialog=$('#modal');
  const live=state=>flow===state;
  const controls=['#global-new-button','#global-manage-button','#new-button','#manage-button','#batch-button','#batch-queue-button','#material-picker-button','#folder-picker-button','#folder-drop-path','#script-picker-button','#import-button','#close-modal'];
  const disabled=new Map();
  function lock(value){controls.forEach(selector=>{const el=$(selector);if(!el)return;if(value){disabled.set(selector,!!el.disabled);el.disabled=true}else el.disabled=disabled.get(selector)||false});if(!value)disabled.clear()}
  function paint(state,html){if(live(state)){modal(html);$('#close-modal').disabled=true}}
  async function discard(id){
    if(!id)return true;if(discarding.has(id))return discarding.get(id);
    const work=(async()=>{try{await api(`/api/script-import/${encodeURIComponent(id)}/discard`,{});pendingDiscards.delete(id);return true}catch(error){pendingDiscards.add(id);toast('未能释放这份剧本的预览内存；没有删除文件或工程。下次读取时会重试，也可等待预览30分钟过期：'+error.message,true);return false}})();
    discarding.set(id,work);try{return await work}finally{discarding.delete(id)}
  }
  async function releasePreview(state){const id=state.preview?.id;state.preview=null;return discard(id)}
  async function retryDiscards(){for(const id of [...pendingDiscards])await discard(id)}
  function close(state=flow){if(!live(state))return;flow=null;state.closed=true;lock(false);input.value='';dialog.close();void releasePreview(state)}
  function canBegin(){
    if(flow||window.studioFolderDrop?.busy?.()||dialog.open||$('#project-confirm').open){toast('请先完成或关闭当前操作，再读取剧本。',true);return false}return true;
  }
  function createState(options={}){
    if(!canBegin())return null;
    flow={phase:'entry',documents:[],index:0,contextId:options.currentId||null,series:options.currentId===p?.id?(p.series||''):'',closed:false,preview:null,choices:[],results:[]};lock(true);return flow;
  }
  function cancel(state){if(!live(state))return;if(state.phase==='applying'){toast('正在写入已确认的工程，请等待结果，不能把已提交的写入当成撤销。',true);return}close(state)}
  dialog.addEventListener('cancel',event=>{if(flow){event.preventDefault();cancel(flow)}});
  document.addEventListener('click',event=>{if(!flow)return;if(event.target===input||dialog.contains(event.target)||$('#project-confirm').contains(event.target))return;if(event.target.closest?.('button,a,input,select,[data-project]')){event.preventDefault();event.stopImmediatePropagation();toast('请先完成剧本预览或取消此次操作。')}},true);
  window.addEventListener('beforeunload',event=>{if(flow?.phase==='applying'){event.preventDefault();event.returnValue='已确认的剧本写入仍在处理，请等待结果。'}});
  function entry(options={}){
    const state=createState(options);if(!state)return;
    paint(state,`<h2>读取剧本 / 预览分集</h2><p>PDF、TXT、MD、DOCX，每份最多 16 MiB；只在本机读取。预览不会改动任何工程，也不会变成字幕或修改声音。${state.contextId?'本次从当前集进入，匹配建议仍需你逐项勾选确认。':''}</p><button id="script-choose-file" class="accent">选择剧本文件（可多份）</button><hr class="section-break"><label>本机剧本文件完整路径</label><input id="script-source-path" placeholder="C:\\剧本\\全剧.txt"><button id="script-read-path">读取路径并预览</button><hr class="section-break"><label>或粘贴整部剧本文字（保留各集标题）</label><input id="script-source-name" value="粘贴剧本.txt" placeholder="剧本名称"><textarea id="script-source-text" rows="7" placeholder="第1集\n本集内容……\n第2集\n下一集内容……"></textarea><div class="modal-actions"><button id="script-entry-cancel">取消</button><button id="script-read-text" class="primary">预览粘贴的剧本</button></div>`);
    $('#script-entry-cancel').onclick=()=>close(state);
    $('#script-choose-file').onclick=()=>{input.click()};
    $('#script-read-path').onclick=handle(async()=>{const path=$('#script-source-path').value.trim();if(!path)throw Error('请填写一份剧本文件的完整路径');await read(state,{path})});
    $('#script-read-text').onclick=handle(async()=>{const text=$('#script-source-text').value,name=$('#script-source-name').value.trim()||'粘贴剧本.txt';if(!text.trim())throw Error('请先粘贴剧本文字');if(new Blob([text]).size>StudioScripts.maxBytes)throw Error('剧本文字超过 16 MiB，请分文件导入');await read(state,{name,text})});
  }
  async function startFiles(files,options={}){
    let state=options.state;
    if(!state){state=createState(options);if(!state)return}
    if(!live(state))return;
    const accepted=Array.from(files||[]).filter(file=>StudioScripts.accepts(file.name));
    if(!accepted.length){showError(state,Error('没有识别到 PDF / TXT / MD / DOCX 剧本'));return}
    if(accepted.length>30){showError(state,Error('一次最多预览30份剧本，请按剧名分批选择'));return}
    state.documents=accepted;state.index=0;await readNext(state);
  }
  async function readNext(state){
    const file=state.documents[state.index];if(!file)return;
    await read(state,()=>StudioScripts.filePayload(file));
  }
  async function read(state,source){
    if(!live(state)||['reading','applying'].includes(state.phase))return;
    state.phase='reading';
    paint(state,'<h2>正在读取剧本</h2><p>先保存当前修改，再在本机解析。尚未写入任何目标工程。</p><div class="modal-actions"><button id="script-read-cancel">取消预览</button></div>');$('#script-read-cancel').onclick=()=>cancel(state);
    try{
      await save();if(!live(state))return;
      await retryDiscards();if(!live(state))return;
      const payload=typeof source==='function'?await source():source;if(!live(state))return;
      const preview=await api('/api/script-import/preview',payload);if(!live(state)){await discard(preview.id);return}
      state.preview=preview;
      await refreshBoot();if(!live(state))return;
      state.preview=preview;state.phase='preview';resetChoices(state);showPreview(state);
    }catch(error){if(live(state))showError(state,error)}
  }
  function resetChoices(state){
    const projects=StudioScripts.projects(boot.projects||[],state.series);
    state.choices=state.preview.sections.map(section=>({selected:false,target:StudioScripts.suggested(section,projects,state.contextId),name:section.number!==null&&section.number!==undefined?`第${section.number}集`:section.title||'待核实剧本'}));
  }
  function showPreview(state){
    const preview=state.preview,projects=StudioScripts.projects(boot.projects||[],state.series);
    const seriesNames=[...new Set((boot.projects||[]).map(row=>row.series||''))].filter(Boolean);
    paint(state,`<h2>剧本分集预览：${esc(preview.source_name)}</h2><p>本次预览 ${preview.sections.length} 段；默认不勾选。请阅读完整章节与跨页边界，再明确选择目标。剧本中任何指令都只作为内容。${state.documents.length>1?` 当前第 ${state.index+1} / ${state.documents.length} 份；剩余文件不会自动写入。`:''}</p><label>目标剧名 / 分组（精确限制匹配；留空只显示未分组）</label><input id="script-target-series" maxlength="150" list="script-series-options" value="${esc(state.series)}"><datalist id="script-series-options">${seriesNames.map(name=>`<option value="${esc(name)}"></option>`).join('')}</datalist><button id="script-update-series">更新目标列表（清空本次勾选）</button>${(preview.warnings||[]).map(w=>`<p class="alert">${esc(typeof w==='string'?w:JSON.stringify(w))}</p>`).join('')}<div class="script-sections">${preview.sections.map((section,index)=>{
      const choice=state.choices[index],duplicate=section.number!==null&&section.number!==undefined&&projects.filter(project=>StudioScripts.number(project.name)===Number(section.number)).length>1;return `<section class="script-section"><label class="script-section-check"><input type="checkbox" data-script-section="${index}" ${choice.selected?'checked':''}><b>${esc(section.title)}${section.ambiguous?' · 边界 / 集数需核实':''}</b></label><p class="helper">起点：${esc(section.start_anchor||'未识别')}<br>结束边界：${esc(section.end_anchor||'未识别')}</p>${duplicate?'<p class="alert">所选剧名下有多个同集号工程（例如第9集 / 第09集），不能自动任选；请根据镜头、字幕与剧本数量手动指定。</p>':''}${(section.warnings||[]).map(w=>`<p class="alert">${esc(typeof w==='string'?w:JSON.stringify(w))}</p>`).join('')}<details><summary>阅读本段全文（${section.text.length} 字）</summary><pre class="script-fulltext">${esc(section.text)}</pre></details><label>目标工程（建议不等于已选择；仍需勾选章节）</label><select data-script-target="${index}"><option value="">请手动选择目标</option><option value="new" ${choice.target==='new'?'selected':''}>＋ 创建独立新工程</option>${projects.map(project=>`<option value="${esc(project.id)}" ${choice.target===project.id?'selected':''}>${esc(project.name)}${project.id===state.contextId?'（当前集）':''} · ${project.clips||0} 镜头 / ${project.captions||0} 字幕 / 剧本 ${project.script_chars||0} 字</option>`).join('')}</select><input data-script-name="${index}" value="${esc(choice.name)}" maxlength="150" aria-label="新工程集名" placeholder="选择新建时使用此集名" ${choice.target==='new'?'':'hidden'}></section>`;
    }).join('')}</div><p id="script-selection-count" class="manager-count"></p><div class="modal-actions"><button id="script-preview-cancel">取消，不写入</button>${state.index+1<state.documents.length?'<button id="script-next-skip">跳过这份，预览下一份</button>':''}<button id="script-apply" class="primary" disabled>核对所选章节与目标</button></div>`);
    function count(){const n=state.choices.filter(choice=>choice.selected).length;$('#script-selection-count').textContent=`已勾选 ${n} 段，写入前还需确认目标与替换清单`;$('#script-apply').disabled=!n}
    $$('[data-script-section]').forEach(box=>box.onchange=()=>{state.choices[Number(box.dataset.scriptSection)].selected=box.checked;count()});
    $$('[data-script-target]').forEach(select=>select.onchange=()=>{const index=Number(select.dataset.scriptTarget);state.choices[index].target=select.value;$(`[data-script-name="${index}"]`).hidden=select.value!=='new'});
    $$('[data-script-name]').forEach(field=>field.oninput=()=>state.choices[Number(field.dataset.scriptName)].name=field.value);
    $('#script-update-series').onclick=()=>{const next=$('#script-target-series').value.trim();if(next.length>150)return toast('剧名最多150个字符',true);state.series=next;resetChoices(state);showPreview(state)};
    $('#script-preview-cancel').onclick=()=>close(state);
    if(state.index+1<state.documents.length)$('#script-next-skip').onclick=handle(()=>nextDocument(state));
    $('#script-apply').onclick=handle(()=>apply(state));count();
  }
  async function nextDocument(state){
    if(!live(state)||state.phase==='applying'||state.phase==='reading'||state.phase==='releasing')return;
    state.phase='releasing';await releasePreview(state);if(!live(state))return;state.index++;await readNext(state);
  }
  async function apply(state){
    if(!live(state)||state.phase!=='preview')return;
    if($('#script-target-series').value.trim()!==state.series)throw Error('剧名输入已改变，请先点“更新目标列表”，防止写入上一部剧');
    const items=StudioScripts.mapping(state.preview.sections,state.choices,boot.projects||[],state.series);
    state.phase='checking';$('#script-apply').disabled=true;
    try{
      await save();if(!live(state))return;
      const currentBefore=p?copy(p):null,countBefore=dirty,undoBefore=copy(undo),targets=new Map();
      // Fetch current revisions and replacement presence instead of trusting a stale sidebar count.
      for(const item of items){if(item.project_id){const project=await api('/api/projects/'+item.project_id);if(project.archived||(project.series||'')!==state.series)throw Error('目标工程分组或回收站状态已改变，请重新预览');targets.set(project.id,project);item.revision=project.revision;item.replace_confirmed=!!(project.script?.text||project.script?.source)}}
      if(!live(state))return;
      const lines=items.map(item=>{const section=state.preview.sections.find(s=>s.id===item.section_id),project=targets.get(item.project_id);return `• ${section.title} → ${item.create_new?'新建 '+item.name:project.name}${item.replace_confirmed?'【替换已有剧本】':''}`});
      const message=`确认写入以下 ${items.length} 段？\n目标剧名：${state.series||'未分组'}\n\n${lines.join('\n')}\n\n只更新所选工程的剧本内容与边界锚点。已有字幕、必保台词、原声音轨、镜头均保留；不会自动勾选“已完整读取”。标记替换的旧剧本会留在工程历史中，需要重新复核。`;
      if(!await confirmAction(message,'确认这些目标与剧本替换')){if(live(state)){state.phase='preview';$('#script-apply').disabled=false}return}
      if(!live(state))return;state.phase='applying';
      paint(state,'<h2>正在写入已确认的剧本</h2><p>请等待具体结果。不会自动添加字幕、修改原声或删除对白保护清单。</p>');
      let outcome,problem=null;
      try{outcome=await hooks.transaction(()=>api(`/api/script-import/${state.preview.id}/apply`,{confirmed:true,items}))}
      catch(error){problem=error;outcome=error.data||{results:[]}}
      if(!live(state))return;
      const results=outcome.results||[];state.results=results;
      try{await refreshBoot()}catch(error){toast('写入结果已经收到，但工程列表刷新失败：'+error.message,true)}
      const changedCurrent=results.some(row=>StudioScripts.projectId(row)===currentBefore?.id);
      if(changedCurrent&&p?.id===currentBefore.id&&dirty===countBefore&&dirty<=saved){
        try{await openProject(currentBefore.id,{skipSave:true});if(p?.id===currentBefore.id){undo=[...undoBefore,currentBefore].slice(-40);tab='script';render()}}catch(error){toast('剧本已保存，但当前工程重载失败，请稍后手动打开：'+error.message,true)}
      }else if(changedCurrent&&p?.id===currentBefore.id)toast('当前存在更新的本地编辑，已保留，没有用导入结果覆盖；请先保存草稿再手动重载。',true);
      if(live(state))showResults(state,results,problem);
    }catch(error){if(live(state)){state.phase='preview';showPreview(state);toast(error.message,true)}}
  }
  function showResults(state,results,error){
    state.phase='results';
    paint(state,`<h2>${error?'剧本写入未全部确认':'剧本写入结果'}</h2>${error?`<div class="alert">${esc(error.message)}。${error.data?'以下返回的成功项已经保存，不能从头盲目重做。':'请求结果未确认，可能已发生写入，不能声称没有改动。'}失败 / 未确认项请检查工程状态后重新预览。</div>`:''}<p>已确认 ${results.length} 项。字幕、镜头与声音未改动；章节“完整读取”仍需人工复核。</p><div class="manager-list">${results.map(row=>`<div class="batch-result"><b>${esc(row.name||StudioScripts.projectId(row)||'工程')}</b><p>${StudioScripts.resultLabel(row)}${row.error?' · '+esc(row.error):''}</p></div>`).join('')||'<p>没有收到已成功项的记录；这不等于确认没有写入。请先检查工程，不自动重试。</p>'}</div><div class="modal-actions">${state.index+1<state.documents.length?'<button id="script-next-file" class="accent">只预览下一份剧本</button>':''}<button id="script-results-done">完成，回到编辑区</button></div>`);
    $('#script-results-done').onclick=()=>close(state);
    if(state.index+1<state.documents.length)$('#script-next-file').onclick=handle(()=>nextDocument(state));
  }
  function showError(state,error){
    state.phase='error';paint(state,`<h2>剧本尚未写入</h2><div class="alert">${esc(error.message)}</div><p>没有据此改动工程。请核对文件、文字与分集标题后重新读取。扫描型 PDF 若不能提取文字，需要提供可复制文本。</p><div class="modal-actions">${state.index+1<state.documents.length?'<button id="script-error-next">跳过这份，预览下一份</button>':''}<button id="script-error-close">关闭</button></div>`);$('#script-error-close').onclick=()=>close(state);
    if(state.index+1<state.documents.length)$('#script-error-next').onclick=handle(()=>nextDocument(state));
  }
  input.onchange=()=>{const files=Array.from(input.files||[]);input.value='';if(files.length)void startFiles(files,flow?{state:flow}:{})};
  $('#script-picker-button').onclick=()=>entry();
  renderScript=function(){
    originalRenderScript();if(!p)return;
    $('#script-import').textContent='读取 / 替换剧本并预览分集';$('#script-import').onclick=()=>entry({currentId:p.id});
    $('#script-text').placeholder='可直接拖入 PDF / TXT / MD / DOCX 剧本，先预览本集匹配再确认；也可在此手动编辑';
    $('#script-text').classList.add('script-drop-zone');
    const tip=document.createElement('p');tip.className='helper script-drop-note';tip.textContent='将剧本文件直接拖进上方大文本框，可预览并匹配当前集；原有剧本不会直接覆盖。';$('#script-text').after(tip);
  };
  window.addEventListener('drop',event=>{
    if(!StudioFolderDrop.hasFiles(event.dataTransfer))return;
    const inPanel=!!event.target.closest?.('#script-text,.script-drop-note');
    const snapshots=StudioFolderDrop.capture(event.dataTransfer);
    const directScripts=snapshots.length&&snapshots.every(item=>!item.entry?.isDirectory&&StudioScripts.accepts(item.file?.name||item.entry?.name));
    if(!inPanel&&!directScripts)return;
    event.preventDefault();event.stopImmediatePropagation();document.body.classList.remove('folder-drag-active');
    const state=createState({currentId:p?.id||null});if(!state)return;
    state.phase='scanning';paint(state,'<h2>读取拖入的剧本清单</h2><p>只在本机解析，之后逐份预览，不会直接覆盖已有剧本。</p>');
    void (async()=>{try{const scan=await StudioFolderDrop.scan(snapshots,{allowScriptRoots:true,cancelled:()=>!live(state)});if(live(state))await startFiles(scan.records.map(row=>row.file),{state})}catch(error){if(live(state))showError(state,error)}})();
  },true);
  window.studioScriptImport={busy:()=>!!flow,open:entry,startFiles};
}

;
// Source: txt-captions.js
'use strict';
const StudioTxtCaptions={
  maxBytes:1024*1024,
  decode(buffer){
    const bytes=new Uint8Array(buffer);
    if(!bytes.length||bytes.length>this.maxBytes)throw Error('TXT 文件必须非空且不超过 1 MiB');
    let text;
    if(bytes[0]===0xff&&bytes[1]===0xfe)text=new TextDecoder('utf-16le',{fatal:true}).decode(bytes);
    else if(bytes[0]===0xfe&&bytes[1]===0xff)text=new TextDecoder('utf-16be',{fatal:true}).decode(bytes);
    else{try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes)}catch(_){text=new TextDecoder('gb18030',{fatal:true}).decode(bytes)}}
    if(text.includes('\0')||text.includes('\ufffd'))throw Error('无法读取 TXT 编码，请另存为 UTF-8 后重试');
    return text.replace(/^\ufeff/,'');
  },
  split(text,mode='lines'){
    if(typeof text!=='string'||new TextEncoder().encode(text).length>this.maxBytes)throw Error('字幕文字不能超过 1 MiB');
    if(!['lines','sentences'].includes(mode))throw Error('请选择有效的分句方式');
    const lines=text.replace(/^\ufeff/,'').replace(/\r\n?/g,'\n').split('\n');
    const result=lines.flatMap(line=>mode==='lines'?[line]:line.replace(/([。！？!?；;]+[”’」』"']*|\.(?=\s|$))/gu,'$1\n').split('\n')).map(line=>line.trim()).filter(Boolean);
    if(!result.length)throw Error('请先输入字幕文字');
    if(result.length>10000)throw Error('一次最多分配 10000 条字幕，请分集输入');
    return result;
  }
};
if(typeof module!=='undefined'&&module.exports)module.exports=StudioTxtCaptions;

function installTxtCaptions(){
  const original=renderCaptions;
  renderCaptions=function(){
    original();
    const button=document.createElement('button');button.id='import-txt';button.textContent='TXT 分配字幕';
    $('#import-srt').after(button);button.onclick=handle(open);
  };
  function open(){
    if(!p)throw Error('请先打开一集');
    if(p.track_locks?.includes('caption'))throw Error('字幕轨道已锁定，请先解锁');
    const projectId=p.id;let preview=null,reading=0,busy=false,activeJob=null,interval=null,polling=false;
    modal(`<h2>TXT 分配字幕</h2><p>按本集最终音轨的对白自动对齐 TXT 原文。需要已配置的本地语音模型，完成后预览并应用。</p><label>选择 TXT（UTF-8 / UTF-16 / GB18030，最多 1 MiB）</label><input id="txt-caption-file" type="file" accept=".txt,text/plain"><label>或直接粘贴对白文字（与音频语言相同，不含角色名和动作说明）</label><textarea id="txt-caption-text" rows="8" placeholder="每行一句字幕"></textarea><label>分句方式</label><select id="txt-caption-split"><option value="lines">每个非空行一条</option><option value="sentences">按句末标点分句</option></select><p class="helper">保留输入原文和标点，使用本集全局字幕样式。应用会替换本集全部字幕，可撤销；对齐结果仍需试听校对。</p><div id="txt-caption-preview" role="status" aria-live="polite"></div><div class="modal-actions"><button id="txt-caption-cancel">关闭</button><button id="txt-caption-preview-button">按音频对齐并预览</button><button id="txt-caption-apply" class="primary" disabled>应用字幕</button></div>`);
    const splitControl=$('#txt-caption-split');
    const language=document.createElement('div');language.innerHTML='<label>音频对白语言</label><select id="txt-caption-language"><option value="">自动检测</option><option value="zh">中文</option><option value="en">英语</option><option value="pt">葡萄牙语</option><option value="es">西班牙语</option><option value="ja">日语</option><option value="ko">韩语</option><option value="fr">法语</option><option value="de">德语</option></select>';splitControl.after(language);
    const languageControl=$('#txt-caption-language');
    const dialog=$('#modal'),field=$('#txt-caption-text'),file=$('#txt-caption-file'),split=$('#txt-caption-split'),apply=$('#txt-caption-apply'),output=$('#txt-caption-preview'),start=$('#txt-caption-preview-button');
    const current=()=>p?.id===projectId&&dialog.open&&$('#txt-caption-text')===field;
    const signature=()=>JSON.stringify([p?.id,p?.revision,dirty,p?.captions,p?.track_locks,p?.clips,p?.audios,p?.fps]);
    function invalidate(){preview=null;apply.disabled=true;output.textContent=''}
    function lock(value){busy=value;for(const el of [field,file,split,languageControl,start])el.disabled=value}
    function stop(){clearInterval(interval);interval=null;activeJob=null;lock(false)}
    function show(result,stamp){
      if(!current())return;
      if(signature()!==stamp)throw Error('对齐期间工程已变化，已保留当前字幕；请按当前工程重新对齐');
      const cues=result.captions;
      if(!result.alignment||!cues?.length)throw Error('没有生成有效的 TXT 对齐字幕，未替换当前字幕');
      preview={cues,signature:stamp,sound:result.sound_digest};apply.disabled=false;
      output.innerHTML=`<p>已对齐 ${cues.length} 条，文字匹配率 ${Math.round(result.alignment.coverage*100)}%。请试听确认。${cues.length>200?'下表显示前200条。':''}</p><div style="max-height:240px;overflow:auto"><table><thead><tr><th>时间</th><th>字幕原文</th></tr></thead><tbody>${cues.slice(0,200).map(cue=>`<tr><td>${time(cue.start)} → ${time(cue.end)}</td><td>${esc(cue.text)}</td></tr>`).join('')}</tbody></table></div>`;
    }
    field.addEventListener('input',invalidate);split.addEventListener('change',invalidate);languageControl.addEventListener('change',invalidate);
    file.onchange=handle(async()=>{
      const chosen=file.files[0];if(!chosen)return;
      const ticket=++reading,before=field.value;invalidate();start.disabled=true;
      try{
        if(!/\.txt$/i.test(chosen.name))throw Error('请选择 TXT 文本文件');
        if(chosen.size>StudioTxtCaptions.maxBytes)throw Error('TXT 文件不能超过 1 MiB');
        const text=StudioTxtCaptions.decode(await chosen.arrayBuffer());
        if(!current()||reading!==ticket)return;
        if(field.value!==before)throw Error('读取期间文字已修改，已保留你的输入，请重新选择 TXT');
        field.value=text;invalidate();
      }finally{if(reading===ticket){file.value='';start.disabled=false}}
    });
    $('#txt-caption-cancel').onclick=()=>dialog.close();
    dialog.addEventListener('close',()=>{stop();reading++},{once:true});
    start.onclick=handle(async()=>{
      if(!current()||busy)return;
      StudioTxtCaptions.split(field.value,split.value);invalidate();lock(true);
      try{
        await save();if(!current())return;
        const stamp=signature();
        const job=await api(`/api/projects/${projectId}/jobs`,{kind:'transcribe',revision:p.revision,language:languageControl.value,subtitle_text:field.value,subtitle_split:split.value});
        activeJob=job.id;
        if(!current()){stop();return}
        output.textContent='正在后台对齐音频对白，可关闭窗口；完成后也可从处理记录应用字幕草稿。';
        async function poll(){
          if(polling||!activeJob)return;polling=true;
          try{
            const result=await api('/api/jobs/'+job.id);
            if(!current()){stop();return}
            if(result.state==='complete'){stop();show(result.result,stamp)}
            else if(['failed','cancelled','interrupted'].includes(result.state)){stop();output.textContent=result.message;toast(result.message,true)}
            else output.textContent=result.message||'正在对齐音频对白…';
          }catch(error){stop();if(current()){output.textContent=error.message;toast(error.message,true)}}
          finally{polling=false}
        }
        interval=setInterval(poll,1500);await poll();
      }catch(error){stop();throw error}
      finally{if(!activeJob)lock(false)}
    });
    apply.onclick=handle(async()=>{
      if(!current()||!preview||signature()!==preview.signature)throw Error('工程或字幕已变化，请重新对齐预览');
      if(p.track_locks?.includes('caption'))throw Error('字幕轨道已锁定，请先解锁');
      apply.disabled=true;
      try{
        const proposal=preview,stamp=signature();await refreshQA();
        if(!current()||preview!==proposal||signature()!==stamp||proposal.sound!==qa.sound_hash)throw Error('声音或工程已变化，请重新对齐预览');
        remember();p.captions=copy(proposal.cues);selected=p.captions[0]?.id;mark();dialog.close();render();toast(`已分配 ${p.captions.length} 条 TXT 字幕，可撤销；请试听校对时间`);
      }finally{if(current()&&preview)apply.disabled=false}
    });
  }
}

;
// Source: folder-drop.js
'use strict';

// This module never asks for absolute paths or sends file bytes off the local origin.
const StudioFolderDrop={
  limits:{files:10000,entries:30000,depth:32},
  video:/\.(mp4|mov|mkv|webm|avi|m4v)$/i,
  audio:/\.(mp3|wav|m4a|aac|flac|ogg)$/i,
  script:/\.(pdf|txt|md|docx)$/i,
  caption:/\.(srt|vtt)$/i,
  // Keep this conservative directory-only list aligned with episode_folders.IGNORED_FOLDERS.
  ignoredFolders:new Set(['venv','models','data','bin','cache','__pycache__','node_modules','site-packages','jobs','renders','history','trash','recovery','batches','test-output','__macosx','$recycle.bin','system volume information']),
  ignoredName(name){return name.startsWith('.')||this.ignoredFolders.has(name.normalize('NFC').toLocaleLowerCase())},
  hasFiles(transfer){return Array.from(transfer?.types||[]).includes('Files')||Array.from(transfer?.items||[]).some(item=>item.kind==='file')},
  capture(transfer){
    // These methods must run synchronously in the drop event, before any await.
    const snapshots=[];
    for(const item of Array.from(transfer?.items||[])){
      if(item.kind!=='file')continue;
      let entry=null,file=null,handlePromise=null;
      try{entry=(item.getAsEntry||item.webkitGetAsEntry)?.call(item)||null}catch(e){}
      if(!entry&&typeof item.getAsFileSystemHandle==='function'){
        try{handlePromise=Promise.resolve(item.getAsFileSystemHandle()).catch(()=>null)}catch(e){}
      }
      try{file=item.getAsFile?.()||null}catch(e){}
      snapshots.push({entry,handlePromise,file});
    }
    if(!snapshots.length)for(const file of Array.from(transfer?.files||[]))snapshots.push({file});
    return snapshots;
  },
  relative(value){
    const path=String(value||'').replaceAll('\\','/');
    if(!path||path.startsWith('/')||path.includes('\0')||path.split('/').some(part=>!part||part==='.'||part==='..'))throw Error('文件夹内出现无效的相对路径');
    return path;
  },
  kind(name){name=String(name||'');if(this.video.test(name))return 'video';if(this.audio.test(name))return 'audio';if(this.script.test(name))return 'script';if(this.caption.test(name))return 'caption';return 'other'},
  standalonePath(file,options={}){
    const name=String(file?.name||'').replaceAll('\\','/').split('/').pop();
    if(!name)throw Error('无法读取所选文件名，请重新选择');
    const kind=this.kind(name);
    if(kind==='script')return '添加的剧本/'+name;
    if(kind==='caption')return '添加的字幕/'+name;
    if(options.groupLooseMedia&&['video','audio'].includes(kind))return '添加的素材/'+name;
    let stem=name.replace(/\.[^.]+$/,'').trim();
    if(!stem||stem==='.'||stem==='..')stem='添加的素材';
    return stem+'/'+name;
  },
  manifest(records){return records.map(row=>({relative_path:row.relative_path,size:row.size,last_modified:row.last_modified}))},
  plan(records,roots,selected,series=''){
    const plan={files:this.manifest(records),roots:[...roots],selected:[...selected],confirmed:true};
    if(series.trim())plan.series=series.trim();
    return plan;
  },
  resultRows(result){return result.results||((result.episodes||[]).map(row=>({...row,id:row.project_id||null})))},
  canOpen(row){return !!row.id&&!row.archived&&!row.unavailable&&row.state!=='failed'},
  bytes(value){const n=Math.max(0,Number(value)||0);if(n>=1024**3)return (n/1024**3).toFixed(2)+' GB';if(n>=1024**2)return (n/1024**2).toFixed(1)+' MB';if(n>=1024)return (n/1024).toFixed(1)+' KB';return n+' B'},
  async scan(snapshots,options={}){
    const limits={...this.limits,...options.limits},records=[],roots=new Set(),seen=new Set(),skipped=new Set();let visited=0,totalBytes=0;
    const skipPath=path=>{const parts=path.split('/');for(let i=0;i<parts.length;i++)if(this.ignoredName(parts[i])){skipped.add(parts.slice(0,i+1).join('/'));return true}return false};
    const cancelled=()=>{if(options.cancelled?.()){const e=Error('已停止读取文件夹目录');e.name='ImportCancelled';throw e}};
    const visit=depth=>{cancelled();if(depth>limits.depth)throw Error(`目录层级超过 ${limits.depth} 层，请选择具体剧名目录`);if(++visited>limits.entries)throw Error(`目录条目超过 ${limits.entries} 个，请按剧名分批导入`)};
    const add=(file,path)=>{
      cancelled();path=this.relative(path);
      if(skipPath(path))return;
      if(!path.includes('/'))path=this.standalonePath(file,options);
      if(seen.has(path))throw Error('有两个根目录包含同名相对路径，请分开导入：'+path);
      if(records.length>=limits.files)throw Error(`文件超过 ${limits.files} 个，请按剧名分批选择`);
      if(!Number.isSafeInteger(file.size)||file.size<0)throw Error('无法读取文件大小：'+path);
      seen.add(path);roots.add(path.split('/')[0]);totalBytes+=file.size;
      records.push({relative_path:path,size:file.size,last_modified:Number(file.lastModified)||0,file});
      options.progress?.({count:records.length,bytes:totalBytes,path});
    };
    const entryFile=entry=>new Promise((resolve,reject)=>entry.file(resolve,reject));
    const readBatch=reader=>new Promise((resolve,reject)=>reader.readEntries(resolve,reject));
    const walkEntry=async(entry,prefix,depth)=>{
      cancelled();const path=prefix?prefix+'/'+entry.name:entry.name;if(skipPath(path))return;visit(depth);
      if(entry.isFile){add(await entryFile(entry),path);return}
      if(!entry.isDirectory)throw Error('这个拖入项不是可读取的文件夹');
      const reader=entry.createReader();
      for(;;){cancelled();const batch=await readBatch(reader);if(!batch.length)break;for(const child of batch)await walkEntry(child,path,depth+1)}
    };
    const walkHandle=async(handle,prefix,depth)=>{
      cancelled();const path=prefix?prefix+'/'+handle.name:handle.name;if(skipPath(path))return;visit(depth);
      if(handle.kind==='file'){add(await handle.getFile(),path);return}
      if(handle.kind!=='directory'||typeof handle.values!=='function')throw Error('当前浏览器不支持目录句柄，请使用“选择文件夹”');
      for await(const child of handle.values()){cancelled();await walkHandle(child,path,depth+1)}
    };
    for(const snapshot of snapshots){
      cancelled();
      if(snapshot.entry){await walkEntry(snapshot.entry,'',0);continue}
      const handle=snapshot.handlePromise?await snapshot.handlePromise:null;
      if(handle){await walkHandle(handle,'',0);continue}
      if(snapshot.file){const path=snapshot.file.webkitRelativePath||snapshot.relative_path||snapshot.file.name;if(skipPath(path))continue;visit(0);add(snapshot.file,path);continue}
      throw Error('无法取得文件夹结构，请改用“选择文件夹”');
    }
    if(!records.length)throw Error('文件夹中没有可读取文件'+(skipped.size?'；已跳过隐藏 / 缓存 / 软件目录：'+[...skipped].join('、'):''));
    records.sort((a,b)=>a.relative_path.localeCompare(b.relative_path,undefined,{numeric:true}));
    return {records,roots:[...roots],bytes:totalBytes,skipped:[...skipped]};
  },
  selectedBytes(preview,ids){
    const wanted=new Set((preview.episodes||[]).filter(row=>ids.includes(row.id)).flatMap(row=>row.file_ids||[]));
    return (preview.normalized_files||[]).filter(file=>wanted.has(file.id)).reduce((n,file)=>n+file.size,0);
  },
  async transfer(session,files,options){
    if(options.confirmed!==true)throw Error('必须先明确确认所选剧集，才允许读取媒体内容');
    const requested=Number(session.max_chunk_size)||8*1024*1024;
    const chunkSize=Math.max(1,Math.floor(Math.min(requested,8*1024*1024)));
    const total=session.files.reduce((n,row)=>n+row.size,0);
    const report=row=>options.progress?.({bytes:session.files.reduce((n,file)=>n+file.offset,0),total,file:row?.relative_path||''});
    report();
    for(const row of session.files){
      const file=files.get(row.relative_path);
      if(!file||file.size!==row.size)throw Error('原文件引用不可用或大小已变化，请重新选择同一文件夹：'+row.relative_path);
      if(!Number.isSafeInteger(row.offset)||row.offset<0||row.offset>row.size)throw Error('服务端返回了无效的续传位置');
      while(row.offset<row.size){
        await options.beforeChunk?.();
        if(options.cancelled?.()){const e=Error('已停止后续分块');e.name='ImportCancelled';throw e}
        const offset=row.offset,end=Math.min(row.size,offset+chunkSize);
        const body=file.slice(offset,end);
        const response=await options.put(session.id,row.id,offset,body);
        const accepted=response.file?.offset;
        if(!Number.isSafeInteger(accepted)||accepted!==end)throw Error('确认字节位置不一致，请按服务端记录重试续传');
        row.offset=accepted;row.state=response.file?.state||row.state;report(row);
      }
    }
    return session;
  }
};
if(typeof module!=='undefined'&&module.exports)module.exports=StudioFolderDrop;

function installFolderDrop(){
  let flow=null,flowNumber=0,dragDepth=0;
  const previousDisabled=new Map();
  const confirmAction=window.studioProjectConfirm;
  const modalElement=$('#modal'),input=$('#folder-drop-input'),materialInput=$('#material-file-input');
  const current=state=>flow===state;
  const busy=()=>!!flow;
  const controls=['#global-new-button','#global-manage-button','#new-button','#manage-button','#batch-button','#batch-queue-button','#material-picker-button','#folder-picker-button','#folder-drop-path','#script-picker-button','#import-button'];
  function lock(value){[...controls,'#close-modal'].forEach(selector=>{const el=$(selector);if(!el)return;if(value){previousDisabled.set(selector,!!el.disabled);el.disabled=true}else{el.disabled=previousDisabled.get(selector)||false}});if(!value)previousDisabled.clear();$('#folder-drop-target').classList.toggle('import-busy',value)}
  function paint(html,state=flow){if(!current(state))return;modal(html);$('#close-modal').disabled=true}
  function closeFlow(state=flow){
    if(!current(state))return;state.cancelled=true;flow=null;lock(false);input.value='';materialInput.value='';$('#modal').close();
    $('#folder-drop-hint').textContent=state.session?'素材已保存在本机；再次选择相同内容不会重复添加。':'自动识别类型，只在本机处理。';
  }
  function showFailure(error,state){
    if(!current(state))return;state.phase='failed';
    paint(`<h2>${state.session?'素材添加中断':'无法读取这次选择'}</h2><div class="alert">${esc(error.message)}</div><p>${state.session?'已经复制到本机的部分会保留；重试从确认位置继续，不会从头重复发送。':'没有添加或改动任何素材。可以直接重新选文件或文件夹。'}</p><div class="modal-actions">${state.session?'<button id="folder-drop-retry" class="primary">继续重试</button>':'<button id="folder-drop-reselect" class="primary">重新选择文件</button><button id="folder-drop-refolder">选择文件夹</button>'}<button id="folder-drop-stop">关闭</button></div>`,state);
    if(state.session)$('#folder-drop-retry').onclick=handle(()=>startTransfer(state,true));
    if(!state.session){$('#folder-drop-reselect').onclick=()=>{closeFlow(state);setTimeout(()=>materialInput.click())};$('#folder-drop-refolder').onclick=()=>{closeFlow(state);setTimeout(()=>input.click())}}
    $('#folder-drop-stop').onclick=handle(()=>cancelFlow(state));
  }
  async function cancelFlow(state=flow){
    if(!current(state))return;
    if(state.phase==='complete'){closeFlow(state);return}
    if(state.phase==='committing'){toast('正在建立独立工程，请等待结果；不能把已提交操作当作已撤销。',true);return}
    if(state.phase==='uploading'||state.phase==='starting'){
      if(state.pauseGate)return;
      state.pauseGate=confirmAction('停止本次导入？\n\n当前分块结束后暂停发送下一块，等待本次选择。确认停止后，已拷贝到本机的数据保留以便续传，不会删除原文件、现有工程或已导出视频。','停止后续分块');
      const accepted=await state.pauseGate;state.pauseGate=null;if(!accepted)return;
      if(!current(state))return;state.cancelled=true;$('#folder-drop-progress-message').textContent='停止请求已记录，等待当前分块结束…';return;
    }
    if(state.session){
      if(!await confirmAction('结束这次未完成导入？\n\n已拷贝缓存保留，可再次选择同一文件夹续传。不会删除缓存或原文件。','结束并保留暂存'))return;
      try{await api(`/api/folder-drop/${state.session.id}/cancel`,{})}catch(error){toast('未能确认服务端取消状态；本机暂存未删除。'+error.message,true)}
    }
    closeFlow(state);
  }
  modalElement.addEventListener('cancel',event=>{if(flow){event.preventDefault();void cancelFlow(flow)}});
  // Prevent other toolbar actions from replacing this flow's modal while work is pending.
  document.addEventListener('click',event=>{
    if(!flow)return;
    const target=event.target;
    if(modalElement.contains(target)||$('#project-confirm').contains(target))return;
    if(target.closest?.('button,a,input,select,[data-project]')){event.preventDefault();event.stopImmediatePropagation();toast('请先完成或结束当前文件夹导入，再进行其他操作。')}
  },true);
  function canBegin(){
    if(busy()||window.studioScriptImport?.busy?.()){toast('已有导入正在处理，请先完成或结束，不会重复创建。',true);return false}
    if($('#modal').open||$('#project-confirm').open){toast('请先完成或关闭当前对话框，再拖入文件夹。',true);return false}
    return true;
  }
  async function begin(snapshots,options={}){
    if(!canBegin())return;
    const state={id:++flowNumber,phase:'scanning',cancelled:false,session:null,records:[],roots:[],plan:null,inFlight:false,targetProjectId:options.targetProjectId||null,extraScripts:[],extraCaptions:[]};flow=state;lock(true);
    paint('<h2>正在识别素材</h2><p>读取文件名、大小和类型；还没有复制或改动工程。</p><p id="folder-scan-progress">正在读取选择…</p><div class="modal-actions"><button id="folder-scan-cancel">取消</button></div>',state);
    $('#folder-scan-cancel').onclick=()=>{state.cancelled=true;closeFlow(state)};
    try{
      await save();
      if(!current(state)||state.cancelled)return;
      const scanned=await StudioFolderDrop.scan(snapshots,{allowScriptRoots:true,groupLooseMedia:!!state.targetProjectId,cancelled:()=>state.cancelled||!current(state),progress:progress=>{if(current(state)&&$('#folder-scan-progress'))$('#folder-scan-progress').textContent=`已发现 ${progress.count} 个文件 · ${StudioFolderDrop.bytes(progress.bytes)}（尚未复制）`}});
      if(!current(state))return;
      const media=scanned.records.filter(row=>['video','audio'].includes(StudioFolderDrop.kind(row.relative_path)));
      state.extraScripts=scanned.records.filter(row=>StudioFolderDrop.kind(row.relative_path)==='script');
      state.extraCaptions=scanned.records.filter(row=>StudioFolderDrop.kind(row.relative_path)==='caption');
      const unsupported=scanned.records.filter(row=>StudioFolderDrop.kind(row.relative_path)==='other');
      if(!media.length&&state.extraScripts.length){const files=state.extraScripts.map(row=>row.file),currentId=state.targetProjectId;closeFlow(state);await window.studioScriptImport.startFiles(files,{currentId});return}
      if(!media.length&&state.extraCaptions.length){const files=state.extraCaptions.map(row=>row.file);if(!state.targetProjectId)throw Error('字幕需要添加到具体剧集，请先新建或打开一集');closeFlow(state);await window.studioImportSubtitleFiles(files);return}
      if(!media.length)throw Error(unsupported.length?'没有识别到可添加的视频、音频、字幕或剧本':'所选内容中没有可添加的素材');
      if(!state.targetProjectId&&!media.some(row=>StudioFolderDrop.kind(row.relative_path)==='video'))throw Error('音频需要添加到具体剧集，请先新建或打开一集');
      state.records=media;state.roots=[...new Set(media.map(row=>row.relative_path.split('/')[0]))];state.skipped=scanned.skipped;state.phase='previewing';
      const preview=await api('/api/folder-drop/preview',{files:StudioFolderDrop.manifest(state.records),roots:state.roots,include_audio_only:!!state.targetProjectId});
      if(!current(state)||state.cancelled)return;preview.warnings=[...(preview.warnings||[]),...(state.skipped.length?['浏览器已提前跳过以下隐藏 / 缓存 / 软件目录或文件，未读取其内容：'+state.skipped.join('、')]:[])];state.preview=preview;state.phase='preview';
      if(state.targetProjectId){
        if(!(preview.episodes||[]).length)throw Error('没有识别到可添加的视频或音频');
        if(preview.episodes.length===1){
          state.plan={...StudioFolderDrop.plan(state.records,state.roots,[preview.episodes[0].id]),target_project_id:state.targetProjectId,append:true};
          await startTransfer(state,false);
        }else showProjectPreview(state);
      }else showPreview(state);
    }catch(error){if(error.name==='ImportCancelled'){if(current(state))closeFlow(state)}else showFailure(error,state)}
  }
  function showProjectPreview(state){
    const preview=state.preview;
    paint(`<h2>选择要加入当前分集的素材</h2><p>识别到 ${preview.episodes.length} 个分集 / 素材分组。为避免串集，一次只能把其中一个分组加入当前工程；其他分组不会复制或改动。</p><div class="folder-drop-episodes">${preview.episodes.map(row=>`<label class="manager-row"><input type="radio" name="folder-project-episode" data-folder-episode="${esc(row.id)}"><span><b>${esc(row.name)}</b><small>剧名：${esc(row.series||'未识别')} · 来源：${esc(row.source_folder||'')}</small><small>${row.video_count||0} 个视频 / ${row.audio_count||0} 个音频</small></span></label>`).join('')}</div><details class="batch-skipped"><summary>识别提示与跳过项</summary>${(preview.warnings||[]).map(row=>`<p>${esc(typeof row==='string'?row:JSON.stringify(row))}</p>`).join('')}${(preview.skipped||[]).map(row=>`<p>${esc(typeof row==='string'?row:[row.name||row.relative_path||row.path||'',row.reason||''].join('：'))}</p>`).join('')}</details><p id="folder-drop-selection" class="manager-count">尚未选择 · 不会自动合并不同集素材</p><div class="modal-actions"><button id="folder-drop-use-path">改用路径导入（免复制）</button><button id="folder-drop-preview-cancel">取消</button><button id="folder-drop-confirm" class="primary" disabled>添加所选分组</button></div>`,state);
    $$('[data-folder-episode]').forEach(box=>box.onchange=()=>{const row=preview.episodes.find(item=>item.id===box.dataset.folderEpisode);$('#folder-drop-selection').textContent=`已选择 1 个分组 · 需要额外拷贝 ${StudioFolderDrop.bytes(StudioFolderDrop.selectedBytes(preview,[row.id]))}`;$('#folder-drop-confirm').disabled=false});
    $('#folder-drop-preview-cancel').onclick=()=>closeFlow(state);
    $('#folder-drop-use-path').onclick=()=>{closeFlow(state);$('#batch-button').click()};
    $('#folder-drop-confirm').onclick=handle(async()=>{
      const selected=$('[data-folder-episode]:checked');
      if(!selected)throw Error('请先选择一个要加入当前分集的素材分组');
      const row=preview.episodes.find(item=>item.id===selected.dataset.folderEpisode),bytes=StudioFolderDrop.selectedBytes(preview,[row.id]);
      if(!await confirmAction(`只把“${row.name}”加入当前分集？\n\n将向本机数据目录额外拷贝约 ${StudioFolderDrop.bytes(bytes)}。其他分组不会复制；原文件和当前工程已有编辑不删除。`,'确认添加这个分组'))return;
      if(!current(state))return;
      state.plan={...StudioFolderDrop.plan(state.records,state.roots,[row.id]),target_project_id:state.targetProjectId,append:true};
      await startTransfer(state,false);
    });
  }
  function showPreview(state){
    const preview=state.preview;
    paint(`<h2>预览识别到的剧集</h2><p>浏览器不能提供本地文件夹的绝对路径。此方式需要把所选素材<strong>分块拷贝到本机软件数据目录</strong>，占用额外磁盘空间；不会发往外部网站。大素材建议使用“路径导入”免复制。</p><label>统一剧名 / 分组（可选；填写后覆盖所选各集分组）</label><input id="folder-drop-series" maxlength="150" placeholder="留空时使用各集识别到的剧名"><div class="folder-drop-episodes">${(preview.episodes||[]).map(row=>`<label class="manager-row"><input type="checkbox" data-folder-episode="${esc(row.id)}"><span><b>${esc(row.name)}</b><small>剧名：${esc(row.series||'未识别，可自行填写')} · 来源：${esc(row.source_folder||'')}</small><small>${row.video_count||0} 个视频 / ${row.audio_count||0} 个音频${row.needs_selection?' · 命名需核实：不猜测未知集数，请确认后再选':''}</small></span></label>`).join('')||'<p>没有可导入的剧集，请检查文件夹结构或改用路径导入。</p>'}</div><details class="batch-skipped"><summary>识别提示与跳过项</summary>${(preview.warnings||[]).map(row=>`<p>${esc(typeof row==='string'?row:JSON.stringify(row))}</p>`).join('')}${(preview.skipped||[]).map(row=>`<p>${esc(typeof row==='string'?row:[row.name||row.relative_path||row.path||'',row.reason||''].join('：'))}</p>`).join('')}</details><p id="folder-drop-selection" class="manager-count">已选择 0 集 · 需要额外拷贝 0 B</p><div class="modal-actions"><button id="folder-drop-use-path">改用路径导入（免复制）</button><button id="folder-drop-preview-cancel">取消</button><button id="folder-drop-confirm" class="primary" disabled>确认所选剧集并拷贝</button></div>`,state);
    $$('[data-folder-episode]').forEach(box=>box.onchange=()=>{const selected=$$('[data-folder-episode]:checked').map(item=>item.dataset.folderEpisode);$('#folder-drop-selection').textContent=`已选择 ${selected.length} 集 · 需要额外拷贝 ${StudioFolderDrop.bytes(StudioFolderDrop.selectedBytes(preview,selected))}`;$('#folder-drop-confirm').disabled=!selected.length});
    $('#folder-drop-preview-cancel').onclick=()=>closeFlow(state);
    $('#folder-drop-use-path').onclick=()=>{closeFlow(state);$('#batch-button').click()};
    $('#folder-drop-confirm').onclick=handle(async()=>{
      const selected=$$('[data-folder-episode]:checked').map(item=>item.dataset.folderEpisode),series=$('#folder-drop-series').value.trim();
      if(!selected.length)throw Error('请先逐项勾选需要导入的剧集');
      if(series.length>150)throw Error('剧名最多150个字符');
      const names=preview.episodes.filter(row=>selected.includes(row.id)).map(row=>row.name);
      const bytes=StudioFolderDrop.selectedBytes(preview,selected);
      if(!await confirmAction(`确认导入以下 ${names.length} 集？\n\n${names.map(name=>'• '+name).join('\n')}\n\n将向本机数据目录额外拷贝约 ${StudioFolderDrop.bytes(bytes)}，需要相应磁盘空间。原文件和当前编辑工程不修改。未勾选项目不导入。`,'确认并开始本机拷贝'))return;
      if(!current(state))return;
      state.plan=StudioFolderDrop.plan(state.records,state.roots,selected,series);
      await startTransfer(state,false);
    });
  }
  function showProgress(state){
    paint(`<h2>${state.targetProjectId?'正在添加素材':'正在导入所选剧集'}</h2><p>复制到百慕的本机素材库，不会上传云端。显示的是本机已确认接收的字节。</p><progress id="folder-drop-progress" value="0" max="1"></progress><p id="folder-drop-bytes">正在核对已接收位置…</p><p id="folder-drop-progress-message"></p><p id="folder-drop-current-file" class="helper"></p><div class="modal-actions"><button id="folder-drop-upload-cancel">停止</button></div>`,state);
    $('#folder-drop-upload-cancel').onclick=handle(()=>cancelFlow(state));
  }
  function updateProgress(state,progress){
    if(!current(state))return;
    $('#folder-drop-progress').max=Math.max(1,progress.total);$('#folder-drop-progress').value=progress.bytes;
    $('#folder-drop-bytes').textContent=`已确认 ${StudioFolderDrop.bytes(progress.bytes)} / ${StudioFolderDrop.bytes(progress.total)}`;
    $('#folder-drop-current-file').textContent=progress.file||'';
    if(!state.cancelled)$('#folder-drop-progress-message').textContent='分块发送中；停止操作会保留已经拷贝的暂存。';
  }
  async function put(sessionId,fileId,offset,blob){
    const response=await fetch(`/api/folder-drop/${encodeURIComponent(sessionId)}/files/${encodeURIComponent(fileId)}?offset=${offset}`,{method:'PUT',headers:{'X-Studio-Token':token,'Content-Type':'application/octet-stream'},body:blob});
    let result;try{result=await response.json()}catch(e){throw Error('未收到可确认的分块响应；请按服务端记录重试，不盲目从零发送')}
    if(!response.ok)throw Error(result.error||'本机分块接收失败');return result;
  }
  async function startTransfer(state,retry){
    if(!current(state)||state.inFlight)return;
    state.inFlight=true;state.cancelled=false;state.phase='starting';showProgress(state);
    try{
      if(retry&&state.session)state.session=await api(`/api/folder-drop/${state.session.id}`);
      // start is idempotent and re-enables a cancelled session with its recorded offsets.
      state.session=await api('/api/folder-drop/start',state.plan);
      if(state.pauseGate)await state.pauseGate;
      if(!current(state))return;
      if(state.cancelled){if(state.session.requires_reuse_confirmation){closeFlow(state);return}const e=Error('停止请求已生效');e.name='ImportCancelled';throw e}
      try{localStorage.setItem('studio-folder-drop-last',JSON.stringify({id:state.session.id,roots:state.roots,time:Date.now()}))}catch(e){}
      if(state.session.requires_reuse_confirmation){
        state.phase='reuse';
        const accepted=await confirmAction('这份文件名、大小和修改时间清单对应已经完成的导入。\n\n本次没有重新读取新文件内容，也没有做新旧文件的 SHA 一致性验证。是否只打开已有工程并保留已有编辑？\n\n已归档的工程不会自动恢复；同路径素材实际改变请使用明确更新素材的入口。','只查看已有工程，不重新导入');
        if(!current(state))return;
        if(!accepted){closeFlow(state);return}
        showComplete(state,state.session,true);return;
      }
      if(state.session.resume_warning){
        state.phase='resume-check';
        const accepted=await confirmAction('检测到已有的未完成会话。\n\n续传位置只依据文件路径、大小与修改时间匹配，没有重新做文件内容 SHA 对比。必须继续使用上次相同、未被替换的原文件，避免前后分块混合。\n\n'+state.session.resume_warning,'确认原文件未改变，继续续传');
        if(!accepted){closeFlow(state);return}
      }
      state.phase='uploading';
      const files=new Map(state.records.map(row=>[row.relative_path,row.file]));
      await StudioFolderDrop.transfer(state.session,files,{confirmed:true,put,beforeChunk:()=>state.pauseGate,cancelled:()=>state.cancelled||!current(state),progress:progress=>updateProgress(state,progress)});
      if(state.pauseGate)await state.pauseGate;
      if(state.cancelled){const error=Error('停止请求已生效');error.name='ImportCancelled';throw error}
      state.phase='committing';$('#folder-drop-upload-cancel').disabled=true;$('#folder-drop-progress-message').textContent=state.targetProjectId?'素材已接收，正在检查并添加到当前工程。':'素材已接收，正在检查并建立独立工程；当前工程不被替换。';
      const result=await api(`/api/folder-drop/${state.session.id}/commit`,{});
      if(!current(state))return;state.session=result;await refreshBoot();
      if(state.targetProjectId&&p?.id===state.targetProjectId){await openProject(state.targetProjectId,{skipSave:true});tab='clips';render()}
      showComplete(state,result,false);
    }catch(error){
      if(!current(state))return;
      if(error.name==='ImportCancelled'||state.cancelled){
        let note='已停止发送后续分块，已拷贝的本机暂存保留，可再次选择同一文件夹续传。';
        try{if(state.session)await api(`/api/folder-drop/${state.session.id}/cancel`,{})}catch(e){note+=' 服务端取消状态未确认：'+e.message}
        state.phase='cancelled';paint(`<h2>本次导入已停止</h2><p>${esc(note)}</p><p>源文件与原有工程未删除；没有声称清理暂存。</p><div class="modal-actions"><button id="folder-drop-resume" class="primary">按现有位置继续</button><button id="folder-drop-close">关闭</button></div>`,state);
        $('#folder-drop-resume').onclick=handle(()=>startTransfer(state,true));$('#folder-drop-close').onclick=()=>closeFlow(state);
      }else{
        if(state.session){try{const latest=await api(`/api/folder-drop/${state.session.id}`);state.session=latest;if(latest.results?.length){showPartial(state,error,latest);return}}catch(e){}}
        showFailure(error,state);
      }
    }finally{state.inFlight=false}
  }
  function showComplete(state,result,reused){
    state.phase='complete';
    const rows=StudioFolderDrop.resultRows(result);
    const projectMode=!!state.targetProjectId;
    paint(`<h2>${projectMode?'素材已添加':reused?'已有工程，请按需打开':'导入完成'}</h2><p>${projectMode?'视频已经加入画面轨道；音频已进入当前工程素材库。原文件没有改动。':reused?'本次只复用已有工程记录，没有重读文件内容或验证新旧内容相同。':'所选素材已经复制到本机并建立独立工程，没有覆盖原工程。'}</p><div class="folder-drop-episodes">${rows.map(row=>`<div class="batch-result"><b>${esc(row.name||row.source_folder||'工程')}</b><p>${esc(row.state||'完成')}${row.archived?' · 已在回收站，请手动恢复':''}${row.unavailable?' · 工程暂不可用':''}${row.error?' · '+esc(row.error):''}</p>${!projectMode&&StudioFolderDrop.canOpen(row)?`<button data-folder-open="${esc(row.id)}">打开这个工程</button>`:''}</div>`).join('')}</div><div class="modal-actions"><button id="folder-drop-done" class="primary">完成</button></div>`,state);
    $$('[data-folder-open]').forEach(button=>button.onclick=handle(async()=>{const pid=button.dataset.folderOpen;closeFlow(state);await openProject(pid);tab='clips';render()}));
    $('#folder-drop-done').onclick=()=>closeFlow(state);
    const scripts=state.extraScripts||[];
    if(scripts.length&&window.studioScriptImport){const button=document.createElement('button');button.id='folder-attached-scripts';button.className='accent';button.textContent=`继续读取剧本（${scripts.length} 份）`;button.onclick=handle(async()=>{const files=scripts.map(row=>row.file),currentId=state.targetProjectId;closeFlow(state);await window.studioScriptImport.startFiles(files,{currentId})});$('#modal-body').append(button)}
    const captions=state.extraCaptions||[];
    if(captions.length&&window.studioImportSubtitleFiles){const button=document.createElement('button');button.id='folder-attached-captions';button.textContent=`继续添加字幕（${captions.length} 份）`;button.onclick=handle(async()=>{const files=captions.map(row=>row.file);closeFlow(state);await window.studioImportSubtitleFiles(files)});$('#modal-body').append(button)}
  }
  function showPartial(state,error,result){
    showComplete(state,result,false);state.phase='failed';
    const warning=document.createElement('div');warning.className='alert';warning.textContent='部分工程已经建立，不能当作全部成功或从头重复创建。'+error.message;$('#modal-body').prepend(warning);
    const retry=document.createElement('button');retry.textContent='重试同一会话的未完成部分';retry.onclick=handle(()=>startTransfer(state,true));$('#modal-body').append(retry);
  }
  const openFiles=()=>{if(canBegin())materialInput.click()};
  const openFolder=()=>{if(canBegin())input.click()};
  $('#material-picker-button').onclick=openFiles;
  $('#folder-picker-button').onclick=openFolder;
  $('#folder-drop-path').onclick=()=>{if(canBegin())$('#batch-button').click()};
  materialInput.onchange=()=>{const snapshots=Array.from(materialInput.files||[]).map(file=>({file}));materialInput.value='';if(snapshots.length)void begin(snapshots,{targetProjectId:p?.id||null})};
  input.onchange=()=>{const snapshots=Array.from(input.files||[]).map(file=>({file}));input.value='';if(snapshots.length)void begin(snapshots,{targetProjectId:p?.id||null})};
  window.addEventListener('dragenter',event=>{if(StudioFolderDrop.hasFiles(event.dataTransfer)){event.preventDefault();dragDepth++;document.body.classList.add('folder-drag-active')}});
  window.addEventListener('dragover',event=>{if(StudioFolderDrop.hasFiles(event.dataTransfer)){event.preventDefault();event.dataTransfer.dropEffect=busy()?'none':'copy'}});
  window.addEventListener('dragleave',event=>{if(StudioFolderDrop.hasFiles(event.dataTransfer)&&--dragDepth<=0){dragDepth=0;document.body.classList.remove('folder-drag-active')}});
  window.addEventListener('drop',event=>{
    if(!StudioFolderDrop.hasFiles(event.dataTransfer))return;
    event.preventDefault();dragDepth=0;document.body.classList.remove('folder-drag-active');
    const snapshots=StudioFolderDrop.capture(event.dataTransfer);
    void begin(snapshots,{targetProjectId:p?.id||null});
  });
  window.addEventListener('beforeunload',event=>{if(flow&&['starting','uploading','committing'].includes(flow.phase)){event.preventDefault();event.returnValue='素材仍在添加；关闭后可重新选择相同内容续传。'}});
  window.studioFolderDrop={busy,begin};
  window.studioMaterialImport={open:openFiles,openFolder};
}

;
// Source: font-preset.js
'use strict';
const StudioFontPreset={
  apply(project,style){
    const result=JSON.parse(JSON.stringify(project));
    result.style={...result.style,...style};
    // Explicit whole-episode apply wins over old per-cue style overrides only.
    for(const cue of result.captions){
      if(!cue.style)continue;
      for(const key of Object.keys(style))delete cue.style[key];
    }
    return result;
  }
};
if(typeof module!=='undefined')module.exports=StudioFontPreset;
function installFontPreset(){
  const old=renderInspector;
  renderInspector=function(){
    old();if(!p)return;
    const preset=boot.settings?.subtitle_reference_preset,style=preset?.style||boot.settings?.subtitle_default_style;
    if(!preset||!style)return;
    const box=document.createElement('section');box.className='subtitle-preset';
    box.innerHTML=`<h3>${esc(preset.name)}</h3><details><summary>参数说明与换算</summary><p class="helper">${esc(preset.note)}</p><p class="helper">此字体不含中文字形：中文界面由系统字体补足；中文字幕导出会提示缺字。你仍可导入其他字体、调整单句或整集字幕。</p></details><button id="apply-font-preset" class="wide accent">应用统一字幕预设（整集）</button><p class="helper">可撤销；不改文字、时间或音画。调整样式后请点“自动断行”，再重新导出烧录审阅版；旧视频不会自动改变。</p>`;
    $('#inspector').prepend(box);
    const status=document.createElement('div');status.id='subtitle-preset-status';status.setAttribute('role','status');box.append(status);
    $('#apply-font-preset').onclick=handle(async()=>{
      const pid=p.id,next=StudioFontPreset.apply(p,style);
      const changed=JSON.stringify(next.style)!==JSON.stringify(p.style)||next.captions.some((cue,i)=>JSON.stringify(cue.style)!==JSON.stringify(p.captions[i].style));
      if(changed){remember();p=next;mark();renderInspector();updateOverlay()}
      let status=$('#subtitle-preset-status');status.textContent=changed?'整集预设已应用，正在保存…':'本集样式已经与预设一致，正在检查预览…';
      $('#apply-font-preset').disabled=true;
      try{
        await save();if(p?.id!==pid)return;
        const mode=await window.studioPreviewSubtitleStyle?.();if(p?.id!==pid||mode==='switched')return;
        status=$('#subtitle-preset-status');
        const prefix=changed?'整集预设已保存。':'本集已与预设一致，无需重复修改。';
        status.innerHTML=`<p class="helper">${prefix}${mode==='live'?'播放器正在显示新样式的即时字幕；已导出的MP4仍需重新导出。':mode==='burned'?'当前是旧的烧录视频，画面内字幕不会随工程修改。请生成样式预览，或重新导出审阅版。':'本集还没有可用的当前混音，请生成样式预览。'}</p><div class="toolbar">${mode==='live'?'':'<button id="preset-style-preview">生成样式预览</button>'}<button id="preset-style-export">导出新样式审阅版</button></div>`;
        const preview=$('#preset-style-preview');if(preview)preview.onclick=handle(async()=>{preview.disabled=true;try{await submitJob('preview');status.querySelector('p').textContent='混音预览已加入队列，完成后会打开新字幕样式。'}catch(error){preview.disabled=false;throw error}});
        $('#preset-style-export').onclick=()=>$('#export-button').click();
        toast(changed?'整集字幕预设已保存；'+(mode==='live'?'已显示新样式预览':'旧视频需重新生成才能更新字幕'):'本集已经应用了这套字幕预设');
      }catch(error){if(p?.id===pid&&$('#subtitle-preset-status'))$('#subtitle-preset-status').textContent='参数已应用，但保存或预览未完成：'+error.message;throw error}
      finally{if(p?.id===pid&&$('#apply-font-preset'))$('#apply-font-preset').disabled=false}
    });
  };
  const settings=$('#settings-button').onclick;
  $('#settings-button').onclick=function(){
    settings();
    const preset=boot.settings?.subtitle_reference_preset;
    if(!preset)return;
    const note=document.createElement('section');note.className='subtitle-preset';
    note.innerHTML=`<h3>可用成片参考：${esc(preset.name)}</h3><p class="helper">${esc(preset.note)}</p><p class="helper">手动调整过的新工程默认值和界面字体会保留。中文界面使用系统字形补足。旧工程或自定义样式可在右侧点击“应用统一字幕预设（整集）”；原工程、旧导出和历史记录不会自动覆盖。</p>`;
    $('#modal-body').prepend(note);
  };
}

;
// Source: timeline-model.js
/* Pure timeline model. Video is magnetic; independent tracks keep absolute time. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.StudioTimeline=api;
})(typeof window!=='undefined'?window:globalThis,function(){
  'use strict';
  const AUDIO=new Set(['dialogue','narration','bgm','sfx']),EPS=1e-7,MAX_TIME=86400;
  const fail=message=>{throw Error(message)};
  const clone=value=>{
    if(Array.isArray(value))return value.map(clone);
    if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([key,item])=>[key,clone(item)]));
    return value;
  };
  function number(value,min,max,label){
    if(typeof value!=='number'||!Number.isFinite(value)||value<min||value>max)fail(`${label}必须为 ${min} 至 ${max} 的有效数字`);
    return value;
  }
  function fpsValue(value){
    if(typeof value!=='number'&&typeof value!=='string')fail('帧率格式无效');
    const parts=String(value).split('/');
    const syntax=parts.length===2?/^[+-]?\d+$/:/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i;
    if(parts.length>2||parts.some(part=>!syntax.test(part.trim())||!Number.isFinite(Number(part))))fail('帧率格式无效');
    return number(parts.length===2?Number(parts[0])/Number(parts[1]):Number(parts[0]),1,120,'帧率');
  }
  function frame(time,fps,label='时间'){
    number(time,0,MAX_TIME,label);
    return Math.round(time*fps)/fps;
  }
  function sourceEndLimit(asset,fps,isVideo){
    let end=asset.duration;
    if(isVideo&&typeof asset.native_duration==='number'&&Number.isFinite(asset.native_duration)){
      const rate=typeof asset.fps==='number'&&Number.isFinite(asset.fps)&&asset.fps>0?asset.fps:fps;
      // Jianying may retain a frame-aligned/material endpoint while the media
      // stream reports a slightly shorter container timestamp. Trust only a
      // nearby native endpoint; a corrupt or unrelated duration still fails.
      const drift=Math.max(.05,1/rate+EPS);
      if(asset.native_duration>=asset.duration-EPS&&asset.native_duration<=asset.duration+drift+EPS)
        end=Math.max(end,asset.native_duration);
    }
    return Math.round((end+.00001)*1e6)/1e6;
  }
  const frameCount=(clip,fps)=>Math.max(1,Math.floor((clip.out-clip.in)*fps+EPS));
  function validate(project,overlapAllowed=false){
    if(!project||typeof project!=='object')fail('工程数据无效');
    const fps=fpsValue(project.fps),assets=new Map();
    for(const key of ['assets','clips','audios','captions']){
      if(!Array.isArray(project[key])||project[key].length>10000)fail(`${key}轨道数据无效`);
      const ids=new Set();
      for(const item of project[key]){
        if(!item||typeof item.id!=='string'||!item.id||ids.has(item.id))fail(`${key}包含无效或重复ID`);
        ids.add(item.id);
      }
    }
    for(const asset of project.assets){number(asset.duration,0,Number.MAX_SAFE_INTEGER,'素材时长');assets.set(asset.id,asset)}
    for(const [list,isVideo] of [[project.clips,true],[project.audios,false]])for(const item of list){
      const asset=assets.get(item.asset_id);
      if(!asset)fail('片段引用的素材不存在');
      if(isVideo&&typeof (item.audio_detached??false)!=='boolean')fail('原声分离标记无效');
      if(isVideo&&asset.kind!=='video')fail('画面轨必须引用视频素材');
      if(isVideo&&item.start!==undefined)number(item.start,0,MAX_TIME,'画面开始时间');
      number(item.in,0,asset.duration,'源入点');number(item.out,0,sourceEndLimit(asset,fps,isVideo),'源出点');
      if(item.out<=item.in||(isVideo&&item.out-item.in<1/fps-EPS))fail(isVideo?'视频片段不能短于一帧':'音频源出点必须晚于入点');
      number(item.gain===undefined?0:item.gain,-60,12,'音量');
      if(item.audio_stream!==undefined&&item.audio_stream!==null){
        if(!Number.isInteger(item.audio_stream)||!(asset.audio_streams||[]).some(stream=>stream.index===item.audio_stream))fail('所选原声音轨不存在');
      }
      if(!isVideo){
        number(item.start,0,MAX_TIME,'音频开始时间');
        if(!AUDIO.has(item.role))fail('音频类型必须为人物原声、旁白、BGM或音效');
        if(item.loop!==undefined&&typeof item.loop!=='boolean')fail('循环设置必须为布尔值');
        if(item.loop_duration!==undefined)number(item.loop_duration,1/fps,MAX_TIME,'循环片段时长');
        if(item.loop_offset!==undefined)number(item.loop_offset,0,item.out-item.in,'循环偏移');
        const streams=asset.audio_streams||[],stream=item.audio_stream==null?(streams.length===1?streams[0]:null):streams.find(s=>s.index===item.audio_stream);
        if(stream&&stream.duration_verified&&Number.isFinite(stream.start)&&Number.isFinite(stream.end)
          &&(item.in<stream.start-.002||item.out>stream.end+.002))fail('音频源入出点超出所选音轨的有效范围');
      }
    }
    for(const cue of project.captions){
      number(cue.start,0,MAX_TIME,'字幕开始时间');number(cue.end,0,MAX_TIME,'字幕结束时间');
      if(cue.end<=cue.start)fail('字幕结束必须晚于开始');
      if(typeof cue.text!=='string'||cue.text.length>3000)fail('字幕文字必须为不超过3000字符的文本');
    }
    const masks=project.masks||[];
    if(!Array.isArray(masks)||masks.length>200)fail('打码轨道数据无效');
    const maskIds=new Set();
    for(const mask of masks){
      if(!mask||typeof mask.id!=='string'||!mask.id||maskIds.has(mask.id))fail('打码包含无效或重复ID');
      maskIds.add(mask.id);
      number(mask.start,0,MAX_TIME,'打码开始');number(mask.end,0,MAX_TIME,'打码结束');
      if(mask.end-mask.start<1/fps-EPS)fail('打码时长不能短于一帧');
      number(mask.w,16,4320,'打码宽度');number(mask.h,16,7680,'打码高度');
      number(mask.x,-mask.w,1080,'打码横坐标');number(mask.y,-mask.h,1920,'打码纵坐标');
      if(mask.x>=1080||mask.y>=1920||mask.x+mask.w<=0||mask.y+mask.h<=0)fail('打码区域必须与画面相交');
      number(mask.blur,1,40,'模糊强度');number(mask.white,0,.6,'白色强度');
      number(mask.feather??0,0,1,'羽化强度');
      if(!['blur','solid'].includes(mask.mode||'blur'))fail('打码类型无效');
      if(!['below_captions','above_captions'].includes(mask.layer||'below_captions'))fail('打码层级无效');
      if(!Array.isArray(mask.keyframes)||mask.keyframes.length>100)fail('打码关键帧无效');
      let last=mask.start;
      for(const point of mask.keyframes){
        number(point.time,mask.start,mask.end,'关键帧时间');
        if(point.time<=last+EPS)fail('打码关键帧必须按时间递增，且晚于打码开始');
        if(point.time>=mask.end-EPS)fail('打码关键帧必须早于打码结束');
        const width=point.w??mask.w,height=point.h??mask.h;
        number(width,16,4320,'关键帧宽度');number(height,16,7680,'关键帧高度');
        number(point.x,-width,1080,'关键帧横坐标');number(point.y,-height,1920,'关键帧纵坐标');
        if(point.x>=1080||point.y>=1920||point.x+width<=0||point.y+height<=0)fail('关键帧打码区域必须与画面相交');
        last=point.time;
      }
    }
    if(!overlapAllowed){
      const sorted=[...project.captions].sort((a,b)=>a.start-b.start||a.end-b.end);
      for(let index=1;index<sorted.length;index++)if(sorted[index].start<sorted[index-1].end-EPS)fail('字幕时间重叠，请先调整边界；不能让两条字幕同时出现');
    }
    return {fps,assets};
  }
  function layout(project){
    const {fps,assets}=validate(project,true),items=[],warnings=[];
    let cursor=0;
    for(const clip of project.clips){
      const count=frameCount(clip,fps),asset=assets.get(clip.asset_id),start=clip.start===undefined?cursor/fps:frame(clip.start,fps),end=start+count/fps;
      const common={id:clip.id,start,end,sourceIn:clip.in,sourceOut:clip.out,asset_id:clip.asset_id,linked:true,linkedId:clip.id,
        gain:clip.gain===undefined?0:clip.gain,audio_stream:clip.audio_stream??null,loop:false,label:asset.name||'视频素材',frames:count};
      items.push({...common,kind:'video'});
      if(!clip.audio_detached)items.push({...common,kind:'original',hasAudio:!!asset.has_audio,label:asset.has_audio?'人物原声':'无原声（静音）'});
      cursor=Math.max(cursor,Math.round(end*fps));
    }
    const duration=Math.max(cursor/fps,project.native?.shared?Math.ceil((project.native.duration_us||0)/1e6*fps-1e-7)/fps:0);
    for(const cue of project.captions)items.push({kind:'caption',id:cue.id,start:cue.start,end:cue.end,sourceIn:null,sourceOut:null,linked:false,text:cue.text,label:cue.text,loop:false});
    for(const mask of project.masks||[])items.push({kind:'mask',id:mask.id,start:mask.start,end:mask.end,sourceIn:null,sourceOut:null,linked:false,label:'打码遮挡',loop:false});
    for(const audio of project.audios){
      const looping=audio.role==='bgm'&&audio.loop===true,asset=assets.get(audio.asset_id);
      items.push({kind:audio.role,id:audio.id,start:audio.start,end:looping?(audio.loop_duration===undefined?Math.max(audio.start,duration):audio.start+audio.loop_duration):audio.start+audio.out-audio.in,
        sourceIn:audio.in,sourceOut:audio.out,asset_id:audio.asset_id,linked:false,gain:audio.gain===undefined?0:audio.gain,
        audio_stream:audio.audio_stream??null,loop:!!audio.loop,effectiveLoop:looping,label:asset.name||'音频素材'});
      if(audio.loop&&audio.role!=='bgm')warnings.push('循环仅对BGM生效；当前非BGM音频的循环标记不改变渲染长度。');
    }
    const captions=[...project.captions].sort((a,b)=>a.start-b.start);
    if(captions.some((cue,index)=>index&&cue.start<captions[index-1].end-EPS))warnings.push('已有字幕时间重叠，可逐条修复；正式交付前必须消除重叠。');
    if(items.some(item=>!item.linked&&item.end>duration+EPS))warnings.push('部分字幕、打码或独立音频超出画面范围，导出时不能完整出现，请调整。');
    return {fps,duration,items,warnings:[...new Set(warnings)]};
  }
  function get(project,kind,id){
    const item=layout(project).items.find(item=>item.kind===kind&&item.id===id);
    if(!item)fail('所选时间线片段已不存在，请刷新后重试');
    return item;
  }
  function newIdentifier(project,newId){
    const id=typeof newId==='function'?newId():newId;
    if(typeof id!=='string'||!id||[...project.clips,...project.audios,...project.captions,...(project.masks||[])].some(item=>item.id===id))fail('切分需要一个新的、不重复的片段ID');
    return id;
  }
  function preserveOrReduceOverlaps(before,after){
    const previous=new Map(before.captions.map(cue=>[cue.id,cue]));
    const overlap=(left,right)=>left&&right?Math.max(0,Math.min(left.end,right.end)-Math.max(left.start,right.start)):0;
    // Only time-changed/new cues can add or worsen a pair. This permits repairing
    // one fault at a time and avoids quadratic work for unrelated audio edits.
    const changed=after.captions.filter(cue=>{
      const old=previous.get(cue.id);
      return !old||old.start!==cue.start||old.end!==cue.end;
    });
    for(const cue of changed)for(const other of after.captions){
      if(cue.id===other.id)continue;
      const currentOverlap=overlap(cue,other);
      if(currentOverlap>overlap(previous.get(cue.id),previous.get(other.id))+EPS)
        fail('字幕时间重叠新增或加重，请调整边界；已有重叠可以逐条修复');
    }
  }
  function patchItem(item,patch,allowed,fps){
    if(!patch||typeof patch!=='object'||Array.isArray(patch))fail('请提供需要修改的字段');
    if(Object.keys(patch).some(key=>!allowed.includes(key)))fail('此轨道不允许修改所提供的字段');
    for(const [key,value] of Object.entries(patch)){
      // The property form submits unchanged timing fields together with gain.
      // Preserve legacy source offsets exactly unless that field was changed.
      if(value===item[key])continue;
      item[key]=['start','end','in','out'].includes(key)?frame(value,fps,key):clone(value);
    }
  }
  function maskPosition(mask,t){
    const points=[{time:mask.start,x:mask.x,y:mask.y,w:mask.w,h:mask.h}];
    for(const raw of mask.keyframes)points.push({...points.at(-1),...raw});
    for(let index=1;index<points.length;index++){
      const left=points[index-1],right=points[index];
      if(t<=right.time){const ratio=Math.max(0,Math.min(1,(t-left.time)/(right.time-left.time)));
        return {x:left.x+(right.x-left.x)*ratio,y:left.y+(right.y-left.y)*ratio,w:left.w+(right.w-left.w)*ratio,h:left.h+(right.h-left.h)*ratio}}
    }
    return {x:points.at(-1).x,y:points.at(-1).y,w:points.at(-1).w,h:points.at(-1).h};
  }
  function apply(project,operation,newId){
    const beforeLayout=layout(project),fps=beforeLayout.fps;
    if(!operation||typeof operation!=='object')fail('时间线操作无效');
    const {type,kind,id}=operation;
    if(type==='reorder_selection'){
      if(!Array.isArray(operation.items)||!operation.items.length||operation.items.length>10000)fail('请选择要排序的片段');
      const chosen=new Map();for(const entry of operation.items){const view=get(project,entry.kind,entry.id);chosen.set(view.kind+':'+view.id,view)}
      const videoIds=new Set([...chosen.values()].filter(v=>v.kind==='video').map(v=>v.id));
      for(const entry of chosen.values()){const linked=project.native_links?.[entry.id]?.linked_video_id;if(linked)videoIds.add(linked)}
      if(!videoIds.has(id))fail('请从选中的画面拖动整组选区');
      if((project.track_locks||[]).includes('video'))fail('画面轨道已锁定');
      const indices=project.clips.map((c,i)=>videoIds.has(c.id)?i:-1).filter(i=>i>=0);
      if(indices.at(-1)-indices[0]+1!==indices.length)fail('主轨整组排序需选择连续镜头；非连续选区请关闭主轨磁吸后整体移动');
      const next=clone(project),block=next.clips.filter(c=>videoIds.has(c.id)),rest=next.clips.filter(c=>!videoIds.has(c.id));
      if(!Number.isInteger(operation.targetIndex)||operation.targetIndex<0||operation.targetIndex>rest.length)fail('目标排序位置无效');
      rest.splice(operation.targetIndex,0,...block);next.clips=rest;for(const clip of next.clips)delete clip.start;
      const delta=get(next,'video',id).start-get(project,'video',id).start;
      for(const view of chosen.values()){
        if(view.kind==='video'||videoIds.has(project.native_links?.[view.id]?.linked_video_id))continue;
        if(view.kind==='original')fail('内嵌原声请随对应画面移动');
        if((project.track_locks||[]).includes(view.kind))fail('所选跟随轨道已锁定');
        if(view.start+delta<-EPS)fail('排序后选中片段会产生负时间');
        const list=view.kind==='caption'?next.captions:view.kind==='mask'?next.masks:next.audios,row=list.find(row=>row.id===view.id);
        row.start=view.start+delta;if(['caption','mask'].includes(view.kind))row.end=view.end+delta;
        if(view.kind==='mask')row.keyframes=row.keyframes.map(point=>({...point,time:point.time+delta}));
      }
      validate(next,true);preserveOrReduceOverlaps(project,next);
      next.reviews={};for(const cue of next.captions)delete cue.speech;
      return {project:next,warnings:['连续镜头整组插入排序；所选独立轨道跟随拖动镜头的时间差，未选独立轨道不动。']};
    }
    if(type==='replace_video'){
      const view=get(project,'video',id),asset=project.assets.find(a=>a.id===operation.asset_id);
      if(!asset||asset.kind!=='video')fail('请选择已导入的视频素材');
      if(!['fit','gap','ripple'].includes(operation.strategy))fail('请选择保长裁切、保留空位或推动后续');
      const sourceIn=frame(operation.in??0,fps,'新素材入点'),available=frame(operation.out??Math.floor(asset.duration*fps)/fps,fps,'新素材出点')-sourceIn;
      if(available<1/fps-EPS||sourceIn+available>sourceEndLimit(asset,fps,true)+EPS)fail('新素材选段无效');
      const length=view.end-view.start;
      if(operation.strategy==='fit'&&available<length-EPS)fail('新素材不足原片段长度，请改选保留空位或推动后续，不会自动补帧');
      const used=operation.strategy==='ripple'?available:Math.min(length,available),delta=used-length;
      const next=clone(project),clip=next.clips.find(c=>c.id===id);
      for(const row of next.clips)row.start=get(project,'video',row.id).start;
      if((project.track_locks||[]).includes('video'))fail('画面轨道已锁定');
      clip.asset_id=asset.id;clip.in=sourceIn;clip.out=sourceIn+used;
      if(operation.audio_stream===undefined)delete clip.audio_stream;else clip.audio_stream=operation.audio_stream;
      if(operation.strategy==='ripple'){
        const follow=operation.follow??[];
        if(!Array.isArray(follow)||follow.some(kind=>!['caption','mask',...AUDIO].includes(kind)))fail('跟随轨道设置无效');
        for(const row of next.clips)if(row.id!==id&&row.start>=view.end-EPS)row.start+=delta;
        for(const entry of beforeLayout.items)if(follow.includes(entry.kind)&&entry.start>=view.end-EPS){
          if((project.track_locks||[]).includes(entry.kind)&&Math.abs(delta)>EPS)fail('需要跟随移动的轨道已锁定');
          const list=entry.kind==='caption'?next.captions:entry.kind==='mask'?next.masks:next.audios;
          const row=list.find(row=>row.id===entry.id);row.start+=delta;
          if(['caption','mask'].includes(entry.kind))row.end+=delta;
          if(entry.kind==='mask')row.keyframes=row.keyframes.map(point=>({...point,time:point.time+delta}));
        }
      }
      validate(next,true);preserveOrReduceOverlaps(project,next);
      const videos=layout(next).items.filter(row=>row.kind==='video').sort((a,b)=>a.start-b.start);
      for(let i=1;i<videos.length;i++)if(videos[i].start<videos[i-1].end-EPS)fail('替换后画面重叠，工程未修改');
      next.reviews={};for(const cue of next.captions)delete cue.speech;
      return {project:next,warnings:['仅替换所选画面及其已联动的原声；独立声音保持不变，请试听确认。']};
    }
    if(type==='move_selection'){
      if(!Array.isArray(operation.items)||!operation.items.length||operation.items.length>10000)fail('请选择需要一起移动的片段');
      number(operation.delta,-MAX_TIME,MAX_TIME,'移动时间差');
      const delta=Math.round(operation.delta*fps)/fps,next=clone(project),chosen=new Map();
      for(const entry of operation.items){
        if(!entry||entry.kind==='original')fail('内嵌原声请先分离，或选择对应画面');
        const view=get(project,entry.kind,entry.id);chosen.set(view.kind+':'+view.id,view);
      }
      // Include an existing native pair once. Never infer caption/music links.
      for(const view of [...chosen.values()]){
        const link=project.native_links?.[view.id];
        const peer=link?.linked_audio_id?get(project,'dialogue',link.linked_audio_id):link?.linked_video_id?get(project,'video',link.linked_video_id):null;
        if(peer)chosen.set(peer.kind+':'+peer.id,peer);
      }
      for(const clip of next.clips)clip.start=get(project,'video',clip.id).start;
      for(const view of chosen.values()){
        if((project.track_locks||[]).includes(view.kind))fail('所选片段或关联原声的轨道已锁定');
        if(view.start+delta<-EPS)fail('移动后不能产生负时间');
        const list=view.kind==='video'?next.clips:view.kind==='caption'?next.captions:view.kind==='mask'?next.masks:next.audios;
        const record=list.find(row=>row.id===view.id);
        record.start=Math.max(0,view.start+delta);
        if(['caption','mask'].includes(view.kind))record.end=view.end+delta;
        if(view.kind==='mask')record.keyframes=record.keyframes.map(point=>({...point,time:point.time+delta}));
        if(view.kind==='caption')delete record.speech;
      }
      next.clips.sort((a,b)=>a.start-b.start);
      validate(next,true);
      const videos=layout(next).items.filter(row=>row.kind==='video').sort((a,b)=>a.start-b.start);
      for(let i=1;i<videos.length;i++)if(videos[i].start<videos[i-1].end-EPS)fail('画面片段重叠：请把整组选区放到空白区');
      preserveOrReduceOverlaps(project,next);
      if([...chosen.values()].some(view=>!['caption','mask'].includes(view.kind)))for(const cue of next.captions)delete cue.speech;
      next.reviews={};
      return {project:next,warnings:['只移动所选片段与其已联动原声；未选字幕、旁白、音乐保持原位置。',...layout(next).warnings]};
    }
    const linkedVideo=project.native_links?.[id]?.linked_video_id;
    if(type==='unlink'){
      if(!project.native?.shared||!['video','dialogue'].includes(kind))fail('请选择已联动的画面或人物原声');
      get(project,kind,id);
      const videoId=kind==='video'?id:linkedVideo,audioId=kind==='dialogue'?id:project.native_links?.[id]?.linked_audio_id;
      if(!videoId||!audioId||project.native_links?.[audioId]?.linked_video_id!==videoId)fail('这段原声已经独立，无须解除联动');
      if((project.track_locks||[]).some(k=>['video','dialogue'].includes(k)))fail('画面或原声轨道已锁定，请先解锁');
      const next=clone(project),audio=next.audios.find(a=>a.id===audioId);
      if(!audio)fail('关联原声已不存在');
      audio.linked_video_id=null;
      delete next.native_links[videoId].linked_audio_id;delete next.native_links[audioId].linked_video_id;
      next.reviews={};return {project:next,selection:{kind:'dialogue',id:audioId},warnings:['已解除联动，原声可单独移动。']};
    }
    if(linkedVideo&&type==='split')return apply(project,{...operation,kind:'video',id:linkedVideo},newId);
    if(type==='style'){
      if(kind!=='caption'||!operation.patch||typeof operation.patch!=='object'||Array.isArray(operation.patch))fail('字幕样式操作无效');
      if(Object.keys(operation.patch).some(k=>!Object.hasOwn(project.style,k)))fail('不支持的字幕样式字段');
      if((project.track_locks||[]).includes('caption'))fail('字幕轨道已锁定');
      const next=clone(project),patch=clone(operation.patch);
      if(operation.scope==='all'){
        Object.assign(next.style,patch);for(const cue of next.captions)for(const field of Object.keys(patch))if(cue.style)delete cue.style[field];
      }else if(operation.scope==='one'){
        const cue=next.captions.find(c=>c.id===id);if(!cue)fail('字幕已不存在');cue.style={...cue.style,...patch};
      }else fail('请明确选择整集或单条字幕');
      next.reviews={};return {project:next,warnings:[]};
    }
    if(type==='lock'){
      if(!['video','original','caption','mask',...AUDIO].includes(kind)||typeof operation.locked!=='boolean')fail('轨道锁定参数无效');
      const next=clone(project);next.track_locks=[...new Set(project.track_locks||[])].filter(k=>k!==kind);
      if(operation.locked)next.track_locks.push(kind);
      return {project:next,warnings:[]};
    }
    if(!['move','trim','split','remove','update','reorder'].includes(type))fail('不支持的时间线操作');
    if(!['video','original','caption','mask',...AUDIO].includes(kind))fail('不支持的轨道类型');
    const view=get(project,kind,id),next=clone(project),warnings=[];
    const videoViews=project.clips.map(clip=>beforeLayout.items.find(row=>row.kind==='video'&&row.id===clip.id));
    const magneticVideo=operation.magnetic!==false&&videoViews.every((row,index)=>row&&(index===0?Math.abs(row.start)<EPS:Math.abs(row.start-videoViews[index-1].end)<EPS));
    if((project.track_locks||[]).includes(kind))fail('这条轨道已锁定，请先解锁');
    const list=kind==='video'||kind==='original'?next.clips:kind==='caption'?next.captions:kind==='mask'?next.masks:next.audios;
    const index=list.findIndex(item=>item.id===id),item=list[index];
    if(kind==='video'&&type!=='reorder'&&(type==='move'||!magneticVideo))for(const video of next.clips){video.start=beforeLayout.items.find(v=>v.kind==='video'&&v.id===video.id).start}
    if(kind==='original'&&type!=='update'){
      if((project.track_locks||[]).includes('dialogue'))fail('人物原声轨已锁定，请先解锁');
      const a=project.assets.find(a=>a.id===item.asset_id),streams=a.audio_streams||[];
      const stream=item.audio_stream==null?(streams.length===1?streams[0]:null):streams.find(s=>s.index===item.audio_stream);
      if(!stream||!stream.duration_verified)fail('请先明确选择已确认时长的原声音轨');
      const sourceIn=Math.max(item.in,stream.start||0),sourceOut=Math.min(item.in+view.end-view.start,stream.end);
      if(sourceOut<=sourceIn)fail('此画面选段内没有有效原声');
      const audio={id:newIdentifier(next,newId),asset_id:item.asset_id,role:'dialogue',start:view.start+sourceIn-item.in,in:sourceIn,out:sourceOut,
        gain:item.gain||0,audio_stream:stream.index,detached_from:item.id,loop:false};
      item.audio_detached=true;next.audios.push(audio);
      const result=apply(next,{...operation,kind:'dialogue',id:audio.id},newId);
      return {...result,selection:{kind:'dialogue',id:audio.id},warnings:['原声已分离，画面保持位置。',...result.warnings]};
    }
    if(kind==='caption'&&type==='split')fail('字幕不能自动复制切分；请先按语义人工分句，再分别设置起止时间');
    if(kind==='mask'&&type==='split')fail('打码暂不支持切分；请添加第二个打码区间');
    if(type==='update'){
      const patch=operation.patch;
      if(kind==='original')patchItem(item,patch,['gain','audio_stream'],fps);
      else if(kind==='video'){patchItem(item,patch,['start','in','out','gain','audio_stream'],fps);if(magneticVideo&&('in' in patch||'out' in patch))for(const clip of next.clips)delete clip.start}
      else if(kind==='caption')patchItem(item,patch,['text','start','end','style'],fps);
      else if(kind==='mask')patchItem(item,patch,['start','end','x','y','w','h','blur','white','feather','mode','layer','keyframes'],fps);
      else{
        if(patch&&patch.role!==undefined&&patch.role!==item.role&&item.loop&&patch.loop===undefined)fail('改变带循环标记的音频类型前，请明确关闭循环，避免渲染语义变化');
        patchItem(item,patch,['start','in','out','gain','audio_stream','loop','role','loop_duration','loop_offset'],fps);
        if(patch&&patch.loop===true&&item.role!=='bgm')fail('只有BGM支持循环，请先选择BGM类型');
        if(item.loop&&item.role==='bgm'&&(patch.loop===true||patch.role==='bgm'))warnings.push('循环BGM会从开始位置持续到画面结尾，不以单次素材长度结束。');
      }
    }else if(type==='remove'){list.splice(index,1);if(kind==='video'&&magneticVideo)for(const clip of next.clips)delete clip.start}
    else if(type==='reorder'){
      if(kind!=='video')fail('只有磁吸视频轨支持插入排序；其他轨道请移动绝对时间');
      let target;
      if(type==='reorder'){
        if(!Number.isInteger(operation.targetIndex)||operation.targetIndex<0||operation.targetIndex>=list.length)fail('视频目标排序位置无效');
        target=operation.targetIndex;
      }else{
        const targetTime=frame(operation.targetTime,fps,'目标时间');
        target=beforeLayout.items.filter(v=>v.kind==='video'&&v.id!==id&&targetTime>=(v.start+v.end)/2).length;
      }
      list.splice(index,1);list.splice(target,0,item);
      for(const clip of list)delete clip.start;
    }else if(type==='move'){
      const start=frame(operation.targetTime,fps,'目标时间');
      if(kind==='video')for(const video of next.clips){const previous=beforeLayout.items.find(v=>v.kind==='video'&&v.id===video.id);video.start=previous.start}
      if(kind==='caption'||kind==='mask'){
        const length=item.end-item.start;
        if(kind==='mask'){const delta=start-item.start;item.keyframes=item.keyframes.map(point=>({...point,time:point.time+delta}))}
        item.start=start;item.end=start+length;
      }else item.start=start;
    }else if(type==='trim'){
      if(operation.start===undefined&&operation.end===undefined)fail('请指定裁剪开始或结束时间');
      const start=operation.start===undefined?view.start:frame(operation.start,fps,'裁剪开始');
      const end=operation.end===undefined?view.end:frame(operation.end,fps,'裁剪结束');
      if(end<=start)fail('裁剪结束必须晚于开始');
      if(kind==='video'){
        if(!magneticVideo)for(const video of next.clips){const previous=beforeLayout.items.find(v=>v.kind==='video'&&v.id===video.id);video.start=previous.start}
        const oldIn=item.in;
        if(operation.start!==undefined)item.in=oldIn+(start-view.start);
        if(operation.end!==undefined&&Math.abs(end-view.end)>EPS)item.out=oldIn+(end-view.start);
        if(magneticVideo)for(const video of next.clips)delete video.start;else item.start=start;
      }else if(kind==='caption'){item.start=start;item.end=end}
      else if(kind==='mask'){
        if(start>view.start+EPS){const at=maskPosition(item,start);item.x=at.x;item.y=at.y;item.w=at.w;item.h=at.h}
        item.start=start;item.end=end;
        item.keyframes=item.keyframes.filter(point=>point.time>start+EPS&&point.time<end-EPS);
      }
      else if(kind==='bgm'&&item.loop){
        const period=item.out-item.in;
        item.loop_offset=(((item.loop_offset||0)+start-view.start)%period+period)%period;
        item.start=start;item.loop_duration=end-start;
      }else{
        const oldIn=item.in;
        item.in=oldIn+(start-view.start);item.out=oldIn+(end-view.start);item.start=start;
      }
    }else if(type==='split'){
      const time=frame(operation.time,fps,'切分时间');
      const offsetFrames=Math.round((time-view.start)*fps);
      const totalFrames=kind==='video'?frameCount(item,fps):null;
      if(kind==='video'?(offsetFrames<=0||offsetFrames>=totalFrames):(time-view.start<1/fps-EPS||view.end-time<1/fps-EPS))fail('请在片段内部按帧切分，两侧至少各保留一帧');
      if(kind==='bgm'&&item.loop){
        const right=clone(item),period=item.out-item.in;right.id=newIdentifier(next,newId);
        right.start=time;right.loop_duration=view.end-time;right.loop_offset=((item.loop_offset||0)+time-view.start)%period;
        item.loop_duration=time-view.start;list.splice(index+1,0,right);
        validate(next,true);return {project:next,warnings:[]};
      }
      const right=clone(item),boundary=item.in+(kind==='video'?offsetFrames/fps:time-view.start);
      right.id=newIdentifier(next,newId);right.in=boundary;item.out=boundary;
      if(kind==='video'){if(magneticVideo){for(const video of next.clips)delete video.start;delete right.start}else{for(const video of next.clips){const previous=beforeLayout.items.find(v=>v.kind==='video'&&v.id===video.id);video.start=previous.start}right.start=time}}
      if(AUDIO.has(kind)){
        right.start=time;
        // Preserve optional legacy fades at the outside edges only. This does
        // not claim custom fades are currently supported by the renderer.
        if(Object.hasOwn(item,'fade_out'))item.fade_out=0;
        if(Object.hasOwn(right,'fade_in'))right.fade_in=0;
      }
      list.splice(index+1,0,right);
    }
    validate(next,true);
    const videos=layout(next).items.filter(v=>v.kind==='video').sort((a,b)=>a.start-b.start);
    for(let i=1;i<videos.length;i++)if(videos[i].start<videos[i-1].end-EPS)fail('画面片段重叠：请放到空白区，或先移开相邻镜头');
    preserveOrReduceOverlaps(project,next);
    const changed=JSON.stringify(next)!==JSON.stringify(project);
    if(changed){
      next.reviews={};
      if(kind==='video'||kind==='original'||AUDIO.has(kind)){
        for(const cue of next.captions)delete cue.speech;
        warnings.push('声音版本已变化，已清除字幕发声验证；请重新试听并确认字幕同步。');
      }else if(kind==='caption'){
        for(const cue of next.captions)if(cue.id===id)delete cue.speech;
        warnings.push('字幕内容或时间已修改，请重新核对实际发声与字幕边界。');
      }else if(kind==='mask'){
        warnings.push('打码已修改；旧预览不会自动更新，请重新生成并检查遮挡范围。');
      }
      if(kind==='video')warnings.push(project.native_links?.[id]?.linked_audio_id?'画面与关联原声同步修改；主轨保持吸附。':'主轨保持吸附；字幕和独立声音保留原时间。');
    }
    return {project:next,warnings:[...new Set([...warnings,...layout(next).warnings])]};
  }
  return {layout,get,apply,fpsValue};
});

;
// Source: timeline.js
'use strict';
function studioAudioRelation(project,item){
  if(!project||!item||!['video','original','dialogue'].includes(item.kind))return null;
  const link=project.native_links?.[item.id],videoId=link?.linked_video_id||(link?.linked_audio_id?item.id:null);
  const clip=project.clips.find(c=>c.id===(videoId||item.id));
  const number=String(project.clips.findIndex(c=>c.id===(videoId||item.id))+1).padStart(2,'0');
  if(videoId)return {state:'linked',pair:videoId,label:`联动 ${number}`,detail:`已分轨，仍与画面联动（${number}组）。移动、裁剪或删除任一条，会同时影响同组画面和原声；音量分别调整。`};
  if(item.kind==='dialogue')return {state:'independent',pair:null,label:'独立原声',detail:'已独立：移动、裁剪或删除这段原声，不会带动画面。'};
  const source=project.assets.find(a=>a.id===clip?.asset_id);
  if(!source?.has_audio)return {state:'silent',pair:null,label:'无原声',detail:'源视频没有原声音轨。'};
  if(clip?.audio_detached)return {state:'independent',pair:null,label:'画面独立',detail:'画面原声已关闭，与声音轨没有联动关系。移动、裁剪画面不会带动独立音频；声音请在对应音频轨调整。'};
  return {state:'embedded',pair:clip?.id,label:`未分离 ${number}`,detail:item.kind==='original'?'未分离：这是视频内的原声。拖动这条原声会先自动分离，再独立移动；也可点击“分离音频”。':'未分离：原声仍在视频内，移动、裁剪画面时原声一起变化。'};
}
/* A view/editor for the existing render model, not a second hidden timeline. */
function installStudioTimeline(){
  const root=$('#timeline');
  if(!root||typeof StudioTimeline==='undefined')return;
  const old={render,mark,renderInspector,updateOverlay,openProject,viewRender};
  const kinds=[['mask','打码','#f5f7ec'],['caption','字幕','#db987b'],['video','主轨','#5abdb3'],['original','内嵌原声','#5d9ed3'],['dialogue','人物原声','#70b7ed'],['narration','旁白 / 配音','#b198dc'],['bgm','背景音乐','#7db28c'],['sfx','音效','#d5b36c']];
  const kindName=kind=>kinds.find(row=>row[0]===kind)?.[1]||kind;
  const kindColor=kind=>kinds.find(row=>row[0]===kind)?.[2]||'#8fa0b5';
  function visibleTracks(layout){
    const has=kind=>layout.items.some(item=>item.kind===kind);
    return [
      {key:'mask',name:'效果',icon:'◆',kinds:['mask'],color:'#f5f7ec',show:has('mask')},
      {key:'caption',name:'字幕',icon:'T',kinds:['caption'],color:'#db987b',show:has('caption')},
      {key:'video',name:'主轨',icon:'▣',kinds:['video'],color:'#5abdb3',show:true},
      {key:'audio',name:'音频',icon:'♫',kinds:['dialogue','narration','bgm','sfx'],color:'#70b7ed',show:['dialogue','narration','bgm','sfx'].some(has)}
    ].filter(track=>track.show);
  }
  const state={pid:null,selection:null,selections:[],magnetic:true,follow:new Set(),cursor:0,scale:24,snap:true,collapsed:false,focus:false,drag:null,layout:null,frame:null,media:new Map(),pending:new Set(),loading:0,stale:false,locked:new Set(),mediaEpoch:0};
  const key=(kind,itemId)=>kind+':'+itemId;
  const sig=()=>JSON.stringify([p?.clips,p?.audios,p?.captions,p?.masks,p?.fps]);
  const viewSignature=()=>JSON.stringify([p?.id,p?.clips,p?.audios,p?.captions,p?.masks,p?.fps,p?.assets,p?.style,p?.track_locks,p?.native_links,p?.native]);
  const labelWidth=()=>Number.parseFloat(getComputedStyle(root).getPropertyValue('--track-label'))||114;
  const maxScale=()=>Math.max(600,rate()*20);
  function zoomTo(value,clientX){
    const scroll=root.querySelector('.tl-scroll');if(!scroll||state.drag)return;
    const x=clientX==null?scroll.clientWidth/2:Math.max(labelWidth(),clientX-scroll.getBoundingClientRect().left);
    const anchor=Math.max(0,(scroll.scrollLeft+x-labelWidth())/state.scale);
    const next=Math.max(5,Math.min(maxScale(),value));if(next===state.scale)return;
    state.scale=next;draw();
    root.querySelector('.tl-scroll').scrollLeft=Math.max(0,labelWidth()+anchor*next-x);
  }
  root.addEventListener('wheel',event=>{
    const scroll=event.target.closest('.tl-scroll');if(!scroll||!p)return;
    // Ordinary wheel keeps native vertical track scrolling. Ctrl zooms, Shift pans.
    if(!event.ctrlKey){
      if(event.shiftKey){event.preventDefault();const unit=event.deltaMode===1?16:event.deltaMode===2?scroll.clientWidth:1;scroll.scrollLeft+=(event.deltaY||event.deltaX)*unit}
      return;
    }
    event.preventDefault();
    if(!event.deltaY)return;
    if(state.drag)return;
    const delta=event.deltaY*(event.deltaMode===1?16:event.deltaMode===2?scroll.clientHeight:1);
    zoomTo(state.scale*Math.exp(-Math.max(-240,Math.min(240,delta))*.002),event.clientX);
  },{passive:false});
  const quant=t=>Math.max(0,Math.round(t*rate())/rate());
  const itemNow=layout=>{try{return state.selection&&p?(layout||StudioTimeline.layout(p)).items.find(item=>item.kind===state.selection.kind&&item.id===state.selection.id)||null:null}catch(e){return null}};
  const editing=()=>document.activeElement?.matches('input,textarea,select,[contenteditable=true]');
  const getRecord=item=>item.kind==='caption'?p.captions.find(c=>c.id===item.id):item.kind==='mask'?(p.masks||[]).find(c=>c.id===item.id):['video','original'].includes(item.kind)?p.clips.find(c=>c.id===item.id):p.audios.find(c=>c.id===item.id);
  const heading=item=>item.kind==='caption'?getRecord(item)?.text:item.kind==='mask'?'打码遮挡':asset(item.asset_id)?.name||'素材';
  const soundKind=kind=>!['caption','mask'].includes(kind);
  function reset(){state.pid=p?.id||null;state.selection=null;state.selections=[];state.cursor=0;state.drag=null;state.stale=false;state.mediaEpoch++;state.media.clear();state.locked.clear();state.drawnSignature=null;}
  function schedule(){if(state.frame)return;state.frame=requestAnimationFrame(()=>{
    state.frame=null;
    if(root.contains(document.activeElement)&&document.activeElement?.matches('input,textarea,select')){state.redrawPending=true;return}
    if(!state.drag){state.redrawPending=false;draw()}
  })}
  root.addEventListener('focusout',()=>{if(state.redrawPending)schedule()});
  function setCursor(value,seek=true){
    state.cursor=Math.max(0,Math.min(total(),Number(value)||0));
    const video=$('#video');
    if(seek){if(window.StudioRealtime?.editing())StudioRealtime.seek(state.cursor);else{video.pause();if(video.getAttribute('src')){try{video.currentTime=Math.min(state.cursor,Number.isFinite(video.duration)?video.duration:state.cursor)}catch(e){}}}}
    $('#seek').value=state.cursor;$('#timecode').textContent=time(state.cursor);
    updateOverlay(state.cursor);paintCursor();
  }
  function paintCursor(){
    const line=root.querySelector('.tl-playhead');if(line)line.style.left=(labelWidth()+state.cursor*state.scale)+'px';
    const field=$('#tl-position');if(field&&document.activeElement!==field)field.value=time(state.cursor);
  }
  function selectedItems(layout){
    if(!p||!state.selections.length)return [];
    try{
      const available=new Set((layout||StudioTimeline.layout(p)).items.map(item=>key(item.kind,item.id)));
      return state.selections.filter(entry=>available.has(key(entry.kind,entry.id)));
    }catch{return []}
  }
  function selectionHas(kind,itemId){return state.selections.some(entry=>entry.kind===kind&&entry.id===itemId)}
  function renderSelection(previousTab){
    // Selecting an existing clip changes highlights and properties, not track DOM,
    // thumbnails, the caption list, or the compiled playback timeline.
    if(previousTab!==tab||state.drawnSignature!==viewSignature()||!window.StudioRealtime?.editing()||!$('#tl-split')||
       (tab==='captions'&&state.locked.has('caption'))||(tab==='masks'&&state.locked.has('mask'))){render();return}
    const active=itemNow(state.layout),locked=active&&state.locked.has(active.kind),multiple=state.selections.length>1;
    const pairs=new Set(state.selections.map(entry=>studioAudioRelation(p,entry)?.pair).filter(Boolean));
    root.querySelectorAll('[data-tl-id]').forEach(node=>{
      const kind=node.dataset.tlKind,id=node.dataset.tlId,pair=studioAudioRelation(p,{kind,id})?.pair;
      node.classList.toggle('selected',selectionHas(kind,id)||!!pair&&pairs.has(pair));
    });
    $('#tl-split').disabled=multiple||!active||locked||['caption','mask'].includes(active.kind);
    $('#tl-delete').disabled=multiple||!active||locked;
    $('#tl-detach-audio').disabled=multiple||!active||!['video','original'].includes(active.kind)||locked||state.locked.has('video')||state.locked.has('original')||getRecord(active)?.audio_detached||!asset(active.asset_id)?.has_audio;
    $('#tl-unlink-audio')?.remove();
    if(studioAudioRelation(p,active)?.state==='linked'){
      const unlink=document.createElement('button');unlink.id='tl-unlink-audio';unlink.textContent='解除联动';unlink.disabled=!canUnlink();unlink.title='解除后声音可单独拖动';unlink.onclick=handle(unlinkSelected);$('#tl-detach-audio').after(unlink);
    }
    root.querySelector('.tl-edit-settings summary').textContent=`联动设置 · ${state.selections.length} 项`;
    $$('[data-cue]').forEach(node=>node.classList.toggle('selected',node.dataset.cue===selected));
    $$('[data-mask-card]').forEach(node=>node.classList.toggle('mask-card-active',node.dataset.maskCard===state.selection?.id));
    renderInspector();updateOverlay();
  }
  function selectItem(kind,itemId,seek=true,additive=false){
    const previousTab=tab;
    const entry={kind,id:itemId};
    state.selections=additive?(selectionHas(kind,itemId)?state.selections.filter(row=>key(row.kind,row.id)!==key(kind,itemId)):[...state.selections,entry]):[entry];
    state.selection=state.selections.at(-1)||null;const item=itemNow();if(!item){render();return}
    if(kind==='video'&&!additive){
      for(const candidate of StudioTimeline.layout(p).items)if(state.follow.has(candidate.kind)&&candidate.start<item.end&&candidate.end>item.start&&!selectionHas(candidate.kind,candidate.id))state.selections.push({kind:candidate.kind,id:candidate.id});
    }
    if(kind==='caption'){selected=itemId;tab='captions'}else if(kind==='mask')tab='masks';
    if(seek)setCursor(Math.min(item.start,total()));
    renderSelection(previousTab);
  }
  async function change(op){
    if(!p)throw Error('请先打开剧集');
    if(state.locked.has(op.kind))throw Error('这条轨道已锁定，请先点击轨道旁的锁解锁');
    const result=await StudioEditActions.execute(op);
    if(state.selection&&['dialogue','narration','bgm','sfx'].includes(state.selection.kind)){
      const audio=p.audios.find(row=>row.id===state.selection.id);
      state.selection=audio?{kind:audio.role,id:audio.id}:null;
    }
    window.StudioRealtime?.clearPreview();
    state.selections=selectedItems();if(!itemNow())state.selection=state.selections.at(-1)||null;
    state.cursor=Math.min(state.cursor,total());render();
    if(result.selection)state.selection=result.selection;
  }
  function boundarySnap(value,exclude){
    if(!state.snap)return quant(value);
    const points=[0,total(),state.cursor];
    for(const item of state.layout.items){if(!exclude.endsWith(':'+item.id)&&!(state.drag?.multi&&selectionHas(item.kind,item.id)))points.push(item.start,item.end)}
    let best=value,dist=7/state.scale;
    state.snapPoint=null;for(const point of points){const delta=Math.abs(point-value);if(delta<dist){best=point;dist=delta;state.snapPoint=point}}
    return quant(best);
  }
  function lanes(items){
    const ends=[];
    return [...items].sort((a,b)=>a.start-b.start||a.end-b.end).map(item=>{let lane=ends.findIndex(end=>end<=item.start+1e-7);if(lane<0)lane=ends.length;ends[lane]=item.end;return {...item,lane}});
  }
  function waveSvg(item,data){
    const wave=data?.waveform;if(!wave?.points?.length)return '';
    const source=getRecord(item),duration=Number(wave.duration)||0;if(!duration)return '';
    const sourceIn=source.in||0,sourceOut=source.out||duration,period=sourceOut-sourceIn;
    const peak=Math.max(.001,...wave.points.filter(value=>Number.isFinite(value)).map(value=>Math.abs(value)));
    const durationOnTrack=item.end-item.start,segments=[];
    const count=Math.max(12,Math.min(180,Math.ceil(durationOnTrack*state.scale/3)));
    for(let n=0;n<count;n++){
      let at=sourceIn+(n+.5)/count*durationOnTrack;
      if(source.loop&&item.kind==='bgm')at=sourceIn+((at-sourceIn)%period);
      const index=Math.min(wave.points.length-1,Math.max(0,Math.floor(at/duration*wave.points.length)));
      const value=wave.points[index];if(value===null||value===undefined)continue;
      const height=Math.max(.4,Math.min(1,Math.abs(value)/peak)*15),x=(n+.5)/count*1000;
      segments.push(`M${x.toFixed(2)},${(16-height).toFixed(2)}V${(16+height).toFixed(2)}`);
    }
    return `<svg class="tl-wave" viewBox="0 0 1000 32" preserveAspectRatio="none" aria-hidden="true"><path d="${segments.join('')}" stroke="currentColor" stroke-width="2" fill="none"/></svg>`;
  }
  function mediaKey(item){const a=asset(item.asset_id),record=getRecord(item);return `${p.id}:${item.asset_id}:${record?.audio_stream??''}:${a?.mtime_ns??a?.mtime??''}:${a?.size??''}`}
  function decorate(item){
    if(item.kind==='caption'||item.kind==='mask')return '';
    const data=state.media.get(mediaKey(item));
    if(item.kind==='video'){
      const thumbs=(data?.thumbnails||[]).filter(x=>typeof x.data_url==='string'&&x.data_url.startsWith('data:image/jpeg;base64,'));
      if(!thumbs.length)return '';
      const record=getRecord(item),usable=thumbs.filter(x=>x.time>=record.in&&x.time<=record.out);
      const list=usable.length?usable:[thumbs.reduce((a,b)=>Math.abs(a.time-record.in)<Math.abs(b.time-record.in)?a:b)];
      return `<div class="tl-thumbs">${list.slice(0,6).map(t=>`<img src="${t.data_url}" alt="" draggable="false">`).join('')}</div>`;
    }
    return waveSvg(item,data);
  }
  function queueMedia(){
    if(!p||state.collapsed)return;
    const pid=p.id,epoch=state.mediaEpoch;
    const items=state.layout.items.filter(item=>item.asset_id);
    for(const item of items){
      if(state.loading>=2)break;
      const cacheKey=mediaKey(item);if(state.media.has(cacheKey)||state.pending.has(cacheKey))continue;
      const record=getRecord(item),query=record.audio_stream==null?'':`?stream=${encodeURIComponent(record.audio_stream)}`;
      state.pending.add(cacheKey);state.loading++;
      api(`/api/projects/${pid}/timeline-media/${item.asset_id}${query}`).then(data=>{
        if(p?.id===pid&&state.mediaEpoch===epoch)state.media.set(cacheKey,data);
      }).catch(e=>{if(p?.id===pid&&state.mediaEpoch===epoch){state.media.set(cacheKey,{error:e.message});if(/缺失|丢失|已移动/.test(e.message))window.studioMediaRelink?.refresh().catch(()=>{})}}).finally(()=>{
        state.loading--;state.pending.delete(cacheKey);schedule();
      });
    }
  }
  function draw(){
    if(state.drag)return;
    if(state.pid!==p?.id)reset();
    document.body.classList.toggle('timeline-ready',!!p);
    document.body.classList.toggle('timeline-focus',!!p&&state.focus);
    if(!p){root.innerHTML='<div class="tl-empty-project">打开剧集后，这里显示打码、画面、人物原声、字幕、旁白、音乐与音效轨道。</div>';return}
    state.locked=new Set(p.track_locks||[]);
    try{state.layout=StudioTimeline.layout(p)}catch(error){root.innerHTML=`<div class="tl-empty-project">时间线暂不可用：${esc(error.message)}。请修正左侧片段的时间 / 音量输入，或点击上方“撤销”；原文件不会改动。</div>`;return}
    state.selections=selectedItems(state.layout);if(state.selection&&!itemNow(state.layout))state.selection=state.selections.at(-1)||null;
    const oldScroll=root.querySelector('.tl-scroll'),scrollLeft=oldScroll?.scrollLeft||0,scrollTop=oldScroll?.scrollTop||0;
    // Reuse the validated layout for every clip; total() rebuilds the entire model.
    const duration=state.layout.duration;
    const label=labelWidth(),length=Math.max(duration,...state.layout.items.map(x=>Math.min(x.end,duration+30)),1),tail=Math.max(50,root.clientWidth-label),width=Math.max(root.clientWidth-2,label+length*state.scale+tail);
    const tickStep=state.scale>=rate()*8?1/rate():state.scale>=300?.2:state.scale>=90?1:state.scale>=40?2:state.scale>=16?5:10;
    const labelEvery=Math.max(1,Math.ceil(70/(tickStep*state.scale)));
    const tickMarkup=i=>{const t=i*tickStep,major=i%labelEvery===0;return `<span class="tl-tick${major?'':' minor'}" style="left:${label+t*state.scale}px">${major?(tickStep<1?time(t):time(t).slice(0,5)):''}</span>`};
    const ticks=[],tickStart=Math.max(0,Math.floor((scrollLeft-label)/state.scale/tickStep)-1),tickEnd=Math.min(Math.ceil(length/tickStep),Math.ceil((scrollLeft+root.clientWidth)/state.scale/tickStep)+1);
    for(let i=tickStart;i<=tickEnd;i++)ticks.push(tickMarkup(i));
    const active=itemNow(state.layout),locked=active&&state.locked.has(active.kind),activeRelation=studioAudioRelation(p,active),displayTracks=visibleTracks(state.layout);
    root.classList.toggle('tl-collapsed',state.collapsed);
    root.innerHTML=`<div class="tl-toolbar"><button id="tl-undo" title="撤销 · Ctrl+Z" aria-keyshortcuts="Control+Z Meta+Z">↶ 撤销</button><button id="tl-add-material" class="accent">＋ 添加素材</button><button id="tl-split" ${!active||locked||['caption','mask'].includes(active.kind)?'disabled':''} title="在播放头处分割，快捷键 S">分割</button><button id="tl-delete" class="danger" ${!active||locked?'disabled':''}>删除</button><button id="tl-detach-audio" ${!active||!['video','original'].includes(active.kind)||locked||state.locked.has('video')||state.locked.has('original')||getRecord(active)?.audio_detached||!asset(active.asset_id)?.has_audio?'disabled':''}>分离音频</button><details class="tl-add-menu"><summary>＋ 添加</summary><div><button id="tl-add-caption">字幕</button><button id="tl-add-audio">音频</button><button id="tl-add-mask">打码</button><label><input id="tl-snap" type="checkbox" ${state.snap?'checked':''}> 磁吸</label><button id="tl-focus">${state.focus?'恢复布局':'扩大轨道'}</button><button id="tl-collapse">${state.collapsed?'展开轨道':'收起轨道'}</button></div></details><span class="tl-spacer"></span><input id="tl-position" class="tl-time" value="${time(state.cursor)}" aria-label="播放头时间" title="输入秒，或 分:秒.毫秒 后按回车"><span class="tl-duration">/ ${time(duration)}</span><button id="tl-zoom-out" aria-label="缩小时间线">−</button><input id="tl-zoom" aria-label="时间线缩放" type="range" min="5" max="160" value="${state.scale}"><button id="tl-zoom-in" aria-label="放大时间线">＋</button><button id="tl-fit">适应</button><span class="tl-zoom-label">${Math.round(state.scale)} px/s</span></div><div class="tl-scroll"><div class="tl-content" style="width:${width}px;--grid-width:${tickStep*state.scale}px"><div class="tl-ruler">${ticks.join('')}<div class="tl-ruler-label">时间</div></div>${displayTracks.map(track=>{
      const items=lanes(state.layout.items.filter(x=>track.kinds.includes(x.kind))),laneHeight=track.key==='video'?68:43,height=Math.max(1,...items.map(x=>x.lane+1))*laneHeight+4,lockKind=track.kinds.length===1?track.kinds[0]:null;
      return `<div class="tl-row" data-track="${track.key}" style="height:${height}px;--track-color:${track.color}"><div class="tl-grid"></div>${!items.length?`<span class="tl-empty">把视频拖到这里，主轨会自动吸附</span>`:''}${items.map(item=>{
        const relation=studioAudioRelation(p,item);
        const title=heading(item),selectedItem=selectionHas(item.kind,item.id)||(relation?.pair&&state.selections.some(entry=>studioAudioRelation(p,entry)?.pair===relation.pair)),rec=getRecord(item),badge=item.kind==='video'&&relation?.state==='embedded'?'🔊 原声':relation?.state==='linked'?(item.kind==='video'?'🔗 原声':'🔗 跟随画面'):track.key==='audio'?kindName(item.kind):'';
        return `<div class="tl-clip ${relation?.pair?'linked ':''}${selectedItem?'selected ':''}${rec.gain<=-59?'tl-muted':''}" tabindex="0" role="button" aria-label="${esc(track.name+'：'+String(title).replaceAll('\n',' ')+'，'+time(item.start)+'至'+time(item.end)+(relation?'，'+relation.detail:''))}" data-tl-kind="${item.kind}" data-tl-id="${item.id}" data-audio-state="${relation?.state||''}" style="--clip-color:${kindColor(item.kind)};left:${label+item.start*state.scale}px;top:${2+item.lane*laneHeight}px;width:${Math.max(3,(item.end-item.start)*state.scale)}px;height:${laneHeight-4}px" title="${esc(title)}\n${time(item.start)} → ${time(item.end)}\n拖中间移动，拖两端裁剪">${decorate(item)}<span class="tl-clip-title">${badge?`<span class="tl-relation ${relation?.state||'type'}">${esc(badge)}</span>`:''}<span class="tl-clip-name">${esc(title)}</span></span>${item.kind==='bgm'&&rec.loop?'<span class="tl-clip-sub">↻ 循环</span>':''}${!state.locked.has(item.kind)?'<span class="tl-handle left" data-trim="start" title="拖动裁剪左边" aria-label="裁剪左边"></span><span class="tl-handle right" data-trim="end" title="拖动裁剪右边" aria-label="裁剪右边"></span>':''}</div>`;
      }).join('')}<div class="tl-label"><b><span class="tl-track-icon">${track.icon}</span>${track.name}</b>${lockKind?`<button class="tl-lock" data-lock="${lockKind}" title="${state.locked.has(lockKind)?'解锁':'锁定'}${track.name}">${state.locked.has(lockKind)?'🔒':'🔓'}</button>`:''}</div></div>`;
    }).join('')}<div class="tl-end" style="left:${label+duration*state.scale}px"></div><div class="tl-playhead"></div><div class="tl-drop-line"></div></div></div><div class="tl-note"><span id="tl-hint">${state.stale?'<span class="warn">预览已更新。</span>':'拖动主轨镜头可排序 · 拖动两端可裁剪 · 点击空白移动播放头'}</span><span>主轨自动吸附，音频和字幕可以自由摆放</span></div>`;
    const scroll=root.querySelector('.tl-scroll');scroll.scrollLeft=scrollLeft;scroll.scrollTop=scrollTop;
    const settings=document.createElement('span');settings.className='tl-edit-settings';
    settings.innerHTML=`<label title="关闭后，移动、缩短或删除画面会保留空位；不会自动合拢主轨"><input id="tl-magnetic" type="checkbox" ${state.magnetic?'checked':''}>主轨磁吸</label><details class="tl-add-menu"><summary>联动设置 · ${state.selections.length} 项</summary><div><p>默认仅移动选中项及已联动原声。Ctrl 点击增减选区；拖动轨道空白框选，Ctrl 框选可追加。</p><p>可选：选画面时连选时间重叠的：</p>${['caption','narration','bgm','sfx','mask'].map(kind=>`<label><input data-tl-follow="${kind}" type="checkbox" ${state.follow.has(kind)?'checked':''}>${kindName(kind)}</label>`).join('')}<p>只影响后续选择；裁剪不自动裁切独立字幕或声音。原声要独立编辑请点“解除联动”。</p><button id="tl-clear-selection">清除选区</button></div></details><label title="拖动时吸附到其他片段边界和播放头，不等于主轨合拢"><input id="tl-auto-snap" type="checkbox" ${state.snap?'checked':''}>自动吸附</label></span>`;
    $('#tl-add-material').after(settings);
    $('#tl-magnetic').onchange=e=>{state.magnetic=e.target.checked};
    $('#tl-auto-snap').onchange=e=>{state.snap=e.target.checked;$('#tl-snap').checked=state.snap};
    root.querySelectorAll('[data-tl-follow]').forEach(field=>field.onchange=()=>{if(field.checked)state.follow.add(field.dataset.tlFollow);else state.follow.delete(field.dataset.tlFollow)});
    $('#tl-clear-selection').onclick=()=>{state.selection=null;state.selections=[];render()};
    const multiple=state.selections.length>1;
    for(const selector of ['#tl-split','#tl-delete','#tl-detach-audio'])if(multiple)$(selector).disabled=true;
    $('#tl-hint').textContent='Ctrl 点击多选 · 拖动空白框选 · 主轨磁吸：连续镜头整组排序；关闭：整组平移 · 点击标尺定位';
    let rulerFrame=null;
    scroll.addEventListener('scroll',()=>{
      if(rulerFrame)return;
      rulerFrame=requestAnimationFrame(()=>{
        rulerFrame=null;if(!scroll.isConnected)return;
        const start=Math.max(0,Math.floor((scroll.scrollLeft-label)/state.scale/tickStep)-1);
        const end=Math.min(Math.ceil(length/tickStep),Math.ceil((scroll.scrollLeft+scroll.clientWidth)/state.scale/tickStep)+1);
        const ruler=scroll.querySelector('.tl-ruler'),labels=[];
        for(let i=start;i<=end;i++)labels.push(tickMarkup(i));
        ruler.querySelectorAll('.tl-tick').forEach(t=>t.remove());ruler.insertAdjacentHTML('afterbegin',labels.join(''));
      });
    });
    const unavailable=[...state.media.values()].filter(data=>data.error||data.status==='busy'||data.status==='partial').length;
    if(unavailable){const retry=document.createElement('button');retry.id='tl-reload-media';retry.textContent='刷新素材预览';retry.title='重新读取缩略图与波形，不改变工程';retry.onclick=()=>{state.media.clear();state.mediaEpoch++;draw()};$('#tl-fit').before(retry);const warning=document.createElement('span');warning.className='warn';warning.textContent=`${unavailable} 项缩略图或波形未加载。`;root.querySelector('.tl-note').append(warning)}
    if(state.layout.warnings.length){const warning=document.createElement('span');warning.className='warn';warning.textContent=state.layout.warnings.join(' ');root.querySelector('.tl-note').append(warning)}
    if(state.stale&&!previewJob)$('#tl-hint').textContent='实时预览已更新。';
    const redo=document.createElement('button');redo.id='tl-redo';redo.textContent='↷ 重做';redo.title='重做 · Ctrl+Shift+Z / Ctrl+Y';redo.setAttribute('aria-keyshortcuts','Control+Shift+Z Control+Y Meta+Shift+Z');$('#tl-undo').after(redo);redo.onclick=()=>$('#redo-button').click();
    $('#tl-undo').onclick=()=>$('#undo-button').click();
    $('#tl-add-material').onclick=()=>window.studioMaterialImport?.open();
    $('#tl-split').onclick=handle(()=>{const item=itemNow();change({type:'split',kind:item.kind,id:item.id,time:state.cursor})});
    $('#tl-delete').onclick=handle(removeSelected);
    $('#tl-detach-audio').onclick=handle(()=>window.studioDetachAudio(itemNow().id));
    if(activeRelation?.state==='linked'){const unlink=document.createElement('button');unlink.id='tl-unlink-audio';unlink.textContent='解除联动';unlink.disabled=!canUnlink();unlink.title='解除后声音可单独拖动';unlink.onclick=handle(unlinkSelected);$('#tl-detach-audio').after(unlink)}
    $('#tl-add-mask').onclick=handle(addMask);
    $('#tl-add-caption').onclick=handle(addCaption);
    $('#tl-add-audio').onclick=()=>{const previous=tab;state.selection=null;state.selections=[];tab='audio';render();$('#add-audio').click();tab=previous;render()};
    $('#tl-snap').onchange=e=>{state.snap=e.target.checked;$('#tl-auto-snap').checked=state.snap};
    $('#tl-position').onchange=handle(e=>{const parts=e.target.value.trim().split(':').map(Number);if(parts.length>3||parts.some(n=>!Number.isFinite(n)||n<0))throw Error('请输入秒或 分:秒.毫秒');setCursor(parts.reduce((a,n)=>a*60+n,0))});
    $('#tl-position').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();e.currentTarget.onchange(e)}};
    $('#tl-position').oninput=e=>{if(/^\d+(?::\d+){0,2}(?:\.\d+)?$/.test(e.target.value.trim())){const value=e.target.value.trim().split(':').map(Number).reduce((a,n)=>a*60+n,0);setCursor(value)}};
    $('#tl-zoom').oninput=e=>{root.querySelector('.tl-zoom-label').textContent=Math.round(Number(e.target.value))+' px/s'};
    $('#tl-zoom').max=maxScale();$('#tl-zoom').step='any';$('#tl-zoom').value=state.scale;
    $('#tl-zoom').onchange=e=>zoomTo(Number(e.target.value));
    $('#tl-zoom-out').onclick=()=>zoomTo(state.scale/1.35);
    $('#tl-zoom-in').onclick=()=>zoomTo(state.scale*1.35);
    $('#tl-fit').onclick=()=>{state.scale=Math.max(5,Math.min(160,(root.clientWidth-label-30)/Math.max(1,total())));draw();root.querySelector('.tl-scroll').scrollLeft=0};
    $('#tl-focus').onclick=()=>{state.focus=!state.focus;draw()};
    $('#tl-collapse').onclick=()=>{state.collapsed=!state.collapsed;draw()};
    root.querySelectorAll('[data-lock]').forEach(button=>button.onclick=handle(()=>StudioEditActions.execute({type:'lock',kind:button.dataset.lock,locked:!state.locked.has(button.dataset.lock)})));
    state.drawnSignature=viewSignature();
    paintCursor();queueMedia();
  }
  function addCaption(){
    if(state.locked.has('caption'))throw Error('字幕轨已锁定');
    const start=quant(state.cursor),next=p.captions.filter(c=>c.start>=start).sort((a,b)=>a.start-b.start)[0],end=Math.min(total(),start+2,next?.start??Infinity);
    if(p.captions.some(c=>start>=c.start&&start<c.end)||end-start<1/rate())throw Error('这里已有字幕或空间不足，请选择没有字幕的时间段');
    remember();const cue={id:id(),start,end,text:'请输入字幕',style:{}};p.captions.push(cue);p.captions.sort((a,b)=>a.start-b.start);mark();selectItem('caption',cue.id);
  }
  function addMask(){
    if(state.locked.has('mask'))throw Error('打码轨已锁定');
    const start=quant(state.cursor),end=Math.min(total(),start+2);
    if(end-start<1/rate())throw Error('播放头后至少需要一帧画面才能添加打码');
    remember();p.masks=p.masks||[];
    const mask={id:id(),start,end,x:350,y:710,w:380,h:300,blur:18,white:.2,mode:'solid',keyframes:[]};
    p.masks.push(mask);mark(false);selectItem('mask',mask.id);
  }
  async function removeSelected(){
    if(state.selections.length>1)throw Error('多选当前支持整体移动；请单选后删除，避免误删关联原声');
    const item=itemNow();if(!item)return;
    await change({type:'remove',kind:item.kind,id:item.id,magnetic:state.magnetic});
  }
  function canUnlink(){return studioAudioRelation(p,itemNow())?.state==='linked'&&!state.locked.has('video')&&!state.locked.has('dialogue')}
  async function unlinkSelected(){
    const item=itemNow();if(!item||!canUnlink())return;
    await change({type:'unlink',kind:item.kind,id:item.id});
    toast('已解除联动，原声可单独拖动；可点撤销恢复联动。');
  }
  function renderProperties(){
    if(state.selections.length>1){$('#inspector').innerHTML=`<section class="tl-properties"><h3>已选择 ${state.selections.length} 项</h3><p>未选字幕、旁白和音乐不移动。主轨磁吸开启时，从画面拖动连续选中镜头可整组排序；关闭时，整组保持相对时间平移。</p><p>Ctrl 点击增减选区；点击单个未选片段恢复单选。不自动裁切独立声音。</p></section>`;return true}
    const item=itemNow();if(!item||item.kind==='caption'||item.kind==='mask')return false;
    const relation=studioAudioRelation(p,item),record=getRecord(item),isOriginal=item.kind==='original',isVideo=item.kind==='video',a=asset(item.asset_id),locked=state.locked.has(item.kind);
    const number=(key,label,value,min)=>`<div><label>${label}</label><input data-tl-prop="${key}" inputmode="decimal" type="text" value="${Number(value)}" ${min!==undefined?`data-min="${min}"`:''}></div>`;
    const relationText=relation?.state==='embedded'?'原声跟随画面。需要单独移动时，点击“分离音频”。':relation?.state==='linked'?'画面和原声仍然联动，移动、裁剪或删除会一起生效。':relation?.state==='independent'?'这段声音和画面已经独立，可以单独移动。':relation?.detail||'';
    const timing=!isOriginal?`<details class="tl-advanced"><summary>精确时间</summary>${!isVideo?number('start','成片开始 / 秒',record.start??item.start,0):''}<div class="row">${number('in','素材入点 / 秒',record.in,0)}${number('out','素材出点 / 秒',record.out,0)}</div>${(a?.audio_streams||[]).length?`<label>源音轨</label><select data-tl-prop="audio_stream"><option value="">${a.audio_streams.length===1?'默认音轨':'请选择音轨'}</option>${a.audio_streams.map(s=>`<option value="${s.index}" ${record.audio_stream===s.index?'selected':''}>音轨 ${s.index} · ${esc(s.language||'未知语言')} ${esc(s.title||'')}</option>`).join('')}</select>`:''}</details>`:'';
    $('#inspector').innerHTML=`<section class="tl-properties"><h3>${isVideo?'视频片段':'音频片段'}</h3><span class="tl-badge">${esc(kindName(item.kind))}${locked?' · 已锁定':''}</span><div class="tl-name">${esc(a?.name)}</div><div class="helper">${time(item.start)} → ${time(item.end)} · 时长 ${time(item.end-item.start)}</div>${relationText?`<p class="tl-relation-detail ${relation?.state||''}">${esc(relationText)}</p>`:''}<fieldset ${locked?'disabled':''} style="border:0;padding:0;margin:0">${number('gain',isVideo||isOriginal?'原声音量 / dB':'音量 / dB',record.gain??0)}${!isOriginal&&!isVideo?`<label>类型</label><select data-tl-prop="role">${kinds.filter(t=>['dialogue','narration','bgm','sfx'].includes(t[0])).map(t=>`<option value="${t[0]}" ${item.kind===t[0]?'selected':''}>${t[1]}</option>`).join('')}</select><label class="tl-check"><input data-tl-prop="loop" type="checkbox" ${record.loop?'checked':''}> 背景音乐循环到片尾</label>`:''}${timing}<button id="tl-apply-props" class="accent tl-submit">应用</button></fieldset><p class="tl-warning">${isVideo?'主轨会自动吸附。拖动片段是在镜头之间插入排序；拖两端裁剪。':'拖动片段改变位置，拖两端裁剪。'}</p><button id="tl-to-start">把播放头移到片段开始</button></section>`;
    if(isVideo&&record.audio_detached){
      for(const field of document.querySelectorAll('[data-tl-prop="gain"],[data-tl-prop="audio_stream"]'))field.disabled=true;
      const note=document.createElement('p');note.className='helper';note.textContent=relation?.state==='linked'?`原声音量请选中“人物原声”轨的「${relation.label}」调整。`:'画面原声已关闭；请在对应声音轨调整音量。';$('#inspector').prepend(note);
    }
    $('#tl-apply-props').onclick=handle(()=>{
      const patch={};$$('[data-tl-prop]').forEach(el=>{const k=el.dataset.tlProp;patch[k]=el.type==='checkbox'?el.checked:k==='role'?el.value:k==='audio_stream'&&el.value===''?null:Number(el.value);if(el.type==='text'&&!el.value.trim())throw Error('时间与音量不能为空')});
      for(const k of Object.keys(patch)){if(patch[k]===record[k]||(k==='audio_stream'&&patch[k]==null&&record[k]==null))delete patch[k]}
      if(!Object.keys(patch).length)return;
      change({type:'update',kind:item.kind,id:item.id,patch,magnetic:state.magnetic});
    });
    $('#tl-to-start').onclick=()=>setCursor(item.start);
    if(isVideo){const replace=document.createElement('button');replace.id='tl-replace-video';replace.textContent='替换视频…';replace.disabled=locked;replace.onclick=handle(()=>replaceVideo(item.id));$('#tl-to-start').after(replace)}
    if(relation?.state==='linked'){
      const unlink=document.createElement('button');unlink.id='tl-properties-unlink';unlink.textContent='解除联动';unlink.disabled=!canUnlink();
      unlink.onclick=handle(unlinkSelected);$('#inspector .tl-relation-detail').after(unlink);
    }
    return true;
  }
  async function replaceVideo(clipId){
    await save();const pid=p.id;
    modal(`<h2>替换当前视频片段</h2><p>只替换这一段，不覆盖同素材的其他镜头。已有联动原声随新画面换源，独立原声不变；音量和原生未知字段保留。新素材请先从“添加素材”导入。</p><label>新视频素材</label><select id="replace-video-source">${p.assets.filter(a=>a.kind==='video').map(a=>`<option value="${a.id}">${esc(a.name)} · ${time(a.duration)}</option>`).join('')}</select><div class="row"><div><label>新素材入点 / 秒</label><input id="replace-video-in" type="number" min="0" step="any" value="0"></div><div><label>新素材出点 / 秒</label><input id="replace-video-out" type="number" min="0" step="any"></div></div><label>长度处理</label><select id="replace-video-strategy"><option value="fit">保长裁切：保持原片段长度（新素材不足则拒绝）</option><option value="gap">保留后续位置：长则裁切，短则留空，不自动冻结补帧</option><option value="ripple">使用新选段长度：推动后续画面</option></select><p>“推动后续”中，默认只有画面和已联动原声移动。可勾选跟随的新片段起点在旧画面结束之后；跨越替换边界的长音乐/旁白保持原样，不自动切断。</p>${['caption','narration','bgm','sfx','mask'].map(kind=>`<label><input data-replace-follow="${kind}" type="checkbox"> 同时推动后续${kindName(kind)}</label>`).join('')}<div id="replace-video-stream"></div><div class="modal-actions"><button id="replace-video-confirm" class="primary">确认替换</button></div>`);
    const sourceChange=()=>{const source=asset($('#replace-video-source').value);$('#replace-video-out').value=Math.floor(source.duration*rate())/rate();$('#replace-video-stream').innerHTML=(source.audio_streams||[]).length>1?`<label>原声音轨（不可猜测）</label><select id="replace-video-audio-stream"><option value="">请选择</option>${source.audio_streams.map(s=>`<option value="${s.index}">${s.index} · ${esc(s.title||s.language||'未知音轨')}</option>`).join('')}</select>`:''};
    $('#replace-video-source').onchange=sourceChange;sourceChange();
    $('#replace-video-confirm').onclick=handle(async()=>{
      if(p?.id!==pid)throw Error('工程已切换，请重新选择片段');
      const stream=$('#replace-video-audio-stream');if(stream&&stream.value==='')throw Error('请选择新视频的原声音轨');
      const op={type:'replace_video',id:clipId,asset_id:$('#replace-video-source').value,in:Number($('#replace-video-in').value),out:Number($('#replace-video-out').value),strategy:$('#replace-video-strategy').value,follow:$$('[data-replace-follow]:checked').map(el=>el.dataset.replaceFollow)};
      if(stream)op.audio_stream=Number(stream.value);
      $('#replace-video-confirm').disabled=true;
      try{await change(op);$('#modal').close();toast('已替换这一段，原工程历史可撤销；请核对切点和原声。')}catch(error){$('#replace-video-confirm').disabled=false;throw error}
    });
  }
  root.addEventListener('pointerdown',e=>{
    if(e.button!==0||!p||e.target.closest('button,input,select,.tl-label'))return;
    const clip=e.target.closest('[data-tl-id]'),scroll=root.querySelector('.tl-scroll');if(!scroll||!scroll.contains(e.target))return;
    if(!clip){
      const rect=scroll.getBoundingClientRect(),x=e.clientX-rect.left+scroll.scrollLeft-labelWidth();
      if(x<0)return;
      if(e.target.closest('.tl-ruler')){setCursor(quant(x/state.scale));state.drag={scrub:true,pointer:e.pointerId}}
      else{
        const content=root.querySelector('.tl-content').getBoundingClientRect();
        state.drag={box:true,pointer:e.pointerId,startX:e.clientX,startY:e.clientY,contentX:e.clientX-content.left,contentY:e.clientY-content.top,base:e.ctrlKey||e.metaKey?selectedItems():[],pid:p.id,signature:sig(),moved:false};
        const box=document.createElement('div');box.className='tl-selection-box';root.querySelector('.tl-content').append(box);
      }
      root.setPointerCapture(e.pointerId);e.preventDefault();return;
    }
    const kind=clip.dataset.tlKind,itemId=clip.dataset.tlId,edge=e.target.dataset.trim;
    if(e.ctrlKey||e.metaKey){selectItem(kind,itemId,false,true);root.focus({preventScroll:true});e.preventDefault();return}
    if(!selectionHas(kind,itemId)||edge)selectItem(kind,itemId,false);else state.selection={kind,id:itemId};root.focus({preventScroll:true});
    const item=itemNow();if(!item)return;
    if(state.locked.has(kind)){setCursor(item.start);toast('此轨道已锁定');return}
    window.StudioRealtime?.pause();
    const sc=root.querySelector('.tl-scroll');
    state.drag={kind,id:itemId,item:{...item},multi:state.selections.length>1,edge,startX:e.clientX,scrollLeft:sc.scrollLeft,pid:p.id,signature:sig(),moved:false,op:null,pointer:e.pointerId};
    root.setPointerCapture(e.pointerId);e.preventDefault();
  });
  root.addEventListener('pointermove',e=>{
    const drag=state.drag;if(!drag||e.pointerId!==drag.pointer)return;
    if(drag.scrub){const scroll=root.querySelector('.tl-scroll'),rect=scroll.getBoundingClientRect();setCursor(quant((e.clientX-rect.left+scroll.scrollLeft-labelWidth())/state.scale));return}
    if(p?.id!==drag.pid||sig()!==drag.signature){cancelDrag();return}
    if(drag.box){
      const content=root.querySelector('.tl-content').getBoundingClientRect(),x=e.clientX-content.left,y=e.clientY-content.top;
      drag.moved ||= Math.abs(e.clientX-drag.startX)+Math.abs(e.clientY-drag.startY)>3;
      const left=Math.max(labelWidth(),Math.min(x,drag.contentX)),right=Math.max(x,drag.contentX),top=Math.min(y,drag.contentY),bottom=Math.max(y,drag.contentY);
      const box=root.querySelector('.tl-selection-box');Object.assign(box.style,{left:left+'px',top:top+'px',width:Math.max(0,right-left)+'px',height:(bottom-top)+'px'});
      const entries=new Map(drag.base.map(entry=>[key(entry.kind,entry.id),entry]));
      root.querySelectorAll('[data-tl-id]').forEach(node=>{const r=node.getBoundingClientRect();if(r.right>content.left+left&&r.left<content.left+right&&r.bottom>content.top+top&&r.top<content.top+bottom)entries.set(key(node.dataset.tlKind,node.dataset.tlId),{kind:node.dataset.tlKind,id:node.dataset.tlId})});
      drag.entries=[...entries.values()];
      root.querySelectorAll('[data-tl-id]').forEach(node=>node.classList.toggle('selected',entries.has(key(node.dataset.tlKind,node.dataset.tlId))));return;
    }
    const scroll=root.querySelector('.tl-scroll'),rect=scroll.getBoundingClientRect();
    if(e.clientX>rect.right-30)scroll.scrollLeft+=12;else if(e.clientX<rect.left+labelWidth()+24)scroll.scrollLeft-=12;
    const dx=e.clientX-drag.startX+scroll.scrollLeft-drag.scrollLeft;
    if(Math.abs(dx)<3&&!drag.moved)return;drag.moved=true;
    const node=root.querySelector(`[data-tl-kind="${drag.kind}"][data-tl-id="${drag.id}"]`),exclude=key(drag.kind,drag.id);
    let start=drag.item.start,end=drag.item.end,reorderIndex=null;
    if(drag.edge){
      if(drag.edge==='start')start=boundarySnap(start+dx/state.scale,exclude);else end=boundarySnap(end+dx/state.scale,exclude);
      drag.op={type:'trim',kind:drag.kind,id:drag.id,[drag.edge]:drag.edge==='start'?start:end,magnetic:state.magnetic};
    }else if(drag.kind==='video'&&state.magnetic){
      const pointerTime=Math.max(0,(e.clientX-rect.left+scroll.scrollLeft-labelWidth())/state.scale);
      const selectedVideos=new Set(selectedItems().flatMap(entry=>entry.kind==='video'?[entry.id]:p.native_links?.[entry.id]?.linked_video_id?[p.native_links[entry.id].linked_video_id]:[]));
      const others=state.layout.items.filter(item=>item.kind==='video'&&!selectedVideos.has(item.id)).sort((a,b)=>a.start-b.start);
      reorderIndex=others.filter(item=>pointerTime>(item.start+item.end)/2).length;
      drag.op=drag.multi?{type:'reorder_selection',id:drag.id,items:selectedItems(),targetIndex:reorderIndex}:{type:'reorder',kind:'video',id:drag.id,targetIndex:reorderIndex};
    }else{
      start=boundarySnap(drag.item.start+dx/state.scale,exclude);end=start+drag.item.end-drag.item.start;
      drag.op=drag.multi?{type:'move_selection',items:selectedItems(),delta:start-drag.item.start}:{type:'move',kind:drag.kind,id:drag.id,targetTime:start};
    }
    let error='';try{const candidate=StudioTimeline.apply(p,drag.op,()=> 'timeline-preview-'+drag.id),view=StudioTimeline.get(candidate.project,drag.kind,drag.id);start=view.start;end=view.end;if(reorderIndex!==null){state.snapPoint=start}if(drag.multi)for(const entry of selectedItems()){const row=StudioTimeline.get(candidate.project,entry.kind,entry.id),element=root.querySelector(`[data-tl-kind="${entry.kind}"][data-tl-id="${entry.id}"]`);if(element)element.style.left=(labelWidth()+row.start*state.scale)+'px'}window.StudioRealtime?.preview(candidate.project)}catch(err){error=err.message;window.StudioRealtime?.clearPreview()}
    drag.error=error;
    if(node){node.classList.add('dragging');node.style.left=(labelWidth()+start*state.scale)+'px';node.style.width=Math.max(3,(end-start)*state.scale)+'px';node.style.borderColor=error?'#ff9696':'#e3f6bc'}
    const line=root.querySelector('.tl-drop-line');if(line){line.style.display=state.snapPoint==null?'none':'block';line.style.left=(labelWidth()+state.snapPoint*state.scale)+'px'}
    const hint=$('#tl-hint');hint.textContent=error||(reorderIndex!==null?`放到第 ${reorderIndex+1} 个镜头 · 松开完成排序`:`${drag.edge?(drag.edge==='start'?'裁剪左边':'裁剪右边'):'移动片段'}：${time(start)} → ${time(end)}${state.snapPoint==null?'':' · 已吸附'}`);hint.className=error?'warn':'';
  });
  root.addEventListener('pointerup',async e=>{
    const drag=state.drag;if(!drag||e.pointerId!==drag.pointer)return;
    state.drag=null;if(root.hasPointerCapture(e.pointerId))root.releasePointerCapture(e.pointerId);
    if(drag.scrub){draw();return}
    if(drag.box){if(p?.id===drag.pid&&sig()===drag.signature){state.selections=drag.moved?(drag.entries||drag.base):drag.base;state.selection=state.selections.at(-1)||null}render();return}
    if(p?.id!==drag.pid||sig()!==drag.signature){draw();toast('工程在拖动期间已改变，本次拖动未应用。',true);return}
    try{if(drag.moved&&drag.op){if(drag.error)throw Error(drag.error);await change(drag.op)}else setCursor(drag.item.start)}catch(err){toast(err.message,true)}finally{window.StudioRealtime?.clearPreview();draw()}
  });
  function cancelDrag(){const drag=state.drag;state.drag=null;if(drag&&root.hasPointerCapture(drag.pointer))root.releasePointerCapture(drag.pointer);window.StudioRealtime?.clearPreview();draw()}
  root.addEventListener('pointercancel',cancelDrag);
  root.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&state.drag){e.preventDefault();cancelDrag();return}
    if(editing()||!p)return;
    if((e.ctrlKey||e.metaKey)&&['z','y'].includes(e.key.toLowerCase())){e.preventDefault();if(e.shiftKey||e.key.toLowerCase()==='y')$('#redo-button').click();else $('#undo-button').click();return}
    if(e.key==='Delete'||e.key==='Backspace'){e.preventDefault();handle(removeSelected)();return}
    if(e.key.toLowerCase()==='s'&&!e.ctrlKey&&!e.metaKey){e.preventDefault();$('#tl-split')?.click();return}
    if(e.key==='Enter'){const target=e.target.closest('[data-tl-id]');if(target){e.preventDefault();selectItem(target.dataset.tlKind,target.dataset.tlId)}}
  });
  render=function(...args){
    if(state.pid!==p?.id)reset();
    if(state.selection?.kind==='caption'&&tab==='captions'&&selected!==state.selection.id){state.selection=p.captions.some(c=>c.id===selected)?{kind:'caption',id:selected}:null;state.selections=state.selection?[state.selection]:[]}
    old.render(...args);draw();
  };
  renderInspector=function(...args){if(!renderProperties())old.renderInspector(...args)};
  mark=function(sound=false,...args){old.mark(sound,...args);if(sound&&!window.StudioRealtime?.editing()){state.stale=true;$('#video').pause()}schedule()};
  updateOverlay=function(frameTime){
    const effective=Number.isFinite(frameTime)?frameTime:(window.StudioRealtime?.editing()?StudioRealtime.time():$('#video').getAttribute('src')?$('#video').currentTime:state.cursor);
    old.updateOverlay(effective);state.cursor=Math.max(0,Math.min(total(),effective||0));paintCursor();
  };
  openProject=async function(pid,...args){await old.openProject(pid,...args);if(p?.id===pid)draw()};
  viewRender=async function(...args){await old.viewRender(...args);state.stale=!!previewJob&&!!qa&&(previewJob.result?.sound_digest!==qa.sound_hash);schedule()};
  const oldTabs=$('#tabs').onclick;
  $('#tabs').onclick=function(e){state.selection=null;state.selections=[];return oldTabs(e)};
  window.addEventListener('resize',schedule);
  window.StudioTimelineUI={canDetach:()=>!state.locked.has('video')&&!state.locked.has('original'),refresh:draw,previewUpdated:stale=>{state.stale=!!stale;schedule()},selection:()=>state.selection?{...state.selection}:null,selections:()=>selectedItems().map(entry=>({...entry})),select:selectItem,seek:setCursor,addMask,dragging:()=>!!state.drag};
}

;
// Source: mask-ui.js
'use strict';
/* One local visual effect: a white, softly blurred rectangular privacy mask. */
function installStudioMasking(){
  const layer=$('#mask-layer');
  if(!layer||!window.StudioTimelineUI)return;
  const old={render,renderInspector,updateOverlay,openProject,viewRender};
  let visualDirty=false,drag=null,lastInspectorFrame=null;
  const current=()=>StudioTimelineUI.selection()?.kind==='mask'?(p?.masks||[]).find(m=>m.id===StudioTimelineUI.selection().id):null;
  const now=()=>{
    if(window.StudioRealtime?.editing())return StudioRealtime.time();
    if($('#video').getAttribute('src'))return $('#video').currentTime||0;
    return ($('#tl-position')?.value||'0').split(':').map(Number).reduce((a,n)=>a*60+n,0);
  };
  // A pointer gesture can report a playhead exactly half a frame away from
  // the rounded keyframe time. Treat that boundary as the same frame so one
  // drag updates one keyframe instead of appending a duplicate per move event.
  const almost=(a,b)=>Math.abs(a-b)<=.500001/rate();
  function position(mask,t){
    const points=[{time:mask.start,x:mask.x,y:mask.y,w:mask.w,h:mask.h}];
    for(const raw of mask.keyframes)points.push({...points.at(-1),...raw});
    for(let i=1;i<points.length;i++){
      const right=points[i],left=points[i-1];
      if(t<=right.time){const f=Math.max(0,Math.min(1,(t-left.time)/(right.time-left.time)));return {x:left.x+(right.x-left.x)*f,y:left.y+(right.y-left.y)*f,w:left.w+(right.w-left.w)*f,h:left.h+(right.h-left.h)*f}}
    }
    return {x:points.at(-1).x,y:points.at(-1).y,w:points.at(-1).w,h:points.at(-1).h};
  }
  function activePoint(mask,t,create){
    if(t<=mask.start+.5/rate())return mask;
    let point=mask.keyframes.find(k=>almost(k.time,t));
    if(!point&&create&&t<mask.end-.5/rate()){
      point={time:Math.round(t*rate())/rate(),...position(mask,t)};
      mask.keyframes.push(point);mask.keyframes.sort((a,b)=>a.time-b.time);
    }
    return point;
  }
  const staleBurned=()=>!!(previewJob?.result?.masks_burned&&(visualDirty||previewJob.result.project_hash!==qa?.hash));
  const shouldSimulate=()=>false; // Live canvas owns pixels; this layer only holds editing handles.
  function paint(t=now()){
    if(!p){layer.replaceChildren();return}
    const selectedId=current()?.id;
    const active=window.StudioLiveEditor?.editing()?(p.masks||[]).filter(m=>t>=m.start&&t<m.end):[];
    const ids=active.map(m=>m.id).join('|');
    if(layer.dataset.ids!==ids&&!drag){
      layer.innerHTML=active.map(m=>`<div class="white-mask" data-mask-id="${m.id}" title="打码：拖动定位；拖右下角调整大小"><span class="mask-resize" data-mask-resize="1"></span></div>`).join('');
      layer.dataset.ids=ids;
    }
    for(const mask of active){
      const el=layer.querySelector(`[data-mask-id="${mask.id}"]`);if(!el)continue;
      const at=position(mask,t),selected=selectedId===mask.id;
      Object.assign(el.style,{left:(at.x/1080*100)+'%',top:(at.y/1920*100)+'%',width:(at.w/1080*100)+'%',height:(at.h/1920*100)+'%',backdropFilter:shouldSimulate()?`blur(${mask.blur*$('#stage').clientWidth/1080}px)`:'none',background:shouldSimulate()?`rgba(255,255,255,${mask.white})`:'transparent'});
      el.classList.toggle('selected',selected);
      el.classList.toggle('stale',false);
      el.style.pointerEvents=selected?'auto':'none';
    }
    window.StudioLiveEditor?.paintMasks(t);
  }
  function changed(){visualDirty=true;mark(false);paint();window.StudioLiveEditor?.refresh();}
  function validateMask(candidate){
    if(candidate.end>total()+1e-7)throw Error('打码不能超出本集画面结尾');
    StudioTimeline.layout({...p,masks:(p.masks||[]).map(m=>m.id===candidate.id?candidate:m)});
  }
  async function commit(candidate){
    try{validateMask(candidate);const {id,...patch}=candidate;const result=StudioTimeline.apply(p,{type:'update',kind:'mask',id,patch});remember();p=result.project;mark(false);render()}
    catch(error){toast(error.message,true)}
  }
  function renderPanel(){
    if(!p)return;
    const masks=p.masks||[];
    $('#panel').innerHTML=`<div class="panel-head"><h3>打码</h3><small>${masks.length} 段</small></div><p class="helper">在编辑预览中拖动方框即时遮挡，支持实心白块或模糊＋提亮。移动目标可添加位置关键帧；可在属性中选择打码位于字幕上方或下方。</p><div class="toolbar"><button id="mask-add" class="accent">＋ 在播放头添加</button></div>${masks.length?masks.map((m,i)=>`<div class="card mask-card ${current()?.id===m.id?'mask-card-active':''}" data-mask-card="${m.id}"><div class="card-title">${i+1}. ${m.mode==='solid'?'实心白块':'模糊＋提亮'}</div><small>${time(m.start)} → ${time(m.end)} · ${m.keyframes.length} 个位置/尺寸关键帧</small></div>`).join(''):empty('还没有打码','将播放头移动到需要遮挡的画面，点击添加。')}`;
    $('#mask-add').onclick=handle(()=>StudioTimelineUI.addMask());
    $$('[data-mask-card]').forEach(el=>el.onclick=()=>StudioTimelineUI.select('mask',el.dataset.maskCard));
  }
  function renderMaskInspector(atTime=now()){
    const m=current();if(!m)return false;
    const t=atTime,pos=position(m,t),point=activePoint(m,t,false);
    lastInspectorFrame=`${m.id}:${Math.round(t*rate())}`;
    const field=(k,label,v,step='1')=>`<div><label>${label}</label><input data-mask-field="${k}" type="text" inputmode="decimal" value="${Number(v.toFixed(3))}" data-step="${step}"></div>`;
    $('#inspector').innerHTML=`<h3>打码属性</h3><span class="tl-badge">实时打码 · 不影响声音</span><div class="row">${field('start','开始 / 秒',m.start,'.001')}${field('end','结束 / 秒',m.end,'.001')}</div><hr class="section-break"><p class="helper">暂停画面后拖动白框定位，拖右下角调整宽高。中途调整会自动建立关键帧，位置与尺寸在关键帧之间平滑变化。</p><div class="row">${field('x','当前 X / 1080',pos.x)}${field('y','当前 Y / 1920',pos.y)}</div><div class="row">${field('w','宽度 / 1080',pos.w)}${field('h','高度 / 1920',pos.h)}</div><div class="row">${field('blur','模糊强度 1–40',m.blur)}${field('white','白色柔化 0–0.6',m.white,'.01')}</div><div class="row">${field('feather','边缘羽化 0–1',m.feather||0,'.01')}</div><button id="mask-apply" class="wide accent">应用打码参数</button><div class="toolbar"><button id="mask-key-add" ${point||t<=m.start||t>=m.end?'disabled':''}>＋ 当前位置关键帧</button><button id="mask-key-delete" class="danger" ${!point||point===m?'disabled':''}>删除此关键帧</button></div><div class="helper">${m.keyframes.length?m.keyframes.map(k=>`<button class="mask-key-jump" data-mask-jump="${k.time}">${time(k.time)}</button>`).join(' '):'暂无关键帧，遮挡框在整段内保持不动。'}</div><p class="helper">编辑预览即时显示打码；X/Y 按左上角起算。剪映原生矩形模糊的羽化在本地导出中使用兼容近似，原生草稿参数保持不变。最终效果请分别核对本地导出和剪映画面。</p>`;
    const mode=document.createElement('label');mode.innerHTML=`打码效果<select id="mask-effect-mode"><option value="solid" ${m.mode==='solid'?'selected':''}>实心白块</option><option value="blur" ${(m.mode||'blur')==='blur'?'selected':''}>模糊＋提亮</option></select>`;
    const order=document.createElement('label');order.innerHTML=`与字幕的上下关系<select id="mask-layer-order"><option value="below_captions" ${m.layer!=='above_captions'?'selected':''}>字幕在上，打码在下</option><option value="above_captions" ${m.layer==='above_captions'?'selected':''}>打码在上，遮住字幕</option></select>`;
    $('#inspector').append(order);
    $('#mask-layer-order').onchange=()=>commit({...copy(m),layer:$('#mask-layer-order').value});
    $('#inspector h3').after(mode);
    $('#mask-effect-mode').onchange=()=>{const next=copy(m);next.mode=$('#mask-effect-mode').value;if(next.mode==='solid')next.feather=0;if(p.native?.shared&&next.mode==='blur')next.white=0;commit(next)};
    for(const key of ['blur','white','feather'])$(`[data-mask-field="${key}"]`).disabled=m.mode==='solid';
    $('#mask-apply').onclick=handle(()=>{
      const values={};
      $$('[data-mask-field]').forEach(el=>{if(!el.value.trim()||!Number.isFinite(Number(el.value)))throw Error('请输入有效数字');values[el.dataset.maskField]=Number(el.value)});
      const next=copy(m);
      if(values.start>=values.end)throw Error('开始必须早于结束');
      if(values.start>next.start){const at=position(next,values.start);next.x=at.x;next.y=at.y;next.w=at.w;next.h=at.h;next.keyframes=next.keyframes.filter(k=>k.time>values.start)}
      next.start=values.start;next.end=values.end;next.keyframes=next.keyframes.filter(k=>k.time<next.end);
      for(const key of ['blur','white','feather'])next[key]=values[key];
      const animatedSize=next.keyframes.some(k=>'w' in k||'h' in k),geometryChanged=['x','y','w','h'].some(key=>Math.abs(values[key]-pos[key])>1e-4);
      if(geometryChanged&&(animatedSize||t>next.start+.5/rate())){
        const at=activePoint(next,t,true);if(!at)throw Error('播放头必须位于这段打码内部');for(const key of ['x','y','w','h'])at[key]=values[key];
      }else{
        for(const key of ['x','y','w','h'])next[key]=values[key];
      }
      if(JSON.stringify(next)!==JSON.stringify(m))commit(next);
    });
    $('#mask-key-add').onclick=handle(()=>{const next=copy(m);activePoint(next,t,true);commit(next)});
    $('#mask-key-delete').onclick=handle(()=>{const next=copy(m);next.keyframes=next.keyframes.filter(k=>!almost(k.time,t));commit(next)});
    $$('[data-mask-jump]').forEach(el=>el.onclick=()=>{StudioTimelineUI.seek(Number(el.dataset.maskJump));renderInspector()});
    if((p.track_locks||[]).includes('mask'))for(const control of $$('#inspector input,#inspector select,#inspector button'))control.disabled=true;
    return true;
  }
  layer.addEventListener('pointerdown',e=>{
    const box=e.target.closest('[data-mask-id]'),m=current();
    if(e.button!==0||!box||!m||box.dataset.maskId!==m.id||(p.track_locks||[]).includes('mask'))return;
    const t=now();if(t<m.start||t>=m.end)return;
    window.StudioRealtime?.pause();$('#video').pause();clearTimeout(timer);
    drag={id:m.id,t,startX:e.clientX,startY:e.clientY,original:copy(m),resize:!!e.target.closest('[data-mask-resize]'),pointer:e.pointerId,changed:false};
    layer.setPointerCapture(e.pointerId);e.preventDefault();
  });
  layer.addEventListener('pointermove',e=>{
    if(!drag||e.pointerId!==drag.pointer)return;
    const m=(p.masks||[]).find(v=>v.id===drag.id);if(!m)return;
    const dx=(e.clientX-drag.startX)*1080/$('#stage').clientWidth,dy=(e.clientY-drag.startY)*1920/$('#stage').clientHeight;
    if(Math.abs(dx)+Math.abs(dy)<1&&!drag.changed)return;
    const snapshot=drag.original;
    if(drag.resize){
      const base=position(snapshot,drag.t),width=Math.max(16,Math.min(4320,Math.round(base.w+dx))),height=Math.max(16,Math.min(7680,Math.round(base.h+dy)));
      if(snapshot.keyframes.some(k=>'w' in k||'h' in k)||drag.t>snapshot.start+.5/rate()){
        const point=activePoint(m,drag.t,true);point.w=width;point.h=height;
      }else{m.w=width;m.h=height}
    }else{
      const point=activePoint(m,drag.t,true),base=activePoint(snapshot,drag.t,false)||position(snapshot,drag.t);
      const size=position(m,drag.t);
      if(point){point.x=Math.max(16-size.w,Math.min(1064,Math.round(base.x+dx)));point.y=Math.max(16-size.h,Math.min(1904,Math.round(base.y+dy)))}
    }
    drag.changed=true;paint(drag.t);window.StudioRealtime?.refresh();
  });
  async function finishDrag(e,cancel=false){
    if(!drag||e.pointerId!==drag.pointer)return;
    const entry=drag;drag=null;if(layer.hasPointerCapture(e.pointerId))layer.releasePointerCapture(e.pointerId);
    if(cancel){const i=p.masks.findIndex(m=>m.id===entry.id);if(i>=0)p.masks[i]=entry.original;paint();window.StudioRealtime?.refresh();if(dirty>saved)timer=setTimeout(()=>save().catch(e=>toast(e.message,true)),600);return}
    if(!entry.changed)return;
    const changedMask=p.masks.find(m=>m.id===entry.id);
    try{validateMask(changedMask)}catch(err){const i=p.masks.findIndex(m=>m.id===entry.id);p.masks[i]=entry.original;paint();toast(err.message,true);return}
    const candidate=copy(changedMask);p.masks=p.masks.map(m=>m.id===entry.id?entry.original:m);
    await commit(candidate);if(tab==='masks')renderPanel();renderInspector();StudioTimelineUI.refresh();window.StudioRealtime?.refresh();
  }
  layer.addEventListener('pointerup',e=>finishDrag(e));
  layer.addEventListener('pointercancel',e=>finishDrag(e,true));
  render=function(...args){old.render(...args);if(tab==='masks')renderPanel();paint()};
  renderInspector=function(...args){if(!renderMaskInspector())old.renderInspector(...args)};
  updateOverlay=function(frameTime){
    old.updateOverlay(frameTime);
    const t=Number.isFinite(frameTime)?frameTime:now();paint(t);
    const m=current(),frame=m?`${m.id}:${Math.round(t*rate())}`:null;
    if(frame&&frame!==lastInspectorFrame&&!$('#inspector').contains(document.activeElement))renderMaskInspector(t);
  };
  openProject=async function(...args){visualDirty=false;await old.openProject(...args);paint()};
  viewRender=async function(...args){await old.viewRender(...args);visualDirty=false;paint()};
  window.StudioMasks={position,paint,dragging:()=>!!drag};
}

;
// Source: library.js
'use strict';
function installStudioLibrary(){
  const original={api,refreshBoot,renderProjects,openProject,modal,pollJobs};
  let folders=[],folder=null,started=false,openSequence=0;
  const sortKey='studio-library-sort',sortModes=['name-asc','name-desc','modified-desc','modified-asc'];
  const nameOrder=new Intl.Collator('zh-CN-u-co-pinyin',{numeric:true,sensitivity:'base'});
  let sortMode='name-asc';
  try{const saved=localStorage.getItem(sortKey);if(sortModes.includes(saved))sortMode=saved}catch(_){}
  const params=new URLSearchParams(location.search),workspaceId=params.get('workspace'),projectId=params.get('project');
  const home=document.createElement('section');home.id='library-home';
  home.innerHTML='<div class="library-heading"><div><h1>剧目</h1><p>一部剧一个剧目，打开后按分集剪辑。</p></div><div class="library-actions"><button id="library-manage">管理</button><button id="library-import">导入文件夹</button><button id="library-new" class="primary">＋ 新建剧目</button></div></div><div class="library-summary" id="library-summary"></div><input id="library-search" type="search" placeholder="搜索剧名" aria-label="搜索剧名"><div id="library-cards"></div>';
  const toolbar=document.createElement('div');toolbar.className='library-toolbar';
  const search=home.querySelector('#library-search');search.before(toolbar);toolbar.append(search);
  const sortLabel=document.createElement('label');sortLabel.className='library-sort';
  sortLabel.innerHTML='<span>排序</span><select id="library-sort" aria-label="剧目文件夹排序"><option value="name-asc">首字母 A–Z</option><option value="name-desc">首字母 Z–A</option><option value="modified-desc">修改时间：最新优先</option><option value="modified-asc">修改时间：最早优先</option></select>';
  toolbar.append(sortLabel);sortLabel.querySelector('select').value=sortMode;
  document.querySelector('.app-layout').before(home);
  const button=document.createElement('button');button.id='library-home-button';button.textContent='⌂ 首页';
  document.querySelector('.top-actions').prepend(button);
  const title=document.createElement('span');title.id='library-workspace-title';document.querySelector('.brand').append(title);
  function workspaceUrl(id){return location.origin+location.pathname+'?workspace='+encodeURIComponent(id)+'#token='+encodeURIComponent(token)}
  function showHome(){
    if(window.chrome?.webview){window.chrome.webview.postMessage({type:'open-home'});return}
    location.href=location.origin+location.pathname+'#token='+encodeURIComponent(token);
  }
  button.onclick=handle(async()=>{await save();if(folder)showHome();else await updateLibrary()});
  function openFolder(id){
    if(window.chrome?.webview)window.chrome.webview.postMessage({type:'open-workspace',folder_id:id});
    else window.open(workspaceUrl(id),'baimu-workspace-'+id);
  }
  function drawHome(){
    const query=document.querySelector('#library-search').value.trim().toLocaleLowerCase();
    document.querySelector('#library-summary').textContent=`${folders.length} 部剧 · ${folders.reduce((n,f)=>n+f.episode_count,0)} 个分集工程`;
    const byName=(a,b)=>nameOrder.compare(a.name,b.name)||String(a.id).localeCompare(String(b.id));
    const modified=f=>{const value=Number(f.modified??f.created??0);return Number.isFinite(value)?value:0};
    const rows=folders.filter(f=>f.name.toLocaleLowerCase().includes(query)).sort((a,b)=>{
      if(sortMode==='name-desc')return -byName(a,b);
      if(sortMode==='modified-desc')return modified(b)-modified(a)||byName(a,b);
      if(sortMode==='modified-asc')return modified(a)-modified(b)||byName(a,b);
      return byName(a,b);
    });
    document.querySelector('#library-cards').innerHTML=rows.map(f=>{
      const numbers=(f.episodes||[]).map(row=>row.episode_number).filter(Number.isFinite),range=numbers.length?` · EP${String(Math.min(...numbers)).padStart(2,'0')}–EP${String(Math.max(...numbers)).padStart(2,'0')}`:'';
      return `<button class="library-card" data-folder="${f.id}"><span class="library-folder-icon" aria-hidden="true">▱</span><strong>${esc(f.name)}</strong><span>${f.episode_count} 集${range}</span><b>打开</b></button>`;
    }).join('')||'<div class="empty"><h3>还没有剧目</h3><p>新建剧目，或导入含分集的文件夹。</p></div>';
    document.querySelectorAll('[data-folder]').forEach(el=>el.onclick=()=>openFolder(el.dataset.folder));
  }
  async function updateLibrary(){
    folders=await original.api('/api/library');
    if(folder){
      const next=folders.find(f=>f.id===folder.id);if(!next)throw Error('剧文件夹不存在，请返回首页');folder=next;
      boot.projects=(boot.projects||[]).filter(p=>p.series===folder.series);
    }
    drawHome();
  }
  window.addEventListener('focus',()=>{if(started&&!folder)updateLibrary().catch(error=>toast(error.message,true))});
  function scopeFields(){
    if(!folder)return;
    for(const id of ['create-series','batch-series','folder-drop-series']){
      const input=document.getElementById(id);if(input){input.value=folder.series;input.readOnly=true;input.title='当前工作页只处理这部剧';}
    }
    const series=document.querySelector('#project-series');series.value=folder.name;series.readOnly=true;
  }
  new MutationObserver(scopeFields).observe(document.querySelector('#modal-body'),{childList:true,subtree:true});
  const oldRender=render;
  render=function(...args){oldRender(...args);scopeFields()};
  modal=function(...args){const result=original.modal(...args);scopeFields();return result};
  api=function(path,body){
    if(folder&&path==='/api/jobs'&&body===undefined)path+='?folder_id='+encodeURIComponent(folder.id);
    return original.api(path,body);
  };
  refreshBoot=async function(){await original.refreshBoot();if(started){await updateLibrary();renderProjects()}};
  renderProjects=function(){
    if(!folder){original.renderProjects();return}
    const query=document.querySelector('#project-search').value.trim().toLocaleLowerCase();
    const ranks=new Map(folder.episodes.map((p,i)=>[p.id,i])),episodes=new Map(folder.episodes.map(row=>[row.id,row]));
    const rows=(boot.projects||[]).filter(p=>p.series===folder.series&&(!query||p.name.toLocaleLowerCase().includes(query)))
      .sort((a,b)=>(ranks.get(a.id)??1e9)-(ranks.get(b.id)??1e9)||a.name.localeCompare(b.name,'zh',{numeric:true}));
    document.querySelector('#projects').innerHTML=rows.map(row=>`<button class="project-row ${p?.id===row.id?'active':''}" data-project="${row.id}" title="${esc(row.name)}"><span class="episode-number">${esc(row.name)}</span></button>`).join('')||'<p class="helper">还没有分集</p>';
    document.querySelectorAll('[data-project]').forEach(el=>el.onclick=handle(()=>openProject(el.dataset.project)));
    document.querySelector('#project-list-count').textContent=rows.length;
  };
  document.querySelector('#project-search').oninput=renderProjects;
  openProject=async function(pid,...args){
    // Reserve the selection before any membership request can finish out of order.
    const request=++openSequence;
    if(started&&!folder){
      await updateLibrary();if(request!==openSequence)return;
      const target=folders.find(f=>f.episodes.some(episode=>episode.id===pid));
      if(!target)throw Error('分集工程不存在，请刷新首页');
      openFolder(target.id);return;
    }
    if(folder){const candidate=await original.api('/api/projects/'+pid);if(request!==openSequence)return;if(candidate.series!==folder.series)throw Error('该集属于另一部剧，请从首页打开它的工作页');}
    await original.openProject(pid,...args);
    if(request!==openSequence)return;
    if(folder&&p?.id===pid){try{localStorage.setItem('studio-last-episode:'+folder.id,pid)}catch(_){}document.title=folder.name+' / '+p.name+' · 九州百慕';}
    scopeFields();
  };
  pollJobs=async function(){await original.pollJobs();if(folder)document.querySelector('#job-count').textContent=jobs.filter(j=>['queued','running'].includes(j.state)).length};
  document.querySelector('#library-search').oninput=drawHome;
  document.querySelector('#library-sort').onchange=event=>{
    sortMode=sortModes.includes(event.target.value)?event.target.value:'name-asc';
    try{localStorage.setItem(sortKey,sortMode)}catch(_){}
    drawHome();
  };
  document.querySelector('#library-manage').onclick=()=>document.querySelector('#manage-button').click();
  document.querySelector('#library-import').onclick=()=>window.studioMaterialImport?.openFolder();
  document.querySelector('#library-new').onclick=()=>{
    modal('<h2>新建剧目</h2><p>一部剧一个剧目，进入后再添加分集。不会移动磁盘上的原素材。</p><label>剧名</label><input id="library-folder-name" maxlength="150" placeholder="填写这部剧的名称"><div class="modal-actions"><button id="library-create" class="primary">创建并打开</button></div>');
    document.querySelector('#library-create').onclick=handle(async()=>{
      const el=document.querySelector('#library-create');el.disabled=true;
      try{const created=await original.api('/api/library',{name:document.querySelector('#library-folder-name').value});document.querySelector('#modal').close();await updateLibrary();openFolder(created.id)}finally{el.disabled=false}
    });
  };
  window.studioLibrary={current:()=>folder?{id:folder.id,name:folder.name,series:folder.series}:null,openFolder,refresh:updateLibrary,
    async start(){
      folders=await original.api('/api/library');
      folder=workspaceId?folders.find(f=>f.id===workspaceId||(f.aliases||[]).includes(workspaceId)):projectId?folders.find(f=>f.episodes.some(p=>p.id===projectId)):null;
      if((workspaceId||projectId)&&!folder)throw Error('工作页不存在，请点击首页重新选择');
      started=true;document.body.classList.remove('library-loading');document.body.classList.toggle('library-home-mode',!folder);document.body.classList.toggle('library-workspace-mode',!!folder);
      if(!folder){document.title='剧本总览 · 九州百慕';drawHome();document.querySelector('#save-status').textContent='全部工程保存在本机';return}
      document.querySelector('#library-workspace-title').textContent=folder.name;
      document.querySelector('.sidebar .section-title').firstChild.textContent='分集 ';
      document.querySelector('#new-button').textContent='＋ 新建分集';document.querySelector('#global-new-button').textContent='＋ 新建分集';
      document.querySelector('#project-search').placeholder='搜索本剧集数';
      boot.projects=(boot.projects||[]).filter(p=>p.series===folder.series);
      // Preserve the existing new-project/import handlers' default series.
      const filter=document.querySelector('#series-filter');filter.value='s:'+encodeURIComponent(folder.series);if(filter.value)filter.onchange();
      let last=projectId;try{last=last||localStorage.getItem('studio-last-episode:'+folder.id)}catch(_){}
      const chosen=folder.episodes.find(p=>p.id===last)||folder.episodes[0];
      if(chosen)await openProject(chosen.id);else{render();renderProjects();document.querySelector('#save-status').textContent='新剧已建立，请添加分集';}
      if(window.chrome?.webview)window.chrome.webview.postMessage({type:'workspace-title',title:folder.name});
    }};
}

;
// Source: workflow.js
'use strict';
const StudioWorkflow={
  toPercent(value,dimension,axis){return 50+(axis==='y'?-1:1)*Number(value)/dimension*50},
  fromPercent(value,dimension,axis){return (Number(value)-50)*dimension/50*(axis==='y'?-1:1)}
};
if(typeof module!=='undefined')module.exports=StudioWorkflow;
function installStudioWorkflow(){
  const previous={openProject,renderInspector,mark};let opening=0,packageBusy=false;
  async function restoreOutput(pid,ticket){
    const result=await api('/api/projects/'+pid+'/playback');
    if(ticket!==opening||p?.id!==pid||dirty>saved||$('#video').getAttribute('src'))return false;
    if(result.job){await viewRender(result.job);return true}
    $('#preview-label').textContent='尚无可播放视频';
    $('#preview-note').textContent='本集还没有可用导出或混音预览。点击“生成混音预览”，或导出审阅版。';return false;
  }
  window.studioPreviewSubtitleStyle=async()=>{
    if(!p)return 'none';
    const pid=p.id;
    if(previewJob?.kind==='preview'&&previewJob.result?.sound_digest===qa?.sound_hash&&$('#video').getAttribute('src')){
      updateOverlay();return 'live';
    }
    const result=await api('/api/projects/'+pid+'/playback?mode=mix');
    if(p?.id!==pid)return 'switched';
    if(result.job){
      const position=$('#video').currentTime;
      await viewRender(result.job);
      if(p?.id!==pid)return 'switched';
      if(Number.isFinite(position)&&position>0)$('#video').currentTime=position;
      return 'live';
    }
    return previewJob?.result?.captions_burned?'burned':'none';
  };
  openProject=async function(pid,...args){
    const ticket=++opening;await previous.openProject(pid,...args);
    if(p?.id!==pid||ticket!==opening)return;
    if(window.StudioRealtime)return;
    try{await restoreOutput(pid,ticket)}catch(error){if(p?.id===pid)toast('工程已打开，历史视频暂未加载：'+error.message,true)}
  };
  $('#play-button').onclick=handle(async()=>{
    if(!p)throw Error('请先打开分集');
    const pid=p.id;
    if(!$('#video').getAttribute('src')){
      await save();await restoreOutput(p.id,opening);
      if(p?.id!==pid)return;
      if(!$('#video').getAttribute('src'))throw Error('本集尚无可播放结果，请生成混音预览或导出审阅版');
    }
    if($('#video').paused)await $('#video').play();else $('#video').pause();
  });
  renderInspector=function(){
    previous.renderInspector();if(!p)return;
    let note;
    for(const axis of ['x','y']){
      const percent=document.querySelector(`[data-style="${axis}"]`);if(!percent)continue;
      const dimension=axis==='y'?p.height:p.width,container=percent.parentElement,label=container.querySelector('label');
      label.textContent='剪映位置 '+axis.toUpperCase();percent.hidden=true;
      const input=document.createElement('input');input.type='number';input.id='jianying-'+axis;input.min=-dimension;input.max=dimension;input.step='.01';
      input.value=Number(StudioWorkflow.fromPercent(percent.value,dimension,axis).toFixed(4));
      input.setAttribute('aria-label',label.textContent);
      const hint=document.createElement('small');hint.style.cssText='display:block;color:var(--muted);font-size:10px';
      const sync=()=>{hint.textContent='画布 '+dimension+' px · '+Number(percent.value).toFixed(2)+'%'};sync();
      input.onchange=()=>{
        const value=Number(input.value);
        if(input.value===''||!Number.isFinite(value)||Math.abs(value)>dimension){toast('位置值应在 '+(-dimension)+' 至 '+dimension+' 之间',true);return}
        const converted=StudioWorkflow.toPercent(value,dimension,axis);
        if(Math.abs(Number(percent.value)-converted)<1e-10){sync();return}
        percent.value=converted;percent.onchange();sync();
      };
      container.append(input,hint);note=percent.closest('.row');
    }
    if(note){
      const help=document.createElement('div');help.className='subtitle-preset';help.innerHTML='<p class="helper">整个字幕框居中定位；X 正数向右，Y 正数向上。按当前画布尺寸作 2 倍换算。单行、双行围绕同一中心。此为兼容换算，尚未经本机剪映实测。</p><button id="calibrate-caption-y">校准当前样式：Y = −800</button>';
      note.after(help);help.querySelector('button').onclick=()=>{const input=$('#jianying-y');input.value=-800;input.onchange();toast('已更新当前字幕样式位置；可撤销。请导出样张校准，不会批量修改其他集。')};
    }
  };
  window.addEventListener('beforeunload',event=>{if(packageBusy){event.preventDefault();event.returnValue='工程包正在处理，请等待完成'}});
  async function packageOperation(work){
    if(packageBusy)throw Error('工程包正在处理，请勿重复提交');
    packageBusy=true;try{return await work()}finally{packageBusy=false}
  }
  const share=document.createElement('button');share.id='share-project-button';share.textContent='工程分享';
  document.querySelector('.heading-actions').prepend(share);
  share.onclick=handle(async()=>{
    if(!p)throw Error('请先打开分集');await save();const pid=p.id;
    modal('<h2>单集工程分享包</h2><p>包含当前工程、素材库和所需字体，接收方无需原目录。导入时建立新副本，不覆盖已有工程。</p><p class="helper">不含历史版本、旧成片和外部 PDF/DOCX 原文件；已读入的剧本文字会保留。素材较多时，打包耗时且占用额外磁盘空间。请确认素材与字体允许分享。</p><div id="package-progress"></div><div class="modal-actions"><button id="package-export" class="primary">打包当前已保存版本</button><button id="package-open-import">导入工程包副本</button></div>');
    $('#package-open-import').onclick=()=>showImport();
    $('#package-export').onclick=handle(()=>packageOperation(async()=>{
      await save();if(p?.id!==pid)throw Error('分集已切换，请重新打开工程分享');
      const button=$('#package-export'),progress=$('#package-progress');button.disabled=true;progress.textContent='正在复制并校验素材，请勿关闭窗口…';
      try{
        const result=await api('/api/projects/'+pid+'/package',{revision:p.revision});
        progress.innerHTML=`<p>工程包已生成，${(result.size/1024/1024).toFixed(1)} MB</p><a class="accent" href="${url((result.kind==='native'?'/api/native/packages/':'/api/packages/')+result.id)}" download>保存工程ZIP包</a><p class="helper">${esc(result.note)}</p>`;
      }finally{button.disabled=false}
    }));
  });
  function showImport(){
    const folder=window.studioLibrary?.current();
    modal(`<h2>导入工程包副本</h2><p>填写本机收到的工程ZIP路径。逐个校验素材和字体后创建新工程。</p><input id="package-import-path" placeholder="D:\\收到的工程.zip" style="width:100%"><p class="helper">${folder?'副本将加入当前剧：'+esc(folder.name):'副本将按包内剧名出现在首页'}。验收记录需要重新确认；旧工程、旧导出和历史不覆盖。</p><div id="package-import-status"></div><div class="modal-actions"><button id="package-import-confirm" class="primary">导入为新副本</button></div>`);
    $('#package-import-confirm').onclick=handle(()=>packageOperation(async()=>{
      const path=$('#package-import-path').value.trim();if(!path)throw Error('请填写工程ZIP完整路径');
      const button=$('#package-import-confirm');button.disabled=true;$('#package-import-status').textContent='正在校验并导入…';
      try{
        await save();const created=await api('/api/packages/import',{path,...(folder?{series:folder.series}:{})});
        $('#modal').close();await refreshBoot();
        if(created.kind==='native'){await window.studioNativeDrafts.show(created.key);toast(created.message)}
        else{await openProject(created.id);toast('工程已导入为新副本，旧工程未覆盖')}
      }finally{button.disabled=false}
    }));
  }
  const homeImport=document.createElement('button');homeImport.id='library-import-package';homeImport.textContent='导入工程包';homeImport.onclick=()=>showImport();
  document.querySelector('.library-actions').prepend(homeImport);
}

;
// Source: live-editor.js
'use strict';
const StudioLiveLayers={
  reference(p){
    const pick=(o,keys)=>Object.fromEntries(keys.map(k=>[k,o[k]??null]));
    const assets=ids=>p.assets.filter(a=>ids.has(a.id)).map(a=>pick(a,['id','sha256'])).sort((a,b)=>a.id.localeCompare(b.id));
    const clips=p.clips.map(c=>pick(c,['asset_id','in','out']));
    return {
      picture:{clips,assets:assets(new Set(clips.map(c=>c.asset_id))),fps:p.fps,width:p.width,height:p.height},
      sound:{clips:p.clips.map(c=>pick(c,['asset_id','in','out','gain','audio_stream','audio_detached'])),audios:p.audios.map(a=>pick(a,['asset_id','in','out','start','gain','role','loop','audio_stream','fade_in','fade_out'])),assets:assets(new Set([...p.clips,...p.audios].map(a=>a.asset_id))),fps:p.fps},
      subtitles:{style:p.style,captions:p.captions.map(c=>pick(c,['text','start','end','style']))},masks:p.masks||[]
    };
  },
  diff(base,current){
    if(!base)return ['picture','sound','subtitles','masks'];
    const a=this.reference(base),b=this.reference(current);
    return Object.keys(a).filter(k=>JSON.stringify(a[k])!==JSON.stringify(b[k]));
  },
  blur(data,w,h,r,lift){
    // Separable, twice-per-axis box filter with symmetric edge extension.
    const mirror=(i,n)=>i<0?-i-1:i>=n?2*n-i-1:i;
    let a=new Uint8ClampedArray(data),b=new Uint8ClampedArray(a.length);const n=2*r+1;
    for(const horizontal of [true,false])for(let pass=0;pass<2;pass++){
      const lines=horizontal?h:w,length=horizontal?w:h;
      for(let line=0;line<lines;line++)for(let c=0;c<3;c++){
        const index=i=>horizontal?(line*w+i)*4+c:(i*w+line)*4+c;
        let sum=0;for(let i=-r;i<=r;i++)sum+=a[index(mirror(i,length))];
        for(let i=0;i<length;i++){
          b[index(i)]=Math.floor(sum/n+.5);
          sum+=a[index(mirror(i+r+1,length))]-a[index(mirror(i-r,length))];
        }
      }
      for(let i=3;i<b.length;i+=4)b[i]=255;[a,b]=[b,a];
    }
    for(let i=0;i<a.length;i+=4)for(let c=0;c<3;c++)a[i+c]=Math.min(255,Math.floor(a[i+c]+lift*255));
    return a;
  }
};
if(typeof module!=='undefined')module.exports=StudioLiveLayers;

function installStudioLiveEditor(){
  const old={openProject,viewRender,mark,updateOverlay,renderInspector,render};
  const video=$('#video'),overlay=$('#caption-overlay');
  let mode='edit',clean=false,opening=0,openEpoch=0,ticket=0,reference=null,drag=null,errorShown=false,lastStatus=0;
  const toolbar=document.createElement('div');toolbar.className='viewer-modes';
  toolbar.innerHTML='<button id="mode-edit" class="accent">编辑预览</button><button id="mode-export">导出结果</button><button id="refresh-edit-preview" title="更新底图／混音" aria-label="更新底图与混音">↻</button><select id="caption-drag-scope" aria-label="字幕拖动范围"><option value="all">整集拖动</option><option value="one">单条拖动</option></select>';
  document.querySelector('.viewer-top').before(toolbar);
  const canvas=document.createElement('canvas');canvas.id='mask-preview-canvas';$('#mask-layer').before(canvas);
  const scratch=document.createElement('canvas'),ctx=scratch.getContext('2d',{willReadFrequently:true}),out=canvas.getContext('2d');
  const editing=()=>mode==='edit'&&clean;
  function status(force=false){
    if(!force&&performance.now()-lastStatus<180)return;lastStatus=performance.now();
    $('#mode-edit').classList.toggle('accent',mode==='edit');$('#mode-export').classList.toggle('accent',mode==='export');
    $('#caption-drag-scope').hidden=mode!=='edit'||tab!=='captions';
    if(!p)return;
    const diff=reference?StudioLiveLayers.diff(reference,p):[],names={picture:'镜头画面',sound:'声音',subtitles:'字幕',masks:'打码'};
    if(mode==='edit'){
      if(!clean){$('#preview-label').textContent='编辑底图尚未准备';return}
      const stale=diff.filter(k=>k==='picture'||k==='sound');
      $('#preview-label').textContent=stale.length?stale.map(k=>names[k]).join('、')+'已改 · 请更新底图／混音':'编辑预览 · 字幕／打码实时';
      $('#preview-note').textContent=stale.length?'当前底图或声音来自旧版本；字幕和打码已即时更新。点击“更新底图／混音”后再核对音画。':'字幕可拖动定位、拖角改字号；打码选中后拖动与调大小。当前为编辑效果，导出结果可单独查看。';
    }else{
      $('#preview-label').textContent='导出结果'+(diff.length?' · '+diff.map(k=>names[k]).join('、')+'已修改':' · 与当前内容一致');
      $('#preview-note').textContent='正在播放真实导出MP4，字幕和打码固定在文件中。返回“编辑预览”可即时调整。';
    }
    overlay.style.display=editing()?'block':'none';
    canvas.style.display=editing()?'block':'none';
    $('#mask-layer').style.display=editing()?'block':'none';
  }
  function paintMasks(t){
    if(!editing()||!p||video.readyState<2){out.clearRect(0,0,canvas.width,canvas.height);return}
    const masks=(p.masks||[]).filter(m=>t>=m.start&&t<m.end);
    const w=Math.min(540,video.videoWidth||540),h=Math.round(w*16/9),scale=w/1080;
    if(canvas.width!==w||canvas.height!==h){canvas.width=scratch.width=w;canvas.height=scratch.height=h}
    out.clearRect(0,0,w,h);if(!masks.length)return;
    try{
      ctx.drawImage(video,0,0,w,h);
      for(const m of masks){
        const at=StudioMasks.position(m,t),left=Math.floor(at.x*scale),top=Math.floor(at.y*scale),right=Math.ceil((at.x+at.w)*scale),bottom=Math.ceil((at.y+at.h)*scale);
        const x=Math.max(0,left),y=Math.max(0,top),mw=Math.max(0,Math.min(w,right)-x),mh=Math.max(0,Math.min(h,bottom)-y);if(!mw||!mh)continue;
        if(m.mode==='solid'){ctx.fillStyle='white';ctx.fillRect(x,y,mw,mh)}
        else{
          const image=ctx.getImageData(x,y,mw,mh),radius=Math.max(1,Math.min(Math.round(m.blur*scale),Math.floor(mw/2),Math.floor(mh/2)));
          image.data.set(StudioLiveLayers.blur(image.data,mw,mh,radius,m.white));ctx.putImageData(image,x,y);
        }
        out.drawImage(scratch,x,y,mw,mh,x,y,mw,mh);
      }
    }catch(error){out.clearRect(0,0,w,h);if(!errorShown){errorShown=true;toast('打码实时预览失败：'+error.message,true)}}
  }
  function adorn(){
    const can=editing()&&tab==='captions'&&!!overlay.textContent;
    overlay.classList.toggle('caption-editable',can);overlay.style.pointerEvents=can?'auto':'none';
    overlay.title=can?'拖动字幕位置；右下角改字号。范围由“拖动”选项决定。':'';
    if(can&&!overlay.querySelector('.caption-resize')){const corner=document.createElement('span');corner.className='caption-resize';corner.dataset.captionResize='1';overlay.append(corner)}
  }
  async function loadEdit(){
    if(!p)return false;const pid=p.id,turn=++ticket;mode='edit';clean=false;status(true);
    $('#preview-label').textContent='正在准备编辑底图…';
    const result=await api('/api/projects/'+pid+'/editing-preview',{});
    if(p?.id!==pid||turn!==ticket)return false;
    await refreshQA();if(p?.id!==pid||turn!==ticket)return false;
    if(!result.job){
      video.pause();video.removeAttribute('src');video.load();reference=null;clean=false;
      status(true);$('#preview-label').textContent='首次编辑：请准备底图／混音';$('#preview-note').textContent='点击“更新底图／混音”。准备一次后，字幕和打码调整即时可见。';return false;
    }
    const job=result.job,position=video.currentTime||0;
    previewJob=job;reference=job.view_reference;clean=true;peaks=job.result.waveform;
    const stale=StudioLiveLayers.diff(reference,p).some(k=>k==='picture'||k==='sound');
    StudioTimelineUI.previewUpdated(stale);
    video.src=url(`/render/${job.id}/${job.result.file}`);video.load();
    if(position>0)video.currentTime=position;
    status(true);updateOverlay(position);drawWave();return true;
  }
  async function loadExport(job=null){
    if(!p)return;const pid=p.id,turn=++ticket;
    if(!job){const result=await api('/api/projects/'+pid+'/playback?mode=export');job=result.job}
    if(p?.id!==pid||turn!==ticket)return;
    if(!job){toast('本集还没有导出结果，可先导出审阅版');return}
    mode='export';clean=false;
    await old.viewRender(job);if(p?.id!==pid||turn!==ticket)return;
    reference=previewJob?.view_reference||null;status(true);updateOverlay();
  }
  $('#mode-edit').onclick=handle(async()=>{await save();await loadEdit()});
  $('#mode-export').onclick=handle(async()=>{await save();await loadExport()});
  $('#refresh-edit-preview').onclick=handle(async()=>{mode='edit';await submitJob('preview')});
  $('#preview-button').textContent='更新底图／混音';$('#preview-button').title='镜头或声音改变后更新；字幕和打码无需重复生成';
  $('#preview-button').onclick=handle(async()=>{mode='edit';await submitJob('preview')});
  openProject=async function(pid,...args){
    const epoch=++openEpoch;ticket++;mode='edit';clean=false;reference=null;opening++;canvas.width=canvas.width;
    try{await old.openProject(pid,...args)}finally{opening--}
    if(epoch!==openEpoch)return;
    if(p?.id===pid&&!window.StudioRealtime)try{await loadEdit()}catch(error){clean=false;status();toast('编辑底图未准备完成：'+error.message,true)}
  };
  viewRender=async function(job){
    if(opening)return;
    if(job.project_id!==p?.id){await openProject(job.project_id);if(p?.id!==job.project_id)return}
    if(job.kind==='preview')await loadEdit();else await loadExport(job);
  };
  mark=function(...args){old.mark(...args);status(true)};
  updateOverlay=function(t){
    old.updateOverlay(t);status();
    adorn();
  };
  renderInspector=function(...args){old.renderInspector(...args);adorn()};
  render=function(...args){old.render(...args);status(true);adorn();paintMasks(video.currentTime||0)};
  video.addEventListener('loadeddata',()=>{updateOverlay();status(true)});
  window.studioPreviewSubtitleStyle=async()=>{
    if(mode!=='edit'||!clean)await loadEdit();updateOverlay();return editing()?'live':'none';
  };
  function finish(e,cancel=false){
    if(!drag||e.pointerId!==drag.pointer)return;
    const d=drag;drag=null;if(overlay.hasPointerCapture(d.pointer))overlay.releasePointerCapture(d.pointer);
    if(p?.id!==d.pid)return;
    if(cancel){p.style=copy(d.before.style);p.captions.forEach(c=>{const original=d.before.captions.find(v=>v.id===c.id);if(original)c.style=copy(original.style||{})});updateOverlay();if(dirty>saved)timer=setTimeout(()=>save().catch(e=>toast(e.message,true)),600);return}
    if(!d.changed)return;
    undo.push(d.before);if(undo.length>40)undo.shift();mark(false);renderInspector();updateOverlay();
  }
  overlay.addEventListener('pointerdown',e=>{
    if(e.button!==0||!editing())return;
    const t=video.currentTime||0,cue=p.captions.find(c=>t>=c.start&&t<c.end);if(!cue)return;
    video.pause();clearTimeout(timer);selected=cue.id;tab='captions';
    const effective={...p.style,...cue.style},box=overlay.getBoundingClientRect();
    drag={pid:p.id,pointer:e.pointerId,cue:cue.id,before:copy(p),x:e.clientX,y:e.clientY,style:effective,height:box.height,
          scope:$('#caption-drag-scope').value,resize:!!e.target.closest('[data-caption-resize]'),changed:false};
    overlay.setPointerCapture(e.pointerId);e.preventDefault();
  });
  overlay.addEventListener('pointermove',e=>{
    if(!drag||e.pointerId!==drag.pointer||p?.id!==drag.pid)return;
    const d=drag,stage=$('#stage').getBoundingClientRect(),dx=e.clientX-d.x,dy=e.clientY-d.y;
    if(Math.abs(dx)+Math.abs(dy)<1&&!d.changed)return;
    const patch=d.resize?{font_size:Math.max(4,Math.min(800,Math.round(d.style.font_size*(1+dy/Math.max(12,d.height)))))}:
      {x:Math.max(0,Math.min(100,d.style.x+dx/stage.width*100)),y:Math.max(0,Math.min(100,d.style.y+dy/stage.height*100))};
    if(d.scope==='all'){
      Object.assign(p.style,patch);for(const c of p.captions)for(const k of Object.keys(patch))if(c.style)delete c.style[k];
    }else{const cue=p.captions.find(c=>c.id===d.cue);cue.style={...cue.style,...patch}}
    d.changed=true;updateOverlay();
  });
  overlay.addEventListener('pointerup',e=>finish(e));overlay.addEventListener('pointercancel',e=>finish(e,true));
  window.addEventListener('keydown',e=>{if(e.key==='Escape'&&drag){e.preventDefault();finish({pointerId:drag.pointer},true)}});
  window.addEventListener('beforeunload',e=>{if(drag?.changed){e.preventDefault();e.returnValue='字幕拖动尚未结束'}});
  window.StudioLiveEditor={editing,paintMasks,refresh:()=>{status(true);updateOverlay()},mode:()=>mode,loadEdit};
}

;
// Source: editor-actions.js
'use strict';
function installStudioEditActions(){
  let busy=false,redo=[],polling=false;
  const notice=document.createElement('div');notice.id='parallel-editor-notice';notice.className='parallel-editor-notice';notice.hidden=true;notice.setAttribute('role','status');
  $('.project-heading').after(notice);
  let noticeProject=null,editorRunning=false,syncError='',handoffResult=null,noticeMarkup='';
  function showNotice(){
    if(noticeProject!==p?.id){noticeProject=p?.id;editorRunning=false;syncError='';handoffResult=null;noticeMarkup=''}
    const messages=[];
    if(p?.native?.shared)messages.push(editorRunning?'当前是一份共同草稿。剪映保存后百慕会读取磁盘新版本；百慕保存后，请先在剪映保存当前页面、返回首页，再重开这一集，避免旧页面覆盖新版本。':'当前是一份共同草稿。剪映保存后百慕会自动读取磁盘新版本；百慕修改也直接保存在这份草稿中。');
    if(handoffResult)messages.push(`共同草稿「${handoffResult.name||p.name}」已登记。${handoffResult.refresh_required?'剪映已经运行：保存当前页面并返回首页后打开这一集；不必再次点刷新。若首页仍缓存旧列表，再重启剪映。':'剪映已启动，在本地草稿顶部打开即可。'}`);
    if(syncError)messages.push('暂未同步剪映的新版本：'+syncError+'。当前编辑已保留。');
    notice.hidden=!messages.length;
    const actions=[];
    if(p?.native?.shared)actions.push('<button id="reload-jianying-save">读取剪映已保存</button>');
    if(handoffResult)actions.push('<button id="handoff-reveal">定位工程</button><button id="handoff-launch">打开剪映</button>');
    const markup=messages.map(text=>`<span>${esc(text)}</span>`).join('')+(actions.length?'<div>'+actions.join('')+'</div>':'');
    if(markup===noticeMarkup)return;
    noticeMarkup=markup;notice.innerHTML=markup;
    if(p?.native?.shared)$('#reload-jianying-save').onclick=handle(()=>readSharedSaved(true));
    if(handoffResult){
      const key=handoffResult.key;
      $('#handoff-reveal').onclick=handle(()=>api('/api/native/reveal',{key}));
      $('#handoff-launch').onclick=handle(()=>api('/api/native/launch',{}));
    }
  }
  const oldRemember=remember;
  remember=function(){redo=[];oldRemember()};
  async function transaction(work,saveFirst=true){
    if(busy)throw Error('上一项编辑正在保存');
    busy=true;
    const main=$('main'),previous=main.inert;
    try{
      if(saveFirst)await save();else{clearTimeout(timer);if(saving)await saving}main.inert=true;
      return await studioProjectHooks.transaction(work,{skipSave:!saveFirst});
    }finally{busy=false;main.inert=previous;}
  }
  async function execute(operation){
    return transaction(async()=>{
      const pid=p.id;
      const result=await api(`/api/projects/${pid}/edits`,{revision:p.revision,operations:Array.isArray(operation)?operation:[operation]});
      if(p?.id!==pid)throw Error('工程已切换，请重新打开查看已保存结果');
      if(result.changed){remember();studioProjectHooks.adopt(result.project)}
      render();
      if(result.selection)StudioTimelineUI.select(result.selection.kind,result.selection.id,false);
      return result;
    });
  }
  async function history(direction){
    const stack=direction==='undo'?undo:redo;if(!stack.length)return toast(direction==='undo'?'暂无可撤销的编辑':'暂无可重做的编辑');
    return transaction(async()=>{
      const target=copy(stack.at(-1)),current=copy(p);target.revision=p.revision;
      const savedProject=await api(`/api/projects/${p.id}`,target);
      stack.pop();(direction==='undo'?redo:undo).push(current);
      studioProjectHooks.adopt(savedProject);render();
    },false);
  }
  $('#undo-button').onclick=handle(()=>history('undo'));
  const redoButton=document.createElement('button');redoButton.id='redo-button';redoButton.textContent='↷ 重做';redoButton.title='Ctrl+Shift+Z / Ctrl+Y';$('#undo-button').after(redoButton);
  redoButton.onclick=handle(()=>history('redo'));
  document.addEventListener('keydown',event=>{
    if(event.defaultPrevented||event.isComposing||event.keyCode===229||!p||!(event.ctrlKey||event.metaKey)||event.altKey)return;
    const key=event.key.toLowerCase();if(!['z','y'].includes(key))return;
    if(event.target.closest('input,textarea,select,[contenteditable="true"]')||document.querySelector('dialog[open]'))return;
    event.preventDefault();(event.shiftKey||key==='y'?redoButton:$('#undo-button')).click();
  });
  const oldOpen=openProject;openProject=async function(...args){redo=[];const result=await oldOpen(...args);showNotice();return result};
  window.StudioEditActions={execute,undo:()=>history('undo'),redo:()=>history('redo'),busy:()=>busy};
  const handoff=document.createElement('button');handoff.id='handoff-button';handoff.textContent='导入剪映';$('#export-button').before(handoff);
  handoff.onclick=handle(async()=>{
    if(!p)throw Error('请先打开工程');
    await transaction(async()=>{
      if(p.native?.shared){
        const state=await api(`/api/projects/${p.id}/editor-state`);
        editorRunning=state.editor_running;syncError='';showNotice();
        if(state.revision!==p.revision)throw Error('剪映已有新的保存版本，请先点“读取剪映已保存”再继续');
        if(state.editor_running){
          handoffResult=null;showNotice();
          toast('百慕修改已直接保存；请在剪映返回首页后重开这一集，无需退出或再次刷新');
          return;
        }
      }
      const result=await api(`/api/projects/${p.id}/handoff`,{revision:p.revision});
      studioProjectHooks.adopt(await api(`/api/projects/${p.id}`));render();
      showNotice();handoffResult=result;showNotice();
      if(!result.editor_running)await api('/api/native/launch',{});
      toast(result.refresh_required?'已写入共同草稿；请在剪映保存并返回首页后打开这一集':'已登记共同草稿并启动剪映');
    });
  });
  installBatchJianyingHandoff(transaction,async(result,pid)=>{
    if(p?.id!==pid)return;
    studioProjectHooks.adopt(await api(`/api/projects/${pid}`));render();
    showNotice();handoffResult=result;showNotice();
  });
  async function readSharedSaved(manual=false){
    if(polling||busy||!p?.native?.shared)return;
    if(dirty>saved||saving||StudioTimelineUI.dragging?.()||window.StudioRealtime?.gestureActive()||window.StudioMasks?.dragging()){
      if(manual)throw Error('百慕还有未保存或正在拖动的修改，请保存完成后再读取剪映版本');
      return;
    }
    const pid=p.id,revision=p.revision;polling=true;
    try{
      const state=await api(`/api/projects/${pid}/editor-state`);
      if(p?.id!==pid)return;
      showNotice();editorRunning=state.editor_running;syncError='';showNotice();
      if(state.revision===revision||dirty>saved){if(manual)toast('没有检测到剪映新的已保存版本');return}
      const remote=await api(`/api/projects/${pid}`);
      if(p?.id!==pid||p.revision!==revision||dirty>saved||StudioTimelineUI.dragging?.()||window.StudioRealtime?.gestureActive()||window.StudioMasks?.dragging())return;
      remember();studioProjectHooks.adopt(remote);render();
      toast(manual?'已读取剪映保存的最新版本，可撤销这次更新':'已自动读取剪映保存的新版本，可撤销这次更新');
    }catch(error){if(p?.id===pid){showNotice();syncError=error.message;showNotice()}if(manual)throw error}
    finally{polling=false}
  }
  // Jianying disk saves become visible only when there is no local gesture, draft, or text edit.
  setInterval(async()=>{
    if(document.hidden||document.activeElement?.matches('input,textarea,select'))return;
    await readSharedSaved(false);
  },1500);
}

function installBatchJianyingHandoff(transaction,onImported){
  let running=false,opening=false,stopping=false,rows=[],selected=new Set(),results=new Map();
  const button=document.createElement('button');button.id='batch-handoff-button';button.textContent='批量导入剪映';
  $('#handoff-button').after(button);
  const homeButton=document.createElement('button');homeButton.id='library-batch-handoff';homeButton.textContent='批量导入剪映';
  document.querySelector('.library-actions')?.prepend(homeButton);
  const dialog=document.createElement('dialog');dialog.id='batch-handoff-dialog';dialog.setAttribute('aria-label','批量导入剪映');document.body.append(dialog);
  const el=selector=>dialog.querySelector(selector);
  const visible=()=>rows.filter(row=>(!el('#batch-handoff-series').value||row.series===el('#batch-handoff-series').value)&&(`${row.series||''} ${row.name}`).toLocaleLowerCase().includes(el('#batch-handoff-search').value.trim().toLocaleLowerCase()));
  function draw(){
    el('#batch-handoff-list').innerHTML=visible().map(row=>{
      const result=results.get(row.id);
      return `<label class="manager-row"><input type="checkbox" data-handoff-id="${esc(row.id)}" ${selected.has(row.id)?'checked':''} ${running?'disabled':''}><span><b>${esc(row.name)}</b><small>${esc(row.series||'未分组')}</small><small data-handoff-status="${esc(row.id)}">${esc(result?.message||'待导入')}</small></span></label>`;
    }).join('')||'<p class="helper">没有匹配的分集工程。</p>';
    dialog.querySelectorAll('[data-handoff-id]').forEach(box=>box.onchange=()=>{if(box.checked)selected.add(box.dataset.handoffId);else selected.delete(box.dataset.handoffId);draw()});
    const chosen=rows.filter(row=>selected.has(row.id)),success=chosen.filter(row=>results.get(row.id)?.state==='success').length,failed=chosen.filter(row=>results.get(row.id)?.state==='failed').length;
    el('#batch-handoff-count').textContent=`已选 ${chosen.length} 集 · 成功 ${success} 集 · 失败 ${failed} 集 · 待处理 ${chosen.length-success-failed} 集`;
    el('#batch-handoff-progress').max=Math.max(1,chosen.length);el('#batch-handoff-progress').value=success+failed;
    el('#batch-handoff-start').disabled=running||!chosen.some(row=>results.get(row.id)?.state!=='success');
    el('#batch-handoff-start').textContent=success||failed?'继续导入未成功的集数':'导入所选分集';
    el('#batch-handoff-retry').disabled=running||!failed;
    el('#batch-handoff-stop').hidden=!running;el('#batch-handoff-stop').disabled=stopping;
    for(const selector of ['#batch-handoff-all','#batch-handoff-clear','#batch-handoff-close','#batch-handoff-series','#batch-handoff-search'])el(selector).disabled=running;
    el('#batch-handoff-launch').disabled=running||![...results.values()].some(result=>result.state==='success');
  }
  async function run(failedOnly=false){
    if(running)return;
    const queue=rows.filter(row=>selected.has(row.id)&&(failedOnly?results.get(row.id)?.state==='failed':results.get(row.id)?.state!=='success'));
    if(!queue.length)return;
    running=true;stopping=false;draw();el('#batch-handoff-message').textContent='正在保存当前编辑…';
    try{
      await transaction(async()=>{
        for(const [index,row] of queue.entries()){
          if(stopping)break;
          results.set(row.id,{state:'running',message:'正在导入…'});draw();
          el('#batch-handoff-message').textContent=`正在导入 ${index+1}/${queue.length}：${row.name}`;
          try{
            const project=await api(`/api/projects/${row.id}`);
            const result=await api(`/api/projects/${row.id}/handoff`,{revision:project.revision});
            results.set(row.id,{state:'success',message:`已导入：${result.name||row.name}`});
            try{await onImported(result,row.id)}catch(error){results.get(row.id).message+='；当前视图刷新失败：'+error.message}
          }catch(error){results.set(row.id,{state:'failed',message:'失败：'+error.message})}
          draw();
        }
      });
      el('#batch-handoff-message').textContent=stopping?'已停止后续导入，已成功的工程保留。可继续导入剩余集数。':'批量导入结束。剪映已经运行时请先返回首页查看；若首页仍缓存旧列表，再重启剪映。';
    }catch(error){el('#batch-handoff-message').textContent='未开始导入：'+error.message}
    finally{running=false;stopping=false;draw()}
  }
  async function show(){
    if(running||opening)return;
    opening=true;
    try{
    await refreshBoot();
    rows=[...(boot.projects||[])].filter(row=>!row.archived).sort((a,b)=>(a.series||'').localeCompare(b.series||'','zh')||a.name.localeCompare(b.name,'zh',{numeric:true}));
    selected=new Set();results=new Map();
    const series=[...new Set(rows.map(row=>row.series).filter(Boolean))];
    dialog.innerHTML=`<h2>批量导入剪映</h2><p>勾选需要导入的分集，或全选当前列表。开始前自动保存当前编辑；重复导入会登记同一份工程。</p><div class="toolbar"><select id="batch-handoff-series" aria-label="筛选剧名"><option value="">全部剧名</option>${series.map(name=>`<option value="${esc(name)}">${esc(name)}</option>`).join('')}</select><input id="batch-handoff-search" type="search" placeholder="搜索集名" aria-label="搜索集名"></div><div class="toolbar"><button id="batch-handoff-all">全选当前列表</button><button id="batch-handoff-clear">清空选择</button></div><div class="manager-list" id="batch-handoff-list"></div><div id="batch-handoff-count" class="manager-count" role="status"></div><progress id="batch-handoff-progress" style="width:100%" aria-label="导入进度"></progress><p id="batch-handoff-message" role="status">尚未开始导入。</p><div class="modal-actions"><button id="batch-handoff-start" class="primary">导入所选分集</button><button id="batch-handoff-retry">仅重试失败集数</button><button id="batch-handoff-stop" hidden>完成当前集后停止</button><button id="batch-handoff-launch">打开剪映</button><button id="batch-handoff-close">关闭</button></div>`;
    el('#batch-handoff-series').value=window.studioLibrary?.current()?.series||p?.series||'';
    el('#batch-handoff-series').onchange=draw;el('#batch-handoff-search').oninput=draw;
    el('#batch-handoff-all').onclick=()=>{visible().forEach(row=>selected.add(row.id));draw()};
    el('#batch-handoff-clear').onclick=()=>{selected.clear();draw()};
    el('#batch-handoff-start').onclick=()=>run();el('#batch-handoff-retry').onclick=()=>run(true);
    el('#batch-handoff-stop').onclick=()=>{stopping=true;draw();el('#batch-handoff-message').textContent='正在完成当前集，之后停止。'};
    el('#batch-handoff-launch').onclick=handle(()=>api('/api/native/launch',{}));
    el('#batch-handoff-close').onclick=()=>{if(!running)dialog.close()};
    draw();dialog.showModal();
    }finally{opening=false}
  }
  button.onclick=homeButton.onclick=handle(show);
  dialog.addEventListener('cancel',event=>{if(running)event.preventDefault()});
  window.addEventListener('beforeunload',event=>{if(running){event.preventDefault();event.returnValue='正在批量导入剪映'}});
}

;
// Source: realtime-player.js
'use strict';
/* Source-based timeline playback. Exported files remain a separate viewing mode. */
function installStudioRealtime(){
  const old={openProject,render,mark,updateOverlay,viewRender,renderClips};
  const stage=$('#stage'),exportVideo=$('#video');
  const overlay=$('#caption-overlay').cloneNode(true);$('#caption-overlay').replaceWith(overlay);
  const canvas=document.createElement('canvas');canvas.id='realtime-canvas';canvas.width=540;canvas.height=960;stage.prepend(canvas);
  const ctx=canvas.getContext('2d',{willReadFrequently:true});
  const picture=document.createElement('canvas');picture.width=canvas.width;picture.height=canvas.height;const pictureCtx=picture.getContext('2d');
  const foreground=document.createElement('div');foreground.id='foreground-masks';stage.append(foreground);
  const pool=document.createElement('div');pool.className='live-media-pool';pool.setAttribute('aria-hidden','true');document.body.append(pool);
  let mode='edit',pid=null,position=0,playing=false,anchor=0,frame=null,compiled=null,candidate=null,epoch=0,buffering=false,captionDrag=null;
  let compiledSignature=null,paintFrame=null;
  let audioContext=null,voiceBus,musicBus,musicGain,master,analyser,samples;
  const videos=new Map(),audios=new Map();let error='',notice='';
  const current=()=>candidate||p;
  const activeAudio=t=>(compiled?.items||[]).filter(i=>['original','dialogue','narration','bgm','sfx'].includes(i.kind)&&i.start<=t&&t<i.end&&(i.kind!=='original'||i.hasAudio));
  const now=()=>playing?Math.min(compiled?.duration||0,position+(audioContext.currentTime-anchor)):position;
  const editing=()=>mode==='edit';
  function setStatus(){
    if(!p)return;
    $('#mode-edit').hidden=editing();$('#mode-export').classList.toggle('accent',!editing());
    $('#refresh-edit-preview').hidden=!editing()||!error;
    $('#preview-label').textContent=editing()?(error?'实时预览：'+error:buffering?'正在准备源素材…':notice||'实时预览 · 当前工程'):'导出结果 · 已生成的视频';
    $('#preview-note').textContent=editing()?'修改即时预览，自动保存。首次加载素材需要片刻；空格播放 / 暂停。':'正在查看已导出的视频；点击“返回剪辑”或直接修改，即可回到当前预览。';
    $('#caption-drag-scope').hidden=!editing()||tab!=='captions';
    $('#play-button').textContent=playing||!editing()&&!exportVideo.paused?'Ⅱ':'▶';
    document.body.classList.toggle('realtime-editing',editing()&&!!p);
    canvas.hidden=!editing();foreground.hidden=!editing();overlay.style.display=editing()?'block':'none';$('#mask-layer').style.display=editing()?'block':'none';
    document.querySelectorAll('.caption-extra').forEach(node=>node.style.display=editing()?'block':'none');
    $('#mask-preview-canvas').style.display='none';
  }
  function audioGraph(){
    if(audioContext)return;
    audioContext=new AudioContext();voiceBus=audioContext.createGain();musicBus=audioContext.createGain();musicGain=audioContext.createGain();
    if(current()?.native?.shared)master=audioContext.createGain();
    else{master=audioContext.createDynamicsCompressor();master.threshold.value=-.45;master.knee.value=0;master.ratio.value=20;master.attack.value=.003;master.release.value=.2;}
    analyser=audioContext.createAnalyser();analyser.fftSize=1024;samples=new Float32Array(analyser.fftSize);
    voiceBus.connect(analyser);analyser.connect(master);musicBus.connect(musicGain);musicGain.connect(master);master.connect(audioContext.destination);
  }
  function mediaFailure(message){error=message;pause();setStatus()}
  function makeVideo(asset){
    const key=pid+':'+asset.id+':'+asset.sha256;let record=videos.get(key);if(record)return record;
    const el=document.createElement('video');el.muted=true;el.playsInline=true;el.preload='auto';el.src=url(`/asset/${pid}/${asset.id}`);pool.append(el);
    record={el};videos.set(key,record);
    el.addEventListener('loadeddata',requestDraw);el.addEventListener('seeked',requestDraw);
    el.addEventListener('error',()=>mediaFailure('无法解码画面 '+asset.name));return record;
  }
  function makeAudio(item){
    const project=current(),record=item.kind==='original'?project.clips.find(c=>c.id===item.id):project.audios.find(a=>a.id===item.id);
    const asset=project.assets.find(a=>a.id===item.asset_id),streams=asset.audio_streams||[];
    const stream=record.audio_stream==null?(streams.length===1?streams[0]:null):streams.find(s=>s.index===record.audio_stream);
    if(!stream){if(item.kind==='original'&&!asset.has_audio)return null;throw Error('请为 '+asset.name+' 明确选择音轨')}
    const key=[pid,item.kind,item.id,asset.id,asset.sha256,stream.index].join(':');let node=audios.get(key);if(node)return node;
    const el=document.createElement('audio');el.preload='auto';el.src=url(`/api/projects/${pid}/live-audio/${asset.id}?stream=${stream.index}`);pool.append(el);
    node={el,recordId:item.id,key,kind:item.kind};audios.set(key,node);
    el.addEventListener('error',()=>{node.error='无法准备声音 '+asset.name;if(node.active)mediaFailure(node.error)});return node;
  }
  function connectAudio(node){
    if(node.gain)return;
    node.source=audioContext.createMediaElementSource(node.el);node.gain=audioContext.createGain();
    node.source.connect(node.gain);node.gain.connect(node.kind==='bgm'?musicBus:voiceBus);
  }
  function stopMedia(){for(const {el} of [...videos.values(),...audios.values()])el.pause()}
  function startMedia(node){
    if(!node.el.paused||node.starting)return;
    const ticket=epoch;node.starting=true;
    node.el.play().catch(e=>{if(e.name!=='AbortError'&&playing&&ticket===epoch&&node.active)mediaFailure(e.message)}).finally(()=>{node.starting=false});
  }
  function pause(redraw=true){epoch++;if(playing)position=now();playing=false;buffering=false;stopMedia();if(frame!==null)cancelAnimationFrame(frame);frame=null;setStatus();if(redraw)requestDraw()}
  function waitReady(el){
    if(el.readyState>=2&&!el.seeking)return Promise.resolve();
    return new Promise((resolve,reject)=>{
      const readyEvents=['loadeddata','canplay','seeked'];
      const done=err=>{clearTimeout(timer);clearInterval(readiness);for(const event of readyEvents)el.removeEventListener(event,ok);el.removeEventListener('error',bad);err?reject(err):resolve()};
      const ok=()=>{if(el.readyState>=2&&!el.seeking)done()},bad=()=>done(Error('源素材无法加载'));const timer=setTimeout(()=>done(Error('源素材准备超时，可再次播放重试')),30000);
      for(const event of readyEvents)el.addEventListener(event,ok);el.addEventListener('error',bad);
      // A seek-triggered draw can temporarily lower readyState inside a media event.
      const readiness=setInterval(ok,50);
    });
  }
  function audioPosition(item,t){
    const record=item.kind==='original'?current().clips.find(c=>c.id===item.id):current().audios.find(a=>a.id===item.id);
    const local=Math.max(0,t-item.start),period=record.out-record.in;
    return record.in+(item.effectiveLoop?((record.loop_offset||0)+local)%period:local);
  }
  async function prepareMedia(el,target){
    await waitReady(el);
    if(Math.abs(el.currentTime-target)>.01){el.currentTime=target;await waitReady(el)}
  }
  function warmAudio(t){
    const upcoming=(compiled?.items||[]).filter(i=>['original','dialogue','narration','bgm','sfx'].includes(i.kind)&&i.start>t&&i.start<=t+5&&(i.kind!=='original'||i.hasAudio)).sort((a,b)=>a.start-b.start).slice(0,8);
    for(const item of upcoming){
      let node;try{node=makeAudio(item)}catch(e){continue}
      if(!node||node.warmed)continue;node.warmed=true;
      node.preparing=prepareMedia(node.el,audioPosition(item,item.start)).catch(e=>{node.error=e.message});
    }
  }
  async function play(){
    if(!editing())return exportVideo.play();
    if(current()?.native?.issues?.length)throw Error('此工程包含尚不能本地预览的效果：'+current().native.issues.join('；'));
    if(!p?.clips.length)throw Error('请先添加画面片段');
    if(playing||buffering)return;
    if(!compiled){refresh();if(!compiled)throw Error(error||'当前时间线无法预览，请检查片段时间和素材')}
    const ticket=++epoch;buffering=true;setStatus();
    error='';notice='';
    if(position>=compiled.duration-.001)position=0;
    try{
      audioGraph();
      await audioContext.resume();if(ticket!==epoch)return;
      const pending=[];const video=compiled.items.find(v=>v.kind==='video'&&v.start<=position&&position<v.end);
      if(video)pending.push(prepareMedia(makeVideo(current().assets.find(a=>a.id===video.asset_id)).el,video.sourceIn+position-video.start));
      for(const item of activeAudio(position)){const node=makeAudio(item);if(node){if(node.error)throw Error(node.error);connectAudio(node);pending.push((async()=>{await node.preparing;if(ticket!==epoch)return;await prepareMedia(node.el,audioPosition(item,position))})())}}
      warmAudio(position);
      await Promise.all(pending);if(ticket!==epoch)return;
      buffering=false;playing=true;anchor=audioContext.currentTime;setStatus();tick();
    }catch(e){if(ticket===epoch){buffering=false;mediaFailure(e.message);throw e}}
  }
  function seek(value){pause(false);position=Math.max(0,Math.min(compiled?.duration||0,Number(value)||0));notice='';requestDraw();setStatus()}
  function syncVideo(t){
    for(const entry of videos.values())entry.active=false;
    const item=compiled?.items.find(v=>v.kind==='video'&&t>=v.start&&t<v.end);if(!item){for(const {el} of videos.values())el.pause();return null}
    const asset=current().assets.find(a=>a.id===item.asset_id),record=makeVideo(asset),el=record.el;record.active=true;
    const desired=item.sourceIn+t-item.start;
    const tolerance=playing?.12:.5/compiled.fps;
    if(el.readyState>=2&&!el.seeking&&Math.abs(el.currentTime-desired)>tolerance){el.currentTime=desired;return null}
    if(playing&&el.readyState>=2)startMedia(record);
    if(!playing&&!el.paused)el.pause();
    // Warm the next source without changing its timeline position.
    const next=compiled.items.find(v=>v.kind==='video'&&v.start>t&&v.start<t+3);
    if(next)makeVideo(current().assets.find(a=>a.id===next.asset_id));
    for(const entry of videos.values())if(!entry.active)entry.el.pause();
    return el.readyState>=2&&!el.seeking?el:null;
  }
  function syncAudio(t){
    for(const node of audios.values())node.active=false;
    for(const item of activeAudio(t)){
      const node=makeAudio(item);if(!node)continue;node.active=true;
      if(!playing){node.el.pause();continue}
      connectAudio(node);
      if(node.error){mediaFailure(node.error);return false}
      // Seeking briefly lowers readyState; it must not stop every other track.
      if(node.el.readyState<2&&!node.el.seeking){position=t;playing=false;stopMedia();play().catch(e=>toast(e.message,true));return false}
      const record=item.kind==='original'?current().clips.find(c=>c.id===item.id):current().audios.find(a=>a.id===item.id);
      const local=t-item.start,period=record.out-record.in;
      const desired=record.in+(item.effectiveLoop?((record.loop_offset||0)+local)%period:local);
      const cycle=item.effectiveLoop?Math.floor(((record.loop_offset||0)+local)/period):0;
      if(!node.el.seeking&&(Math.abs(node.el.currentTime-desired)>.15||(node.cycle!==undefined&&node.cycle!==cycle)))node.el.currentTime=desired;
      node.cycle=cycle;
      let gain=Math.pow(10,(record.gain||0)/20);
      if(record.muted)gain=0;
      if(record.fade_in>0)gain*=Math.min(1,local/record.fade_in);
      if(record.fade_out>0)gain*=Math.min(1,(item.end-t)/record.fade_out);
      if(item.kind==='bgm'&&!current()?.native?.shared){
        const cycle=((record.loop_offset||0)+local)%period;
        gain*=Math.min(1,(item.effectiveLoop?cycle:local)/Math.min(.01,period/4));
        gain*=Math.min(1,(period-cycle)/Math.min(.01,period/4));
        gain*=Math.min(1,(item.end-t)/Math.min(.08,(item.end-item.start)/4));
      }
      node.gain.gain.setValueAtTime(gain,audioContext.currentTime);
      startMedia(node);
    }
    for(const node of audios.values())if(!node.active)node.el.pause();
    if(playing&&!current()?.native?.shared){
      analyser.getFloatTimeDomainData(samples);let sum=0;for(const v of samples)sum+=v*v;
      const rms=Math.sqrt(sum/samples.length),duck=rms>.03?Math.pow(.03/rms,7/8):1;
      musicGain.gain.setTargetAtTime(duck,audioContext.currentTime,duck<musicGain.gain.value?.02:.45);
    }
    return true;
  }
  function paintMasks(t){
    for(const m of current()?.masks||[]){
      if(t<m.start||t>=m.end||m.layer==='above_captions')continue;
      const at=StudioMasks.position(m,t),scale=canvas.width/1080,left=Math.floor(at.x*scale),top=Math.floor(at.y*scale),right=Math.ceil((at.x+at.w)*scale),bottom=Math.ceil((at.y+at.h)*scale),x=Math.max(0,left),y=Math.max(0,top),w=Math.max(0,Math.min(canvas.width,right)-x),h=Math.max(0,Math.min(canvas.height,bottom)-y);if(!w||!h)continue;
      if(m.mode==='solid'){ctx.fillStyle='#fff';ctx.fillRect(x,y,w,h)}
      else{
        const image=ctx.getImageData(x,y,w,h),radius=Math.max(1,Math.min(Math.round(m.blur*scale),Math.floor(w/2),Math.floor(h/2)));
        image.data.set(StudioLiveLayers.blur(image.data,w,h,radius,m.white));ctx.putImageData(image,x,y);
      }
    }
    const above=(current()?.masks||[]).filter(m=>m.layer==='above_captions'&&t>=m.start&&t<m.end);
    const ids=above.map(m=>m.id).join('|');
    if(foreground.dataset.ids!==ids){foreground.replaceChildren(...above.map(m=>{const node=document.createElement('div');node.dataset.foregroundMask=m.id;return node}));foreground.dataset.ids=ids}
    for(const m of above){const node=foreground.querySelector(`[data-foreground-mask="${m.id}"]`),at=StudioMasks.position(m,t);
      Object.assign(node.style,{position:'absolute',left:at.x/1080*100+'%',top:at.y/1920*100+'%',width:at.w/1080*100+'%',height:at.h/1920*100+'%',background:m.mode==='solid'?'#fff':`rgba(255,255,255,${m.white||0})`,backdropFilter:m.mode==='solid'?'none':`blur(${m.blur*stage.clientWidth/1080}px)`});
    }
  }
  function adorn(){
    const editable=editing()&&tab==='captions'&&!!overlay.textContent&&!(p?.track_locks||[]).includes('caption');
    overlay.classList.toggle('caption-editable',editable);overlay.style.pointerEvents=editable?'auto':'none';
    if(editable&&!overlay.querySelector('.caption-resize')){const handle=document.createElement('span');handle.className='caption-resize';handle.dataset.captionResize='1';handle.title='拖动调整字号';overlay.append(handle)}
  }
  function requestDraw(){
    // Selection, save acknowledgement and media events can all refresh in one turn.
    if(paintFrame===null)paintFrame=requestAnimationFrame(()=>{paintFrame=null;draw()});
  }
  function draw(){
    if(paintFrame!==null){cancelAnimationFrame(paintFrame);paintFrame=null}
    if(!editing()||!p||pid!==p.id||!compiled)return;
    if(p.native?.issues?.length){error=p.native.issues.join('；');setStatus();ctx.clearRect(0,0,canvas.width,canvas.height);foreground.replaceChildren();foreground.dataset.ids='';overlay.textContent='';document.querySelectorAll('.caption-extra').forEach(n=>n.remove());return}
    const t=now();ctx.fillStyle='#000';ctx.fillRect(0,0,canvas.width,canvas.height);
    const video=syncVideo(t);
    if(video){const factor=Math.min(canvas.width/video.videoWidth,canvas.height/video.videoHeight),w=video.videoWidth*factor,h=video.videoHeight*factor;pictureCtx.fillStyle='#000';pictureCtx.fillRect(0,0,picture.width,picture.height);pictureCtx.drawImage(video,(canvas.width-w)/2,(canvas.height-h)/2,w,h)}
    if(compiled.items.some(v=>v.kind==='video'&&t>=v.start&&t<v.end))ctx.drawImage(picture,0,0);
    paintMasks(t);
    const committed=p;try{if(candidate)p=candidate;updateOverlay(t)}finally{p=committed}
    $('#timecode').textContent=time(t);$('#seek').value=t;$('#duration').textContent=time(compiled.duration).slice(0,5);
    $('#seek').max=compiled.duration||1;adorn();
  }
  function tick(){
    frame=null;if(!playing||!editing())return;
    const t=now();if(t>=compiled.duration){position=compiled.duration;pause();return}
    try{warmAudio(t);if(!syncAudio(t))return;draw();if(playing)frame=requestAnimationFrame(tick)}catch(e){mediaFailure(e.message)}
  }
  function cleanup(){
    // Invalidate the old timeline before pause or media callbacks can redraw.
    // The global project may already contain the next episode's asset list.
    compiled=null;compiledSignature=null;candidate=null;
    if(paintFrame!==null){cancelAnimationFrame(paintFrame);paintFrame=null}
    pictureCtx.clearRect(0,0,picture.width,picture.height);foreground.replaceChildren();foreground.dataset.ids='';
    pause(false);for(const node of audios.values()){node.source?.disconnect();node.gain?.disconnect()}
    for(const {el} of [...videos.values(),...audios.values()]){el.removeAttribute('src');el.load();el.remove()}
    videos.clear();audios.clear();if(audioContext){audioContext.close().catch(()=>{});audioContext=null}candidate=null;position=0;error='';notice='';
  }
  function refresh(){
    if(!p){cleanup();pid=null;compiled=null;document.body.classList.remove('realtime-editing');canvas.hidden=true;return}
    if(pid!==p.id){cleanup();pid=p.id}
    try{
      const project=current();
      // Compare values as controls and autosave also mutate records in place.
      // Never include revision alone: both candidate edits and legacy data lack it.
      const signature=JSON.stringify([project.id,project.fps,project.assets,project.clips,project.audios,project.captions,project.masks,project.native?.shared,project.native?.duration_us]);
      if(!compiled||signature!==compiledSignature){compiled=StudioTimeline.layout(project);compiledSignature=signature}
      position=Math.min(position,compiled.duration);error='';requestDraw();setStatus();
    }catch(e){compiled=null;compiledSignature=null;mediaFailure(e.message)}
  }
  async function loadEdit(){mode='edit';exportVideo.pause();refresh();StudioTimelineUI.previewUpdated(false);return true}
  $('#mode-edit').textContent='返回剪辑';$('#mode-edit').onclick=handle(loadEdit);
  $('#mode-export').onclick=handle(async()=>{
    pause();const result=await api(`/api/projects/${p.id}/playback?mode=export`);if(!result.job)return toast('本集还没有导出结果');
    await viewRender(result.job);
  });
  $('#refresh-edit-preview').textContent='重试加载';$('#refresh-edit-preview').title='重新读取当前源素材';$('#refresh-edit-preview').onclick=()=>{error='';refresh()};
  $('#preview-button').textContent='实时预览';$('#preview-button').onclick=handle(loadEdit);
  $('#play-button').onclick=handle(async()=>{if(editing()){if(playing||buffering)pause();else await play()}else{if(exportVideo.paused)await exportVideo.play();else exportVideo.pause()}});
  $('#play-button').title='播放 / 暂停（空格）';
  $('#play-button').setAttribute('aria-label','播放 / 暂停');
  $('#play-button').setAttribute('aria-keyshortcuts','Space');
  document.addEventListener('keydown',event=>{
    const arrow=event.key==='ArrowLeft'||event.key==='ArrowRight';
    if(!arrow&&event.code!=='Space'&&event.key!==' ')return;
    const target=event.target;
    if(event.defaultPrevented||event.isComposing||event.keyCode===229||event.ctrlKey||event.metaKey||event.altKey||(!arrow&&event.shiftKey)||!p)return;
    if(target.isContentEditable||target.closest('input,textarea,[role="textbox"],[role="separator"],[role="slider"],[role="spinbutton"],[inert]')||(arrow&&target.closest('select'))||document.querySelector('dialog[open],[aria-modal="true"]'))return;
    event.preventDefault();
    event.stopPropagation();
    if(captionDrag||window.StudioTimelineUI?.dragging()||window.StudioMasks?.dragging())return;
    if(arrow)stepFrames((event.key==='ArrowLeft'?-1:1)*(event.shiftKey?10:1));
    else if(!event.repeat)$('#play-button').click();
  },true);
  function stepFrames(count){
    const at=editing()?now():exportVideo.currentTime;
    StudioTimelineUI.seek((Math.round(at*rate())+count)/rate());
  }
  $('#seek').oninput=e=>editing()?seek(Number(e.target.value)):(exportVideo.currentTime=Number(e.target.value));
  $('#back-frame').onclick=()=>stepFrames(-1);$('#back-frame').title='播放头后退一帧（←）';
  $('#next-frame').onclick=()=>stepFrames(1);$('#next-frame').title='播放头前进一帧（→）';
  $('#waveform').onclick=e=>editing()?seek(e.offsetX/$('#waveform').clientWidth*(compiled?.duration||0)):(exportVideo.currentTime=e.offsetX/$('#waveform').clientWidth*exportVideo.duration);
  updateOverlay=function(t){old.updateOverlay(Number.isFinite(t)?t:editing()?now():exportVideo.currentTime);if(editing()){overlay.style.display='block';adorn()}setStatus()};
  function resumeEditing(){if(!editing()){pause();mode='edit';exportVideo.pause();candidate=null}}
  mark=function(...args){resumeEditing();old.mark(...args);refresh()};
  render=function(...args){
    resumeEditing();
    old.render(...args);
    const locks=p?.track_locks||[],locked=tab==='captions'&&locks.includes('caption')||tab==='masks'&&locks.includes('mask')||tab==='clips'&&(locks.includes('video')||locks.includes('original'));
    if(locked){
      for(const el of $$('#panel input,#panel textarea,#panel select,#panel button,#inspector input,#inspector textarea,#inspector select,#inspector button'))el.disabled=true;
      const note=document.createElement('p');note.className='helper';note.textContent='此轨道已锁定，请在时间线轨道名称旁解锁后编辑。';$('#panel').prepend(note);
    }
    refresh();
  };
  renderClips=function(...args){
    old.renderClips(...args);
    $$('[data-up],[data-down]').forEach(button=>{
      button.title='按镜头顺序重新首尾相接；字幕和独立音频保留位置';
      button.onclick=handle(async()=>{const clipId=button.dataset.up||button.dataset.down,index=p.clips.findIndex(c=>c.id===clipId),targetIndex=index+(button.dataset.up?-1:1);if(targetIndex<0||targetIndex>=p.clips.length)return;await StudioEditActions.execute({type:'reorder',kind:'video',id:clipId,targetIndex})});
    });
    $$('[data-remove-clip]').forEach(button=>button.onclick=handle(()=>StudioEditActions.execute({type:'remove',kind:'video',id:button.dataset.removeClip})));
  };
  openProject=async function(...args){cleanup();mode='edit';await old.openProject(...args);mode='edit';exportVideo.pause();candidate=null;refresh();StudioTimelineUI.previewUpdated(false)};
  viewRender=async function(job){pause();await old.viewRender(job);mode='export';setStatus()};
  window.studioPreviewSubtitleStyle=async()=>{await loadEdit();return 'live'};
  async function finishCaption(event,cancel=false){
    const d=captionDrag;if(!d||event.pointerId!==d.pointer)return;captionDrag=null;overlay.releasePointerCapture?.(d.pointer);
    if(p?.id!==d.pid)return;
    if(cancel){p.style=copy(d.before.style);p.captions.forEach(c=>{const previous=d.before.captions.find(v=>v.id===c.id);if(previous)c.style=copy(previous.style||{})});refresh();return}
    if(d.changed){
      const cue=p.captions.find(c=>c.id===d.cue),style=d.scope==='all'?p.style:cue.style;
      const fields=d.resize?['font_size']:['x','y'],patch=Object.fromEntries(fields.map(k=>[k,style[k]]));
      p.style=copy(d.before.style);p.captions.forEach(c=>{const old=d.before.captions.find(v=>v.id===c.id);if(old)c.style=copy(old.style||{})});
      try{const result=StudioTimeline.apply(p,{type:'style',kind:'caption',id:d.cue,scope:d.scope,patch});remember();p=result.project;mark(false);renderInspector()}catch(error){toast(error.message,true)}
      refresh();
    }
  }
  overlay.addEventListener('pointerdown',e=>{
    if(e.button!==0||!editing()||(p.track_locks||[]).includes('caption'))return;const cue=p.captions.find(c=>now()>=c.start&&now()<c.end);if(!cue)return;
    pause();clearTimeout(timer);selected=cue.id;tab='captions';
    captionDrag={pointer:e.pointerId,pid:p.id,before:copy(p),cue:cue.id,x:e.clientX,y:e.clientY,style:{...p.style,...cue.style},height:overlay.clientHeight,scope:$('#caption-drag-scope').value,resize:!!e.target.closest('[data-caption-resize]'),changed:false};
    overlay.setPointerCapture(e.pointerId);e.preventDefault();
  });
  overlay.addEventListener('pointermove',e=>{
    const d=captionDrag;if(!d||e.pointerId!==d.pointer||p?.id!==d.pid)return;
    const box=stage.getBoundingClientRect(),dx=e.clientX-d.x,dy=e.clientY-d.y;if(Math.abs(dx)+Math.abs(dy)<1)return;
    const patch=d.resize?{font_size:Math.max(4,Math.min(800,Math.round(d.style.font_size*(1+dy/Math.max(12,d.height)))))}:{x:Math.max(0,Math.min(100,d.style.x+dx/box.width*100)),y:Math.max(0,Math.min(100,d.style.y+dy/box.height*100))};
    if(d.scope==='all'){Object.assign(p.style,patch);for(const c of p.captions)for(const key of Object.keys(patch))if(c.style)delete c.style[key]}
    else{const cue=p.captions.find(c=>c.id===d.cue);cue.style={...cue.style,...patch}}
    d.changed=true;refresh();
  });
  overlay.addEventListener('pointerup',e=>finishCaption(e));overlay.addEventListener('pointercancel',e=>finishCaption(e,true));
  window.addEventListener('keydown',e=>{if(e.key==='Escape'&&captionDrag){e.preventDefault();finishCaption({pointerId:captionDrag.pointer},true)}});
  window.addEventListener('blur',()=>{if(playing)pause()});
  window.StudioRealtime={editing,time:now,seek,pause,play,refresh,gestureActive:()=>!!captionDrag,preview(project){resumeEditing();candidate=project;refresh()},clearPreview(){if(!candidate)return;candidate=null;refresh()},debug(){return {mode,position:now(),playing,buffering,contextState:audioContext?.state,videoCount:videos.size,audioCount:audios.size,error}}};
  // The mask UI paints handles; this renderer owns the full pixel scene once.
  window.StudioLiveEditor={editing,paintMasks:()=>{},refresh,mode:()=>mode,loadEdit};
  refresh();
}

;
// Source: native-drafts.js
'use strict';
function installNativeDrafts(){
  let overview=null,detail=null,active=false,pending=false,generation=0,loading=false,previousTitle='',nativePackageBusy=false;
  const button=document.createElement('button');button.id='native-drafts-button';button.textContent='剪映工程';
  document.querySelector('.top-actions').prepend(button);
  const panel=document.createElement('section');panel.id='native-drafts';
  panel.setAttribute('role','main');
  panel.innerHTML=`<div class="native-heading"><div><p class="eyebrow">JIANYING / NATIVE DRAFTS</p><h1>剪映工程</h1><p>保留原生草稿。返回百慕时重新读取，写回前检查版本。</p></div><div class="toolbar"><button id="native-back">返回百慕工程</button><button id="native-launch" class="primary">启动剪映 ↗</button><button id="native-refresh">重新扫描</button></div></div><div id="native-status" role="status"></div><div class="native-columns"><aside class="native-sidebar"><input id="native-search" type="search" placeholder="搜索剪映草稿"><div id="native-list"></div></aside><div id="native-detail"><p>选择一份草稿读取。</p></div></div>`;
  document.querySelector('.app-layout').before(panel);
  const el=s=>panel.querySelector(s);
  const importNativeButton=document.createElement('button');importNativeButton.id='native-import-top';importNativeButton.textContent='导入共同工程包';importNativeButton.onclick=()=>showNativeImport();panel.querySelector('.native-heading .toolbar').append(importNativeButton);
  function status(text,error=false){el('#native-status').textContent=text;el('#native-status').classList.toggle('native-error',error)}
  function drawList(){
    const q=el('#native-search').value.trim().toLocaleLowerCase();
    const rows=(overview?.drafts||[]).filter(x=>x.name.toLocaleLowerCase().includes(q));
    el('#native-list').innerHTML=rows.map(row=>`<button class="native-row ${detail?.key===row.key?'selected':''}" data-native-key="${row.key}"><b>${esc(row.name)}</b><small>${row.exists?'可定位':'目录已丢失'} · ${esc(row.path)}</small></button>`).join('')||'<p>没有匹配的剪映草稿。</p>';
    panel.querySelectorAll('[data-native-key]').forEach(b=>b.onclick=handle(()=>load(b.dataset.nativeKey)));
  }
  async function scan(){overview=await api('/api/native/overview');drawList();return overview}
  async function show(key){
    await window.studioProjectHooks.transaction(async()=>{});
    if(!active)previousTitle=document.title;
    active=true;document.title='剪映工程 · 九州百慕';document.body.classList.add('native-mode');status('正在扫描本机剪映草稿…');
    await scan();
    const binding=p&&overview.bindings?.[p.id];
    status(`发现 ${overview.drafts.length} 份草稿。${overview.editor_running?'剪映正在运行，可并行编辑；同一工程的后续保存可能覆盖另一边的修改。':'可进行受支持的文字保存。'}`);
    if(key||binding?.key)await load(key||binding.key);
    else drawMigration();
  }
  async function load(key,quiet=false){
    if(pending){status('有尚未保存的原生文字，已保留输入。请保存，或点击“放弃文字并重读”。',true);return}
    const mine=++generation;loading=true;
    if(!quiet)status('正在读取当前原生草稿…');
    try{
      const next=await api('/api/native/drafts/'+key);
      if(mine!==generation||!active)return;
      detail=next;drawDetail();drawList();
      status(`已读取“${next.name}”。${next.editor_running?'剪映同时运行，编辑和保存可用。':'可保存支持的原生文字。'} 智能识别字幕和复杂效果完整保留，暂不修改。`);
    }catch(error){
      if(mine===generation){status(error.message,true);if(!quiet){el('#native-detail').innerHTML=`<h2>当前草稿未载入</h2><p>${esc(error.message)}</p><p>未使用备份或其他主文件代替当前版本，也没有写入原草稿。</p><button id="native-recover">恢复最近一次未完成交接</button>`;el('#native-recover').onclick=handle(async()=>{const r=await api('/api/native/recover',{key});status('已恢复提交前版本');pending=false;await load(key)})}}
    }finally{if(mine===generation)loading=false}
  }
  function drawDetail(){
    const d=detail,missing=d.media.filter(m=>!m.exists);
    const binding=p&&overview.bindings?.[p.id];
    el('#native-detail').innerHTML=`<div class="native-detail-heading"><div><h2>${esc(d.name)}</h2><p>${esc(d.width)} × ${esc(d.height)} · ${time(d.duration_us/1e6)} · ${d.tracks.length} 条轨道 · ${d.timeline_count} 条活动时间线</p></div><button id="native-read">重新读取当前版本</button></div><div class="native-path">${esc(d.path)}</div><p class="native-small">项目 ${esc(d.draft_id)}<br>主时间线 ${esc(d.main_timeline_id)}<br>版本 ${esc(d.revision.slice(0,16))}</p><div class="toolbar native-tools"><button id="native-reveal">定位文件夹</button><button id="native-snapshot">备份当前控制文件</button><button id="native-verify">检查字段完整性</button>${p?`<button id="native-bind" class="accent">${binding?.key===d.key?'已关联本集 · 更新版本记录':'关联当前分集：'+esc(p.name)}</button>`:''}</div><p>${d.editor_running?'剪映同时运行：可继续操作。剪映已打开的工程不会自动刷新，旧窗口后续保存可能覆盖百慕的修改；建议错开同一工程的保存。':'写回会备份当前版本，并检查草稿是否在别处改变。保存后请在剪映重开验收。'}</p>${missing.length?`<div class="native-warning">${missing.length} 个外部素材引用未找到。${missing.slice(0,4).map(x=>'<p>'+esc(x.path)+'</p>').join('')}</div>`:''}<details><summary>轨道与片段</summary><ul>${d.tracks.map(t=>`<li>${esc(t.name||t.type)} · ${esc(t.type)} · ${t.segments} 段</li>`).join('')}</ul></details><div class="native-subhead"><h3>原生字幕</h3><button id="native-discard">放弃文字并重读</button></div><p>当前支持单一样式、无关联的文字修改；其他字幕只读保留。画面、原声、转场、关键帧等不会经过百慕简化模型重建。</p><div class="native-texts">${d.texts.map((t,i)=>`<article class="native-text-row"><div><b>${i+1}</b><span>${esc(t.reason)}</span></div><textarea data-text-id="${t.id}" ${t.editable?'':'readonly'} rows="2">${esc(t.text)}</textarea>${t.editable?`<button data-save-text="${t.id}">保存这一条</button>`:''}</article>`).join('')||'<p>主时间线没有文字素材。</p>'}</div><div id="native-migrate-slot"></div>`;
    el('#native-read').onclick=handle(()=>load(d.key));
    el('#native-discard').onclick=handle(()=>{pending=false;return load(d.key)});
    el('#native-reveal').onclick=handle(()=>api('/api/native/reveal',{key:d.key}));
    el('#native-snapshot').onclick=handle(async()=>{const r=await api('/api/native/snapshot',{key:d.key});status('已备份控制文件：'+r.path+'；外部媒体未包含在此快照内。')});
    el('#native-verify').onclick=handle(async()=>{status('正在检查全部活动时间线的编解码完整性…');const r=await api('/api/native/verify',{key:d.key});status(`检查通过：${r.files.length} 个原生时间线文件的字段完整，原文件未改动；视觉重开需另行验收。`)});
    if(el('#native-bind'))el('#native-bind').onclick=handle(async()=>{await api('/api/native/bind',{project_id:p.id,key:d.key,revision:d.revision});await scan();status('已关联当前分集。旧百慕工程保留，不会用旧时间线覆盖剪映草稿。');drawDetail()});
    panel.querySelectorAll('[data-text-id]').forEach(box=>box.oninput=()=>{pending=true;status('文字尚未保存。当前每次保存一条，其他待改文字会保留在本页。')});
    panel.querySelectorAll('[data-save-text]').forEach(b=>b.onclick=handle(async()=>{
      const row=d.texts.find(t=>t.id===b.dataset.saveText),box=el(`[data-text-id="${row.id}"]`),value=box.value;
      // One explicit edit per commit. Prevent another dirty field from being
      // discarded when the current draft is reloaded after this save.
      const other=d.texts.filter(t=>t.id!==row.id&&el(`[data-text-id="${t.id}"]`)?.value!==t.text);
      if(other.length)throw Error('请每次只修改并保存一条文字，避免重读时丢失其他待保存输入。');
      b.disabled=true;status('正在备份并保存这一条原生文字…');
      try{const r=await api('/api/native/patch',{key:d.key,revision:d.revision,operation:{type:'simple_text',material_id:row.id,old:row.text,new:value}});pending=false;detail=r.detail;drawDetail();status(r.message+'。备份：'+r.backup)}
      catch(error){b.disabled=false;throw error}
    }));
    drawNativeWorkspace(d);
    drawMigration(el('#native-migrate-slot'));
  }
  function drawNativeWorkspace(d){
    const section=document.createElement('section');section.className='native-workspace';
    const duration=Math.max(1,d.duration_us);
    section.innerHTML=`<h3>共同工程 · 原生轨道</h3><p>此处直接修改当前剪映草稿，保存后在剪映重开即可继续。未修改的图层、效果和未知字段保留。当前是轨道数据视图，尚无剪映合成画面预览。</p><div class="toolbar"><button id="native-package">一键打包共同工程</button><button id="native-import-package">导入共同工程包</button></div><div id="native-package-result"></div>${d.tracks.map(t=>`<section class="native-track"><b>${esc(t.name||t.type)}</b><div class="native-track-lane">${(t.items||[]).map(s=>`<span class="native-clip-bar" style="left:${Math.max(0,s.start_us/duration*100)}%;width:${Math.max(.3,s.duration_us/duration*100)}%" title="${esc(s.name||s.id)}"></span>`).join('')}</div>${(t.items||[]).map(s=>`<div class="native-segment-row"><span>${esc((s.name||s.id).slice(0,70))}</span><small>${(s.start_us/1e6).toFixed(3)}s · ${(s.duration_us/1e6).toFixed(3)}s${s.group_id?' · 分组联动':''}${s.font_size!=null?' · 字号 '+esc(s.font_size):''}</small><button data-native-move="${esc(s.id)}">移动</button>${t.type==='audio'?`<button data-native-volume="${esc(s.id)}">音量</button>`:''}${s.font_size!=null?`<button data-native-font="${esc(s.id)}">字号</button>`:''}</div>`).join('')}</section>`).join('')}`;
    el('.native-path').before(section);
    section.querySelector('#native-package').onclick=handle(()=>packageNative(d,false));
    section.querySelector('#native-import-package').onclick=()=>showNativeImport();
    for(const [attribute,type,label] of [['data-native-move','move','开始时间（秒，分组片段一起移动）'],['data-native-volume','volume','线性音量（0静音，1原音量，最大4）'],['data-native-font','font_size','剪映原生字号']]){
      section.querySelectorAll('['+attribute+']').forEach(button=>button.onclick=handle(async()=>{
        if(pending)throw Error('请先保存或放弃尚未保存的文字');
        const segment=d.tracks.flatMap(t=>t.items||[]).find(s=>s.id===button.getAttribute(attribute));
        const value=type==='move'?segment.start_us/1e6:type==='volume'?segment.volume:segment.font_size;
        modal(`<h2>${esc(label)}</h2><input id="native-parameter" type="number" step="any" min="0" value="${value}"><p>保存修改的是这份原生工程；将备份当前版本。</p><button id="native-parameter-save" class="primary">保存到共同工程</button>`);
        $('#native-parameter-save').onclick=handle(async()=>{
          const input=$('#native-parameter');if(input.value==='')throw Error('请输入数值');
          const v=Number(input.value);if(!Number.isFinite(v))throw Error('请输入有效数值');
          const operation={type,...(type==='font_size'?{material_id:segment.material_id}:{segment_id:segment.id}),...(type==='move'?{start_us:Math.round(v*1e6)}:{value:v})};
          $('#native-parameter-save').disabled=true;
          try{const result=await api('/api/native/patch',{key:d.key,revision:d.revision,operation});$('#modal').close();await load(d.key);status(result.message)}
          catch(error){$('#native-parameter-save').disabled=false;throw error}
        });
      }));
    }
  }
  async function packageNative(d,allowOffline){
    if(pending)throw Error('请先保存或放弃尚未保存的文字');
    if(nativePackageBusy)throw Error('工程正在打包，请等待完成');nativePackageBusy=true;
    const button=el('#native-package');if(button)button.disabled=true;status('正在打包原生时间线、素材和字体…');
    try{
      const result=await api('/api/native/package',{key:d.key,revision:d.revision,allow_offline:allowOffline});
      el('#native-package-result').innerHTML=`<p>已打包 ${(result.size/1024/1024).toFixed(1)} MB · ${result.media_files} 个素材/字体 · ${result.offline} 个离线引用</p><a href="${url('/api/native/packages/'+result.id)}" download>保存共同工程ZIP</a><p>${esc(result.note)}</p>`;status('工程包已生成，可将保存的ZIP交给接收方。');
    }catch(error){
      if(!allowOffline&&String(error.message).includes('缺失素材')){
        modal('<h2>工程含缺失素材</h2><p>可以把缺失文件保留为离线片段；接收方能看到位置和参数，但无法播放丢失的内容。</p><button id="native-package-offline">保留离线引用并打包</button>');
        $('#native-package-offline').onclick=handle(async()=>{$('#modal').close();await packageNative(d,true)});
      }else throw error;
    }finally{nativePackageBusy=false;if(button)button.disabled=false}
  }
  function showNativeImport(){
    modal('<h2>导入共同工程包</h2><p>填写收到的工程ZIP路径，可保持剪映打开。将校验素材并创建独立副本。</p><input id="native-package-path" style="width:100%" placeholder="D:\\收到的共同工程.zip"><button id="native-package-import">导入并打开</button>');
    $('#native-package-import').onclick=handle(async()=>{
      const button=$('#native-package-import');button.disabled=true;
      try{const result=await api('/api/native/import-package',{path:$('#native-package-path').value});$('#modal').close();await scan();await load(result.key);status(result.message)}
      catch(error){button.disabled=false;throw error}
    });
  }
  function drawMigration(slot){
    const target=slot||el('#native-detail');
    const html=`<section class="native-migration"><h3>把百慕已有工程交给剪映</h3><p>先检查当前工程与素材。两种迁移方式都新建草稿，旧百慕工程保留。</p><div class="native-project-picker"><select id="native-project">${(boot.projects||[]).map(row=>`<option value="${row.id}" ${row.id===p?.id?'selected':''}>${esc(row.series||'未分组')} / ${esc(row.name)}</option>`).join('')}</select><button id="native-check-migration">检查迁移条件</button></div><div id="native-migration-result"></div></section>`;
    if(slot)target.innerHTML=html;else target.innerHTML='<h2>剪映原生草稿与百慕工程</h2><p>左侧可直接读取已有剪映草稿。也可将百慕现有工程迁移为新草稿。</p>'+html;
    el('#native-check-migration').onclick=handle(async()=>{
      const pid=el('#native-project').value;if(!pid)throw Error('请先选择百慕工程');
      const b=el('#native-check-migration');b.disabled=true;status('正在核对素材和已完成成片…');
      try{const r=await api('/api/native/migration/'+pid);drawMigrationReport(r);status('迁移检查完成；没有修改原工程。')}
      finally{b.disabled=false}
    });
  }
  function drawMigrationReport(r){
    el('#native-migration-result').innerHTML=`<p><b>${esc(r.series)} / ${esc(r.name)}</b> · ${time(r.duration)} · ${r.clips} 个镜头 · ${r.captions} 条字幕</p><div class="native-migration-options"><article><h4>保留成片 · 单轨</h4><p>${esc(r.film_notice)}</p><p>${r.film_available?'已找到与当前工程编辑内容一致的成片。':'没有匹配当前版本的成片，请先在百慕导出审阅版。'}</p><button id="native-export-film" ${r.film_available?'':'disabled'}>复制原样成片到新剪映草稿</button></article><article><h4>可编辑轨道 · 需要复核</h4>${r.editable_blocked.map(x=>'<p class="native-error">'+esc(x)+'</p>').join('')}${r.editable_warnings.map(x=>'<p>'+esc(x)+'</p>').join('')}<p>没有完成视觉与混音对照前，不标为无损。</p><button id="native-export-editable" ${r.editable_available?'':'disabled'}>按以上差异建立可编辑草稿</button></article></div>${r.missing.length?`<details><summary>查看 ${r.missing.length} 个缺失素材</summary>${r.missing.map(x=>'<p>'+esc(x.name)+'<br>'+esc(x.path)+'</p>').join('')}</details>`:''}`;
    const options=el('.native-migration-options');
    const editable=el('#native-export-editable');
    options.prepend(editable.closest('article'));
    if(r.offline_audio_available){
      const offline=document.createElement('article');
      offline.innerHTML=`<h4>保留离线音频片段</h4><p>${esc(r.offline_notice)}</p><p>其余轨道按兼容方式迁移，样式和混音差异仍需核对。</p><button id="native-export-offline">生成含离线音频的可编辑草稿</button>`;
      options.append(offline);
    }
    editable.textContent='仅生成兼容核对草稿（仍有差异）';
    const preservation=r.preservation||{exact_available:false,unresolved:['原样工程保留检查尚未完成']};
    const exact=document.createElement('article');exact.className='native-exact-handoff';
    exact.innerHTML=`<h4>原样工程交接</h4><p>以全部编辑结果、图层和原轨道组织一致为验收标准。</p>${preservation.unresolved.map(x=>'<p>'+esc(x)+'</p>').join('')}<button id="native-export-exact" class="primary" ${preservation.exact_available&&r.editable_available?'':'disabled'}>原样交给剪映${preservation.exact_available?'':' · 尚未通过'}</button>`;
    options.before(exact);
    el('#native-export-film').textContent='仅复制成片（没有可编辑图层）';
    function exportMode(mode,requireExact=false,allowOffline=false){return handle(async()=>{
      status('正在建立独立剪映草稿，旧工程保持原样…');
      panel.querySelectorAll('#native-export-film,#native-export-editable,#native-export-exact,#native-export-offline').forEach(b=>b.disabled=true);
      try{const result=await api('/api/native/export',{project_id:r.project_id,revision:r.revision,mode,require_exact:requireExact,allow_offline_audio:allowOffline,accept_approximate:mode==='editable'&&!requireExact});await scan();pending=false;await load(result.key);status(result.message+'。模式：'+(mode==='film'?'原样成片单轨':requireExact?'原样工程':allowOffline?'含离线音频，缺失部分不能播放；其余兼容差异需复核':'兼容核对草稿，尚未达到原样交接'))}
      catch(error){drawMigrationReport(r);throw error}
    })}
    el('#native-export-film').onclick=exportMode('film');el('#native-export-editable').onclick=exportMode('editable');
    el('#native-export-exact').onclick=exportMode('editable',true);
    if(el('#native-export-offline'))el('#native-export-offline').onclick=exportMode('editable',false,true);
  }
  button.onclick=handle(async()=>{
    if(window.chrome?.webview&&new URLSearchParams(location.search).get('native')!=='1'){
      await window.studioProjectHooks.transaction(async()=>{});
      window.chrome.webview.postMessage({type:'open-native',project_id:p?.id||''});return;
    }
    await show();
  });
  el('#native-back').onclick=()=>{if(pending){status('有尚未保存的原生文字，请先保存或放弃文字并重读。',true);return}active=false;generation++;document.title=previousTitle;document.body.classList.remove('native-mode')};
  el('#native-refresh').onclick=handle(async()=>{await scan();if(detail&&!pending)await load(detail.key)});
  el('#native-launch').onclick=handle(async()=>{if(pending)throw Error('有尚未保存的原生文字，请先处理');const r=await api('/api/native/launch',{});status(r.message+(detail?'：'+detail.name:''))});
  el('#native-search').oninput=drawList;
  window.addEventListener('focus',()=>{if(active&&detail&&!pending&&!loading)load(detail.key,true).catch(e=>status(e.message,true))});
  window.addEventListener('beforeunload',event=>{if(pending||nativePackageBusy){event.preventDefault();event.returnValue=nativePackageBusy?'共同工程正在打包':'剪映文字尚未保存'}});
  window.studioNativeDrafts={show,isActive:()=>active};
}

;
// Source: caption-preview.js
'use strict';
const StudioCaptionPreview={
  rgba(hex,alpha){const rgb=hex.replace('#','').match(/../g).map(x=>parseInt(x,16));return `rgba(${rgb.join(',')},${alpha})`},
  nativeRatio(font={},project={width:1080,height:1920}){
    const profile=font.jianying_font_size||{},ratio=Number(profile.native_units_per_1080px),
      width=Number(profile.canvas_width),height=Number(profile.canvas_height);
    if(Number.isFinite(ratio)&&ratio>0&&ratio<1&&width>0&&height>0&&
       Math.abs(width/height-Number(project.width||1080)/Number(project.height||1920))<1e-9)return ratio;
    return 1/8;
  },
  nativeSize(st,font={},project={width:1080,height:1920}){
    return Number(st.font_size)*this.nativeRatio(font,project);
  },
  canvasSize(value,font={},project={width:1080,height:1920}){
    return Number(value)/this.nativeRatio(font,project);
  },
  displayNativeSize(st,font={},project={width:1080,height:1920}){
    return Number(this.nativeSize(st,font,project).toFixed(4));
  },
  style(st,font={},scale=1){
    const opacity=st.opacity??1,angle=(st.shadow_angle??45)*Math.PI/180,distance=(st.shadow??0)*scale;
    return {position:'absolute',transform:'translate(-50%,-50%)',textAlign:'center',whiteSpace:'pre-wrap',paintOrder:'stroke fill',
      fontFamily:`"Studio${st.font_id}",sans-serif`,width:st.max_width+'%',fontSize:st.font_size*scale+'px',
      fontStyle:st.italic?'italic':'normal',textDecorationLine:st.underline?'underline':'none',
      lineHeight:(st.font_size*(font.line_height||1.2)+(st.line_spacing||0))*scale+'px',
      left:st.x+'%',top:st.y+'%',opacity:'1',color:this.rgba(st.color,opacity),fontWeight:st.bold?'700':String(font.weight||400),
      letterSpacing:(st.spacing||0)*scale+'px',webkitTextStroke:`${st.outline*2*scale}px ${this.rgba(st.outline_color,(st.outline_opacity??1)*opacity)}`,
      textShadow:`${distance*Math.cos(angle)}px ${distance*Math.sin(angle)}px ${(st.shadow_blur||0)*scale}px ${this.rgba('#000000',(st.shadow_opacity??.1)*opacity)}`};
  }
};
if(typeof module!=='undefined')module.exports=StudioCaptionPreview;

;
// Source: media-relink.js
'use strict';

function installMediaRelink(){
  let status=null,serial=0;
  const oldOpen=openProject;
  async function refreshStatus(){
    if(!p)return;
    const pid=p.id,result=await api(`/api/projects/${pid}/media-status`,{});
    if(p?.id!==pid)return;
    status=result;
    let notice=$('#missing-media-notice');
    if(!notice){notice=document.createElement('div');notice.id='missing-media-notice';notice.className='parallel-editor-notice';$('.project-heading').after(notice)}
    const missing=result.assets.filter(a=>a.missing);notice.hidden=!missing.length;
    notice.innerHTML=missing.length?`<span>素材已经丢失：${missing.length} 项。工程和原裁剪仍然保留，请重连素材；不会自动删除片段。</span><button id="missing-media-relink">重连素材</button>`:'';
    if(missing.length)$('#missing-media-relink').onclick=handle(()=>openRelink(missing[0].id));
  }
  openProject=async function(...args){await oldOpen(...args);await refreshStatus()};
  async function openRelink(assetId){
    if(!p)throw Error('请先打开工程');
    await save();
    const pid=p.id,revision=p.revision,assets=p.assets.map(a=>({...a}));
    let preview=null;
    modal(`<h2>重连素材</h2><p>选择原文件的新位置。按 SHA-256 核对内容，不按同名猜测；保留原入出点、时间位置、音量与联动。不同内容请使用替换，不会悄悄当成原素材。</p><label>丢失或移动的素材</label><select id="relink-source">${assets.map(a=>`<option value="${a.id}" ${a.id===assetId?'selected':''}>${esc(a.name)}${status?.assets.find(row=>row.id===a.id)?.missing?' · 已丢失':''}</option>`).join('')}</select><p id="relink-old-path" class="helper"></p><label>新文件路径</label><div class="row"><input id="relink-path" placeholder="选择原媒体文件，或粘贴完整路径"><button id="relink-pick">选择文件</button></div><p id="relink-result" role="status"></p><div class="modal-actions"><button id="relink-check">检查素材</button><button id="relink-confirm" class="primary" disabled>确认重连并保留原裁剪</button></div>`);
    const invalidate=()=>{preview=null;$('#relink-confirm').disabled=true;$('#relink-result').textContent='';$('#relink-old-path').textContent=assets.find(a=>a.id===$('#relink-source').value)?.path||''};
    $('#relink-source').onchange=invalidate;$('#relink-path').oninput=invalidate;invalidate();
    $('#relink-pick').onclick=()=>{
      if(!window.chrome?.webview){$('#relink-result').textContent='浏览器无法读取文件的原始完整路径，请从资源管理器复制路径粘贴到上方。桌面版可直接选择文件。';$('#relink-path').focus();return}
      const request_id='relink-'+(++serial);
      const listener=event=>{
        const data=event.data;if(data?.type!=='media-file-picked'||data.request_id!==request_id)return;
        window.chrome.webview.removeEventListener('message',listener);
        if(p?.id!==pid||!$('#relink-path'))return;
        if(data.path){$('#relink-path').value=data.path;invalidate();$('#relink-check').click()}
      };
      window.chrome.webview.addEventListener('message',listener);
      window.chrome.webview.postMessage({type:'pick-media-file',request_id});
      $('#relink-result').textContent='请选择原文件；若旧桌面程序未响应，可直接粘贴完整路径。';
    };
    $('#relink-check').onclick=handle(async()=>{
      invalidate();const source=$('#relink-source').value,path=$('#relink-path').value;
      const result=await api(`/api/projects/${pid}/relink-preview`,{revision,asset_id:source,path});
      if(p?.id!==pid||!$('#relink-path')||$('#relink-path').value!==path||$('#relink-source').value!==source)return;
      preview=result;$('#relink-result').textContent=`${result.notice}。时长 ${time(result.asset.duration)}，${result.asset.width||0} × ${result.asset.height||0}。`;
      $('#relink-confirm').disabled=!result.identical;
    });
    $('#relink-confirm').onclick=handle(async()=>{
      if(!preview?.identical)throw Error('请先检查并确认原素材');
      if(p?.id!==pid||p.revision!==revision)throw Error('工程已变化，请重新打开重连');
      $('#relink-confirm').disabled=true;
      try{
        const result=await api(`/api/projects/${pid}/relink-asset`,{revision,asset_id:preview.asset.id,path:preview.asset.path,expected_sha256:preview.asset.sha256,confirmed:true});
        if(p?.id===pid){remember();studioProjectHooks.adopt(result);render();window.StudioRealtime?.refresh();await refreshQA();await refreshStatus()}
        $('#modal').close();toast('素材已重连，保留原裁剪和时间位置；请播放核对。');
      }catch(error){$('#relink-confirm').disabled=false;throw error}
    });
  }
  window.studioMediaRelink={open:openRelink,refresh:refreshStatus};
}

;
// Source: app.js
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const copy=x=>JSON.parse(JSON.stringify(x)), id=()=>crypto.randomUUID().replaceAll('-','');
const token=new URLSearchParams(location.hash.slice(1)).get('token')||sessionStorage.getItem('studio-token')||'';
sessionStorage.setItem('studio-token',token); history.replaceState(null,'',location.pathname+location.search);
let boot={}, p=null, tab='captions', selected=null, jobs=[], undo=[], dirty=0,saved=0,saving=null,timer=null;
let previewJob=null, waitingPreview=null, peaks=null, qa=null, knownFonts=new Set();
const url=path=>path+(path.includes('?')?'&':'?')+'token='+encodeURIComponent(token);
const time=t=>{t=Math.max(0,Number(t)||0);return `${Math.floor(t/60).toString().padStart(2,'0')}:${(t%60).toFixed(3).padStart(6,'0')}`};
// Number controls commit as they are edited; do not depend on a later blur.
document.addEventListener('input',e=>{const el=e.target;if(el.type==='number'&&el.value!==''&&Number.isFinite(Number(el.value))&&typeof el.onchange==='function')el.onchange(e)});
function toast(text,error=false){$('#toast').textContent=text;$('#toast').style.background=error?'#ffc0b2':'#d4f29a';$('#toast').classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('#toast').classList.remove('show'),error?8000:3800)}
async function api(path,body){const r=await fetch(path,{method:body===undefined?'GET':'POST',headers:{'X-Studio-Token':token,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});const data=await r.json();if(!r.ok){const error=Error(data.error||'请求失败');error.data=data;error.status=r.status;throw error}return data}
function handle(fn){return async e=>{try{await fn(e)}catch(err){toast(err.message,true)}}}
function remember(){if(p){undo.push(copy(p));if(undo.length>40)undo.shift()}}
function mark(sound=false){dirty++;$('#save-status').textContent='有修改 · 正在保存';clearTimeout(timer);timer=setTimeout(()=>save().catch(e=>toast(e.message,true)),600);if(sound&&previewJob){$('#preview-label').textContent='声音已修改 · 请重生成';}updateOverlay()}
async function save(){clearTimeout(timer);if(saving){await saving;if(dirty>saved)return save();return}if(!p||dirty<=saved)return;const count=dirty, pid=p.id,body=copy(p);saving=api('/api/projects/'+pid,body);try{const result=await saving;if(p?.id===pid){p.revision=result.revision;p.reviews=result.reviews;saved=count;$('#save-status').textContent='已保存到本机';}}finally{saving=null}if(dirty>saved)return save()}
async function refreshBoot(){boot=await api('/api/bootstrap');renderProjects();if($('.version'))$('.version').textContent=`开发预览版 ${boot.version} · 原素材不覆盖`;await loadFonts()}
async function loadFonts(){
  for(const font of boot.fonts||[]){
    if(knownFonts.has(font.id))continue;
    try{const face=new FontFace('Studio'+font.id,`url("${url('/font/'+font.id)}")`,{weight:String(font.weight||400),style:font.italic?'italic':'normal'});await face.load();document.fonts.add(face);knownFonts.add(font.id)}
    catch(e){toast('字体预览加载失败：'+font.name,true)}
  }
  const fid=boot.settings?.ui_font_id;
  if(fid&&knownFonts.has(fid)&&document.documentElement){document.documentElement.style.setProperty('--ui-font',`"Studio${fid}","Microsoft YaHei UI","Microsoft YaHei",sans-serif`)}
  updateOverlay();
}
async function openProject(pid){await save();p=await api('/api/projects/'+pid);dirty=saved=0;selected=p.captions[0]?.id;undo=[];previewJob=null;peaks=null;$('#video').pause();$('#video').removeAttribute('src');$('#video').load();$('#stage-placeholder').style.display='flex';$('#preview-label').textContent='尚未生成';$('#project-name').value=p.name;$('#save-status').textContent='已保存到本机';await refreshQA();renderProjects();render();drawWave()}
function renderProjects(){$('#projects').innerHTML=(boot.projects||[]).map(x=>`<button class="project-row ${x.id===p?.id?'active':''}" data-project="${x.id}"><div>${esc(x.name)}</div><small>${x.clips} 个镜头 · ${x.captions} 条字幕</small></button>`).join('')||'<p class="helper">还没有分集，点击＋创建</p>';$$('[data-project]').forEach(b=>b.onclick=handle(()=>openProject(b.dataset.project)))}
function modal(html){$('#modal-body').innerHTML=html;$('#modal').showModal()}
$('#close-modal').onclick=()=>$('#modal').close();
function total(){if(!p)return 0;return StudioTimeline.layout(p).duration}
function rate(){if(!p)return 24;const a=String(p.fps).split('/').map(Number);return a[0]/(a[1]||1)}
function playbackTime(){return window.StudioRealtime?.editing()?StudioRealtime.time():($('#video').currentTime||0)}
function seekPlayback(t){if(window.StudioRealtime?.editing())StudioRealtime.seek(t);else $('#video').currentTime=t}
function currentCue(){return p?.captions.find(c=>c.id===selected)}
function asset(aid){return p.assets.find(a=>a.id===aid)}
function empty(title,text,button=''){return `<div class="empty"><div class="frame-icon" style="display:inline-block">＋</div><h3>${title}</h3><p>${text}</p>${button}</div>`}
function render(){if(!p){$('#panel').innerHTML=empty('开始第一集','新建分集，导入素材、剧本与音乐。','<button id="empty-new" class="primary">新建分集</button>');$('#empty-new').onclick=newProject;return}$('#project-name').value=p.name;$('#project-meta').textContent=`${p.width} × ${p.height} · ${p.fps} fps · ${time(total())} · ${p.captions.length} 条字幕`;$('#duration').textContent=time(total()).slice(0,5);$('#seek').max=total()||1;$('#footer-left').textContent=`${p.clips.length} 个画面片段 · ${p.audios.length} 条附加音频 · 修订 ${p.revision}`;$$('.tabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));if(tab==='captions')renderCaptions();if(tab==='clips')renderClips();if(tab==='audio')renderAudio();if(tab==='script')renderScript();if(tab==='qa')renderQA();renderInspector();updateOverlay()}
$('#tabs').onclick=handle(async e=>{const b=e.target.closest('[data-tab]');if(b){tab=b.dataset.tab;if(tab==='qa'){await save();await refreshQA()}render()}});
function renderCaptions(){$('#panel').innerHTML=`<div class="panel-head"><h3>字幕时间线</h3><small>${p.captions.length} 条</small></div><div class="toolbar"><button id="add-cue">＋ 添加</button><button id="import-srt">导入 SRT</button><button id="asr">识别最终音轨</button><button id="wrap-all">自动断行</button><button id="shift-all">整体移时</button></div>${p.captions.length?'':empty('为声音加上准确字幕','可导入SRT、逐条添加，或识别生成后的最终音轨。<br>自动识别结果需要校对。')}<div id="cue-list">${p.captions.map((c,i)=>`<div class="cue ${c.id===selected?'selected':''}" data-cue="${c.id}"><span class="cue-index">${String(i+1).padStart(2,'0')}</span><div><span class="cue-time">${time(c.start)} → ${time(c.end)}</span><div class="cue-text">${esc(c.text)}</div></div></div>`).join('')}</div>`;$$('[data-cue]').forEach(b=>b.onclick=()=>{selected=b.dataset.cue;const c=currentCue();seekPlayback(c.start);render()});$('#add-cue').onclick=()=>{remember();const start=playbackTime(),c={id:id(),start:Math.min(start,Math.max(0,total()-.5)),end:Math.min(Math.max(start+2,.5),total()||2),text:'请输入字幕',style:{}};p.captions.push(c);p.captions.sort((a,b)=>a.start-b.start);selected=c.id;mark();render()};$('#import-srt').onclick=()=>$('#srt-file').click();$('#asr').onclick=handle(()=>submitJob('transcribe'));$('#wrap-all').onclick=handle(async()=>{await save();p=await api(`/api/projects/${p.id}/wrap`,{});render();toast('已按所选字体宽度断行，字号保持不变')});$('#shift-all').onclick=()=>{modal('<h2>整体调整字幕时间</h2><p>正数延后，负数提前。请根据实际声音，不要盲目整体平移。</p><input id="shift-value" type="number" step="0.01" value="0"><div class="modal-actions"><button id="shift-ok" class="primary">应用到全部字幕</button></div>');$('#shift-ok').onclick=handle(()=>{const delta=Number($('#shift-value').value);if(!Number.isFinite(delta)||p.captions.some(c=>c.start+delta<0))throw Error('移动后不能产生负时间');remember();p.captions.forEach(c=>{c.start+=delta;c.end+=delta});mark();render();$('#modal').close()})}}
function renderInspector(){if(!p)return;const cue=currentCue(),individual=!!(cue&&Object.keys(cue.style||{}).length),st=individual&&tab==='captions'?{...p.style,...cue.style}:p.style,font=(boot.fonts||[]).find(f=>f.id===st.font_id)||{},nativeFontSize=StudioCaptionPreview.displayNativeSize(st,font,p);$('#inspector').innerHTML=`<h3>${tab==='captions'?'字幕属性':'字幕全局样式'}</h3>${cue&&tab==='captions'?`<label>当前字幕文字</label><textarea id="cue-text" rows="3">${esc(cue.text)}</textarea><div class="row"><div><label>开始（秒）</label><input id="cue-start" type="number" step="0.01" min="0" value="${cue.start.toFixed(3)}"></div><div><label>结束（秒）</label><input id="cue-end" type="number" step="0.01" value="${cue.end.toFixed(3)}"></div></div><div class="toolbar" style="margin-top:8px"><button id="in-now">入点=播放头</button><button id="out-now">出点=播放头</button><button id="delete-cue" class="danger">删除</button></div><label><input type="checkbox" id="individual" ${individual?'checked':''}> 仅调整这一条的样式</label><label>语音标记（不改变字幕语言）</label><select id="spoken-lang"><option value="">未标记</option><option value="zh" ${cue.spoken_language==='zh'?'selected':''}>此处有人物说中文 · 仅在交付报告注明</option></select><hr class="section-break">`:''}<div class="panel-head"><span class="chip">${individual&&tab==='captions'?'当前字幕':'整集统一样式'}</span><button id="import-font" style="font-size:10px;padding:4px 7px">＋ 导入字体</button></div><label>字体</label><select data-style="font_id">${(boot.fonts||[]).map(f=>`<option value="${f.id}" ${f.id===st.font_id?'selected':''}>${esc(f.name)}</option>`).join('')}</select><div class="row"><div><label>字号（剪映数值）</label><input data-style="font_size" type="number" min="1" max="100" step=".1" value="${nativeFontSize}"></div><div><label>文字颜色</label><input data-style="color" type="color" value="${st.color}"></div></div><div class="row"><div><label>水平位置 %</label><input data-style="x" type="number" min="0" max="100" step=".5" value="${st.x}"></div><div><label>垂直位置 %</label><input data-style="y" type="number" min="0" max="100" step=".5" value="${st.y}"></div></div><div class="row"><div><label>描边粗细（百慕3≈剪映15）</label><input data-style="outline" type="number" min="0" max="15" step=".5" value="${st.outline}"></div><div><label>描边颜色</label><input data-style="outline_color" type="color" value="${st.outline_color}"></div></div><div class="row"><div><label>阴影距离</label><input data-style="shadow" type="number" min="0" max="20" step=".5" value="${st.shadow}"></div><div><label>阴影不透明度 0–1</label><input data-style="shadow_opacity" type="number" min="0" max="1" step=".05" value="${st.shadow_opacity}"></div></div><div class="row"><div><label>断行最大宽度 %</label><input data-style="max_width" type="number" min="20" max="98" value="${st.max_width}"></div><div><label>字间距</label><input data-style="spacing" type="number" min="0" max="20" step=".5" value="${st.spacing}"></div></div><label><input data-style="bold" type="checkbox" ${st.bold?'checked':''}> 粗体</label><p class="helper">字号按剪映面板数值填写；描边按1080画布像素预览，交接剪映时自动乘5（百慕3约为剪映15）。长句自动换行，不自动缩小。</p><button id="export-srt" class="wide ghost">导出当前 SRT 字幕</button>`;
$('#import-font').onclick=()=>$('#font-file').click();$$('[data-style]').forEach(el=>el.onchange=()=>{remember();const key=el.dataset.style,target=individual&&tab==='captions'?cue.style:p.style;let value=el.type==='checkbox'?el.checked:el.type==='number'?Number(el.value):el.value;if(key==='font_size')value=StudioCaptionPreview.canvasSize(value,font,p);if(key==='font_id'){const nativeSize=StudioCaptionPreview.nativeSize(st,font,p),nextFont=(boot.fonts||[]).find(f=>f.id===value)||{};if(target===p.style)for(const item of p.captions){if(item.style&&item.style.font_size!=null&&!item.style.font_id){const itemNative=StudioCaptionPreview.nativeSize({font_size:item.style.font_size},font,p);item.style.font_size=StudioCaptionPreview.canvasSize(itemNative,nextFont,p)}}target.font_id=value;target.font_size=StudioCaptionPreview.canvasSize(nativeSize,nextFont,p)}else target[key]=value;mark();updateOverlay();if(key==='font_id')renderInspector()});if(cue&&tab==='captions'){const change=(key,value)=>{remember();cue[key]=value;mark();renderCaptions();updateOverlay()};$('#cue-text').oninput=()=>{cue.text=$('#cue-text').value;mark();const row=$(`[data-cue="${cue.id}"] .cue-text`);if(row)row.textContent=cue.text};$('#cue-start').onchange=()=>change('start',Number($('#cue-start').value));$('#cue-end').onchange=()=>change('end',Number($('#cue-end').value));$('#in-now').onclick=()=>{change('start',playbackTime());renderInspector()};$('#out-now').onclick=()=>{change('end',playbackTime());renderInspector()};$('#spoken-lang').onchange=()=>change('spoken_language',$('#spoken-lang').value);$('#delete-cue').onclick=()=>{remember();p.captions=p.captions.filter(c=>c.id!==cue.id);selected=p.captions[0]?.id;mark();render()};$('#individual').onchange=()=>{remember();cue.style=$('#individual').checked?copy(p.style):{};mark();renderInspector()}}$('#export-srt').onclick=()=>{const format=t=>{const ms=Math.round(t*1000);return `${Math.floor(ms/3600000).toString().padStart(2,'0')}:${Math.floor(ms/60000)%60}`.replace(/:(\d)$/,'\:0$1')+`:${(Math.floor(ms/1000)%60).toString().padStart(2,'0')},${(ms%1000).toString().padStart(3,'0')}`};const text=p.captions.map((c,i)=>`${i+1}\n${format(c.start)} --> ${format(c.end)}\n${c.text}`).join('\n\n');download(new Blob(['\ufeff'+text],{type:'text/plain;charset=utf-8'}),p.name+'.srt')}}
function renderClips(){
  $('#panel').innerHTML=`<div class="panel-head"><h3>素材</h3><small>${p.clips.length} 个镜头</small></div><div class="toolbar"><button id="import-media" class="accent">＋ 添加素材</button></div><p class="helper">在下方主轨拖动镜头排序，拖两端裁剪；移动播放头后点“分割”。原文件不会改变。</p>${p.clips.length?`<div class="media-clip-list">${p.clips.map((c,i)=>{const a=asset(c.asset_id);return `<button class="media-clip" data-select-clip="${c.id}"><span class="media-clip-index">${i+1}</span><span><b>${esc(a?.name||'视频素材')}</b><small>${time(c.out-c.in)}${a?.has_audio?' · 含原声':''}</small></span></button>`}).join('')}</div>`:empty('添加你的画面','选择或拖入视频、音频、字幕、剧本或整个文件夹')}<details class="project-settings"><summary>工程设置</summary><div class="row field"><div><label>帧率</label><select id="fps-select">${['24','25','30','24000/1001','30000/1001','60'].map(v=>`<option value="${v}" ${Number(v)===Number(p.fps)||v===p.fps?'selected':''}>${v}</option>`).join('')}<option value="${esc(p.fps)}" selected>${esc(p.fps)}（当前）</option></select></div><div><label>输出尺寸</label><select id="resolution">${[540,720,1080].map(w=>`<option value="${w}" ${w===p.width?'selected':''}>${w} × ${w*16/9}</option>`).join('')}</select></div></div></details>`;
  $('#import-media').onclick=()=>importDialog(true);
  $('#fps-select').onchange=()=>{remember();p.fps=$('#fps-select').value;mark(true);render()};
  $('#resolution').onchange=()=>{remember();p.width=Number($('#resolution').value);p.height=p.width*16/9;mark(true);render()};
  $$('[data-select-clip]').forEach(button=>button.onclick=()=>window.StudioTimelineUI?.select('video',button.dataset.selectClip));
}
function renderAudio(){$('#panel').innerHTML=`<div class="panel-head"><h3>旁白与音乐</h3><small>同号联动，独立片段可单独编辑</small></div><div class="toolbar"><button id="import-audio">添加素材</button><button id="add-audio" class="accent">＋ 放入音轨</button></div><div class="helper">BGM在有人声时自动压低。旁白不会自动覆盖原声，请先核对必保台词；暂不执行未经核实的智能删句。</div>${p.audios.map(a=>`<div class="card"><div class="card-title">${esc(asset(a.asset_id)?.name)}</div><label>类型</label><select data-audio="${a.id}" data-key="role">${[['dialogue','人物原声'],['narration','旁白 / 配音'],['bgm','BGM纯音乐'],['sfx','音效']].map(([v,t])=>`<option value="${v}" ${a.role===v?'selected':''}>${t}</option>`).join('')}</select><div class="row"><div><label>时间线起点 / 秒</label><input data-audio="${a.id}" data-key="start" type="number" min="0" step=".01" value="${a.start}"></div><div><label>音量 / dB</label><input data-audio="${a.id}" data-key="gain" type="number" min="-60" max="12" value="${a.gain}"></div></div><div class="row"><div><label>源入点</label><input data-audio="${a.id}" data-key="in" type="number" step=".01" value="${a.in}"></div><div><label>源出点</label><input data-audio="${a.id}" data-key="out" type="number" step=".01" value="${a.out}"></div></div><label><input style="width:auto" data-audio="${a.id}" data-key="loop" type="checkbox" ${a.loop?'checked':''}> BGM循环到片尾</label><div class="card-actions"><button data-remove-audio="${a.id}" class="danger">移除音频</button></div></div>`).join('')||empty('让音乐衬托对白','添加音频后，从素材库选择曲目放入音轨。')}`;$('#import-audio').onclick=()=>importDialog(false);$('#add-audio').onclick=()=>{const choices=p.assets.filter(a=>a.has_audio);modal(`<h2>放入音轨</h2><label>素材</label><select id="audio-asset">${choices.map(a=>`<option value="${a.id}">${esc(a.name)}</option>`).join('')}</select><label>类型</label><select id="audio-role"><option value="bgm">背景音乐（循环铺满）</option><option value="narration">旁白 / 配音</option><option value="sfx">音效</option></select><div class="modal-actions"><button id="audio-add-ok" class="primary">添加</button></div>`);$('#audio-add-ok').onclick=handle(()=>{const aid=$('#audio-asset').value,role=$('#audio-role').value;if(!aid)throw Error('请先导入音频');remember();p.audios.push({id:id(),asset_id:aid,in:0,out:asset(aid).duration,start:0,role,gain:role==='bgm'?-22:0,loop:role==='bgm'});mark(true);render();$('#modal').close()})};$$('[data-audio]').forEach(el=>el.onchange=()=>{remember();p.audios.find(a=>a.id===el.dataset.audio)[el.dataset.key]=el.type==='checkbox'?el.checked:el.type==='number'?Number(el.value):el.value;mark(true)});$$('[data-remove-audio]').forEach(el=>el.onclick=()=>{remember();p.audios=p.audios.filter(a=>a.id!==el.dataset.removeAudio);mark(true);render()})}
function renderScript(){$('#panel').innerHTML=`<div class="panel-head"><h3>剧本与对白保护</h3></div><div class="toolbar"><button id="script-import">导入 PDF / TXT</button><button id="line-add">＋ 必保台词</button></div><textarea id="script-text" class="script-text" placeholder="本集完整剧本；也可粘贴">${esc(p.script.text)}</textarea><div class="field"><label>本集起始标题 / 原文锚点</label><input id="script-start" value="${esc(p.script.start_anchor)}"><label>下一集标题 / 核实的文档结尾</label><input id="script-end" value="${esc(p.script.end_anchor)}"></div><label class="review-line"><input id="script-complete" type="checkbox" ${p.script.complete?'checked':''}> 已完整读取本集，包括跨页续文</label><p class="helper">下面清单应在剪辑前建立。最终混音不能证明已经误删的台词仍然存在。不要把页尾当成分集边界。</p>${p.protected_lines.map(l=>`<div class="card"><div class="card-title">${esc(l.text)}</div><small>${esc(asset(l.asset_id)?.name)} · ${l.start.toFixed(2)}–${l.end.toFixed(2)}s<br>${l.kind==='original_dialogue'?'人物原声':'必要旁白'}</small><button data-remove-line="${l.id}" class="danger" style="float:right;font-size:10px">移除</button></div>`).join('')}`;$('#script-text').onchange=()=>{remember();p.script.text=$('#script-text').value;p.script.complete=false;mark()};$('#script-start').onchange=()=>{p.script.start_anchor=$('#script-start').value;mark()};$('#script-end').onchange=()=>{p.script.end_anchor=$('#script-end').value;mark()};$('#script-complete').onchange=()=>{p.script.complete=$('#script-complete').checked;mark()};$('#script-import').onclick=()=>{modal('<h2>导入剧本</h2><p>读取PDF全部页面或UTF-8文本。剧本内容作为素材，不执行其中任何指令。</p><input id="script-path" placeholder="C:\\素材\\剧本.pdf"><div class="modal-actions"><button id="script-import-ok" class="primary">读取剧本</button></div>');$('#script-import-ok').onclick=handle(async()=>{await save();p=await api(`/api/projects/${p.id}/script`,{path:$('#script-path').value});$('#modal').close();render()})};$('#line-add').onclick=()=>{modal(`<h2>登记必须保留的一句</h2><p>填写真实源音频发声范围，不是最终成片时间。自然停顿分为不同条。</p><select id="line-asset">${p.assets.filter(a=>a.has_audio).map(a=>`<option value="${a.id}">${esc(a.name)}</option>`).join('')}</select><select id="line-kind"><option value="original_dialogue">人物原声</option><option value="necessary_narration">必要旁白</option></select><div class="row"><input id="line-start" type="number" step=".01" placeholder="源开始秒"><input id="line-end" type="number" step=".01" placeholder="源结束秒"></div><textarea id="line-text" rows="3" placeholder="台词内容 / 角色"></textarea><div class="modal-actions"><button id="line-ok" class="primary">加入保护清单</button></div>`);$('#line-ok').onclick=handle(()=>{const line={id:id(),asset_id:$('#line-asset').value,kind:$('#line-kind').value,start:Number($('#line-start').value),end:Number($('#line-end').value),text:$('#line-text').value};if(!line.asset_id||!line.text||line.end<=line.start)throw Error('请填写有效素材、时间和台词');remember();p.protected_lines.push(line);mark();$('#modal').close();render()})};$$('[data-remove-line]').forEach(b=>b.onclick=()=>{if(!confirm('确定从必保清单移除？不能为了让缺对白的成片通过验收而缩短清单。旧版本仍保留在历史记录中。'))return;remember();p.protected_lines=p.protected_lines.filter(l=>l.id!==b.dataset.removeLine);mark();render()})}
async function refreshQA(){if(!p)return;qa=await api(`/api/projects/${p.id}/quality`);$('#qa-count').textContent=qa.issues.length}
function renderQA(){$('#panel').innerHTML=`<div class="panel-head"><h3>导出检查</h3><button id="qa-refresh">重新检查</button></div><div class="alert ${qa?.issues?.length?'':'success'}">${qa?.issues?.length?`${qa.issues.length} 项提示；不会要求人工打勾才能导出。`:'没有发现结构问题。'}</div>${(qa?.issues||[]).map(i=>`<div class="issue ${i.level}" data-seek="${i.time??''}"><small>${esc(i.code)} ${i.time!=null?time(i.time):''}</small>${esc(i.text)}</div>`).join('')}`;$('#qa-refresh').onclick=handle(async()=>{await save();await refreshQA();renderQA()});$$('[data-seek]').forEach(b=>b.onclick=()=>{if(b.dataset.seek)seekPlayback(Number(b.dataset.seek))})}
function updateOverlay(frameTime){
  if(!p)return;
  const t=Number.isFinite(frameTime)?frameTime:($('#video').currentTime||0),el=$('#caption-overlay');
  const active=p.captions.filter(c=>t>=Math.ceil(c.start*100-1e-7)/100&&t<Math.ceil(c.end*100-1e-7)/100);
  const chosen=active.find(c=>c.id===selected)||active[0];
  document.querySelectorAll('.caption-extra').forEach(node=>node.remove());
  if(!chosen){el.textContent='';return}
  for(const cue of [chosen,...active.filter(c=>c!==chosen)]){
    const node=cue===chosen?el:document.createElement('div'),st={...p.style,...cue.style};
    node.textContent=cue.text;
    Object.assign(node.style,StudioCaptionPreview.style(st,(boot.fonts||[]).find(f=>f.id===st.font_id),$('#stage').clientWidth/1080));
    if(node!==el){node.className='caption-extra';node.style.pointerEvents='none';node.style.zIndex='3';$('#stage').append(node)}
  }
  $$('[data-cue]').forEach(b=>b.classList.toggle('playing',active.some(c=>c.id===b.dataset.cue)));
}
function drawWave(){const c=$('#waveform'),ctx=c.getContext('2d');c.width=Math.round(c.clientWidth*devicePixelRatio);c.height=58*devicePixelRatio;ctx.clearRect(0,0,c.width,c.height);if(!peaks)return;ctx.fillStyle='#7e91b2';const data=peaks.peaks;for(let x=0;x<c.width;x+=2){const a=Math.floor(x/c.width*data.length),b=Math.max(a+1,Math.floor((x+2)/c.width*data.length));let max=0;for(let n=a;n<b;n++)max=Math.max(max,data[n]||0);const h=Math.max(1,max*c.height*.85);ctx.fillRect(x,(c.height-h)/2,1.3,h)}const at=($('#video').currentTime||0)/Math.max(1,peaks.duration);ctx.fillStyle='#d4f29a';ctx.fillRect(at*c.width,0,2,c.height)}
$('#video').ontimeupdate=()=>{$('#timecode').textContent=time($('#video').currentTime);$('#seek').value=$('#video').currentTime;updateOverlay();drawWave()};$('#video').onplay=()=>$('#play-button').textContent='Ⅱ';$('#video').onpause=()=>$('#play-button').textContent='▶';$('#video').onloadeddata=()=>$('#stage-placeholder').style.display='none';$('#play-button').onclick=handle(async()=>{if(!$('#video').getAttribute('src'))throw Error('请先生成混音预览');if($('#video').paused)await $('#video').play();else $('#video').pause()});$('#seek').oninput=()=>{$('#video').currentTime=Number($('#seek').value);updateOverlay()};$('#back-frame').onclick=()=>{$('#video').pause();$('#video').currentTime=Math.max(0,$('#video').currentTime-1/rate())};$('#next-frame').onclick=()=>{$('#video').pause();$('#video').currentTime=Math.min(total(),$('#video').currentTime+1/rate())};$('#waveform').onclick=e=>{if(!peaks)return;$('#video').currentTime=(e.offsetX/$('#waveform').clientWidth)*peaks.duration};window.addEventListener('resize',()=>{drawWave();updateOverlay()});new ResizeObserver(updateOverlay).observe($('#stage'));
function importDialog(){if(!p)return toast('请先新建分集',true);if(window.studioMaterialImport)return window.studioMaterialImport.open();$('#material-file-input').click()}
async function newProject(){const name=prompt('分集名（同时作为导出名）','EP01');if(!name)return;await save();const n=await api('/api/projects',{name});await refreshBoot();await openProject(n.id);tab='clips';render()}
$('#new-button').onclick=handle(newProject);$('#project-name').onchange=()=>{if(p){p.name=$('#project-name').value;mark()}};$('#save-button').onclick=handle(async()=>{await save();toast('工程已保存')});$('#undo-button').onclick=()=>{if(!undo.length)return toast('暂无可撤销的编辑');const previous=undo.pop();previous.revision=p.revision;p=previous;mark(true);render()};
$('#font-file').onchange=handle(async e=>{const file=e.target.files[0];if(!file)return;if(file.size>30*1024*1024)throw Error('字体文件不能超过30MB');const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=reject;r.readAsDataURL(file)});const font=await api('/api/fonts',{name:file.name,data});await refreshBoot();if(p){remember();const c=currentCue();if(tab==='captions'&&c&&Object.keys(c.style||{}).length)c.style.font_id=font.id;else p.style.font_id=font.id;mark();renderInspector();updateOverlay()}toast('字体已加入本地字体库：'+font.name);e.target.value=''});
$('#srt-file').onchange=handle(async e=>{const f=e.target.files[0];if(!f||!p)return;const cues=await api(`/api/projects/${p.id}/srt`,{text:await f.text()});if(p.captions.length&&!confirm('用导入字幕替换当前字幕？旧版本仍保留，可撤销。'))return;remember();p.captions=cues;selected=cues[0]?.id;mark();render();e.target.value=''});
function canEnhanceExport(kind){return kind==='draft'||kind==='final'}
function exportQualityOptions(kind,options={}){return canEnhanceExport(kind)?{enhance_hd:options?.enhance_hd===true}:{}}
function exportQualityControl(name,disabled=false){return `<label class="review-line"><input id="${name}" type="checkbox" aria-describedby="${name}-note" ${disabled?'disabled':''}>增强清晰度</label><p id="${name}-note" class="helper">轻度降噪、缩放和锐化。处理更慢，不改变音频或字幕时间。</p>`}
function jobQualityLabel(job){return canEnhanceExport(job.kind)&&job.options?.enhance_hd===true?' · 一键高清':''}
async function submitJob(kind,options={}){
  if(!p)throw Error('请先新建分集');const pid=p.id,qualityOptions=exportQualityOptions(kind,options);
  await save();if(p?.id!==pid)throw Error('当前分集已改变，请重新打开导出窗口');
  const job=await api(`/api/projects/${pid}/jobs`,{kind,language:p.language,...qualityOptions});
  if(kind==='preview')waitingPreview=job.id;
  toast(kind==='transcribe'?'正在后台识别；结果会作为字幕草稿':'正在后台导出；可以继续剪辑');
  // A failed list refresh must not make an accepted job look safe to resubmit.
  try{await pollJobs()}catch(e){toast('任务已加入队列，但列表刷新失败；请刷新查看，不要重复提交。'+e.message,true)}
  return job;
}
$('#preview-button').onclick=handle(()=>submitJob('preview'));
function exportHistoryMarkup(pid){
  const rows=jobs.filter(job=>job.project_id===pid&&['draft','final'].includes(job.kind)).slice(0,6);
  return rows.length?rows.map(job=>`<div class="export-row"><span><b>${esc(job.name)}</b><small>${esc(job.message)}${jobQualityLabel(job)}</small>${job.state==='complete'&&job.result?.output?`<small style="overflow-wrap:anywhere">本机生成文件：${esc(job.result.output)}</small><small>下载 MP4 可另存到其他位置；内容仍需看片、试听确认。</small>`:''}</span>${job.state==='complete'&&job.result?.file?`<button data-view-export="${job.id}">播放</button><a href="${url(`/render/${job.id}/${job.result.file}?download=1`)}">下载 MP4</a>`:`<span class="export-state">${job.state==='failed'?'失败':job.state==='cancelled'?'已取消':'处理中'}</span>`}</div>`).join(''):'<p class="helper">还没有导出记录。</p>';
}
function renderExportHistory(){const slot=$('#export-history');if(!slot||!p)return;slot.innerHTML=exportHistoryMarkup(p.id);$$('[data-view-export]').forEach(button=>button.onclick=handle(async()=>{$('#modal').close();await viewRender(jobs.find(job=>job.id===button.dataset.viewExport))}))}
$('#export-button').onclick=handle(async()=>{
  if(!p)throw Error('请先建立工程');await save();await refreshQA();const pid=p.id;
  const issueMarkup=(qa.issues||[]).length?`<details class="export-checks"><summary>${qa.issues.length} 项检查提示（不阻止导出）</summary>${qa.issues.map(item=>`<p>${esc(item.text)}</p>`).join('')}</details>`:'<p class="success export-ready">未发现结构问题</p>';
  modal(`<h2>导出 ${esc(p.name)}</h2><p>生成一个新的 MP4，不覆盖原素材或旧导出。</p>${issueMarkup}${exportQualityControl('export-enhance-hd')}<div class="modal-actions"><button id="final-export" class="primary">导出 MP4</button></div><h3 class="export-history-title">最近导出</h3><div id="export-history"></div>`);
  const final=$('#final-export'),enhance=$('#export-enhance-hd');let submitting=false;
  renderExportHistory();
  final.onclick=handle(async()=>{
    if(submitting)return;if(p?.id!==pid)throw Error('当前分集已改变，请重新打开导出窗口');
    submitting=true;final.disabled=enhance.disabled=true;
    try{await submitJob('final',{enhance_hd:enhance.checked});$('#modal').close()}
    finally{submitting=false;final.disabled=enhance.disabled=false}
  });
});
async function pollJobs(){
  jobs=await api('/api/jobs');
  $('#job-count').textContent=jobs.filter(j=>['queued','running'].includes(j.state)).length;
  $('#jobs').innerHTML=jobs.slice(0,30).map(j=>`<div class="job"><div class="title"><b>${esc(j.name)}</b><span class="chip">${({preview:'预览',draft:'审阅',final:'成片',transcribe:'识别'})[j.kind]}${jobQualityLabel(j)}</span></div><p>${esc(j.message)}</p><progress max="1" value="${j.progress}"></progress>${['queued','running'].includes(j.state)?`<button data-cancel="${j.id}">取消</button>`:''}${j.state==='complete'&&j.result?.file?`<button data-view="${j.id}">播放</button><a href="${url(`/render/${j.id}/${j.result.file}?download=1`)}">下载视频</a><a href="${url(`/render/${j.id}/quality.json?download=1`)}">质检报告</a>`:''}${j.state==='complete'&&j.kind==='transcribe'?`<button data-apply-asr="${j.id}">应用字幕草稿</button>`:''}</div>`).join('');
  renderExportHistory();
  $$('[data-cancel]').forEach(b=>b.onclick=handle(()=>api(`/api/jobs/${b.dataset.cancel}/cancel`,{})));
  $$('[data-view]').forEach(b=>b.onclick=handle(()=>viewRender(jobs.find(j=>j.id===b.dataset.view))));
  $$('[data-apply-asr]').forEach(b=>b.onclick=handle(async()=>{
    return window.studioApplyASR(b.dataset.applyAsr); /* job details are loaded on demand */
  }));
  if(waitingPreview){const j=jobs.find(j=>j.id===waitingPreview);if(j&&j.state==='complete'){waitingPreview=null;if(p?.id===j.project_id)await viewRender(j)}else if(j&&['failed','cancelled','interrupted'].includes(j.state)){waitingPreview=null;toast(j.message,true)}}
}
async function viewRender(j){if(p?.id!==j.project_id)await openProject(j.project_id);await save();await refreshQA();previewJob=j;$('#video').src=url(`/render/${j.id}/${j.result.file}`);peaks=j.result.waveform;const stale=j.result.captions_burned?j.result.project_hash!==qa.hash:j.result.sound_digest!==qa.sound_hash;$('#preview-label').textContent=stale?'旧版输出 · 当前工程已修改':j.result.captions_burned?'已烧录字幕 · 导出结果':'真实混音 · 字幕即时预览';$('#caption-overlay').style.display=j.result.captions_burned?'none':'block';$('#preview-note').textContent=(stale?'注意：这不是当前工程版本，请重新生成。':'')+(j.result.captions_burned?'正在播放已烧录的导出结果。修改字幕后重新导出才会更新此视频。':'字幕为即时样式预览；最终以烧录导出为准。声音改变后请重新生成混音预览。');drawWave()}
$('#batch-button').onclick=()=>{modal('<h2>批量导入分集</h2><p>选择一个包含01、02…等分集子文件夹的目录，每个文件夹建立独立工程。这里只导入，不自动删对白或直接交付。</p><input id="batch-path" placeholder="F:\\剧名"><div class="modal-actions"><button id="batch-ok" class="primary">建立批次工程</button></div>');$('#batch-ok').onclick=handle(async()=>{const b=$('#batch-ok');b.disabled=true;b.textContent='批量读取中…';try{await save();const results=await api('/api/batch',{path:$('#batch-path').value});$('#modal').close();await refreshBoot();toast(`已处理 ${results.length} 个分集目录`);if(results[0])await openProject(results[0].id)}finally{b.disabled=false}})};
$('#settings-button').onclick=()=>{modal(`<h2>本地设置</h2><p>数据目录：${esc(boot.data_dir||'')}</p><div class="alert ${boot.ffmpeg?'success':''}">${boot.ffmpeg?'FFmpeg已就绪':'尚未找到FFmpeg，请将ffmpeg.exe与ffprobe.exe放入bin目录'}</div><label>本地语音模型目录</label><input id="model-path" value="${esc(boot.settings?.model_path)}" placeholder="…\\models\\faster-whisper-small"><p>目录中需含model.bin。应用不会擅自下载或上传音频。首次安装可运行“准备语音模型.cmd”。识别结果仍须校对。</p><label>当前分集字幕/识别语言</label><select id="language">${[['pt','葡萄牙语'],['es','西班牙语'],['en','英语'],['zh','中文'],['','自动识别（不自动翻译）']].map(([v,t])=>`<option value="${v}" ${p?.language===v?'selected':''}>${t}</option>`).join('')}</select><div class="modal-actions"><button id="settings-ok" class="primary">保存设置</button></div>`);$('#settings-ok').onclick=handle(async()=>{if($('#model-path').value.trim())await api('/api/settings',{model_path:$('#model-path').value.trim()});if(p){p.language=$('#language').value;mark()}await refreshBoot();$('#modal').close();toast('设置已保存')})};
function download(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
$('#history-button').onclick=handle(async()=>{
  if(!p)throw Error('请先打开工程');await save();
  const rows=await api(`/api/projects/${p.id}/history`);
  modal(`<h2>恢复历史版本</h2><p>恢复会保存当前版的备份，原素材不改动。恢复后必须重新验收。</p><select id="history-revision">${rows.map(r=>`<option value="${r.revision}">修订 ${r.revision} · ${esc(r.name)} · ${r.clips}镜头 / ${r.captions}字幕</option>`).join('')}</select><div class="modal-actions"><button id="history-restore" class="primary" ${rows.length?'':'disabled'}>恢复所选版本</button></div>`);
  $('#history-restore').onclick=handle(async()=>{const result=await api(`/api/projects/${p.id}/restore`,{revision:p.revision,history_revision:Number($('#history-revision').value)});$('#modal').close();await refreshBoot();await openProject(result.id);toast('历史版本已恢复，刚才的版本也已保留')});
});
$('#batch-queue-button').onclick=handle(async()=>{
  await save();await refreshBoot();
  modal(`<h2>批量导出</h2><p>选择分集后在本机依次导出，不需要人工审批。</p><div style="max-height:270px;overflow:auto">${boot.projects.map(r=>`<label class="review-line"><input type="checkbox" data-batch-id="${r.id}" ${r.clips?'checked':''}>${esc(r.name)}</label>`).join('')}</div><select id="batch-kind"><option value="final">导出 MP4</option><option value="preview">生成声音预览</option><option value="transcribe">生成字幕草稿</option></select>${exportQualityControl('batch-enhance-hd')}<div class="modal-actions"><button id="batch-submit" class="primary">开始</button></div>`);
  const button=$('#batch-submit'),selector=$('#batch-kind'),enhance=$('#batch-enhance-hd'),batchRequestId=id();let submitting=false,submitted=false;
  selector.value='final';enhance.checked=false;enhance.disabled=false;button.disabled=false;
  selector.onchange=()=>{enhance.disabled=submitting||!canEnhanceExport(selector.value);if(!canEnhanceExport(selector.value))enhance.checked=false};
  button.onclick=handle(async()=>{
    if(submitting||submitted)return;
    const ids=$$('[data-batch-id]:checked').map(b=>b.dataset.batchId),kind=selector.value,options=exportQualityOptions(kind,{enhance_hd:enhance.checked}),errors=[];
    if(!ids.length)throw Error('请选择至少一集');submitting=true;button.disabled=selector.disabled=enhance.disabled=true;let count=0;
    try{
      const projects=[];for(const pid of ids){try{const project=await api('/api/projects/'+pid);projects.push({id:pid,revision:project.revision})}catch(e){errors.push((boot.projects.find(r=>r.id===pid)?.name||pid)+'：'+e.message)}}
      if(projects.length){const batch=await api('/api/exports/batch',{request_id:batchRequestId,projects,kind,options});for(const item of batch.results){if(item.error)errors.push((boot.projects.find(r=>r.id===item.project_id)?.name||item.project_id)+'：'+item.error);else count++}}
      submitted=true;try{await pollJobs()}catch(e){errors.push('列表刷新失败；请刷新查看，勿重复提交：'+e.message)}
      if($('#batch-submit')===button)$('#modal').close();toast(`已加入${count}集${errors.length?'；'+errors.join('；'):''}`,!!errors.length);
    }finally{submitting=false;if(!submitted){button.disabled=selector.disabled=false;selector.onchange()}}
  });
});
window.studioPrepareClose=async()=>{try{await save();const event=new Event('beforeunload',{cancelable:true});return window.dispatchEvent(event)&&dirty<=saved}catch(error){toast(error.message,true);return false}};
window.addEventListener('beforeunload',e=>{if(dirty>saved){e.preventDefault();e.returnValue='尚有未保存修改'}});
installStudioHardening();
installProjectManagement();
installScriptImport();
installTxtCaptions();
installFolderDrop();
installFontPreset();
installStudioTimeline();
installStudioMasking();
installStudioLibrary();
installStudioWorkflow();
installStudioLiveEditor();
installStudioEditActions();
installStudioRealtime();
installNativeDrafts();
installMediaRelink();
(async()=>{try{await refreshBoot();await window.studioLibrary.start();if(new URLSearchParams(location.search).get('native')==='1')await window.studioNativeDrafts.show();await pollJobs();setInterval(()=>pollJobs().catch(()=>{}),1800)}catch(e){toast(e.message,true);$('#panel').innerHTML=empty('无法连接本机服务',esc(e.message));}})();

;
// Source: layout.js
'use strict';
// Layout preferences are per device. They never change the episode or its review hash.
(() => {
  const key = 'studio-layout-v2';
  const defaults = {sidebar:148, edit:300, inspector:285, timeline:300};
  let prefs;
  try {
    const saved=JSON.parse(localStorage.getItem(key)||'null');
    const legacy=JSON.parse(localStorage.getItem('studio-layout-v1')||'null');
    prefs=saved?{...defaults,...saved}:{...defaults,...legacy,sidebar:defaults.sidebar};
  }
  catch (_) { prefs = {...defaults}; }
  for (const k of Object.keys(defaults)) if (!Number.isFinite(prefs[k])) prefs[k]=defaults[k];
  const app=document.querySelector('.app-layout'), workspace=document.querySelector('.workspace');
  const main=document.querySelector('main'), timeline=document.querySelector('#timeline');
  document.body.classList.add('resizable-layout');
  let drag=null;
  const clamp=(n,min,max)=>Math.min(Math.max(n,min),Math.max(min,max));
  const actual=name=>document.querySelector({sidebar:'.sidebar',edit:'.edit-panel',inspector:'.inspector',timeline:'#timeline'}[name]).getBoundingClientRect()[name==='timeline'?'height':'width'];
  function apply(){
    const width=app.clientWidth, height=main.clientHeight;
    const side=clamp(prefs.sidebar,124,Math.min(260,width*.22));
    const available=width-side-6;
    const edit=clamp(prefs.edit,190,Math.max(190,available-455));
    const inspector=clamp(prefs.inspector,220,Math.max(220,available-edit-235));
    app.style.setProperty('--sidebar-width',side+'px');
    workspace.style.setProperty('--edit-width',edit+'px');
    workspace.style.setProperty('--inspector-width',inspector+'px');
    const fixed=[...main.children].filter(n=>!n.matches('.workspace,#timeline,.layout-divider')).reduce((s,n)=>s+n.getBoundingClientRect().height,0);
    main.style.setProperty('--timeline-height',clamp(prefs.timeline,125,height-fixed-285)+'px');
  }
  function store(){try{localStorage.setItem(key,JSON.stringify(prefs))}catch(_){}}
  function separator(name,label,orientation,parent,before){
    const el=document.createElement('div');el.className='layout-divider divider-'+name;
    el.tabIndex=0;el.role='separator';el.title=label+'：拖动调整，双击恢复；方向键微调';
    el.setAttribute('aria-label',label);el.setAttribute('aria-orientation',orientation);
    el.dataset.panel=name;parent.insertBefore(el,before);
    el.addEventListener('pointerdown',event=>{
      if(event.button!==0||matchMedia('(max-width: 1000px)').matches)return;
      drag={name,startX:event.clientX,startY:event.clientY,initial:actual(name),before:{...prefs},pointer:event.pointerId,el};
      el.focus({preventScroll:true});
      el.setPointerCapture(event.pointerId);document.body.classList.add('resizing-panels');
      document.body.style.cursor=orientation==='vertical'?'col-resize':'row-resize';event.preventDefault();
    });
    el.addEventListener('pointermove',event=>{
      if(!drag||drag.el!==el||event.pointerId!==drag.pointer)return;
      const delta=orientation==='vertical'?event.clientX-drag.startX:event.clientY-drag.startY;
      prefs[name]=drag.initial+delta*(['inspector','timeline'].includes(name)?-1:1);apply();
    });
    function end(cancel=false){
      if(!drag||drag.el!==el)return;
      const current=drag;drag=null;
      if(cancel)prefs=current.before;
      if(el.hasPointerCapture(current.pointer))el.releasePointerCapture(current.pointer);
      document.body.classList.remove('resizing-panels');document.body.style.cursor='';
      apply();store();window.dispatchEvent(new Event('resize'));
    }
    el.addEventListener('pointerup',()=>end());el.addEventListener('pointercancel',()=>end(true));
    el.addEventListener('keydown',event=>{
      if(event.key==='Escape'){end(true);return;}
      const arrows=orientation==='vertical'?['ArrowLeft','ArrowRight']:['ArrowUp','ArrowDown'];
      if(!arrows.includes(event.key))return;
      event.preventDefault();prefs[name]=actual(name)+(event.key===arrows[0]?-16:16)*(['inspector','timeline'].includes(name)?-1:1);apply();store();
    });
    el.addEventListener('dblclick',()=>{prefs[name]=defaults[name];apply();store()});
  }
  separator('sidebar','剧集列表宽度','vertical',app,main);
  separator('edit','编辑区与预览区宽度','vertical',workspace,document.querySelector('.viewer-panel'));
  separator('inspector','属性区宽度','vertical',workspace,document.querySelector('.inspector'));
  separator('timeline','预览与时间线高度','horizontal',main,timeline);
  const reset=document.createElement('button');reset.id='layout-reset';reset.textContent='重置布局';reset.title='恢复各区块的默认大小';
  document.querySelector('.top-actions').insertBefore(reset,document.querySelector('#settings-button'));
  reset.onclick=()=>{prefs={...defaults};apply();store()};
  const tag=document.querySelector('.local');if(tag){
    tag.textContent='本机存储';tag.title='查看工程和导出的实际保存位置';tag.tabIndex=0;tag.role='button';
    function showStorage(){
      modal(`<h2>这台电脑的存储</h2><p>工程、历史、素材库、字体与导出保存在本机，没有云端工程或跨电脑同步。</p><label>工程数据目录</label><pre class="storage-path">${esc(boot.data_dir||'正在读取…')}</pre><p>projects：工程与历史版本；imports：拖入后复制的素材；renders：导出视频与质检报告。</p><p>“路径导入”引用原文件，不复制。浏览器或桌面窗口里的草稿只是临时备份，不能代替保存工程。</p><p>桌面窗口与浏览器共用已保存工程，但各自的未保存草稿独立。换入口前请先保存。</p><div class="modal-actions"><button id="storage-copy">复制数据目录</button>${window.chrome?.webview?'<button id="storage-browser">打开浏览器入口</button><button id="storage-open" class="primary">打开工程文件夹</button>':''}</div>`);
      document.querySelector('#storage-copy').onclick=handle(async()=>{await navigator.clipboard.writeText(boot.data_dir);toast('已复制本机数据目录')});
      const browser=document.querySelector('#storage-browser');if(browser)browser.onclick=handle(async()=>{await save();window.chrome.webview.postMessage({type:'open-browser'})});
      const open=document.querySelector('#storage-open');if(open)open.onclick=()=>window.chrome.webview.postMessage({type:'open-data'});
    }
    tag.onclick=showStorage;tag.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();showStorage()}};
  }
  new ResizeObserver(apply).observe(main);
  new ResizeObserver(entries=>{
    const rect=entries[0].contentRect, stage=document.querySelector('#stage');
    stage.style.width=Math.max(0,Math.min(rect.width,rect.height*9/16))+'px';
  }).observe(document.querySelector('.stage-wrap'));
  window.addEventListener('resize',apply);apply();
})();

;
// Source: simple-ui.js
'use strict';
// One editing surface. Keep the original action handlers when relocating controls.
(() => {
  document.body.classList.add('simple-shell');
  const actions=$('.top-actions');
  const more=document.createElement('details');more.id='more-actions';
  more.innerHTML='<summary aria-label="更多操作">更多 ⋯</summary><div class="more-menu" aria-label="更多操作"></div>';
  const menu=more.querySelector('.more-menu');
  actions.append(more);
  const move=(id,label,projectOnly=false)=>{
    const button=$('#'+id);if(!button)return;
    if(label)button.textContent=label;
    if(projectOnly)button.dataset.projectAction='true';
    menu.append(button);
  };
  const handoffButton=$('#handoff-button');handoffButton.textContent='写入剪映';
  handoffButton.title='把当前工程写入同一份剪映草稿';
  move('mode-export','查看最近导出',true);
  move('batch-queue-button','批量导出 / 处理',true);
  move('share-project-button','打包工程与素材',true);
  move('history-button','恢复历史版本',true);
  move('library-import-package','导入工程包');
  move('global-new-button','新建分集',true);
  move('global-manage-button','管理 / 回收站');
  move('settings-button','设置');
  move('layout-reset','重置布局',true);
  move('batch-handoff-button','批量写入剪映',true);
  $('#batch-queue-button').hidden=true;
  const storage=document.createElement('button');storage.id='storage-button';storage.textContent='存储位置';
  storage.onclick=()=>$('.local').click();menu.append(storage);
  for(const id of ['save-button','preview-button','native-drafts-button'])$('#'+id).hidden=true;
  $('#global-new-button').hidden=true;
  // The native data inspector remains available for diagnostics, without a second user entry.
  const home=$('#library-home-button');home.textContent='首页';
  const importButton=document.createElement('button');importButton.id='import-button';importButton.textContent='导入素材';
  importButton.onclick=()=>{
    if(!p)return toast('先新建或打开一集，再导入素材',true);
    window.studioMaterialImport?.open();
  };
  const saveButton=$('#save-button');
  const saveStatus=$('#save-status');saveStatus.setAttribute('role','status');saveStatus.setAttribute('aria-live','polite');
  const retry=document.createElement('button');retry.id='retry-save-button';retry.textContent='重试保存';retry.hidden=true;
  retry.onclick=handle(async()=>{await save();toast('修改已保存')});
  const undoButton=$('#undo-button'),redoButton=$('#redo-button');undoButton.hidden=redoButton.hidden=true;menu.append(undoButton,redoButton);
  const batchHandoffButton=$('#batch-handoff-button');
  actions.replaceChildren(home,importButton,saveStatus,retry,handoffButton,$('#export-button'),more);
  // Lock/conflict handlers still reference the hidden save button.
  menu.append(saveButton);
  $('#export-button').textContent='导出视频';
  $('.viewer-top>span').textContent='实时预览';
  $('#stage-placeholder h3').textContent='导入素材，开始剪辑';
  $('#stage-placeholder p').textContent='修改即时预览，工程自动保存';
  const oldRender=render;
  function sync(){
    const hasProject=!!p,locked=!hasProject||saveButton.disabled||$('main').inert;
    for(const node of [importButton,$('#undo-button'),$('#redo-button'),handoffButton,$('#export-button')])node.disabled=locked;
    batchHandoffButton.disabled=saveButton.disabled||$('main').inert;
    for(const node of menu.querySelectorAll('[data-project-action]'))node.disabled=locked;
    retry.hidden=!hasProject||dirty<=saved||!/尚未保存|冲突|核对后保存/.test(saveStatus.textContent);
    saveStatus.title=dirty>saved?'修改尚未保存；保存成功后会显示“已保存到本机”':'修改会自动保存到本机';
    handoffButton.textContent=p?.native?.shared?'打开剪映':'写入剪映';
    handoffButton.title=p?.native?.shared?'百慕修改已直接保存到共同草稿；打开剪映或提示如何安全重开':'保存当前工程并写入剪映草稿列表';
  }
  render=function(...args){const value=oldRender(...args);sync();return value};
  new MutationObserver(sync).observe(saveStatus,{childList:true,subtree:true,characterData:true});
  new MutationObserver(sync).observe(saveButton,{attributes:true,attributeFilter:['disabled']});
  new MutationObserver(sync).observe($('main'),{attributes:true,attributeFilter:['inert']});
  more.addEventListener('toggle',()=>{if(more.open)sync()});
  menu.addEventListener('click',event=>{if(event.target.closest('button'))more.open=false});
  document.addEventListener('pointerdown',event=>{if(more.open&&!more.contains(event.target))more.open=false});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&more.open){more.open=false;more.querySelector('summary').focus()}});
  sync();
})();

;
// Source: review-rules.js
'use strict';
// Rules and scope live outside p: never mark/save a timeline when editing these.
(() => {
  const link=document.createElement('link');link.rel='stylesheet';link.href='/review-rules.css';document.head.append(link);
  const home=document.createElement('button');home.id='review-rules-home';home.textContent='审核与返工规则';
  $('.library-actions').prepend(home);
  const reviewTab=document.createElement('button');reviewTab.dataset.tab='review';reviewTab.textContent='审核';$('#tabs').append(reviewTab);
  const repairTab=document.createElement('button');repairTab.dataset.tab='repair';repairTab.textContent='修改';$('#tabs').append(repairTab);
  const reviewing=()=>p&&['review','repair'].includes(tab);
  const dialog=document.createElement('dialog');dialog.id='review-skills-dialog';dialog.setAttribute('aria-label','审核与返工规则');document.body.append(dialog);
  let docs=null, draft=null, editorKind='review', editorDirty=false, editorBusy=false, editorOpening=false, context=null, sequence=0, loading=null, scopeOpen=false;
  const editorStatus=message=>{const el=dialog.querySelector('[data-editor-status]');if(el)el.textContent=message};
  function drawEditor(){
    dialog.innerHTML=`<div class="review-dialog-head"><div><h2>审核与返工规则</h2><p>所有分集共用；保存后，Codex 下次审核会读取最新内容。</p></div><button data-editor-close aria-label="关闭规则编辑器">关闭</button></div>
      <div class="review-doc-tabs"><button data-doc="review" class="${editorKind==='review'?'primary':''}">审核要求</button><button data-doc="repair" class="${editorKind==='repair'?'primary':''}">返工方法</button></div>
      <p class="helper">审核要求中的每个 ## 小标题会成为勾选项，正文写细则。新增项默认勾选；改名视为新项。保存不会修改成片。</p>
      <label for="review-markdown">${editorKind==='review'?'审核要求':'返工方法'} · Markdown 原文</label><textarea id="review-markdown" spellcheck="false"></textarea>
      <div class="review-dialog-foot"><span data-editor-status role="status">${editorDirty?'有修改，尚未保存':'已读取当前规则'}</span><button data-editor-reload>重新读取</button><button data-editor-save class="primary">保存两份规则</button></div>`;
    const input=dialog.querySelector('textarea');input.value=draft[editorKind];
    input.oninput=()=>{draft[editorKind]=input.value;editorDirty=true;editorStatus('有修改，尚未保存')};
    dialog.querySelectorAll('[data-doc]').forEach(button=>button.onclick=()=>{editorKind=button.dataset.doc;drawEditor()});
    dialog.querySelector('[data-editor-close]').onclick=closeEditor;
    dialog.querySelector('[data-editor-reload]').onclick=handle(async()=>{
      if(editorDirty&&!confirm('重新读取会丢弃当前未保存的规则文字。继续吗？'))return;
      await loadEditor();
    });
    dialog.querySelector('[data-editor-save]').onclick=async()=>{
      if(editorBusy)return;editorBusy=true;setEditorBusy(true);editorStatus('正在保存…');
      try{
        docs=await api('/api/review-skills',{revision:docs.revision,...draft});
        draft={review:docs.review,repair:docs.repair};editorDirty=false;context=null;
        editorStatus('已保存；新增和修改的内容将在下次审核时核对理解');
        if(reviewing())await loadContext(true);
      }catch(error){editorStatus(error.message+'。当前输入已保留，可先复制再重新读取。')}
      finally{editorBusy=false;setEditorBusy(false)}
    };
  }
  function setEditorBusy(value){dialog.querySelectorAll('button,textarea').forEach(el=>el.disabled=value)}
  async function loadEditor(){
    if(editorBusy)return;editorBusy=true;setEditorBusy(true);
    try{docs=await api('/api/review-skills');draft={review:docs.review,repair:docs.repair};editorDirty=false;drawEditor()}
    finally{editorBusy=false;setEditorBusy(false)}
  }
  async function openEditor(){
    if(editorOpening||dialog.open)return;editorOpening=true;
    try{await loadEditor();dialog.showModal()}finally{editorOpening=false}
  }
  function closeEditor(){
    if(editorBusy)return;
    if(editorDirty&&!confirm('规则文字尚未保存，关闭并放弃这些修改吗？'))return;
    editorDirty=false;dialog.close();
  }
  home.onclick=handle(openEditor);
  dialog.addEventListener('cancel',event=>{event.preventDefault();closeEditor()});
  window.addEventListener('beforeunload',event=>{if(editorDirty){event.preventDefault();event.returnValue='规则文字尚未保存'}});

  function ruleMarkup(item,common=false){
    const status=item.needs_clarification?'新增或修改 · 待确认理解':item.interpretation_current?'已确认理解':'内置初始规则';
    return `<div class="review-rule ${item.needs_clarification?'review-pending':''}">
      ${common?`<b>${esc(item.title)}</b>`:`<label class="review-choice"><input type="checkbox" data-rule="${esc(item.id)}" ${item.selected?'checked':''}><b>${esc(item.title)}</b></label>`}
      <small>${status}</small><details><summary>查看细则与理解说明</summary><pre>${esc(item.body||'尚未填写细则，请补充或与 Codex 确认。')}</pre>
      ${item.interpretation?`<p>${item.interpretation_current?'已确认的理解':'上次理解（原文已变化）'}：</p><blockquote>${esc(item.interpretation)}</blockquote>`:''}
      <label>已确认的理解（各集共用）<textarea data-note="${esc(item.id)}" rows="3" placeholder="可填入与 Codex 讨论后确认的解释">${esc(item.interpretation)}</textarea></label>
      <button data-confirm-rule="${esc(item.id)}">保存为我确认的理解</button></details></div>`;
  }
  function drawContext(){
    if(!reviewing())return;
    if(!context||context.project_id!==p.id){$('#panel').innerHTML='<p class="helper">正在读取本集审核要求…</p>';return}
    $('#panel').innerHTML=`<section class="review-panel"><div class="panel-head"><h3>${tab==='repair'?'修改清单':'审核结果'}</h3><button id="review-edit-rules">编辑规则</button></div>
      <div id="review-findings"><p class="helper">正在读取问题清单…</p></div>
      <details id="review-scope-details" ${tab==='repair'?'hidden':''} ${scopeOpen?'open':''}><summary>自定义审核项目 · 默认全项${context.selected_ids.length!==context.sections.length?' · 已自定义':''}${context.needs_clarification.length?' · 有新规待确认':''}</summary>
      <p class="helper">默认检查全部项目；仅需排除某类时在此调整。这是检查类别，不是修改清单。正在返修时调整范围会使原任务过期。</p>
      <div class="review-toolbar"><button id="review-all">全选</button><button id="review-none">全不选</button><button id="review-refresh">刷新规则</button></div>
      <p id="review-status" role="status">已选 ${context.selected_ids.length} 项 · ${context.needs_clarification.length} 处待确认理解</p>
      ${context.sections.map(s=>ruleMarkup(s)).join('')}
      <details class="review-common"><summary>通用说明与返工方法${context.common.some(s=>s.needs_clarification)?' · 有变更':''}</summary>${context.common.map(s=>ruleMarkup(s,true)).join('')}</details>
      <p class="helper">新增或修改的规则会在下次审核时交给 Codex 核对。确认解释只记录规则含义，不代表成片通过。</p>
      <button id="review-copy-request" class="wide">复制给 Codex 的审片请求</button></details></section>`;
    $('#review-edit-rules').onclick=handle(openEditor);
    $('#review-scope-details').ontoggle=event=>{scopeOpen=event.target.open};
    $('#review-refresh').onclick=handle(()=>loadContext(true));
    const scopedContext=context;
    async function choose(ids){
      const pid=scopedContext.project_id;
      $('#panel').querySelectorAll('button,input,textarea').forEach(el=>el.disabled=true);
      try{
        const next=await api(`/api/projects/${pid}/review-scope`,{rules_revision:scopedContext.rules_revision,scope_revision:scopedContext.scope_revision,selected_ids:ids});
        if(p?.id===pid&&reviewing()){context=next;drawContext()}
      }catch(error){if(p?.id===pid&&reviewing()){drawContext();$('#review-status').textContent=error.message+'；请刷新规则后重试。'}throw error}
    }
    $('#panel').querySelectorAll('[data-rule]').forEach(box=>box.onchange=handle(()=>choose([...$('#panel').querySelectorAll('[data-rule]:checked')].map(el=>el.dataset.rule))));
    $('#review-all').onclick=handle(()=>choose(scopedContext.sections.map(s=>s.id)));
    $('#review-none').onclick=handle(()=>choose([]));
    $('#panel').querySelectorAll('[data-confirm-rule]').forEach(button=>button.onclick=handle(async()=>{
      const pid=scopedContext.project_id,key=button.dataset.confirmRule;
      const note=button.closest('details').querySelector('textarea').value;
      button.disabled=true;
      try{
        const next=await api(`/api/projects/${pid}/review-confirmation`,{rules_revision:scopedContext.rules_revision,scope_revision:scopedContext.scope_revision,id:key,interpretation:note,confirmed_by_user:true});
        if(p?.id===pid&&reviewing()){context=next;drawContext()}
      }finally{button.disabled=false}
    }));
    $('#review-copy-request').onclick=handle(async()=>{
      const sessionOption=boot.settings?.review_rules_preview?`--session-file "${boot.data_dir}/session.json" `:'';
      const message=`请通过 baimu 技能审核百慕${sessionOption?'独立试用版的':''}工程「${p.name}」（ID：${p.id}）。先运行 baimu_client.py ${sessionOption}review-context ${p.id}，从百慕读取最新的两份内置 skill 和本集勾选范围，按 selected_review_markdown 检查实际成片。先与我核对 needs_clarification 中的新规并保存我确认的解释，其它明确项目可继续。此次先审片并报告，不修改工程。`;
      await navigator.clipboard.writeText(message);toast('已复制审片请求，粘贴给 Codex 即可');
    });
    window.studioReviewFindings?.show(scopedContext.project_id);
  }
  async function loadContext(force=false){
    if(!reviewing())return;
    const pid=p.id;
    if(!force&&context?.project_id===pid){drawContext();return}
    if(!force&&loading===pid)return;
    const ticket=++sequence;loading=pid;context=null;drawContext();
    try{
      const value=await api(`/api/projects/${pid}/review-context`);
      if(ticket===sequence&&p?.id===pid&&reviewing()){context=value;drawContext()}
    }catch(error){if(ticket===sequence&&p?.id===pid&&reviewing()){
      $('#panel').innerHTML=`<p class="alert">${esc(error.message)}</p><button id="review-retry">重试读取审核规则</button>`;
      $('#review-retry').onclick=handle(()=>loadContext(true));
    }}finally{if(ticket===sequence)loading=null}
  }
  const oldRender=render;
  let openReviewOnStart=new URLSearchParams(location.search).get('modify')==='1'?'repair':new URLSearchParams(location.search).get('review')==='1'?'review':'';
  render=function(...args){
    if(p&&openReviewOnStart){tab=openReviewOnStart;openReviewOnStart=''}
    oldRender(...args);
    if(reviewing()){
      $('#inspector').innerHTML=tab==='repair'?'<h3>修改意见</h3><p class="helper">选择问题，编辑并保存最终修改意见；按清单修改后，Codex 只读取本轮固定意见。取消勾选表示保留原内容。</p>':'<h3>审核说明</h3><p class="helper">✓ 无问题表示已明确检查通过；未检查不等于无问题。有问题的项目排在前面，具体位置与修改意见在「修改」栏。</p>';
      loadContext();
    }else{sequence++;loading=null;context=null}
  };
  window.addEventListener('focus',()=>{if(reviewing()&&!dialog.open&&!document.activeElement?.matches('#finding-plan,#finding-human-note'))loadContext(true)});
})();

;
// Source: review-findings.js
"use strict";
(() => {
  let state=null,loading=0,busy=false,selectedFinding=null;
  const drafts=new Map();
  const names={pending:'待修改',kept:'人工保留',working:'修改中',awaiting_verification:'待复审',resolved:'已解决',unresolved:'未解决',interrupted:'已中断，需复核'};
  const checkNames={pass:'✓ 无问题',issues:'● 有问题',needs_review:'? 待复核',not_checked:'— 未检查',not_selected:'未纳入本次',pending:'检查中',outdated:'需重新审核'};
  const clock=t=>`${Math.floor(t/60).toString().padStart(2,'0')}:${(t%60).toFixed(2).padStart(5,'0')}`;
  const current=pid=>p?.id===pid&&['review','repair'].includes(tab)&&!!$('#review-findings');
  const draftKey=f=>`${p.id}:${state.report.id}:${f.id}`;
  const hasDrafts=()=>state?.report&&(state.report.findings||[]).some(f=>drafts.has(draftKey(f)));
  const switchTab=value=>{tab=value;render()};
  function taskText(kind){
    const session=boot.settings?.review_rules_preview?`--session-file "${boot.data_dir}/session.json" `:'';
    const instruction=kind==='repair'?`执行百慕固定的返工清单 ${state.active_batch?.id||''}。以 active_batch.findings[].plan 中固定的最终修改意见为准，不重用早期 AI 建议；只修改本轮清单，保留人工取消项，逐项回写修改及实际新成片复审结果。`:
      `执行百慕初审请求 ${state.requests.filter(r=>r.status==='waiting').at(-1)?.id||''}。默认全项检查，尊重本集明确排除项；逐项提交 checks，status 使用 pass/issues/needs_review/not_checked 并提供 evidence。不能以无问题单代替已检查通过。具体问题通过 findings 提交，此次不修改工程。`;
    return `请使用 baimu 技能${instruction}\n工程：${p.name}（${p.id}）。\n先运行 baimu_client.py ${session}review-workflow ${p.id}，并读取 review-context ${p.id}。${session?'所有命令均使用上述独立试用会话。':''}`;
  }
  async function copyTask(kind){
    const value=taskText(kind);
    try{await navigator.clipboard.writeText(value);toast('任务已复制，粘贴给 Codex 执行')}
    catch(_){modal(`<h2>交给 Codex 执行</h2><textarea rows="9" readonly>${esc(value)}</textarea><p>复制以上内容到 Codex。任务已保存。</p>`)}
  }
  async function mutate(payload){
    if(busy)return;busy=true;
    const pid=p.id,revision=state.workflow_revision;
    $('#review-findings').querySelectorAll('button,input,textarea').forEach(el=>el.disabled=true);
    try{const result=await api(`/api/projects/${pid}/review-workflow`,{workflow_revision:revision,...payload});if(current(pid)){state=result;draw();return result}}
    catch(error){if(current(pid)){await show(pid,true);toast(error.message,true)}throw error}
    finally{busy=false;if(current(pid))draw()}
  }
  function inspect(finding,seek=true){
    selectedFinding=finding.id;
    if(seek&&!state.report.stale)seekPlayback(finding.start);
    const draft=drafts.get(draftKey(finding));
    $('#inspector').innerHTML=`<h3>${esc(finding.title)}</h3><p>${clock(finding.start)}–${clock(finding.end)} · ${esc(finding.category)}</p>
      <span class="finding-status">${names[finding.status]}</span>
      <label for="finding-plan">最终修改意见${finding.locked?'（本轮已固定）':'（可编辑）'}</label>
      <textarea id="finding-plan" rows="5" ${finding.locked||finding.status==='resolved'?'disabled':''}>${esc(draft??finding.plan)}</textarea>
      <p id="finding-plan-status" role="status">${draft!=null?'有未保存意见，请先保存再发起修改':finding.plan_source==='human'?'已保存你的最终意见':'当前为 AI 建议，可直接编辑'}</p>
      <button id="finding-save-plan" ${finding.locked||finding.status==='resolved'?'disabled':''}>保存修改意见</button>
      <label>保留理由（可不填）<textarea id="finding-human-note" rows="2" ${finding.locked?'disabled':''}>${esc(finding.human_note)}</textarea></label>
      <button id="finding-save-note" ${finding.locked?'disabled':''}>保存说明</button>
      <details class="finding-evidence"><summary>核对依据与确认程度</summary><h4>观测依据</h4><p class="finding-prose">${esc(finding.evidence)}</p><h4>确认程度</h4><p>${esc(finding.certainty)}</p></details>`;
    $('#finding-plan').oninput=()=>{drafts.set(draftKey(finding),$('#finding-plan').value);$('#finding-plan-status').textContent='有未保存意见，请先保存再发起修改';if($('#review-fix'))$('#review-fix').disabled=true};
    $('#finding-save-plan').onclick=handle(async()=>{
      const key=draftKey(finding),plan=$('#finding-plan').value;
      if(!plan.trim())throw Error('最终修改意见不能为空');
      const result=await mutate({action:'mark',report_id:state.report.id,finding_id:finding.id,selected:finding.selected,plan});
      if(result){drafts.delete(key);draw();toast('最终修改意见已保存')}
    });
    $('#finding-save-note').onclick=handle(()=>mutate({action:'mark',report_id:state.report.id,finding_id:finding.id,selected:finding.selected,human_note:$('#finding-human-note').value}));
  }
  function auditMarkup(){
    const report=state.report,active=state.active_batch,rows=state.review_results||[];
    const rank={issues:0,needs_review:1,outdated:2,pending:3,not_checked:4,pass:5,not_selected:6};
    const sorted=[...rows].sort((a,b)=>(rank[a.status]??4)-(rank[b.status]??4));
    const passed=rows.filter(r=>r.status==='pass').length,issues=rows.filter(r=>r.status==='issues').length;
    const remaining=['needs_review','not_checked','pending','outdated','not_selected'].map(status=>{
      const count=rows.filter(r=>r.status===status).length;
      return count?` · ${count} 项${({needs_review:'待复核',not_checked:'未检查',pending:'检查中',outdated:'需重审',not_selected:'未纳入'})[status]}`:'';
    }).join('');
    return `<div class="review-workflow-bar"><button id="review-start" ${active?'disabled':''}>${report?'重新初审':'开始初审'}</button><button id="review-go-repair">查看修改意见（${report?.findings.length||0}）</button><button id="findings-refresh">刷新</button></div>
      <p class="audit-summary">${rows.filter(r=>r.selected).length===rows.length?'全项已纳入':`已纳入 ${rows.filter(r=>r.selected).length}/${rows.length} 项`} · ${passed} 项无问题 · ${issues} 项有问题${remaining}</p>
      <p class="helper">无问题以明确检查结果为准；没返回结果的项目保持「未检查」。具体问题与可编辑的修改方法在「修改」栏。</p>
      ${state.requests.some(r=>r.status==='waiting')?'<div class="review-task-notice">初审任务已生成，等待 Codex 执行。<button id="review-copy-audit">复制初审任务</button></div>':''}
      ${active?.stale?'<p class="alert">旧返修任务的工程、规则或范围已变化，请到修改栏核对并取消旧任务后重新审核。</p>':''}
      <div class="audit-results">${sorted.map(r=>`<article class="audit-result audit-${esc(r.status)}" data-audit-rule="${esc(r.rule_id)}"><div class="audit-result-head"><b>${esc(r.title)}</b><span class="audit-status">${checkNames[r.status]||'未检查'}${r.finding_count?' · '+r.finding_count+' 处':''}</span></div><details><summary>查看细则与检查说明</summary>${r.evidence?`<p class="finding-prose">${esc(r.evidence)}</p>`:''}<pre>${esc(r.body)}</pre></details></article>`).join('')}</div>`;
  }
  function repairMarkup(){
    const report=state.report,active=state.active_batch,rows=report?.findings||[];
    const kept=rows.filter(f=>!f.selected).length,selected=rows.filter(f=>f.selected&&f.status!=='resolved').length;
    return `<div class="review-workflow-bar"><button id="review-go-audit">查看审核结果</button><button id="review-fix" class="primary" ${!report||report.stale||!selected||active||hasDrafts()?'disabled':''}>按清单修改（${selected}）</button><button id="findings-refresh">刷新</button></div>
      <p class="findings-summary" role="status">${report?`发现 ${rows.length} 处 · 待修改 ${selected} 处 · 人工保留 ${kept} 处`:'尚无初审问题单'}</p>
      <p class="helper">点击问题编辑最终修改意见；取消勾选表示保留。保存意见后发起任务，Codex 读取本轮固定的最终意见。</p>
      ${active?`<div class="review-task-notice">${active.stale?'本轮清单已过期，暂停执行':active.status==='queued'?'本轮清单与最终意见已固定，等待 Codex 修改':'本轮修改进行中'} · ${active.findings.length} 项<button id="review-copy-repair" ${active.stale?'disabled':''}>复制修改任务</button><button id="review-cancel-repair">取消本轮任务</button></div>`:''}
      ${report?.stale?'<p class="alert">原问题单对应的工程、规则或范围已变化。原审计记录保留；新任务须重新审核，本轮有效修改仍按固定批次复审。</p>':''}
      ${report?`<details class="review-coverage"><summary>检查覆盖说明</summary><p>${esc(report.coverage)}</p></details>`:''}
      <div class="finding-list">${rows.map(f=>`<article class="finding-row ${!f.selected?'finding-kept':''}" data-finding="${f.id}"><div class="finding-top"><input type="checkbox" data-mark-finding="${f.id}" aria-label="修改：${esc(f.title)}" ${f.selected?'checked':''} ${f.locked||f.status==='resolved'?'disabled':''}><button data-inspect-finding="${f.id}" class="finding-title">${esc(f.title)}</button></div><div class="finding-meta"><button data-inspect-finding="${f.id}" class="finding-time">${clock(f.start)}–${clock(f.end)}</button><span class="finding-status status-${f.status}">${names[f.status]}</span></div><p class="finding-plan">${f.selected?'最终意见：'+esc(f.plan):'保留原内容，不修改'}</p>${f.selected?`<button data-inspect-finding="${f.id}" class="edit-plan-button">${f.locked?'查看固定意见':'编辑修改意见'}</button>`:''}</article>`).join('')}${report&&!rows.length?'<p class="helper">没有具体修改项。各类别的检查情况请看审核栏。</p>':''}</div>
      ${state.batches.length?`<details class="review-batch-history"><summary>返工记录</summary>${state.batches.slice().reverse().map(b=>`<div class="review-batch"><b>${({queued:'等待执行',running:'执行中',complete:'本轮结束',cancelled:'已取消'})[b.status]} · ${b.findings.length} 项</b>${b.findings.map(f=>`<p>${esc(f.title)}：${names[b.outcomes[f.id].status]}<small>固定意见：${esc(f.plan)}</small><small>${esc(b.outcomes[f.id].note)}</small>${b.outcomes[f.id].verification?`<small>复审：${esc(b.outcomes[f.id].verification.note)}</small>`:''}</p>`).join('')}</div>`).join('')}</details>`:''}`;
  }
  function draw(){
    if(!state||!current(state.project_id))return;
    const root=$('#review-findings');root.innerHTML=tab==='review'?auditMarkup():repairMarkup();
    if($('#review-start'))$('#review-start').onclick=handle(async()=>{await save();const result=await mutate({action:'request_review',request_id:id()});if(result)await copyTask('audit')});
    if($('#review-fix'))$('#review-fix').onclick=handle(async()=>{if(hasDrafts())throw Error('请先保存修改意见');await save();const result=await mutate({action:'create_repair',report_id:state.report.id,request_id:id()});if(result)await copyTask('repair')});
    if($('#review-go-repair'))$('#review-go-repair').onclick=()=>switchTab('repair');
    if($('#review-go-audit'))$('#review-go-audit').onclick=()=>switchTab('review');
    $('#findings-refresh').onclick=handle(()=>show(p.id,true));
    if($('#review-copy-audit'))$('#review-copy-audit').onclick=handle(()=>copyTask('audit'));
    if($('#review-copy-repair'))$('#review-copy-repair').onclick=handle(()=>copyTask('repair'));
    if($('#review-cancel-repair'))$('#review-cancel-repair').onclick=handle(()=>mutate({action:'cancel_repair',batch_id:state.active_batch.id}));
    root.querySelectorAll('[data-mark-finding]').forEach(box=>box.onchange=handle(()=>mutate({action:'mark',report_id:state.report.id,finding_id:box.dataset.markFinding,selected:box.checked})));
    const rows=state.report?.findings||[];
    root.querySelectorAll('[data-inspect-finding]').forEach(button=>button.onclick=()=>inspect(rows.find(f=>f.id===button.dataset.inspectFinding)));
    if(tab==='repair'&&selectedFinding&&rows.some(f=>f.id===selectedFinding))inspect(rows.find(f=>f.id===selectedFinding),false);
  }
  async function show(pid,force=false){
    const ticket=++loading;if(!current(pid))return;
    if(state?.project_id!==pid)selectedFinding=null;
    if(!force&&state?.project_id===pid){draw();return}
    try{const result=await api(`/api/projects/${pid}/review-workflow`);if(ticket!==loading||!current(pid))return;const changed=result.workflow_revision!==state?.workflow_revision||result.report?.stale!==state?.report?.stale||result.active_batch?.stale!==state?.active_batch?.stale||!$('#findings-refresh');state=result;if(changed)draw()}
    catch(error){if(current(pid))$('#review-findings').innerHTML=`<p class="alert">${esc(error.message)}</p><button id="findings-retry">重试读取</button>`;if($('#findings-retry'))$('#findings-retry').onclick=handle(()=>show(pid,true))}
  }
  window.studioReviewFindings={show};
  setInterval(()=>{if(p&&['review','repair'].includes(tab)&&!busy&&!document.querySelector('dialog[open]')&&!document.activeElement?.matches('#finding-plan,#finding-human-note'))show(p.id,true)},4000);
})();

;
// Source: updates.js
/* Shared daily GitHub check; loading the editor never waits for the network. */
(()=>{
  let latestResult=null;
  const label=r=>r.status!=='ok'?(r.message||'暂时无法检查更新'):r.message?r.message:r.update_available?`当前 ${r.current_version} · 发现新版 ${r.latest.tag}`:`当前 ${r.current_version} · 已检查 GitHub，无需更新`;
  function paint(){
    const output=document.getElementById('update-result');
    if(!output||!latestResult)return;
    output.textContent=label(latestResult)+(latestResult.checked_at?`（检查时间：${new Date(latestResult.checked_at).toLocaleString()}）`:'');
  }
  async function check(force=false){
    try{
      latestResult=await api('/api/updates/check',{force,claim_notice:true});
      paint();
      if(latestResult.notify)toast(`百慕有新版 ${latestResult.latest.tag}，可在设置中查看更新`);
    }catch(_){
      latestResult={status:'unavailable',message:'更新检查暂不可用，不影响使用'};paint();
    }
  }
  const settings=document.getElementById('settings-button');
  const previous=settings.onclick;
  settings.onclick=function(...args){
    previous?.apply(this,args);
    const section=document.createElement('section');
    section.innerHTML='<h3>关于与更新</h3><p id="update-result">正在检查 GitHub 最新正式发布…</p><p>每天首次使用检查一次，其他对话与窗口共用当天结果。</p><div class="modal-actions"><a href="https://github.com/kuro19711/baimu/releases/latest" target="_blank" rel="noopener noreferrer">查看发布说明与下载</a><button id="update-check-now" type="button">立即检查</button></div>';
    document.getElementById('modal-body').append(section);paint();
    document.getElementById('update-check-now').onclick=async function(){this.disabled=true;try{await check(true)}finally{this.disabled=false}};
  };
  check();
})();
