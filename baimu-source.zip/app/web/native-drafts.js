'use strict';
function installNativeDrafts(){
  let overview=null,detail=null,active=false,pending=false,generation=0,loading=false,previousTitle='',nativePackageBusy=false;
  const button=document.createElement('button');button.id='native-drafts-button';button.textContent='剪映工程';
  document.querySelector('.top-actions').prepend(button);
  const panel=document.createElement('section');panel.id='native-drafts';
  panel.setAttribute('role','main');
  panel.innerHTML=`<div class="native-heading"><div><p class="eyebrow">JIANYING / NATIVE DRAFTS</p><h1>剪映工程</h1><p>保留原生草稿。返回百慕时重新读取，写回前检查版本。</p></div><div class="toolbar"><button id="native-back">返回百慕工程</button><button id="native-launch" class="primary">启动剪映 ↗</button><button id="native-refresh">重新扫描</button></div></div><div id="native-status" role="status"></div><div class="native-columns"><aside class="native-sidebar"><input id="native-search" type="search" placeholder="搜索剪映草稿"><div id="native-list"></div></aside><div id="native-detail"><p>选择一份草稿读取。</p></div></div>`;
  document.querySelector('.app-layout').before(panel);
  const el=s=>panel.querySelector(s);
  const importNativeButton=document.createElement('button');importNativeButton.id='native-import-top';importNativeButton.textContent='导入共同工程包';importNativeButton.onclick=()=>showNativeImport();panel.querySelector('.native-heading .toolbar').append(importNativeButton);
  function status(text,error=false){el('#native-status').textContent=text;el('#native-status').classList.toggle('native-error',error)}
  function drawList(){
    const q=el('#native-search').value.trim().toLocaleLowerCase();
    const rows=(overview?.drafts||[]).filter(x=>x.name.toLocaleLowerCase().includes(q));
    el('#native-list').innerHTML=rows.map(row=>`<button class="native-row ${detail?.key===row.key?'selected':''}" data-native-key="${row.key}"><b>${esc(row.name)}</b><small>${row.exists?'可定位':'目录已丢失'} · ${esc(row.path)}</small></button>`).join('')||'<p>没有匹配的剪映草稿。</p>';
    panel.querySelectorAll('[data-native-key]').forEach(b=>b.onclick=handle(()=>load(b.dataset.nativeKey)));
  }
  async function scan(){overview=await api('/api/native/overview');drawList();return overview}
  async function show(key){
    await window.studioProjectHooks.transaction(async()=>{});
    if(!active)previousTitle=document.title;
    active=true;document.title='剪映工程 · 九州百慕';document.body.classList.add('native-mode');status('正在扫描本机剪映草稿…');
    await scan();
    const binding=p&&overview.bindings?.[p.id];
    status(`发现 ${overview.drafts.length} 份草稿。${overview.editor_running?'剪映正在运行，可并行编辑；同一工程的后续保存可能覆盖另一边的修改。':'可进行受支持的文字保存。'}`);
    if(key||binding?.key)await load(key||binding.key);
    else drawMigration();
  }
  async function load(key,quiet=false){
    if(pending){status('有尚未保存的原生文字，已保留输入。请保存，或点击“放弃文字并重读”。',true);return}
    const mine=++generation;loading=true;
    if(!quiet)status('正在读取当前原生草稿…');
    try{
      const next=await api('/api/native/drafts/'+key);
      if(mine!==generation||!active)return;
      detail=next;drawDetail();drawList();
      status(`已读取“${next.name}”。${next.editor_running?'剪映同时运行，编辑和保存可用。':'可保存支持的原生文字。'} 智能识别字幕和复杂效果完整保留，暂不修改。`);
    }catch(error){
      if(mine===generation){status(error.message,true);if(!quiet){el('#native-detail').innerHTML=`<h2>当前草稿未载入</h2><p>${esc(error.message)}</p><p>未使用备份或其他主文件代替当前版本，也没有写入原草稿。</p><button id="native-recover">恢复最近一次未完成交接</button>`;el('#native-recover').onclick=handle(async()=>{const r=await api('/api/native/recover',{key});status('已恢复提交前版本');pending=false;await load(key)})}}
    }finally{if(mine===generation)loading=false}
  }
  function drawDetail(){
    const d=detail,missing=d.media.filter(m=>!m.exists);
    const binding=p&&overview.bindings?.[p.id];
    el('#native-detail').innerHTML=`<div class="native-detail-heading"><div><h2>${esc(d.name)}</h2><p>${esc(d.width)} × ${esc(d.height)} · ${time(d.duration_us/1e6)} · ${d.tracks.length} 条轨道 · ${d.timeline_count} 条活动时间线</p></div><button id="native-read">重新读取当前版本</button></div><div class="native-path">${esc(d.path)}</div><p class="native-small">项目 ${esc(d.draft_id)}<br>主时间线 ${esc(d.main_timeline_id)}<br>版本 ${esc(d.revision.slice(0,16))}</p><div class="toolbar native-tools"><button id="native-reveal">定位文件夹</button><button id="native-snapshot">备份当前控制文件</button><button id="native-verify">检查字段完整性</button>${p?`<button id="native-bind" class="accent">${binding?.key===d.key?'已关联本集 · 更新版本记录':'关联当前分集：'+esc(p.name)}</button>`:''}</div><p>${d.editor_running?'剪映同时运行：可继续操作。剪映已打开的工程不会自动刷新，旧窗口后续保存可能覆盖百慕的修改；建议错开同一工程的保存。':'写回会备份当前版本，并检查草稿是否在别处改变。保存后请在剪映重开验收。'}</p>${missing.length?`<div class="native-warning">${missing.length} 个外部素材引用未找到。${missing.slice(0,4).map(x=>'<p>'+esc(x.path)+'</p>').join('')}</div>`:''}<details><summary>轨道与片段</summary><ul>${d.tracks.map(t=>`<li>${esc(t.name||t.type)} · ${esc(t.type)} · ${t.segments} 段</li>`).join('')}</ul></details><div class="native-subhead"><h3>原生字幕</h3><button id="native-discard">放弃文字并重读</button></div><p>当前支持单一样式、无关联的文字修改；其他字幕只读保留。画面、原声、转场、关键帧等不会经过百慕简化模型重建。</p><div class="native-texts">${d.texts.map((t,i)=>`<article class="native-text-row"><div><b>${i+1}</b><span>${esc(t.reason)}</span></div><textarea data-text-id="${t.id}" ${t.editable?'':'readonly'} rows="2">${esc(t.text)}</textarea>${t.editable?`<button data-save-text="${t.id}">保存这一条</button>`:''}</article>`).join('')||'<p>主时间线没有文字素材。</p>'}</div><div id="native-migrate-slot"></div>`;
    el('#native-read').onclick=handle(()=>load(d.key));
    el('#native-discard').onclick=handle(()=>{pending=false;return load(d.key)});
    el('#native-reveal').onclick=handle(()=>api('/api/native/reveal',{key:d.key}));
    el('#native-snapshot').onclick=handle(async()=>{const r=await api('/api/native/snapshot',{key:d.key});status('已备份控制文件：'+r.path+'；外部媒体未包含在此快照内。')});
    el('#native-verify').onclick=handle(async()=>{status('正在检查全部活动时间线的编解码完整性…');const r=await api('/api/native/verify',{key:d.key});status(`检查通过：${r.files.length} 个原生时间线文件的字段完整，原文件未改动；视觉重开需另行验收。`)});
    if(el('#native-bind'))el('#native-bind').onclick=handle(async()=>{await api('/api/native/bind',{project_id:p.id,key:d.key,revision:d.revision});await scan();status('已关联当前分集。旧百慕工程保留，不会用旧时间线覆盖剪映草稿。');drawDetail()});
    panel.querySelectorAll('[data-text-id]').forEach(box=>box.oninput=()=>{pending=true;status('文字尚未保存。当前每次保存一条，其他待改文字会保留在本页。')});
    panel.querySelectorAll('[data-save-text]').forEach(b=>b.onclick=handle(async()=>{
      const row=d.texts.find(t=>t.id===b.dataset.saveText),box=el(`[data-text-id="${row.id}"]`),value=box.value;
      // One explicit edit per commit. Prevent another dirty field from being
      // discarded when the current draft is reloaded after this save.
      const other=d.texts.filter(t=>t.id!==row.id&&el(`[data-text-id="${t.id}"]`)?.value!==t.text);
      if(other.length)throw Error('请每次只修改并保存一条文字，避免重读时丢失其他待保存输入。');
      b.disabled=true;status('正在备份并保存这一条原生文字…');
      try{const r=await api('/api/native/patch',{key:d.key,revision:d.revision,operation:{type:'simple_text',material_id:row.id,old:row.text,new:value}});pending=false;detail=r.detail;drawDetail();status(r.message+'。备份：'+r.backup)}
      catch(error){b.disabled=false;throw error}
    }));
    drawNativeWorkspace(d);
    drawMigration(el('#native-migrate-slot'));
  }
  function drawNativeWorkspace(d){
    const section=document.createElement('section');section.className='native-workspace';
    const duration=Math.max(1,d.duration_us);
    section.innerHTML=`<h3>共同工程 · 原生轨道</h3><p>此处直接修改当前剪映草稿，保存后在剪映重开即可继续。未修改的图层、效果和未知字段保留。当前是轨道数据视图，尚无剪映合成画面预览。</p><div class="toolbar"><button id="native-package">一键打包共同工程</button><button id="native-import-package">导入共同工程包</button></div><div id="native-package-result"></div>${d.tracks.map(t=>`<section class="native-track"><b>${esc(t.name||t.type)}</b><div class="native-track-lane">${(t.items||[]).map(s=>`<span class="native-clip-bar" style="left:${Math.max(0,s.start_us/duration*100)}%;width:${Math.max(.3,s.duration_us/duration*100)}%" title="${esc(s.name||s.id)}"></span>`).join('')}</div>${(t.items||[]).map(s=>`<div class="native-segment-row"><span>${esc((s.name||s.id).slice(0,70))}</span><small>${(s.start_us/1e6).toFixed(3)}s · ${(s.duration_us/1e6).toFixed(3)}s${s.group_id?' · 分组联动':''}${s.font_size!=null?' · 字号 '+esc(s.font_size):''}</small><button data-native-move="${esc(s.id)}">移动</button>${t.type==='audio'?`<button data-native-volume="${esc(s.id)}">音量</button>`:''}${s.font_size!=null?`<button data-native-font="${esc(s.id)}">字号</button>`:''}</div>`).join('')}</section>`).join('')}`;
    el('.native-path').before(section);
    section.querySelector('#native-package').onclick=handle(()=>packageNative(d,false));
    section.querySelector('#native-import-package').onclick=()=>showNativeImport();
    for(const [attribute,type,label] of [['data-native-move','move','开始时间（秒，分组片段一起移动）'],['data-native-volume','volume','线性音量（0静音，1原音量，最大4）'],['data-native-font','font_size','剪映原生字号']]){
      section.querySelectorAll('['+attribute+']').forEach(button=>button.onclick=handle(async()=>{
        if(pending)throw Error('请先保存或放弃尚未保存的文字');
        const segment=d.tracks.flatMap(t=>t.items||[]).find(s=>s.id===button.getAttribute(attribute));
        const value=type==='move'?segment.start_us/1e6:type==='volume'?segment.volume:segment.font_size;
        modal(`<h2>${esc(label)}</h2><input id="native-parameter" type="number" step="any" min="0" value="${value}"><p>保存修改的是这份原生工程；将备份当前版本。</p><button id="native-parameter-save" class="primary">保存到共同工程</button>`);
        $('#native-parameter-save').onclick=handle(async()=>{
          const input=$('#native-parameter');if(input.value==='')throw Error('请输入数值');
          const v=Number(input.value);if(!Number.isFinite(v))throw Error('请输入有效数值');
          const operation={type,...(type==='font_size'?{material_id:segment.material_id}:{segment_id:segment.id}),...(type==='move'?{start_us:Math.round(v*1e6)}:{value:v})};
          $('#native-parameter-save').disabled=true;
          try{const result=await api('/api/native/patch',{key:d.key,revision:d.revision,operation});$('#modal').close();await load(d.key);status(result.message)}
          catch(error){$('#native-parameter-save').disabled=false;throw error}
        });
      }));
    }
  }
  async function packageNative(d,allowOffline){
    if(pending)throw Error('请先保存或放弃尚未保存的文字');
    if(nativePackageBusy)throw Error('工程正在打包，请等待完成');nativePackageBusy=true;
    const button=el('#native-package');if(button)button.disabled=true;status('正在打包原生时间线、素材和字体…');
    try{
      const result=await api('/api/native/package',{key:d.key,revision:d.revision,allow_offline:allowOffline});
      el('#native-package-result').innerHTML=`<p>已打包 ${(result.size/1024/1024).toFixed(1)} MB · ${result.media_files} 个素材/字体 · ${result.offline} 个离线引用</p><a href="${url('/api/native/packages/'+result.id)}" download>保存共同工程ZIP</a><p>${esc(result.note)}</p>`;status('工程包已生成，可将保存的ZIP交给接收方。');
    }catch(error){
      if(!allowOffline&&String(error.message).includes('缺失素材')){
        modal('<h2>工程含缺失素材</h2><p>可以把缺失文件保留为离线片段；接收方能看到位置和参数，但无法播放丢失的内容。</p><button id="native-package-offline">保留离线引用并打包</button>');
        $('#native-package-offline').onclick=handle(async()=>{$('#modal').close();await packageNative(d,true)});
      }else throw error;
    }finally{nativePackageBusy=false;if(button)button.disabled=false}
  }
  function showNativeImport(){
    modal('<h2>导入共同工程包</h2><p>填写收到的工程ZIP路径，可保持剪映打开。将校验素材并创建独立副本。</p><input id="native-package-path" style="width:100%" placeholder="D:\\收到的共同工程.zip"><button id="native-package-import">导入并打开</button>');
    $('#native-package-import').onclick=handle(async()=>{
      const button=$('#native-package-import');button.disabled=true;
      try{const result=await api('/api/native/import-package',{path:$('#native-package-path').value});$('#modal').close();await scan();await load(result.key);status(result.message)}
      catch(error){button.disabled=false;throw error}
    });
  }
  function drawMigration(slot){
    const target=slot||el('#native-detail');
    const html=`<section class="native-migration"><h3>把百慕已有工程交给剪映</h3><p>先检查当前工程与素材。两种迁移方式都新建草稿，旧百慕工程保留。</p><div class="native-project-picker"><select id="native-project">${(boot.projects||[]).map(row=>`<option value="${row.id}" ${row.id===p?.id?'selected':''}>${esc(row.series||'未分组')} / ${esc(row.name)}</option>`).join('')}</select><button id="native-check-migration">检查迁移条件</button></div><div id="native-migration-result"></div></section>`;
    if(slot)target.innerHTML=html;else target.innerHTML='<h2>剪映原生草稿与百慕工程</h2><p>左侧可直接读取已有剪映草稿。也可将百慕现有工程迁移为新草稿。</p>'+html;
    el('#native-check-migration').onclick=handle(async()=>{
      const pid=el('#native-project').value;if(!pid)throw Error('请先选择百慕工程');
      const b=el('#native-check-migration');b.disabled=true;status('正在核对素材和已完成成片…');
      try{const r=await api('/api/native/migration/'+pid);drawMigrationReport(r);status('迁移检查完成；没有修改原工程。')}
      finally{b.disabled=false}
    });
  }
  function drawMigrationReport(r){
    el('#native-migration-result').innerHTML=`<p><b>${esc(r.series)} / ${esc(r.name)}</b> · ${time(r.duration)} · ${r.clips} 个镜头 · ${r.captions} 条字幕</p><div class="native-migration-options"><article><h4>保留成片 · 单轨</h4><p>${esc(r.film_notice)}</p><p>${r.film_available?'已找到与当前工程编辑内容一致的成片。':'没有匹配当前版本的成片，请先在百慕导出审阅版。'}</p><button id="native-export-film" ${r.film_available?'':'disabled'}>复制原样成片到新剪映草稿</button></article><article><h4>可编辑轨道 · 需要复核</h4>${r.editable_blocked.map(x=>'<p class="native-error">'+esc(x)+'</p>').join('')}${r.editable_warnings.map(x=>'<p>'+esc(x)+'</p>').join('')}<p>没有完成视觉与混音对照前，不标为无损。</p><button id="native-export-editable" ${r.editable_available?'':'disabled'}>按以上差异建立可编辑草稿</button></article></div>${r.missing.length?`<details><summary>查看 ${r.missing.length} 个缺失素材</summary>${r.missing.map(x=>'<p>'+esc(x.name)+'<br>'+esc(x.path)+'</p>').join('')}</details>`:''}`;
    const options=el('.native-migration-options');
    const editable=el('#native-export-editable');
    options.prepend(editable.closest('article'));
    if(r.offline_audio_available){
      const offline=document.createElement('article');
      offline.innerHTML=`<h4>保留离线音频片段</h4><p>${esc(r.offline_notice)}</p><p>其余轨道按兼容方式迁移，样式和混音差异仍需核对。</p><button id="native-export-offline">生成含离线音频的可编辑草稿</button>`;
      options.append(offline);
    }
    editable.textContent='仅生成兼容核对草稿（仍有差异）';
    const preservation=r.preservation||{exact_available:false,unresolved:['原样工程保留检查尚未完成']};
    const exact=document.createElement('article');exact.className='native-exact-handoff';
    exact.innerHTML=`<h4>原样工程交接</h4><p>以全部编辑结果、图层和原轨道组织一致为验收标准。</p>${preservation.unresolved.map(x=>'<p>'+esc(x)+'</p>').join('')}<button id="native-export-exact" class="primary" ${preservation.exact_available&&r.editable_available?'':'disabled'}>原样交给剪映${preservation.exact_available?'':' · 尚未通过'}</button>`;
    options.before(exact);
    el('#native-export-film').textContent='仅复制成片（没有可编辑图层）';
    function exportMode(mode,requireExact=false,allowOffline=false){return handle(async()=>{
      status('正在建立独立剪映草稿，旧工程保持原样…');
      panel.querySelectorAll('#native-export-film,#native-export-editable,#native-export-exact,#native-export-offline').forEach(b=>b.disabled=true);
      try{const result=await api('/api/native/export',{project_id:r.project_id,revision:r.revision,mode,require_exact:requireExact,allow_offline_audio:allowOffline,accept_approximate:mode==='editable'&&!requireExact});await scan();pending=false;await load(result.key);status(result.message+'。模式：'+(mode==='film'?'原样成片单轨':requireExact?'原样工程':allowOffline?'含离线音频，缺失部分不能播放；其余兼容差异需复核':'兼容核对草稿，尚未达到原样交接'))}
      catch(error){drawMigrationReport(r);throw error}
    })}
    el('#native-export-film').onclick=exportMode('film');el('#native-export-editable').onclick=exportMode('editable');
    el('#native-export-exact').onclick=exportMode('editable',true);
    if(el('#native-export-offline'))el('#native-export-offline').onclick=exportMode('editable',false,true);
  }
  button.onclick=handle(async()=>{
    if(window.chrome?.webview&&new URLSearchParams(location.search).get('native')!=='1'){
      await window.studioProjectHooks.transaction(async()=>{});
      window.chrome.webview.postMessage({type:'open-native',project_id:p?.id||''});return;
    }
    await show();
  });
  el('#native-back').onclick=()=>{if(pending){status('有尚未保存的原生文字，请先保存或放弃文字并重读。',true);return}active=false;generation++;document.title=previousTitle;document.body.classList.remove('native-mode')};
  el('#native-refresh').onclick=handle(async()=>{await scan();if(detail&&!pending)await load(detail.key)});
  el('#native-launch').onclick=handle(async()=>{if(pending)throw Error('有尚未保存的原生文字，请先处理');const r=await api('/api/native/launch',{});status(r.message+(detail?'：'+detail.name:''))});
  el('#native-search').oninput=drawList;
  window.addEventListener('focus',()=>{if(active&&detail&&!pending&&!loading)load(detail.key,true).catch(e=>status(e.message,true))});
  window.addEventListener('beforeunload',event=>{if(pending||nativePackageBusy){event.preventDefault();event.returnValue=nativePackageBusy?'共同工程正在打包':'剪映文字尚未保存'}});
  window.studioNativeDrafts={show,isActive:()=>active};
}
