'use strict';

const StudioProjects={
  filter(rows,series=null,query=''){
    const needle=query.trim().toLocaleLowerCase();
    return rows.filter(row=>(series===null||(row.series||'')===series)&&(!needle||`${row.series||''} ${row.name}`.toLocaleLowerCase().includes(needle)));
  },
  selection(preview,names){
    const allowed=new Set((preview.folders||[]).map(row=>row.name));
    if(!names.length)throw Error('请逐项勾选需要导入的剧集文件夹');
    if(new Set(names).size!==names.length||names.some(name=>!allowed.has(name)))throw Error('所选文件夹不在刚才的预览中，请重新扫描');
    return [...names];
  },
  confirmation(rows,restore=false){
    if(!rows.length)throw Error('请先勾选具体工程');
    return `${restore?'恢复':'移入回收站'}以下 ${rows.length} 个工程？\n\n${rows.map(row=>`• ${row.series?row.series+' / ':''}${row.name}`).join('\n')}\n\n${restore?'恢复后重新出现在工程列表。':'只移动软件内的工程记录，原视频、源剧本PDF、音乐和已导出视频都不删除。可以恢复。'}`;
  },
  clearScript(project){
    const next=JSON.parse(JSON.stringify(project));
    next.script={text:'',source:'',start_anchor:'',end_anchor:'',complete:false};next.reviews={};return next;
  },
  summary(row){
    return `剧本 ${Number(row.script_chars)||0} 字 · ${Number(row.clips)||0} 镜头 · ${Number(row.audios)||0} 条附加音频 · ${Number(row.captions)||0} 条字幕 · ${Number(row.protected_lines)||0} 条必保台词`;
  }
};
if(typeof module!=='undefined'&&module.exports)module.exports=StudioProjects;

function installProjectManagement(){
  const hooks=window.studioProjectHooks;
  const original={render,renderScript,modal,refreshBoot};
  let seriesFilter=null,projectSearch='',modalVersion=0,managerMode='active',managerBusy=false,scriptTransaction=null;
  let confirmationResolve=null;
  function finishConfirmation(accepted){
    const resolve=confirmationResolve;confirmationResolve=null;
    if($('#project-confirm').open)$('#project-confirm').close();
    if(resolve)resolve(accepted);
  }
  function confirmProjectAction(message,label='确认执行'){
    if(confirmationResolve)throw Error('请先完成当前确认');
    $('#project-confirm-message').textContent=message;
    $('#project-confirm-ok').textContent=label;
    return new Promise(resolve=>{confirmationResolve=resolve;$('#project-confirm').showModal()});
  }
  window.studioProjectConfirm=confirmProjectAction;
  $('#project-confirm-ok').onclick=()=>finishConfirmation(true);
  $('#project-confirm-cancel').onclick=()=>finishConfirmation(false);
  $('#project-confirm').addEventListener('cancel',event=>{event.preventDefault();finishConfirmation(false)});
  $('#project-confirm').addEventListener('close',()=>{if(confirmationResolve&&!$('#project-confirm').open)finishConfirmation(false)});
  modal=function(html){modalVersion++;return original.modal(html)};
  const liveDialog=version=>version===modalVersion&&$('#modal').open;
  $('#modal').addEventListener('cancel',event=>{if(managerBusy)event.preventDefault()});
  function setDialogBusy(value){managerBusy=value;$('#close-modal').disabled=value}
  function updateFilters(){
    const names=[...new Set((boot.projects||[]).map(row=>row.series||''))].sort((a,b)=>a.localeCompare(b,'zh'));
    if(seriesFilter!==null&&!names.includes(seriesFilter))seriesFilter=null;
    $('#series-filter').innerHTML='<option value="all">全部剧名</option>'+names.map(name=>`<option value="s:${esc(encodeURIComponent(name))}">${esc(name||'未分组')}</option>`).join('');
    $('#series-filter').value=seriesFilter===null?'all':'s:'+encodeURIComponent(seriesFilter);
    $('#project-search').value=projectSearch;
  }
  renderProjects=function(){
    updateFilters();
    const rows=StudioProjects.filter(boot.projects||[],seriesFilter,projectSearch);
    $('#projects').innerHTML=rows.map(row=>`<button class="project-row ${row.id===p?.id?'active':''}" data-project="${row.id}"><div>${esc(row.name)}</div><small>${esc(row.series||'未分组')} · 剧本 ${Number(row.script_chars)||0} 字</small><small>${row.clips} 个镜头 · ${row.captions} 条字幕</small></button>`).join('')||'<p class="helper project-empty">没有符合条件的工程。可以清空筛选，或点击上方“新建剧本 / 剧集”。</p>';
    $$('[data-project]').forEach(button=>button.onclick=handle(()=>openProject(button.dataset.project)));
    $('#project-list-count').textContent=`${rows.length} / ${(boot.projects||[]).length}`;
  };
  $('#project-search').oninput=()=>{projectSearch=$('#project-search').value;renderProjects()};
  $('#series-filter').onchange=()=>{const value=$('#series-filter').value;seriesFilter=value==='all'?null:decodeURIComponent(value.slice(2));renderProjects()};
  refreshBoot=async function(){await original.refreshBoot();renderProjects()};
  render=function(){
    if(p&&typeof p.series!=='string')p.series='';
    original.render();
    $('#project-series').value=p?.series||'';$('#project-series').disabled=!p;
    $('#project-name').disabled=!p;
    if(!p){$('#project-meta').textContent='每个剧本 / 剧集都是独立工程，文字、素材与字幕互不覆盖';$('#project-series').value=''}
  };
  $('#project-series').onchange=()=>{
    if(!p)return;const value=$('#project-series').value.trim();if(value===(p.series||''))return;
    if(value.length>150)return toast('剧名不能超过150个字符',true);
    if(typeof p.series!=='string')p.series='';remember();p.series=value;mark(false,true);
    const row=boot.projects?.find(row=>row.id===p.id);if(row)row.series=value;renderProjects();
  };
  $('#project-name').onchange=()=>{
    if(!p)return;const value=$('#project-name').value.trim();if(!value)return toast('请填写集名 / 剧本名称',true);
    if(value===p.name)return;remember();p.name=value;mark();const row=boot.projects?.find(row=>row.id===p.id);if(row)row.name=value;renderProjects();
  };
  newProject=function(){
    modal(`<h2>新建分集</h2><p>每一集的剧本文字、素材、字幕和时间线独立。也可以先建空分集写剧本，不必立即导入视频。</p><label>剧名（可不填）</label><input id="create-series" maxlength="150" value="${esc(seriesFilter??p?.series??'')}" placeholder="例如：黑帮心声"><label>分集名 / 导出名</label><input id="create-name" maxlength="150" value="EP01" placeholder="例如：EP01"><label>从哪里开始</label><select id="create-mode"><option value="script">先编写 / 导入剧本</option><option value="clips">先导入视频素材</option></select><div class="modal-actions"><button id="create-project-ok" class="primary">创建分集</button></div>`);
    const version=modalVersion,origin=p?.id;
    $('#create-project-ok').onclick=handle(async()=>{
      const name=$('#create-name').value.trim(),series=$('#create-series').value.trim(),mode=$('#create-mode').value;
      if(!name)throw Error('请填写集名 / 剧本名称');if(name.length>150||series.length>150)throw Error('名称最多150个字符');
      const button=$('#create-project-ok');button.disabled=true;
      try{
        const created=await hooks.transaction(()=>api('/api/projects',{name,series}));
        await refreshBoot();
        if(liveDialog(version)&&p?.id===origin){$('#modal').close();seriesFilter=series;projectSearch='';await openProject(created.id);tab=mode;render();renderProjects()}
        else toast(`已建立“${name}”，请在左侧选择；没有切换你正在编辑的工程。`);
      }finally{button.disabled=false}
    });
  };
  $('#new-button').onclick=handle(newProject);$('#global-new-button').onclick=handle(newProject);

  async function manager(mode='active'){
    await save();managerMode=mode;
    const origin=p?.id;
    if(mode==='active')await refreshBoot();
    const rows=mode==='trash'?await api('/api/trash'):(boot.projects||[]);
    if(p?.id!==origin)return;
    modal(`<h2>管理工程 / 回收站</h2><div class="toolbar"><button id="manager-active" class="${mode==='active'?'accent':''}">当前工程</button><button id="manager-trash" class="${mode==='trash'?'accent':''}">回收站</button></div><p>${mode==='trash'?'勾选需要恢复的工程。恢复不会覆盖其他工程。':'导入错了可以逐项勾选并移入回收站。这里只管理工程记录，不会删除原视频、源剧本、音乐或导出文件。'}</p><input id="manager-search" placeholder="搜索剧名 / 集名"><div id="manager-list" class="manager-list"></div><div class="manager-count" id="manager-count">已选择 0 项</div><div class="modal-actions"><button id="manager-action" class="${mode==='trash'?'primary':'danger'}" disabled>${mode==='trash'?'恢复所选工程':'将所选工程移入回收站'}</button></div>`);
    const version=modalVersion,selectedIds=new Set();
    function drawManager(){
      const visible=StudioProjects.filter(rows,null,$('#manager-search').value);
      $('#manager-list').innerHTML=visible.map(row=>`<label class="manager-row"><input type="checkbox" data-manage-project="${row.id}" ${selectedIds.has(row.id)?'checked':''}><span><b>${esc(row.name)}</b><small>${esc(row.series||'未分组')}${p?.id===row.id?' · 当前打开':''}</small><small>${esc(StudioProjects.summary(row))}</small></span></label>`).join('')||'<p class="helper">没有工程。</p>';
      $$('[data-manage-project]').forEach(box=>box.onchange=()=>{if(box.checked)selectedIds.add(box.dataset.manageProject);else selectedIds.delete(box.dataset.manageProject);updateManagerCount()});
      updateManagerCount();
    }
    function updateManagerCount(){$('#manager-count').textContent=`已选择 ${selectedIds.size} 项（含筛选前已勾选项）`;$('#manager-action').disabled=!selectedIds.size}
    $('#manager-search').oninput=drawManager;drawManager();
    $('#manager-active').onclick=handle(()=>manager('active'));$('#manager-trash').onclick=handle(()=>manager('trash'));
    $('#manager-action').onclick=handle(async()=>{
      const selected=rows.filter(row=>selectedIds.has(row.id));
      if(!selected.length)throw Error('请先逐项勾选工程');
      if(!await confirmProjectAction(StudioProjects.confirmation(selected,mode==='trash'),mode==='trash'?'确认恢复所选工程':'确认移入回收站'))return;
      $('#manager-action').disabled=true;setDialogBusy(true);
      const succeeded=[],failed=[];
      try{
        await hooks.transaction(async()=>{
          for(const row of selected){
            try{await api(`/api/projects/${row.id}/${mode==='trash'?'unarchive':'archive'}`,{revision:row.revision,confirmed:true});succeeded.push(row);if(mode!=='trash')hooks.detach(row.id)}
            catch(error){failed.push({name:row.name,message:error.message})}
          }
        });
      }finally{setDialogBusy(false)}
      await refreshBoot();
      if(liveDialog(version)){
        await manager(mode);
        const result=document.createElement('div');result.className='alert '+(failed.length?'':'success');
        result.textContent=`${mode==='trash'?'已恢复':'已移入回收站'} ${succeeded.length} 项。${failed.length?'未处理：'+failed.map(item=>item.name+'（'+item.message+'）').join('；'):'原素材没有删除。'}`;
        $('#modal-body').prepend(result);
      }
    });
  }
  $('#manage-button').onclick=handle(()=>manager('active'));$('#global-manage-button').onclick=handle(()=>manager('active'));
  $('#batch-button').onclick=()=>{
    modal('<h2>预览分集文件夹</h2><p>先扫描下一层分集文件夹；不会立即建立工程。只有含视频的文件夹可以勾选，音乐库、缓存等跳过项会列出原因。</p><input id="batch-path" placeholder="F:\\剧名"><div class="modal-actions"><button id="batch-preview" class="primary">扫描并预览</button></div>');
    const version=modalVersion;
    $('#batch-preview').onclick=handle(async()=>{
      const path=$('#batch-path').value.trim(),button=$('#batch-preview');if(!path)throw Error('请填写具体剧名目录');button.disabled=true;
      try{await save();if(!liveDialog(version))return;const preview=await api('/api/batch/preview',{path});if(!liveDialog(version))return;showBatchPreview(preview)}finally{button.disabled=false}
    });
  };
  function showBatchPreview(preview){
    modal(`<h2>确认需要导入的分集</h2><p>目录：${esc(preview.path)}。请逐项勾选；未勾选的目录不会导入。</p><label>这些剧集的剧名 / 分组</label><input id="batch-series" maxlength="150" value="${esc(seriesFilter??p?.series??'')}" placeholder="例如：黑帮心声"><div class="manager-list">${(preview.folders||[]).map(folder=>`<label class="manager-row"><input type="checkbox" data-batch-folder="${esc(folder.name)}"><span><b>${esc(folder.name)}</b><small>${folder.video_count} 个视频 · ${folder.audio_count} 个音频</small></span></label>`).join('')||'<p>没有找到含视频的分集目录。</p>'}</div><details class="batch-skipped"><summary>跳过 ${preview.skipped?.length||0} 个目录</summary>${(preview.skipped||[]).map(row=>`<p><b>${esc(row.name)}</b>：${esc(row.reason)}</p>`).join('')}</details>${(preview.warnings||[]).map(warning=>`<p class="alert">${esc(typeof warning==='string'?warning:JSON.stringify(warning))}</p>`).join('')}<div id="batch-selection-count" class="manager-count">已选择 0 集</div><div class="modal-actions"><button id="batch-confirm" class="primary" disabled>仅导入所选剧集</button></div>`);
    const version=modalVersion;
    $$('[data-batch-folder]').forEach(box=>box.onchange=()=>{const count=$$('[data-batch-folder]:checked').length;$('#batch-selection-count').textContent=`已选择 ${count} 集`;$('#batch-confirm').disabled=!count});
    $('#batch-confirm').onclick=handle(async()=>{
      const selected=StudioProjects.selection(preview,$$('[data-batch-folder]:checked').map(box=>box.dataset.batchFolder)),series=$('#batch-series').value.trim();
      if(series.length>150)throw Error('剧名最多150个字符');
      if(!await confirmProjectAction(`仅为以下 ${selected.length} 个文件夹建立 / 复用工程？\n\n${selected.map(name=>'• '+name).join('\n')}\n\n未勾选目录不导入；源文件不移动、不删除。`,'确认仅导入这些剧集'))return;
      const button=$('#batch-confirm');button.disabled=true;setDialogBusy(true);
      try{
        const results=await hooks.transaction(()=>api('/api/batch',{path:preview.path,selected,series,confirmed:true}));
        await refreshBoot();
        if(!liveDialog(version)){toast('批次处理完成，请在工程管理中查看');return}
        modal(`<h2>本次批量导入结果</h2><p>仅处理了刚才明确勾选的 ${selected.length} 个目录。工程之间独立；原素材未删除。</p><div class="manager-list">${results.map(row=>`<div class="batch-result"><b>${esc(row.name)}</b><p>${esc(row.state||'已建立')}${row.reused?' · 复用已有工程':''}${row.archived?' · 仍在回收站，需手动恢复':''}</p>${row.id&&!row.archived?`<button data-open-import="${row.id}">打开这个工程</button>`:''}</div>`).join('')}</div>`);
        $$('[data-open-import]').forEach(open=>open.onclick=handle(async()=>{$('#modal').close();seriesFilter=series;projectSearch='';await openProject(open.dataset.openImport);tab='clips';render();renderProjects()}));
      }finally{button.disabled=false;setDialogBusy(false)}
    });
  }
  renderScript=function(){
    original.renderScript();if(!p)return;
    scriptTransaction=null;
    const startTransaction=key=>{const identity=`${p.id}:${key}`;if(scriptTransaction!==identity){remember();scriptTransaction=identity}};
    for(const [selector,key] of [['#script-text','text'],['#script-start','start_anchor'],['#script-end','end_anchor']]){
      const field=$(selector);field.onfocus=()=>{scriptTransaction=null};field.onblur=()=>{scriptTransaction=null};field.onchange=null;
      field.oninput=()=>{startTransaction(key);p.script[key]=field.value;p.script.complete=false;$('#script-complete').checked=false;mark()};
    }
    const existingImport=$('#script-import').onclick;
    $('#script-import').textContent=p.script.text||p.script.source?'替换本集剧本':'导入本集剧本';
    $('#script-import').onclick=handle(async()=>{
      const pid=p.id;
      if((p.script.text||p.script.source)&&!await confirmProjectAction(`替换“${p.name}”的剧本文字？\n\n只修改这一集；原PDF/文本文件不删除。现有必保台词、字幕与视频保留，但必须重新核对与新剧本是否一致。可撤销。`,'确认替换本集剧本'))return;
      if(p?.id!==pid)throw Error('当前工程已经变化，请重新选择需要替换剧本的工程');
      existingImport();
    });
    const clear=document.createElement('button');clear.id='clear-script';clear.className='danger wide';clear.textContent='清空本集剧本文字';
    clear.onclick=handle(async()=>{
      if(!p)return;
      const pid=p.id;
      if(!await confirmProjectAction(`清空“${p.name}”当前的剧本文字及章节确认？\n\n源PDF/文本文件不会删除；视频、字幕、必保台词清单全部保留。清空后需重新复核，可点击撤销恢复。`,'确认清空本集剧本文字'))return;
      if(p?.id!==pid)throw Error('当前工程已经变化，请重新选择需要清空剧本的工程');
      remember();p=StudioProjects.clearScript(p);mark();render();toast('本集剧本文字已清空，源文件、字幕与必保台词未删除；可撤销');
    });
    $('#panel').append(clear);
    const note=document.createElement('p');note.className='helper';note.textContent=`正在编辑：${p.series?p.series+' / ':''}${p.name}。本页修改只属于这一工程，不会替换其他剧集。`;$('#panel').prepend(note);
  };
}
