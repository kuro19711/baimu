'use strict';
const StudioTxtCaptions={
  maxBytes:1024*1024,
  decode(buffer){
    const bytes=new Uint8Array(buffer);
    if(!bytes.length||bytes.length>this.maxBytes)throw Error('TXT 文件必须非空且不超过 1 MiB');
    let text;
    if(bytes[0]===0xff&&bytes[1]===0xfe)text=new TextDecoder('utf-16le',{fatal:true}).decode(bytes);
    else if(bytes[0]===0xfe&&bytes[1]===0xff)text=new TextDecoder('utf-16be',{fatal:true}).decode(bytes);
    else{try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes)}catch(_){text=new TextDecoder('gb18030',{fatal:true}).decode(bytes)}}
    if(text.includes('\0')||text.includes('\ufffd'))throw Error('无法读取 TXT 编码，请另存为 UTF-8 后重试');
    return text.replace(/^\ufeff/,'');
  },
  split(text,mode='lines'){
    if(typeof text!=='string'||new TextEncoder().encode(text).length>this.maxBytes)throw Error('字幕文字不能超过 1 MiB');
    if(!['lines','sentences'].includes(mode))throw Error('请选择有效的分句方式');
    const lines=text.replace(/^\ufeff/,'').replace(/\r\n?/g,'\n').split('\n');
    const result=lines.flatMap(line=>mode==='lines'?[line]:line.replace(/([。！？!?；;]+[”’」』"']*|\.(?=\s|$))/gu,'$1\n').split('\n')).map(line=>line.trim()).filter(Boolean);
    if(!result.length)throw Error('请先输入字幕文字');
    if(result.length>10000)throw Error('一次最多分配 10000 条字幕，请分集输入');
    return result;
  }
};
if(typeof module!=='undefined'&&module.exports)module.exports=StudioTxtCaptions;

function installTxtCaptions(){
  const original=renderCaptions;
  renderCaptions=function(){
    original();
    const button=document.createElement('button');button.id='import-txt';button.textContent='TXT 分配字幕';
    $('#import-srt').after(button);button.onclick=handle(open);
  };
  function open(){
    if(!p)throw Error('请先打开一集');
    if(p.track_locks?.includes('caption'))throw Error('字幕轨道已锁定，请先解锁');
    const projectId=p.id;let preview=null,reading=0,busy=false,activeJob=null,interval=null,polling=false;
    modal(`<h2>TXT 分配字幕</h2><p>按本集最终音轨的对白自动对齐 TXT 原文。需要已配置的本地语音模型，完成后预览并应用。</p><label>选择 TXT（UTF-8 / UTF-16 / GB18030，最多 1 MiB）</label><input id="txt-caption-file" type="file" accept=".txt,text/plain"><label>或直接粘贴对白文字（与音频语言相同，不含角色名和动作说明）</label><textarea id="txt-caption-text" rows="8" placeholder="每行一句字幕"></textarea><label>分句方式</label><select id="txt-caption-split"><option value="lines">每个非空行一条</option><option value="sentences">按句末标点分句</option></select><p class="helper">保留输入原文和标点，使用本集全局字幕样式。应用会替换本集全部字幕，可撤销；对齐结果仍需试听校对。</p><div id="txt-caption-preview" role="status" aria-live="polite"></div><div class="modal-actions"><button id="txt-caption-cancel">关闭</button><button id="txt-caption-preview-button">按音频对齐并预览</button><button id="txt-caption-apply" class="primary" disabled>应用字幕</button></div>`);
    const splitControl=$('#txt-caption-split');
    const language=document.createElement('div');language.innerHTML='<label>音频对白语言</label><select id="txt-caption-language"><option value="">自动检测</option><option value="zh">中文</option><option value="en">英语</option><option value="pt">葡萄牙语</option><option value="es">西班牙语</option><option value="ja">日语</option><option value="ko">韩语</option><option value="fr">法语</option><option value="de">德语</option></select>';splitControl.after(language);
    const languageControl=$('#txt-caption-language');
    const dialog=$('#modal'),field=$('#txt-caption-text'),file=$('#txt-caption-file'),split=$('#txt-caption-split'),apply=$('#txt-caption-apply'),output=$('#txt-caption-preview'),start=$('#txt-caption-preview-button');
    const current=()=>p?.id===projectId&&dialog.open&&$('#txt-caption-text')===field;
    const signature=()=>JSON.stringify([p?.id,p?.revision,dirty,p?.captions,p?.track_locks,p?.clips,p?.audios,p?.fps]);
    function invalidate(){preview=null;apply.disabled=true;output.textContent=''}
    function lock(value){busy=value;for(const el of [field,file,split,languageControl,start])el.disabled=value}
    function stop(){clearInterval(interval);interval=null;activeJob=null;lock(false)}
    function show(result,stamp){
      if(!current())return;
      if(signature()!==stamp)throw Error('对齐期间工程已变化，已保留当前字幕；请按当前工程重新对齐');
      const cues=result.captions;
      if(!result.alignment||!cues?.length)throw Error('没有生成有效的 TXT 对齐字幕，未替换当前字幕');
      preview={cues,signature:stamp,sound:result.sound_digest};apply.disabled=false;
      output.innerHTML=`<p>已对齐 ${cues.length} 条，文字匹配率 ${Math.round(result.alignment.coverage*100)}%。请试听确认。${cues.length>200?'下表显示前200条。':''}</p><div style="max-height:240px;overflow:auto"><table><thead><tr><th>时间</th><th>字幕原文</th></tr></thead><tbody>${cues.slice(0,200).map(cue=>`<tr><td>${time(cue.start)} → ${time(cue.end)}</td><td>${esc(cue.text)}</td></tr>`).join('')}</tbody></table></div>`;
    }
    field.addEventListener('input',invalidate);split.addEventListener('change',invalidate);languageControl.addEventListener('change',invalidate);
    file.onchange=handle(async()=>{
      const chosen=file.files[0];if(!chosen)return;
      const ticket=++reading,before=field.value;invalidate();start.disabled=true;
      try{
        if(!/\.txt$/i.test(chosen.name))throw Error('请选择 TXT 文本文件');
        if(chosen.size>StudioTxtCaptions.maxBytes)throw Error('TXT 文件不能超过 1 MiB');
        const text=StudioTxtCaptions.decode(await chosen.arrayBuffer());
        if(!current()||reading!==ticket)return;
        if(field.value!==before)throw Error('读取期间文字已修改，已保留你的输入，请重新选择 TXT');
        field.value=text;invalidate();
      }finally{if(reading===ticket){file.value='';start.disabled=false}}
    });
    $('#txt-caption-cancel').onclick=()=>dialog.close();
    dialog.addEventListener('close',()=>{stop();reading++},{once:true});
    start.onclick=handle(async()=>{
      if(!current()||busy)return;
      StudioTxtCaptions.split(field.value,split.value);invalidate();lock(true);
      try{
        await save();if(!current())return;
        const stamp=signature();
        const job=await api(`/api/projects/${projectId}/jobs`,{kind:'transcribe',revision:p.revision,language:languageControl.value,subtitle_text:field.value,subtitle_split:split.value});
        activeJob=job.id;
        if(!current()){stop();return}
        output.textContent='正在后台对齐音频对白，可关闭窗口；完成后也可从处理记录应用字幕草稿。';
        async function poll(){
          if(polling||!activeJob)return;polling=true;
          try{
            const result=await api('/api/jobs/'+job.id);
            if(!current()){stop();return}
            if(result.state==='complete'){stop();show(result.result,stamp)}
            else if(['failed','cancelled','interrupted'].includes(result.state)){stop();output.textContent=result.message;toast(result.message,true)}
            else output.textContent=result.message||'正在对齐音频对白…';
          }catch(error){stop();if(current()){output.textContent=error.message;toast(error.message,true)}}
          finally{polling=false}
        }
        interval=setInterval(poll,1500);await poll();
      }catch(error){stop();throw error}
      finally{if(!activeJob)lock(false)}
    });
    apply.onclick=handle(async()=>{
      if(!current()||!preview||signature()!==preview.signature)throw Error('工程或字幕已变化，请重新对齐预览');
      if(p.track_locks?.includes('caption'))throw Error('字幕轨道已锁定，请先解锁');
      apply.disabled=true;
      try{
        const proposal=preview,stamp=signature();await refreshQA();
        if(!current()||preview!==proposal||signature()!==stamp||proposal.sound!==qa.sound_hash)throw Error('声音或工程已变化，请重新对齐预览');
        remember();p.captions=copy(proposal.cues);selected=p.captions[0]?.id;mark();dialog.close();render();toast(`已分配 ${p.captions.length} 条 TXT 字幕，可撤销；请试听校对时间`);
      }finally{if(current()&&preview)apply.disabled=false}
    });
  }
}
