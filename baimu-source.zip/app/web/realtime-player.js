'use strict';
/* Source-based timeline playback. Exported files remain a separate viewing mode. */
function installStudioRealtime(){
  const old={openProject,render,mark,updateOverlay,viewRender,renderClips};
  const stage=$('#stage'),exportVideo=$('#video');
  const overlay=$('#caption-overlay').cloneNode(true);$('#caption-overlay').replaceWith(overlay);
  const canvas=document.createElement('canvas');canvas.id='realtime-canvas';canvas.width=540;canvas.height=960;stage.prepend(canvas);
  const ctx=canvas.getContext('2d',{willReadFrequently:true});
  const picture=document.createElement('canvas');picture.width=canvas.width;picture.height=canvas.height;const pictureCtx=picture.getContext('2d');
  const foreground=document.createElement('div');foreground.id='foreground-masks';stage.append(foreground);
  const pool=document.createElement('div');pool.className='live-media-pool';pool.setAttribute('aria-hidden','true');document.body.append(pool);
  let mode='edit',pid=null,position=0,playing=false,anchor=0,frame=null,compiled=null,candidate=null,epoch=0,buffering=false,captionDrag=null;
  let compiledSignature=null,paintFrame=null;
  let audioContext=null,voiceBus,musicBus,musicGain,master,analyser,samples;
  const videos=new Map(),audios=new Map();let error='',notice='';
  const current=()=>candidate||p;
  const activeAudio=t=>(compiled?.items||[]).filter(i=>['original','dialogue','narration','bgm','sfx'].includes(i.kind)&&i.start<=t&&t<i.end&&(i.kind!=='original'||i.hasAudio));
  const now=()=>playing?Math.min(compiled?.duration||0,position+(audioContext.currentTime-anchor)):position;
  const editing=()=>mode==='edit';
  function setStatus(){
    if(!p)return;
    $('#mode-edit').hidden=editing();$('#mode-export').classList.toggle('accent',!editing());
    $('#refresh-edit-preview').hidden=!editing()||!error;
    $('#preview-label').textContent=editing()?(error?'实时预览：'+error:buffering?'正在准备源素材…':notice||'实时预览 · 当前工程'):'导出结果 · 已生成的视频';
    $('#preview-note').textContent=editing()?'修改即时预览，自动保存。首次加载素材需要片刻；空格播放 / 暂停。':'正在查看已导出的视频；点击“返回剪辑”或直接修改，即可回到当前预览。';
    $('#caption-drag-scope').hidden=!editing()||tab!=='captions';
    $('#play-button').textContent=playing||!editing()&&!exportVideo.paused?'Ⅱ':'▶';
    document.body.classList.toggle('realtime-editing',editing()&&!!p);
    canvas.hidden=!editing();foreground.hidden=!editing();overlay.style.display=editing()?'block':'none';$('#mask-layer').style.display=editing()?'block':'none';
    document.querySelectorAll('.caption-extra').forEach(node=>node.style.display=editing()?'block':'none');
    $('#mask-preview-canvas').style.display='none';
  }
  function audioGraph(){
    if(audioContext)return;
    audioContext=new AudioContext();voiceBus=audioContext.createGain();musicBus=audioContext.createGain();musicGain=audioContext.createGain();
    if(current()?.native?.shared)master=audioContext.createGain();
    else{master=audioContext.createDynamicsCompressor();master.threshold.value=-.45;master.knee.value=0;master.ratio.value=20;master.attack.value=.003;master.release.value=.2;}
    analyser=audioContext.createAnalyser();analyser.fftSize=1024;samples=new Float32Array(analyser.fftSize);
    voiceBus.connect(analyser);analyser.connect(master);musicBus.connect(musicGain);musicGain.connect(master);master.connect(audioContext.destination);
  }
  function mediaFailure(message){error=message;pause();setStatus()}
  function makeVideo(asset){
    const key=pid+':'+asset.id+':'+asset.sha256;let record=videos.get(key);if(record)return record;
    const el=document.createElement('video');el.muted=true;el.playsInline=true;el.preload='auto';el.src=url(`/asset/${pid}/${asset.id}`);pool.append(el);
    record={el};videos.set(key,record);
    el.addEventListener('loadeddata',requestDraw);el.addEventListener('seeked',requestDraw);
    el.addEventListener('error',()=>mediaFailure('无法解码画面 '+asset.name));return record;
  }
  function makeAudio(item){
    const project=current(),record=item.kind==='original'?project.clips.find(c=>c.id===item.id):project.audios.find(a=>a.id===item.id);
    const asset=project.assets.find(a=>a.id===item.asset_id),streams=asset.audio_streams||[];
    const stream=record.audio_stream==null?(streams.length===1?streams[0]:null):streams.find(s=>s.index===record.audio_stream);
    if(!stream){if(item.kind==='original'&&!asset.has_audio)return null;throw Error('请为 '+asset.name+' 明确选择音轨')}
    const key=[pid,item.kind,item.id,asset.id,asset.sha256,stream.index].join(':');let node=audios.get(key);if(node)return node;
    const el=document.createElement('audio');el.preload='auto';el.src=url(`/api/projects/${pid}/live-audio/${asset.id}?stream=${stream.index}`);pool.append(el);
    node={el,recordId:item.id,key,kind:item.kind};audios.set(key,node);
    el.addEventListener('error',()=>{node.error='无法准备声音 '+asset.name;if(node.active)mediaFailure(node.error)});return node;
  }
  function connectAudio(node){
    if(node.gain)return;
    node.source=audioContext.createMediaElementSource(node.el);node.gain=audioContext.createGain();
    node.source.connect(node.gain);node.gain.connect(node.kind==='bgm'?musicBus:voiceBus);
  }
  function stopMedia(){for(const {el} of [...videos.values(),...audios.values()])el.pause()}
  function startMedia(node){
    if(!node.el.paused||node.starting)return;
    const ticket=epoch;node.starting=true;
    node.el.play().catch(e=>{if(e.name!=='AbortError'&&playing&&ticket===epoch&&node.active)mediaFailure(e.message)}).finally(()=>{node.starting=false});
  }
  function pause(redraw=true){epoch++;if(playing)position=now();playing=false;buffering=false;stopMedia();if(frame!==null)cancelAnimationFrame(frame);frame=null;setStatus();if(redraw)requestDraw()}
  function waitReady(el){
    if(el.readyState>=2&&!el.seeking)return Promise.resolve();
    return new Promise((resolve,reject)=>{
      const readyEvents=['loadeddata','canplay','seeked'];
      const done=err=>{clearTimeout(timer);clearInterval(readiness);for(const event of readyEvents)el.removeEventListener(event,ok);el.removeEventListener('error',bad);err?reject(err):resolve()};
      const ok=()=>{if(el.readyState>=2&&!el.seeking)done()},bad=()=>done(Error('源素材无法加载'));const timer=setTimeout(()=>done(Error('源素材准备超时，可再次播放重试')),30000);
      for(const event of readyEvents)el.addEventListener(event,ok);el.addEventListener('error',bad);
      // A seek-triggered draw can temporarily lower readyState inside a media event.
      const readiness=setInterval(ok,50);
    });
  }
  function audioPosition(item,t){
    const record=item.kind==='original'?current().clips.find(c=>c.id===item.id):current().audios.find(a=>a.id===item.id);
    const local=Math.max(0,t-item.start),period=record.out-record.in;
    return record.in+(item.effectiveLoop?((record.loop_offset||0)+local)%period:local);
  }
  async function prepareMedia(el,target){
    await waitReady(el);
    if(Math.abs(el.currentTime-target)>.01){el.currentTime=target;await waitReady(el)}
  }
  function warmAudio(t){
    const upcoming=(compiled?.items||[]).filter(i=>['original','dialogue','narration','bgm','sfx'].includes(i.kind)&&i.start>t&&i.start<=t+5&&(i.kind!=='original'||i.hasAudio)).sort((a,b)=>a.start-b.start).slice(0,8);
    for(const item of upcoming){
      let node;try{node=makeAudio(item)}catch(e){continue}
      if(!node||node.warmed)continue;node.warmed=true;
      node.preparing=prepareMedia(node.el,audioPosition(item,item.start)).catch(e=>{node.error=e.message});
    }
  }
  async function play(){
    if(!editing())return exportVideo.play();
    if(current()?.native?.issues?.length)throw Error('此工程包含尚不能本地预览的效果：'+current().native.issues.join('；'));
    if(!p?.clips.length)throw Error('请先添加画面片段');
    if(playing||buffering)return;
    if(!compiled){refresh();if(!compiled)throw Error(error||'当前时间线无法预览，请检查片段时间和素材')}
    const ticket=++epoch;buffering=true;setStatus();
    error='';notice='';
    if(position>=compiled.duration-.001)position=0;
    try{
      audioGraph();
      await audioContext.resume();if(ticket!==epoch)return;
      const pending=[];const video=compiled.items.find(v=>v.kind==='video'&&v.start<=position&&position<v.end);
      if(video)pending.push(prepareMedia(makeVideo(current().assets.find(a=>a.id===video.asset_id)).el,video.sourceIn+position-video.start));
      for(const item of activeAudio(position)){const node=makeAudio(item);if(node){if(node.error)throw Error(node.error);connectAudio(node);pending.push((async()=>{await node.preparing;if(ticket!==epoch)return;await prepareMedia(node.el,audioPosition(item,position))})())}}
      warmAudio(position);
      await Promise.all(pending);if(ticket!==epoch)return;
      buffering=false;playing=true;anchor=audioContext.currentTime;setStatus();tick();
    }catch(e){if(ticket===epoch){buffering=false;mediaFailure(e.message);throw e}}
  }
  function seek(value){pause(false);position=Math.max(0,Math.min(compiled?.duration||0,Number(value)||0));notice='';requestDraw();setStatus()}
  function syncVideo(t){
    for(const entry of videos.values())entry.active=false;
    const item=compiled?.items.find(v=>v.kind==='video'&&t>=v.start&&t<v.end);if(!item){for(const {el} of videos.values())el.pause();return null}
    const asset=current().assets.find(a=>a.id===item.asset_id),record=makeVideo(asset),el=record.el;record.active=true;
    const desired=item.sourceIn+t-item.start;
    const tolerance=playing?.12:.5/compiled.fps;
    if(el.readyState>=2&&!el.seeking&&Math.abs(el.currentTime-desired)>tolerance){el.currentTime=desired;return null}
    if(playing&&el.readyState>=2)startMedia(record);
    if(!playing&&!el.paused)el.pause();
    // Warm the next source without changing its timeline position.
    const next=compiled.items.find(v=>v.kind==='video'&&v.start>t&&v.start<t+3);
    if(next)makeVideo(current().assets.find(a=>a.id===next.asset_id));
    for(const entry of videos.values())if(!entry.active)entry.el.pause();
    return el.readyState>=2&&!el.seeking?el:null;
  }
  function syncAudio(t){
    for(const node of audios.values())node.active=false;
    for(const item of activeAudio(t)){
      const node=makeAudio(item);if(!node)continue;node.active=true;
      if(!playing){node.el.pause();continue}
      connectAudio(node);
      if(node.error){mediaFailure(node.error);return false}
      // Seeking briefly lowers readyState; it must not stop every other track.
      if(node.el.readyState<2&&!node.el.seeking){position=t;playing=false;stopMedia();play().catch(e=>toast(e.message,true));return false}
      const record=item.kind==='original'?current().clips.find(c=>c.id===item.id):current().audios.find(a=>a.id===item.id);
      const local=t-item.start,period=record.out-record.in;
      const desired=record.in+(item.effectiveLoop?((record.loop_offset||0)+local)%period:local);
      const cycle=item.effectiveLoop?Math.floor(((record.loop_offset||0)+local)/period):0;
      if(!node.el.seeking&&(Math.abs(node.el.currentTime-desired)>.15||(node.cycle!==undefined&&node.cycle!==cycle)))node.el.currentTime=desired;
      node.cycle=cycle;
      let gain=Math.pow(10,(record.gain||0)/20);
      if(record.muted)gain=0;
      if(record.fade_in>0)gain*=Math.min(1,local/record.fade_in);
      if(record.fade_out>0)gain*=Math.min(1,(item.end-t)/record.fade_out);
      if(item.kind==='bgm'&&!current()?.native?.shared){
        const cycle=((record.loop_offset||0)+local)%period;
        gain*=Math.min(1,(item.effectiveLoop?cycle:local)/Math.min(.01,period/4));
        gain*=Math.min(1,(period-cycle)/Math.min(.01,period/4));
        gain*=Math.min(1,(item.end-t)/Math.min(.08,(item.end-item.start)/4));
      }
      node.gain.gain.setValueAtTime(gain,audioContext.currentTime);
      startMedia(node);
    }
    for(const node of audios.values())if(!node.active)node.el.pause();
    if(playing&&!current()?.native?.shared){
      analyser.getFloatTimeDomainData(samples);let sum=0;for(const v of samples)sum+=v*v;
      const rms=Math.sqrt(sum/samples.length),duck=rms>.03?Math.pow(.03/rms,7/8):1;
      musicGain.gain.setTargetAtTime(duck,audioContext.currentTime,duck<musicGain.gain.value?.02:.45);
    }
    return true;
  }
  function paintMasks(t){
    for(const m of current()?.masks||[]){
      if(t<m.start||t>=m.end||m.layer==='above_captions')continue;
      const at=StudioMasks.position(m,t),scale=canvas.width/1080,left=Math.floor(at.x*scale),top=Math.floor(at.y*scale),right=Math.ceil((at.x+at.w)*scale),bottom=Math.ceil((at.y+at.h)*scale),x=Math.max(0,left),y=Math.max(0,top),w=Math.max(0,Math.min(canvas.width,right)-x),h=Math.max(0,Math.min(canvas.height,bottom)-y);if(!w||!h)continue;
      if(m.mode==='solid'){ctx.fillStyle='#fff';ctx.fillRect(x,y,w,h)}
      else{
        const image=ctx.getImageData(x,y,w,h),radius=Math.max(1,Math.min(Math.round(m.blur*scale),Math.floor(w/2),Math.floor(h/2)));
        image.data.set(StudioLiveLayers.blur(image.data,w,h,radius,m.white));ctx.putImageData(image,x,y);
      }
    }
    const above=(current()?.masks||[]).filter(m=>m.layer==='above_captions'&&t>=m.start&&t<m.end);
    const ids=above.map(m=>m.id).join('|');
    if(foreground.dataset.ids!==ids){foreground.replaceChildren(...above.map(m=>{const node=document.createElement('div');node.dataset.foregroundMask=m.id;return node}));foreground.dataset.ids=ids}
    for(const m of above){const node=foreground.querySelector(`[data-foreground-mask="${m.id}"]`),at=StudioMasks.position(m,t);
      Object.assign(node.style,{position:'absolute',left:at.x/1080*100+'%',top:at.y/1920*100+'%',width:at.w/1080*100+'%',height:at.h/1920*100+'%',background:m.mode==='solid'?'#fff':`rgba(255,255,255,${m.white||0})`,backdropFilter:m.mode==='solid'?'none':`blur(${m.blur*stage.clientWidth/1080}px)`});
    }
  }
  function adorn(){
    const editable=editing()&&tab==='captions'&&!!overlay.textContent&&!(p?.track_locks||[]).includes('caption');
    overlay.classList.toggle('caption-editable',editable);overlay.style.pointerEvents=editable?'auto':'none';
    if(editable&&!overlay.querySelector('.caption-resize')){const handle=document.createElement('span');handle.className='caption-resize';handle.dataset.captionResize='1';handle.title='拖动调整字号';overlay.append(handle)}
  }
  function requestDraw(){
    // Selection, save acknowledgement and media events can all refresh in one turn.
    if(paintFrame===null)paintFrame=requestAnimationFrame(()=>{paintFrame=null;draw()});
  }
  function draw(){
    if(paintFrame!==null){cancelAnimationFrame(paintFrame);paintFrame=null}
    if(!editing()||!p||pid!==p.id||!compiled)return;
    if(p.native?.issues?.length){error=p.native.issues.join('；');setStatus();ctx.clearRect(0,0,canvas.width,canvas.height);foreground.replaceChildren();foreground.dataset.ids='';overlay.textContent='';document.querySelectorAll('.caption-extra').forEach(n=>n.remove());return}
    const t=now();ctx.fillStyle='#000';ctx.fillRect(0,0,canvas.width,canvas.height);
    const video=syncVideo(t);
    if(video){const factor=Math.min(canvas.width/video.videoWidth,canvas.height/video.videoHeight),w=video.videoWidth*factor,h=video.videoHeight*factor;pictureCtx.fillStyle='#000';pictureCtx.fillRect(0,0,picture.width,picture.height);pictureCtx.drawImage(video,(canvas.width-w)/2,(canvas.height-h)/2,w,h)}
    if(compiled.items.some(v=>v.kind==='video'&&t>=v.start&&t<v.end))ctx.drawImage(picture,0,0);
    paintMasks(t);
    const committed=p;try{if(candidate)p=candidate;updateOverlay(t)}finally{p=committed}
    $('#timecode').textContent=time(t);$('#seek').value=t;$('#duration').textContent=time(compiled.duration).slice(0,5);
    $('#seek').max=compiled.duration||1;adorn();
  }
  function tick(){
    frame=null;if(!playing||!editing())return;
    const t=now();if(t>=compiled.duration){position=compiled.duration;pause();return}
    try{warmAudio(t);if(!syncAudio(t))return;draw();if(playing)frame=requestAnimationFrame(tick)}catch(e){mediaFailure(e.message)}
  }
  function cleanup(){
    // Invalidate the old timeline before pause or media callbacks can redraw.
    // The global project may already contain the next episode's asset list.
    compiled=null;compiledSignature=null;candidate=null;
    if(paintFrame!==null){cancelAnimationFrame(paintFrame);paintFrame=null}
    pictureCtx.clearRect(0,0,picture.width,picture.height);foreground.replaceChildren();foreground.dataset.ids='';
    pause(false);for(const node of audios.values()){node.source?.disconnect();node.gain?.disconnect()}
    for(const {el} of [...videos.values(),...audios.values()]){el.removeAttribute('src');el.load();el.remove()}
    videos.clear();audios.clear();if(audioContext){audioContext.close().catch(()=>{});audioContext=null}candidate=null;position=0;error='';notice='';
  }
  function refresh(){
    if(!p){cleanup();pid=null;compiled=null;document.body.classList.remove('realtime-editing');canvas.hidden=true;return}
    if(pid!==p.id){cleanup();pid=p.id}
    try{
      const project=current();
      // Compare values as controls and autosave also mutate records in place.
      // Never include revision alone: both candidate edits and legacy data lack it.
      const signature=JSON.stringify([project.id,project.fps,project.assets,project.clips,project.audios,project.captions,project.masks,project.native?.shared,project.native?.duration_us]);
      if(!compiled||signature!==compiledSignature){compiled=StudioTimeline.layout(project);compiledSignature=signature}
      position=Math.min(position,compiled.duration);error='';requestDraw();setStatus();
    }catch(e){compiled=null;compiledSignature=null;mediaFailure(e.message)}
  }
  async function loadEdit(){mode='edit';exportVideo.pause();refresh();StudioTimelineUI.previewUpdated(false);return true}
  $('#mode-edit').textContent='返回剪辑';$('#mode-edit').onclick=handle(loadEdit);
  $('#mode-export').onclick=handle(async()=>{
    pause();const result=await api(`/api/projects/${p.id}/playback?mode=export`);if(!result.job)return toast('本集还没有导出结果');
    await viewRender(result.job);
  });
  $('#refresh-edit-preview').textContent='重试加载';$('#refresh-edit-preview').title='重新读取当前源素材';$('#refresh-edit-preview').onclick=()=>{error='';refresh()};
  $('#preview-button').textContent='实时预览';$('#preview-button').onclick=handle(loadEdit);
  $('#play-button').onclick=handle(async()=>{if(editing()){if(playing||buffering)pause();else await play()}else{if(exportVideo.paused)await exportVideo.play();else exportVideo.pause()}});
  $('#play-button').title='播放 / 暂停（空格）';
  $('#play-button').setAttribute('aria-label','播放 / 暂停');
  $('#play-button').setAttribute('aria-keyshortcuts','Space');
  document.addEventListener('keydown',event=>{
    const arrow=event.key==='ArrowLeft'||event.key==='ArrowRight';
    if(!arrow&&event.code!=='Space'&&event.key!==' ')return;
    const target=event.target;
    if(event.defaultPrevented||event.isComposing||event.keyCode===229||event.ctrlKey||event.metaKey||event.altKey||(!arrow&&event.shiftKey)||!p)return;
    if(target.isContentEditable||target.closest('input,textarea,[role="textbox"],[role="separator"],[role="slider"],[role="spinbutton"],[inert]')||(arrow&&target.closest('select'))||document.querySelector('dialog[open],[aria-modal="true"]'))return;
    event.preventDefault();
    event.stopPropagation();
    if(captionDrag||window.StudioTimelineUI?.dragging()||window.StudioMasks?.dragging())return;
    if(arrow)stepFrames((event.key==='ArrowLeft'?-1:1)*(event.shiftKey?10:1));
    else if(!event.repeat)$('#play-button').click();
  },true);
  function stepFrames(count){
    const at=editing()?now():exportVideo.currentTime;
    StudioTimelineUI.seek((Math.round(at*rate())+count)/rate());
  }
  $('#seek').oninput=e=>editing()?seek(Number(e.target.value)):(exportVideo.currentTime=Number(e.target.value));
  $('#back-frame').onclick=()=>stepFrames(-1);$('#back-frame').title='播放头后退一帧（←）';
  $('#next-frame').onclick=()=>stepFrames(1);$('#next-frame').title='播放头前进一帧（→）';
  $('#waveform').onclick=e=>editing()?seek(e.offsetX/$('#waveform').clientWidth*(compiled?.duration||0)):(exportVideo.currentTime=e.offsetX/$('#waveform').clientWidth*exportVideo.duration);
  updateOverlay=function(t){old.updateOverlay(Number.isFinite(t)?t:editing()?now():exportVideo.currentTime);if(editing()){overlay.style.display='block';adorn()}setStatus()};
  function resumeEditing(){if(!editing()){pause();mode='edit';exportVideo.pause();candidate=null}}
  mark=function(...args){resumeEditing();old.mark(...args);refresh()};
  render=function(...args){
    resumeEditing();
    old.render(...args);
    const locks=p?.track_locks||[],locked=tab==='captions'&&locks.includes('caption')||tab==='masks'&&locks.includes('mask')||tab==='clips'&&(locks.includes('video')||locks.includes('original'));
    if(locked){
      for(const el of $$('#panel input,#panel textarea,#panel select,#panel button,#inspector input,#inspector textarea,#inspector select,#inspector button'))el.disabled=true;
      const note=document.createElement('p');note.className='helper';note.textContent='此轨道已锁定，请在时间线轨道名称旁解锁后编辑。';$('#panel').prepend(note);
    }
    refresh();
  };
  renderClips=function(...args){
    old.renderClips(...args);
    $$('[data-up],[data-down]').forEach(button=>{
      button.title='按镜头顺序重新首尾相接；字幕和独立音频保留位置';
      button.onclick=handle(async()=>{const clipId=button.dataset.up||button.dataset.down,index=p.clips.findIndex(c=>c.id===clipId),targetIndex=index+(button.dataset.up?-1:1);if(targetIndex<0||targetIndex>=p.clips.length)return;await StudioEditActions.execute({type:'reorder',kind:'video',id:clipId,targetIndex})});
    });
    $$('[data-remove-clip]').forEach(button=>button.onclick=handle(()=>StudioEditActions.execute({type:'remove',kind:'video',id:button.dataset.removeClip})));
  };
  openProject=async function(...args){cleanup();mode='edit';await old.openProject(...args);mode='edit';exportVideo.pause();candidate=null;refresh();StudioTimelineUI.previewUpdated(false)};
  viewRender=async function(job){pause();await old.viewRender(job);mode='export';setStatus()};
  window.studioPreviewSubtitleStyle=async()=>{await loadEdit();return 'live'};
  async function finishCaption(event,cancel=false){
    const d=captionDrag;if(!d||event.pointerId!==d.pointer)return;captionDrag=null;overlay.releasePointerCapture?.(d.pointer);
    if(p?.id!==d.pid)return;
    if(cancel){p.style=copy(d.before.style);p.captions.forEach(c=>{const previous=d.before.captions.find(v=>v.id===c.id);if(previous)c.style=copy(previous.style||{})});refresh();return}
    if(d.changed){
      const cue=p.captions.find(c=>c.id===d.cue),style=d.scope==='all'?p.style:cue.style;
      const fields=d.resize?['font_size']:['x','y'],patch=Object.fromEntries(fields.map(k=>[k,style[k]]));
      p.style=copy(d.before.style);p.captions.forEach(c=>{const old=d.before.captions.find(v=>v.id===c.id);if(old)c.style=copy(old.style||{})});
      try{const result=StudioTimeline.apply(p,{type:'style',kind:'caption',id:d.cue,scope:d.scope,patch});remember();p=result.project;mark(false);renderInspector()}catch(error){toast(error.message,true)}
      refresh();
    }
  }
  overlay.addEventListener('pointerdown',e=>{
    if(e.button!==0||!editing()||(p.track_locks||[]).includes('caption'))return;const cue=p.captions.find(c=>now()>=c.start&&now()<c.end);if(!cue)return;
    pause();clearTimeout(timer);selected=cue.id;tab='captions';
    captionDrag={pointer:e.pointerId,pid:p.id,before:copy(p),cue:cue.id,x:e.clientX,y:e.clientY,style:{...p.style,...cue.style},height:overlay.clientHeight,scope:$('#caption-drag-scope').value,resize:!!e.target.closest('[data-caption-resize]'),changed:false};
    overlay.setPointerCapture(e.pointerId);e.preventDefault();
  });
  overlay.addEventListener('pointermove',e=>{
    const d=captionDrag;if(!d||e.pointerId!==d.pointer||p?.id!==d.pid)return;
    const box=stage.getBoundingClientRect(),dx=e.clientX-d.x,dy=e.clientY-d.y;if(Math.abs(dx)+Math.abs(dy)<1)return;
    const patch=d.resize?{font_size:Math.max(4,Math.min(800,Math.round(d.style.font_size*(1+dy/Math.max(12,d.height)))))}:{x:Math.max(0,Math.min(100,d.style.x+dx/box.width*100)),y:Math.max(0,Math.min(100,d.style.y+dy/box.height*100))};
    if(d.scope==='all'){Object.assign(p.style,patch);for(const c of p.captions)for(const key of Object.keys(patch))if(c.style)delete c.style[key]}
    else{const cue=p.captions.find(c=>c.id===d.cue);cue.style={...cue.style,...patch}}
    d.changed=true;refresh();
  });
  overlay.addEventListener('pointerup',e=>finishCaption(e));overlay.addEventListener('pointercancel',e=>finishCaption(e,true));
  window.addEventListener('keydown',e=>{if(e.key==='Escape'&&captionDrag){e.preventDefault();finishCaption({pointerId:captionDrag.pointer},true)}});
  window.addEventListener('blur',()=>{if(playing)pause()});
  window.StudioRealtime={editing,time:now,seek,pause,play,refresh,gestureActive:()=>!!captionDrag,preview(project){resumeEditing();candidate=project;refresh()},clearPreview(){if(!candidate)return;candidate=null;refresh()},debug(){return {mode,position:now(),playing,buffering,contextState:audioContext?.state,videoCount:videos.size,audioCount:audios.size,error}}};
  // The mask UI paints handles; this renderer owns the full pixel scene once.
  window.StudioLiveEditor={editing,paintMasks:()=>{},refresh,mode:()=>mode,loadEdit};
  refresh();
}
