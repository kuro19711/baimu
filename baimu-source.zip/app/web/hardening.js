'use strict';

// Pure helpers are also exercised in Node without opening a browser or project.
const StudioSafety = {
  updateInPlace(target, source) {
    const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
    if(Array.isArray(target)&&Array.isArray(source)){
      const keyed=new Map(target.filter(object).filter(item=>item.id!=null).map(item=>[String(item.id),item]));
      const next=source.map(item=>{
        if(object(item)&&item.id!=null&&keyed.has(String(item.id)))return StudioSafety.updateInPlace(keyed.get(String(item.id)),item);
        return JSON.parse(JSON.stringify(item));
      });
      target.splice(0,target.length,...next);return target;
    }
    if(object(target)&&object(source)){
      for(const key of Object.keys(target))if(!(key in source))delete target[key];
      for(const [key,value] of Object.entries(source)){
        if(Array.isArray(target[key])&&Array.isArray(value))StudioSafety.updateInPlace(target[key],value);
        else if(object(target[key])&&object(value))StudioSafety.updateInPlace(target[key],value);
        else target[key]=JSON.parse(JSON.stringify(value));
      }
      return target;
    }
    return JSON.parse(JSON.stringify(source));
  },
  mergeResult(base, current, result) {
    const next = JSON.parse(JSON.stringify(result));
    const editable = ['name','series','width','height','fps','clips','audios','captions','style','script','protected_lines','masks','language','track_locks'];
    const preserved = [];
    for (const key of editable) {
      if (JSON.stringify(base[key]) !== JSON.stringify(current[key])) {
        next[key] = JSON.parse(JSON.stringify(current[key]));
        preserved.push(key);
      }
    }
    if (preserved.length) next.reviews = {};
    return {project: next, preserved};
  },
  reconcile(base, local, remote) {
    if (!base || base.id!==local.id || remote.id!==local.id) return {conflicts:['工程']};
    const next=JSON.parse(JSON.stringify(remote)), conflicts=[];
    for (const key of ['name','series','width','height','fps','clips','audios','captions','masks','style','script','protected_lines','language','track_locks']) {
      const old=JSON.stringify(base[key]), mine=JSON.stringify(local[key]), theirs=JSON.stringify(remote[key]);
      if(mine===old)continue;
      if(theirs!==old && mine!==theirs){conflicts.push(key);continue;}
      if(local[key]===undefined)delete next[key];else next[key]=JSON.parse(mine);
    }
    if(!conflicts.length)next.reviews={};
    return {project:next,conflicts};
  },
  srt(cues) {
    const format = seconds => {
      const n = Math.round(seconds * 1000);
      return `${String(Math.floor(n/3600000)).padStart(2,'0')}:${String(Math.floor(n/60000)%60).padStart(2,'0')}:${String(Math.floor(n/1000)%60).padStart(2,'0')},${String(n%1000).padStart(3,'0')}`;
    };
    return [...cues].sort((a,b)=>a.start-b.start).map((c,i)=>`${i+1}\n${format(c.start)} --> ${format(c.end)}\n${c.text}`).join('\n\n')+'\n';
  },
  effectiveStyle(project, cue, activeTab) {
    return activeTab==='captions' && cue ? {...project.style,...cue.style} : {...project.style};
  },
  draftKey(projectId, windowId) { return `studio-draft:${projectId}:${windowId}`; },
  requestGate() {
    let sequence=0;
    return {begin:()=>++sequence, current:ticket=>ticket===sequence};
  },
  voiceRange(start, end) {
    if (String(start).trim()==='' || String(end).trim()==='') throw Error('请填写实际发声起止时间，不会用字幕时间自动代替');
    start=Number(start); end=Number(end);
    if (!Number.isFinite(start)||!Number.isFinite(end)||start<0||end<=start) throw Error('实际发声终点必须晚于起点');
    return {start,end};
  },
  healthMessages(data) {
    const messages=[];
    if(data.connection_error)messages.push('本地服务连接异常，未保存编辑仍保留在本窗口草稿中');
    if(data.jobs?.storage_error)messages.push('任务记录写入失败：请检查磁盘空间或文件夹权限，不要将此次输出直接交付');
    if(data.jobs?.worker_alive===false)messages.push('后台处理线程已停止：请保存工程并检查记录后重启软件');
    if(data.recovery_issues?.length)messages.push(`有 ${data.recovery_issues.length} 条文件读取或恢复告警，请查看详情；其他正常工程仍可使用`);
    return messages;
  }
};
if (typeof module!=='undefined' && module.exports) module.exports=StudioSafety;

function installStudioHardening() {
  const original={mark,renderCaptions,renderInspector,renderClips,renderAudio,renderScript,renderQA,updateOverlay,viewRender,pollJobs,refreshBoot};
  const gate=StudioSafety.requestGate();
  let operation=null, loading=false, frameHandle=null, frameKind='', textSession=null;
  let acknowledged=null, saveBlocked=false;
  const conflictNotice=document.createElement('div');conflictNotice.className='parallel-editor-notice';conflictNotice.hidden=true;conflictNotice.setAttribute('role','status');$('.project-heading').after(conflictNotice);
  // A duplicated browser tab can inherit sessionStorage: give every live page its own key.
  const windowId=id();
  sessionStorage.setItem('studio-window-id',windowId);
  let draftWarning=false, adoptedDraftKey=null,lastHealthAt=0,lastHealth={jobs:null,recovery_issues:[]};
  const serviceBanner=document.createElement('div');serviceBanner.className='service-health';serviceBanner.id='service-health';serviceBanner.style.display='none';serviceBanner.setAttribute('role','status');$('header').after(serviceBanner);
  function showHealth(update){
    lastHealth={...lastHealth,...update};
    const messages=StudioSafety.healthMessages(lastHealth);
    serviceBanner.style.display=messages.length?'block':'none';
    serviceBanner.innerHTML=messages.map(message=>`<div>${esc(message)}</div>`).join('')+(messages.length?'<button id="health-details">查看服务 / 恢复记录</button>':'');
    if(messages.length)$('#health-details').onclick=()=>modal(`<h2>服务与恢复记录</h2><p>异常记录不会被隐藏为正常完成。请先保留草稿和工程；不要手动删除恢复目录。</p><pre class="health-detail">${esc(JSON.stringify(lastHealth,null,2))}</pre>`);
  }
  refreshBoot=async function(){await original.refreshBoot();showHealth({recovery_issues:boot.recovery_issues||[]})};

  function draftKey(pid) { return StudioSafety.draftKey(pid,windowId); }
  function persistDraft() {
    if(!p || dirty<=saved)return true;
    try {
      localStorage.setItem(draftKey(p.id),JSON.stringify({project:copy(p),saved_at:Date.now(),window_id:windowId}));
      return true;
    } catch(e) {
      if(!draftWarning)toast('浏览器草稿空间不足，尚未保存的修改请先下载备份；不要关闭窗口。',true);
      draftWarning=true;return false;
    }
  }
  function removeOwnDraft(pid) {try{localStorage.removeItem(draftKey(pid))}catch(e){}}
  function findDraft(pid) {
    const rows=[];
    try {
      for(let n=0;n<localStorage.length;n++){
        const key=localStorage.key(n);
        if(key?.startsWith(`studio-draft:${pid}:`)){
          try{const row=JSON.parse(localStorage.getItem(key));if(row.project?.id===pid)rows.push({...row,key})}catch(e){}
        }
      }
    }catch(e){}
    return rows.sort((a,b)=>b.saved_at-a.saved_at)[0];
  }
  function exportDraft(project=p) {download(new Blob([JSON.stringify(project,null,2)],{type:'application/json'}),(project?.name||'工程')+'-未保存草稿.json')}
  function conflictDialog(message) {
    const pid=p?.id;
    conflictNotice.hidden=false;
    conflictNotice.innerHTML=`<span>${esc(message)}。可继续编辑，修改已保留为本地草稿；处理冲突后再写入共同工程。</span><div><button id="draft-download">下载草稿备份</button><button id="conflict-reload">读取本机保存版并比较</button></div>`;
    $('#draft-download').onclick=()=>exportDraft();
    $('#conflict-reload').onclick=handle(async()=>{await openProject(pid,{skipSave:true})});
  }
  function offerDraft(row) {
    if(!row||!p)return;
    const pid=p.id, snapshot=copy(row.project);
    modal(`<h2>发现本集的未保存草稿</h2><p>草稿基于修订 ${snapshot.revision}，本机保存版为修订 ${p.revision}。当前暂时显示本机保存版。草稿不会自动覆盖新版本。</p><div class="modal-actions"><button id="recover-download">下载草稿</button><button id="recover-server">保留本机保存版</button><button id="recover-local" class="primary">恢复草稿为待保存修改</button></div>`);
    $('#recover-download').onclick=()=>exportDraft(snapshot);
    $('#recover-server').onclick=()=>$('#modal').close();
    $('#recover-local').onclick=handle(()=>{
      if(p?.id!==pid)throw Error('当前工程已切换，请重新打开草稿');
      if(!confirm('恢复后会替换当前编辑区内容。保存时将建立历史版本，但其他窗口的新增修改需要你先核对。继续恢复？'))return;
      remember();
      const next={...copy(snapshot),assets:copy(p.assets),revision:p.revision,reviews:{}};
      const available=new Set(next.assets.map(a=>a.id));
      if([...next.clips,...next.audios,...next.protected_lines].some(c=>!available.has(c.asset_id)))throw Error('草稿引用的素材不在当前工程中，请先下载备份，不自动覆盖');
      p=next;adoptedDraftKey=row.key;dirty++;persistDraft();$('#save-status').textContent='已恢复草稿 · 请核对后保存';
      $('#modal').close();render();
    });
  }
  function lockEditing(value) {
    loading=value;
    $('main').inert=value;
    $('#save-button').disabled=value;$('#export-button').disabled=value;
  }
  function refreshMeta() {
    if(!p)return;
    $('#project-meta').textContent=`${p.width} × ${p.height} · ${p.fps} fps · ${time(total())} · ${p.captions.length} 条字幕`;
    $('#duration').textContent=time(total()).slice(0,5);$('#seek').max=total()||1;
    $('#footer-left').textContent=`${p.clips.length} 个画面片段 · ${p.audios.length} 条附加音频 · 修订 ${p.revision}`;
  }
  mark=function(sound=false,metadataOnly=false){
    original.mark(sound);if(!metadataOnly)p.reviews={};persistDraft();refreshMeta();
    if(!metadataOnly&&previewJob?.result?.captions_burned)$('#preview-label').textContent='旧版烧录结果 · 修改后需重新导出';
    if(sound){$('#preview-note').textContent='当前声音/镜头已改变，旧字幕同步依据失效。请重生成最终混音并逐条复核。'}
  };
  save=async function(){
    clearTimeout(timer);
    if(operation){await operation;return save()}
    if(saving){await saving;if(dirty>saved)return save();return}
    if(!p||dirty<=saved)return;
    if(saveBlocked)throw Error('请先处理本机版本冲突；你的修改已保留在草稿中');
    persistDraft();
    const pid=p.id;
    // Hold the lock through acknowledgement, including a single safe reconciliation.
    saving=(async()=>{
      let count=dirty,body=copy(p),result;
      try{
        try{result=await api('/api/projects/'+pid,body)}
        catch(error){
          if(!/另一窗口|版本|工程已/.test(error.message))throw error;
          const remote=await api('/api/projects/'+pid);
          if(p?.id!==pid)throw error;
          const merged=StudioSafety.reconcile(acknowledged,p,remote);
          if(merged.conflicts.length)throw error;
          // Never bypass the backend's revision check; retry against the fetched revision.
          p=merged.project;count=dirty;body=copy(p);
          result=await api('/api/projects/'+pid,body);
        }
        if(p?.id===pid){
          acknowledged=copy(result);p.revision=result.revision;
          // A native save returns a normalized project. Update the live object graph
          // without replacing it so focused controls keep editing the current cue,
          // rather than a detached pre-save object captured by their handlers.
          if(dirty===count&&result.native?.shared)StudioSafety.updateInPlace(p,result);
          if(dirty===count)p.reviews=result.reviews;
          saved=count;
          if(dirty<=saved){removeOwnDraft(pid);if(adoptedDraftKey){try{localStorage.removeItem(adoptedDraftKey)}catch(_){}adoptedDraftKey=null}}else persistDraft();
          $('#save-status').textContent=dirty>saved?'仍有修改 · 正在保存':'已保存到本机';refreshMeta();
          const summary=boot.projects?.find(row=>row.id===pid);
          if(summary)Object.assign(summary,{name:p.name,series:p.series,clips:p.clips.length,captions:p.captions.length});
          renderProjects();
        }
      }catch(error){
        persistDraft();$('#save-status').textContent='尚未保存 · 本机草稿已保留';
        if(/另一窗口|版本|工程已/.test(error.message)&&!saveBlocked){saveBlocked=true;conflictDialog(error.message)}
        throw error;
      }
    })();
    try{await saving}finally{saving=null}
    if(dirty>saved)return save();
  };
  openProject=async function(pid,options={}){
    const ticket=gate.begin();lockEditing(true);
    try{
      if(!options.skipSave){try{await save()}catch(e){if(!persistDraft())throw e;toast('未保存修改已保留在本地草稿；可稍后回本集恢复。',true)}}
      if(!gate.current(ticket))return;
      const next=await api('/api/projects/'+pid);
      if(!gate.current(ticket))return;
      if(next.archived)throw Error('这个工程已在回收站，请先恢复后再打开');
      p=next;acknowledged=copy(next);saveBlocked=false;conflictNotice.hidden=true;dirty=saved=0;selected=p.captions[0]?.id;undo=[];textSession=null;adoptedDraftKey=null;
      previewJob=null;peaks=null;qa=null;
      $('#video').pause();$('#video').removeAttribute('src');$('#video').load();
      $('#caption-overlay').style.display='block';$('#caption-overlay').textContent='';
      $('#stage-placeholder').style.display='flex';$('#preview-label').textContent='尚未生成';
      $('#project-name').value=p.name;$('#save-status').textContent='已保存到本机';
      await refreshQA();if(!gate.current(ticket))return;
      renderProjects();render();drawWave();offerDraft(findDraft(pid));
    }finally{if(gate.current(ticket))lockEditing(false)}
  };
  refreshQA=async function(){
    if(!p)return;const pid=p.id,result=await api(`/api/projects/${pid}/quality`);
    if(p?.id===pid){qa=result;$('#qa-count').textContent=qa.issues.length}
  };
  async function mutate(action,body={},rememberBefore=true){
    await save();
    if(operation){await operation;return mutate(action,body,rememberBefore)}
    if(!p)throw Error('请先打开工程');
    const base=copy(p),pid=p.id,count=dirty;
    if(rememberBefore)remember();
    const pending=api(`/api/projects/${pid}/${action}`,{...body,revision:p.revision});
    operation=pending;
    try{
      const result=await pending;
      if(p?.id!==pid)throw Error('工程已经切换，处理结果已保存在原工程，没有覆盖当前工程');
      const merged=StudioSafety.mergeResult(base,p,result);p=merged.project;acknowledged=copy(result);
      if(dirty!==count||merged.preserved.length){
        if(dirty<=saved)dirty++;persistDraft();
        toast('处理期间的新输入已保留；同时修改的字段以你的新输入为准。');
      }else{removeOwnDraft(pid);$('#save-status').textContent='已保存到本机'}
      render();return result;
    }catch(e){persistDraft();throw e}
    finally{if(operation===pending)operation=null;if(dirty>saved)timer=setTimeout(()=>save().catch(e=>toast(e.message,true)),600)}
  }
  function startTextSession(cueId){
    const key=`${p?.id}:${cueId}`;
    if(textSession!==key){remember();textSession=key}
  }
  renderCaptions=function(){
    if(p)p.captions.sort((a,b)=>a.start-b.start);
    original.renderCaptions();
    $('#wrap-all').onclick=handle(async()=>{await mutate('wrap');toast('已断行；可撤销，字号保持不变')});
  };
  renderInspector=function(){
    original.renderInspector();if(!p)return;
    const cue=currentCue();
    const st=StudioSafety.effectiveStyle(p,cue,tab);
    const extra=document.createElement('div');extra.className='extra-style-controls';
    extra.innerHTML=`<div class="row"><div><label>阴影角度 °</label><input data-extra-style="shadow_angle" type="number" min="-180" max="180" step="1" value="${st.shadow_angle??45}"></div><div><label>阴影模糊 / 1080画布像素</label><input data-extra-style="shadow_blur" type="number" min="0" max="30" step=".5" value="${st.shadow_blur??0}"></div></div><label>额外行间距 / 1080画布像素</label><input data-extra-style="line_spacing" type="number" min="0" max="100" step="1" value="${st.line_spacing??0}"><div class="row"><div><label>整体不透明度 0–1</label><input data-extra-style="opacity" type="number" min="0" max="1" step=".05" value="${st.opacity??1}"></div><div><label>描边不透明度 0–1</label><input data-extra-style="outline_opacity" type="number" min="0" max="1" step=".05" value="${st.outline_opacity??1}"></div></div>`;
    $('#inspector').append(extra);
    extra.querySelectorAll('[data-extra-style]').forEach(el=>el.onchange=()=>{remember();const target=tab==='captions'&&cue&&Object.keys(cue.style||{}).length?cue.style:p.style;target[el.dataset.extraStyle]=Number(el.value);mark();updateOverlay()});
    $('#export-srt').onclick=()=>download(new Blob(['\ufeff'+StudioSafety.srt(p.captions)],{type:'text/plain;charset=utf-8'}),p.name+'.srt');
    if(cue&&tab==='captions'){
      const textInput=$('#cue-text'),oldText=textInput.oninput;
      textInput.onfocus=()=>{textSession=null};textInput.onblur=()=>{textSession=null};
      textInput.oninput=e=>{startTextSession(cue.id);delete cue.speech;oldText(e);persistDraft()};
      for(const key of ['cue-start','cue-end','in-now','out-now']){
        const el=$('#'+key),event=key.includes('now')?'onclick':'onchange',old=el[event];
        el[event]=e=>{delete cue.speech;old(e);persistDraft()};
      }
      const section=document.createElement('div');section.className='speech-confirm';
      section.innerHTML='<hr class="section-break"><h3>按实际声音确认本句</h3><p class="helper">先播放当前最终混音，再填写真实发声范围。这里不把字幕时间当成声音检测结果。</p><div class="row"><div><label>实际发声起点 / 秒</label><input id="voice-start" type="number" min="0" step=".001" placeholder="请试听后填写"></div><div><label>实际发声终点 / 秒</label><input id="voice-end" type="number" min="0" step=".001" placeholder="请试听后填写"></div></div><div class="toolbar"><button id="voice-in-now">发声起点=播放头</button><button id="voice-out-now">发声终点=播放头</button></div><label><input id="voice-listened" type="checkbox"> 我已实际试听当前版本并核对本句</label><button id="confirm-cue" class="wide accent">确认这条字幕的声音依据</button><p id="voice-evidence" class="helper"></p>';
      $('#inspector').append(section);
      $('#voice-evidence').textContent=cue.speech?.method==='manual_verified'?'存在人工时间依据；修改声音或本句文字/时间后需重新确认。':'尚未人工确认；ASR只是识别草稿。';
      $('#voice-in-now').onclick=()=>{$('#voice-start').value=playbackTime().toFixed(3)};
      $('#voice-out-now').onclick=()=>{$('#voice-end').value=playbackTime().toFixed(3)};
      $('#confirm-cue').onclick=handle(async()=>{
        const range=StudioSafety.voiceRange($('#voice-start').value,$('#voice-end').value);
        if(!$('#voice-listened').checked)throw Error('请先实际试听并勾选本句确认');
        if(!previewJob?.id)throw Error('请先生成并打开当前最终混音预览');
        const renderId=previewJob.id,cueId=cue.id,pid=p.id,signature=JSON.stringify(cue);
        await save();await refreshQA();
        const detail=await api('/api/jobs/'+renderId);
        if(p?.id!==pid||detail.project_id!==pid||detail.state!=='complete'||!detail.result?.file||detail.result.sound_digest!==qa?.sound_hash)throw Error('当前播放器不是这一版最终混音，请重新生成并试听');
        if(JSON.stringify(p.captions.find(c=>c.id===cueId))!==signature)throw Error('确认期间本句已经改变，请重新试听核对后确认');
        await mutate('confirm-cue',{cue_id:cueId,render_id:renderId,...range,confirmed:true});
        await refreshQA();toast('已保存这句的人工发声依据；不代表全片自动验收');
      });
    }
  };
  function streamControl(assetId,value,onChange){
    const source=asset(assetId),streams=source?.audio_streams||[];
    if(streams.length<2)return null;
    const wrap=document.createElement('div');wrap.className='audio-stream-select';
    const choice=Number.isInteger(value)?String(value):'';
    wrap.innerHTML=`<label>音轨选择（多音轨素材必须明确选择）</label><select><option value="">请选择，不自动猜测</option>${streams.map(s=>`<option value="${s.index}" ${choice===String(s.index)?'selected':''}>音轨 ${s.index} · ${esc(s.language||'未知语言')} ${esc(s.title||'')} · ${s.channels||'?'}声道</option>`).join('')}</select>`;
    wrap.querySelector('select').onchange=e=>onChange(e.target.value===''?null:Number(e.target.value));return wrap;
  }
  renderClips=function(){original.renderClips();if(!p)return;
    p.clips.forEach(c=>{const anchor=$(`[data-remove-clip="${c.id}"]`)?.closest('.card');
      const control=c.audio_detached?null:streamControl(c.asset_id,c.audio_stream,value=>{remember();if(value===null)delete c.audio_stream;else c.audio_stream=value;mark(true)});
      if(anchor&&control)anchor.append(control);
      if(anchor){
        const relation=studioAudioRelation(p,{kind:'video',id:c.id});
        const gain=anchor.querySelector('[data-key="gain"]');
        if(c.audio_detached){if(gain)gain.disabled=true;const note=document.createElement('p');note.className='helper';note.textContent=relation.detail+' 请在对应声音轨调整音量。';anchor.append(note)}
        const button=document.createElement('button');button.textContent=c.audio_detached?(relation.state==='linked'?'已分轨 · 仍联动':'画面已独立'):'分离音频';button.dataset.detachClip=c.id;button.disabled=!!c.audio_detached||!asset(c.asset_id)?.has_audio;
        button.onclick=handle(()=>window.studioDetachAudio(c.id));anchor.querySelector('.card-actions').append(button);
      }

    });
    $$('[data-clip]').forEach(input=>{const old=input.onchange;input.onchange=e=>{old(e);const clip=p.clips.find(c=>c.id===input.dataset.clip),small=input.closest('.card')?.querySelector('small');if(small&&clip)small.textContent=`${(clip.out-clip.in).toFixed(2)}s · ${asset(clip.asset_id)?.fps.toFixed(2)} fps`;refreshMeta()}});
    const refresh=document.createElement('button');refresh.textContent='素材已替换？更新登记';refresh.className='wide ghost';
    $('#panel').append(refresh);
    const relink=document.createElement('button');relink.id='panel-relink-media';relink.textContent='素材丢失 / 换路径？重连素材';relink.className='wide ghost';
    relink.onclick=handle(()=>window.studioMediaRelink.open());$('#panel').append(relink);
    refresh.onclick=()=>{
      modal(`<h2>更新已替换的源文件</h2><p>仅选择你已在磁盘上替换的文件。会更新素材校验值并使旧混音/字幕依据失效；不自动缩短时间线。新时长不足时会拒绝，保留原工程。</p><div class="asset-refresh-list">${p.assets.map(a=>`<label class="review-line"><input type="checkbox" data-refresh-asset="${a.id}">${esc(a.name)}<small>${esc(a.path)}</small></label>`).join('')}</div><div class="modal-actions"><button id="refresh-assets-ok" class="primary">重新读取选中的文件</button></div>`);
      $('#refresh-assets-ok').onclick=handle(async()=>{const asset_ids=$$('[data-refresh-asset]:checked').map(b=>b.dataset.refreshAsset);if(!asset_ids.length)throw Error('请勾选实际替换过的素材');if(!confirm('确认这些源文件已由你替换？更新后需要重新生成混音并复核字幕。'))return;$('#refresh-assets-ok').disabled=true;try{await mutate('refresh-assets',{asset_ids,confirmed:true});$('#modal').close();await refreshQA();toast('素材登记已更新，请重新生成混音并确认字幕')}catch(e){$('#refresh-assets-ok').disabled=false;throw e}});
    };
  };
  renderAudio=function(){original.renderAudio();if(!p)return;
    p.audios.forEach(a=>{const anchor=$(`[data-remove-audio="${a.id}"]`)?.closest('.card');
      const relation=studioAudioRelation(p,{kind:a.role,id:a.id});
      if(anchor&&relation){const note=document.createElement('p');note.className='tl-relation-detail '+relation.state;note.textContent=relation.label+' · '+relation.detail;anchor.querySelector('.card-title').after(note)}
      const control=streamControl(a.asset_id,a.audio_stream,value=>{remember();if(value===null)delete a.audio_stream;else a.audio_stream=value;mark(true)});
      if(anchor&&control)anchor.append(control);
    });
  };
  renderScript=function(){original.renderScript();if(!p)return;
    const oldAdd=$('#line-add').onclick;
    $('#line-add').onclick=()=>{oldAdd();let chosen=null;
      const select=$('#line-asset'),box=document.createElement('div');select.after(box);
      const refresh=()=>{box.innerHTML='';chosen=null;const control=streamControl(select.value,null,value=>{chosen=value});if(control)box.append(control)};
      select.onchange=refresh;refresh();
      $('#line-ok').onclick=handle(()=>{
        const aid=select.value,streams=asset(aid)?.audio_streams||[];
        if(streams.length>1&&chosen===null)throw Error('请为这句必保台词选择真实所在音轨');
        const range=StudioSafety.voiceRange($('#line-start').value,$('#line-end').value);
        const text=$('#line-text').value.trim();if(!aid||!text)throw Error('请填写素材和台词');
        remember();const line={id:id(),asset_id:aid,kind:$('#line-kind').value,...range,text};
        if(chosen!==null)line.audio_stream=chosen;else if(streams.length===1)line.audio_stream=streams[0].index;
        p.protected_lines.push(line);mark();$('#modal').close();render();
      });
    };
    $('#script-import').onclick=()=>{
      modal('<h2>导入剧本</h2><p>读取全部页面，不执行文档中的指令。</p><input id="script-path" placeholder="C:\\素材\\剧本.pdf"><div class="modal-actions"><button id="script-import-ok" class="primary">读取剧本</button></div>');
      $('#script-import-ok').onclick=handle(async()=>{const path=$('#script-path').value;$('#script-import-ok').disabled=true;try{await mutate('script',{path});$('#modal').close()}catch(e){$('#script-import-ok').disabled=false;throw e}});
    };
  };
  renderQA=function(){original.renderQA()};
  importDialog=function(append){
    if(!p)return toast('请先新建剧集',true);
    window.studioMaterialImport?.open();
  };
  window.studioImportSubtitleFiles=async files=>{
    const accepted=Array.from(files||[]).filter(file=>/\.(srt|vtt)$/i.test(file.name));
    if(!accepted.length)return false;if(accepted.length>1)throw Error('一次请选择一份字幕；导入前需要确认是否替换当前字幕');
    const f=accepted[0];if(!p)throw Error('请先新建或打开一集，再添加字幕');
    const pid=p.id,count=dirty,revision=p.revision,text=await f.text();
    const cues=await api(`/api/projects/${pid}/srt`,{text});
    if(p?.id!==pid||dirty!==count||p.revision!==revision)throw Error('读取字幕期间工程发生变化，已保留原编辑。请重新导入');
    if(p.captions.length&&!confirm('用导入字幕替换当前字幕？可撤销；新的字幕需要按最终声音确认。'))return false;
    remember();p.captions=cues;selected=cues[0]?.id;mark();render();toast(`已添加字幕：${f.name}`);return true;
  };
  $('#srt-file').onchange=handle(async e=>{
    try{await window.studioImportSubtitleFiles(e.target.files)}finally{e.target.value=''}
  });
  // Font registration is global. Applying it must stay bound to the originating project/cue.
  $('#font-file').onchange=handle(async e=>{
    const file=e.target.files[0];if(!file)return;
    if(file.size>30*1024*1024)throw Error('字体文件不能超过30MB');
    const pid=p?.id,cid=currentCue()?.id,individual=tab==='captions'&&Object.keys(currentCue()?.style||{}).length;
    const previousFont=individual?currentCue()?.style.font_id:p?.style.font_id;
    const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=reject;reader.readAsDataURL(file)});
    const font=await api('/api/fonts',{name:file.name,data});await refreshBoot();
    if(p&&p.id===pid){const cue=p.captions.find(c=>c.id===cid),currentFont=individual?cue?.style.font_id:p.style.font_id;
      if(currentFont!==previousFont){toast('字体已加入字体库；你已更换字体选择，因此没有覆盖当前样式。');e.target.value='';return}
      remember();if(individual&&cue)cue.style.font_id=font.id;else p.style.font_id=font.id;mark();renderInspector();updateOverlay()}
    toast('字体已加入字体库'+(p?.id!==pid?'；工程已切换，没有更改当前字幕':'：'+font.name));e.target.value='';
  });
  viewRender=async function(job){
    const origin=p?.id;
    const detail=await api('/api/jobs/'+job.id);
    if(p?.id!==origin)return;
    if(detail.state!=='complete'||!detail.result?.file)throw Error('渲染尚未完成');
    await original.viewRender(detail);
  };
  pollJobs=async function(){
    try{await original.pollJobs();showHealth({connection_error:null})}
    catch(e){showHealth({connection_error:e.message});throw e}
    const cards=$$('#jobs .job');
    jobs.slice(0,30).forEach((job,index)=>{
      if(!cards[index]||!['failed','cancelled','interrupted'].includes(job.state))return;
      const retry=document.createElement('button');retry.textContent='重试原版本';retry.title='重试这次任务的原始快照；如需使用当前编辑，请重新提交';
      retry.onclick=handle(async()=>{retry.disabled=true;try{await api(`/api/jobs/${job.id}/retry`,{});toast('已用原始版本重新排队；没有替换为当前编辑');await pollJobs()}catch(e){retry.disabled=false;throw e}});cards[index].append(retry);
    });
    if(Date.now()-lastHealthAt>=20000){lastHealthAt=Date.now();try{const health=await api('/api/health');showHealth({...health,connection_error:null});if(Number.isFinite(health.jobs?.pending))$('#job-count').textContent=health.jobs.pending}catch(e){showHealth({connection_error:e.message})}}
  };
  updateOverlay=function(frameTime){original.updateOverlay(frameTime)};
  function tick(now,metadata){
    if($('#video').paused||$('#video').ended){frameHandle=null;return}
    const displayedTime=Number.isFinite(metadata?.mediaTime)?metadata.mediaTime:$('#video').currentTime;
    updateOverlay(displayedTime);$('#timecode').textContent=time(displayedTime);$('#seek').value=displayedTime;
    if(typeof $('#video').requestVideoFrameCallback==='function'){frameKind='video';frameHandle=$('#video').requestVideoFrameCallback(tick)}
    else{frameKind='animation';frameHandle=requestAnimationFrame(tick)}
  }
  function stopTick(){if(frameHandle!==null){if(frameKind==='video')$('#video').cancelVideoFrameCallback(frameHandle);else cancelAnimationFrame(frameHandle)}frameHandle=null;updateOverlay()}
  $('#video').addEventListener('play',()=>{stopTick();tick()});$('#video').addEventListener('pause',stopTick);$('#video').addEventListener('ended',stopTick);$('#video').addEventListener('seeked',()=>updateOverlay());
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')persistDraft()});
  window.addEventListener('pagehide',persistDraft);
  // Make per-cue buttons work with the compact job summaries returned by the server.
  window.studioApplyASR=async function(jobId){
    const j=await api('/api/jobs/'+jobId);
    if(!p||p.id!==j.project_id)throw Error('请先打开对应剧集');
    await save();await refreshQA();
    if(j.result?.sound_digest!==qa.sound_hash)throw Error('声音或镜头已变化，请按当前混音重新识别');
    if(!j.result?.captions?.length)throw Error('未识别到有效字幕；不覆盖现有字幕');
    if(!confirm('用识别草稿替换现有字幕？识别不是翻译，也不能代替实际试听逐条确认。'))return;
    remember();p.captions=copy(j.result.captions);selected=p.captions[0]?.id;mark();render();
  };
  window.studioDetachAudio=async clipId=>{
    if(!p)throw Error('请先打开工程');
    if(window.StudioTimelineUI?.canDetach&&!StudioTimelineUI.canDetach())throw Error('画面或联动原声轨已锁定，请先解锁');
    const pid=p.id,known=new Set(p.audios.map(a=>a.id)),sidebar=document.querySelector('.sidebar'),wasInert=sidebar.inert;
    // Detach atomically changes both the clip and independent audio list.
    lockEditing(true);sidebar.inert=true;
    try{
      await mutate('detach-audio',{clip_id:clipId});
      if(p?.id!==pid)return;
      const audio=p.audios.find(a=>a.role==='dialogue'&&a.detached_from===clipId&&!known.has(a.id));
      if(audio){window.StudioTimelineUI?.select('dialogue',audio.id,false);document.querySelector(`[data-tl-kind="dialogue"][data-tl-id="${audio.id}"]`)?.scrollIntoView({block:'nearest',inline:'nearest'})}
      await refreshQA();toast('原声已分离，可独立移动、裁剪和调音量；画面不会重复播放原声，可撤销恢复');
    }finally{sidebar.inert=wasInert;lockEditing(false)}
  };
  // Exposed only as read-only testable helpers; no local file/network operation here.
  window.studioDraftBackup=()=>exportDraft();
  window.studioProjectHooks={
    adopt(project){
      p=project;acknowledged=copy(project);saveBlocked=false;conflictNotice.hidden=true;dirty=saved=0;
      const summary=boot.projects?.find(row=>row.id===project.id);if(summary)Object.assign(summary,{name:project.name,series:project.series,clips:project.clips.length,audios:project.audios.length,captions:project.captions.length});
      removeOwnDraft(project.id);$('#save-status').textContent='已保存到本机';refreshMeta();
    },
    mutate,
    persistDraft,
    async transaction(work,options={}){
      if(!options.skipSave)await save();else if(saving)await saving;
      if(operation){await operation;return this.transaction(work,options)}
      // Reserve the mutation slot before invoking asynchronous work.
      const pending=Promise.resolve().then(work);operation=pending;
      try{return await pending}finally{if(operation===pending)operation=null}
    },
    detach(pid){
      if(p?.id!==pid)return;
      persistDraft();gate.begin();clearTimeout(timer);lockEditing(false);
      p=null;acknowledged=null;saveBlocked=false;conflictNotice.hidden=true;dirty=saved=0;selected=null;undo=[];previewJob=null;waitingPreview=null;peaks=null;qa=null;adoptedDraftKey=null;textSession=null;
      $('#video').pause();$('#video').removeAttribute('src');$('#video').load();
      $('#stage-placeholder').style.display='flex';$('#caption-overlay').textContent='';$('#caption-overlay').style.display='block';
      $('#preview-label').textContent='尚未生成';$('#project-name').value='';$('#project-meta').textContent='创建或打开一个剧本 / 剧集';
      $('#timecode').textContent='00:00.000';$('#duration').textContent='00:00';$('#seek').value=0;$('#seek').max=1;$('#qa-count').textContent='';
      $('#inspector').innerHTML='<p class="helper">请先新建或打开剧本 / 剧集。</p>';$('#save-status').textContent='工程已移至回收站';$('#footer-left').textContent='原素材未删除，可从回收站恢复';
      renderProjects();render();drawWave();
    }
  };
}
