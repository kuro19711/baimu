'use strict';
// Layout preferences are per device. They never change the episode or its review hash.
(() => {
  const key = 'studio-layout-v2';
  const defaults = {sidebar:148, edit:300, inspector:285, timeline:300};
  let prefs;
  try {
    const saved=JSON.parse(localStorage.getItem(key)||'null');
    const legacy=JSON.parse(localStorage.getItem('studio-layout-v1')||'null');
    prefs=saved?{...defaults,...saved}:{...defaults,...legacy,sidebar:defaults.sidebar};
  }
  catch (_) { prefs = {...defaults}; }
  for (const k of Object.keys(defaults)) if (!Number.isFinite(prefs[k])) prefs[k]=defaults[k];
  const app=document.querySelector('.app-layout'), workspace=document.querySelector('.workspace');
  const main=document.querySelector('main'), timeline=document.querySelector('#timeline');
  document.body.classList.add('resizable-layout');
  let drag=null;
  const clamp=(n,min,max)=>Math.min(Math.max(n,min),Math.max(min,max));
  const actual=name=>document.querySelector({sidebar:'.sidebar',edit:'.edit-panel',inspector:'.inspector',timeline:'#timeline'}[name]).getBoundingClientRect()[name==='timeline'?'height':'width'];
  function apply(){
    const width=app.clientWidth, height=main.clientHeight;
    const side=clamp(prefs.sidebar,124,Math.min(260,width*.22));
    const available=width-side-6;
    const edit=clamp(prefs.edit,190,Math.max(190,available-455));
    const inspector=clamp(prefs.inspector,220,Math.max(220,available-edit-235));
    app.style.setProperty('--sidebar-width',side+'px');
    workspace.style.setProperty('--edit-width',edit+'px');
    workspace.style.setProperty('--inspector-width',inspector+'px');
    const fixed=[...main.children].filter(n=>!n.matches('.workspace,#timeline,.layout-divider')).reduce((s,n)=>s+n.getBoundingClientRect().height,0);
    main.style.setProperty('--timeline-height',clamp(prefs.timeline,125,height-fixed-285)+'px');
  }
  function store(){try{localStorage.setItem(key,JSON.stringify(prefs))}catch(_){}}
  function separator(name,label,orientation,parent,before){
    const el=document.createElement('div');el.className='layout-divider divider-'+name;
    el.tabIndex=0;el.role='separator';el.title=label+'：拖动调整，双击恢复；方向键微调';
    el.setAttribute('aria-label',label);el.setAttribute('aria-orientation',orientation);
    el.dataset.panel=name;parent.insertBefore(el,before);
    el.addEventListener('pointerdown',event=>{
      if(event.button!==0||matchMedia('(max-width: 1000px)').matches)return;
      drag={name,startX:event.clientX,startY:event.clientY,initial:actual(name),before:{...prefs},pointer:event.pointerId,el};
      el.focus({preventScroll:true});
      el.setPointerCapture(event.pointerId);document.body.classList.add('resizing-panels');
      document.body.style.cursor=orientation==='vertical'?'col-resize':'row-resize';event.preventDefault();
    });
    el.addEventListener('pointermove',event=>{
      if(!drag||drag.el!==el||event.pointerId!==drag.pointer)return;
      const delta=orientation==='vertical'?event.clientX-drag.startX:event.clientY-drag.startY;
      prefs[name]=drag.initial+delta*(['inspector','timeline'].includes(name)?-1:1);apply();
    });
    function end(cancel=false){
      if(!drag||drag.el!==el)return;
      const current=drag;drag=null;
      if(cancel)prefs=current.before;
      if(el.hasPointerCapture(current.pointer))el.releasePointerCapture(current.pointer);
      document.body.classList.remove('resizing-panels');document.body.style.cursor='';
      apply();store();window.dispatchEvent(new Event('resize'));
    }
    el.addEventListener('pointerup',()=>end());el.addEventListener('pointercancel',()=>end(true));
    el.addEventListener('keydown',event=>{
      if(event.key==='Escape'){end(true);return;}
      const arrows=orientation==='vertical'?['ArrowLeft','ArrowRight']:['ArrowUp','ArrowDown'];
      if(!arrows.includes(event.key))return;
      event.preventDefault();prefs[name]=actual(name)+(event.key===arrows[0]?-16:16)*(['inspector','timeline'].includes(name)?-1:1);apply();store();
    });
    el.addEventListener('dblclick',()=>{prefs[name]=defaults[name];apply();store()});
  }
  separator('sidebar','剧集列表宽度','vertical',app,main);
  separator('edit','编辑区与预览区宽度','vertical',workspace,document.querySelector('.viewer-panel'));
  separator('inspector','属性区宽度','vertical',workspace,document.querySelector('.inspector'));
  separator('timeline','预览与时间线高度','horizontal',main,timeline);
  const reset=document.createElement('button');reset.id='layout-reset';reset.textContent='重置布局';reset.title='恢复各区块的默认大小';
  document.querySelector('.top-actions').insertBefore(reset,document.querySelector('#settings-button'));
  reset.onclick=()=>{prefs={...defaults};apply();store()};
  const tag=document.querySelector('.local');if(tag){
    tag.textContent='本机存储';tag.title='查看工程和导出的实际保存位置';tag.tabIndex=0;tag.role='button';
    function showStorage(){
      modal(`<h2>这台电脑的存储</h2><p>工程、历史、素材库、字体与导出保存在本机，没有云端工程或跨电脑同步。</p><label>工程数据目录</label><pre class="storage-path">${esc(boot.data_dir||'正在读取…')}</pre><p>projects：工程与历史版本；imports：拖入后复制的素材；renders：导出视频与质检报告。</p><p>“路径导入”引用原文件，不复制。浏览器或桌面窗口里的草稿只是临时备份，不能代替保存工程。</p><p>桌面窗口与浏览器共用已保存工程，但各自的未保存草稿独立。换入口前请先保存。</p><div class="modal-actions"><button id="storage-copy">复制数据目录</button>${window.chrome?.webview?'<button id="storage-browser">打开浏览器入口</button><button id="storage-open" class="primary">打开工程文件夹</button>':''}</div>`);
      document.querySelector('#storage-copy').onclick=handle(async()=>{await navigator.clipboard.writeText(boot.data_dir);toast('已复制本机数据目录')});
      const browser=document.querySelector('#storage-browser');if(browser)browser.onclick=handle(async()=>{await save();window.chrome.webview.postMessage({type:'open-browser'})});
      const open=document.querySelector('#storage-open');if(open)open.onclick=()=>window.chrome.webview.postMessage({type:'open-data'});
    }
    tag.onclick=showStorage;tag.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();showStorage()}};
  }
  new ResizeObserver(apply).observe(main);
  new ResizeObserver(entries=>{
    const rect=entries[0].contentRect, stage=document.querySelector('#stage');
    stage.style.width=Math.max(0,Math.min(rect.width,rect.height*9/16))+'px';
  }).observe(document.querySelector('.stage-wrap'));
  window.addEventListener('resize',apply);apply();
})();
