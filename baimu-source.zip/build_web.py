"""Build one ordered browser script; avoid a partial multi-script startup."""
from pathlib import Path
root=Path(__file__).resolve().parent/'app'/'web'
names=['hardening.js','project-management.js','script-import.js','txt-captions.js','folder-drop.js',
       'font-preset.js','timeline-model.js','timeline.js','mask-ui.js','library.js',
       'workflow.js','live-editor.js','editor-actions.js','realtime-player.js','native-drafts.js','caption-preview.js','media-relink.js','app.js','layout.js','simple-ui.js','review-rules.js','review-findings.js','updates.js']
text='\n;\n'.join('// Source: '+name+'\n'+(root/name).read_text(encoding='utf-8-sig') for name in names)
(root/'editor-bundle.js').write_text(text,encoding='utf-8')
print('Built editor-bundle.js:',len(text.encode('utf-8')),'bytes')
